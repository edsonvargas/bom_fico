class PymeWrapper(object):

    def __init__(self) -> None:
        self.STEPS_NUMBER_TO_WTP_INTERPOLATE = 12
        self.TEA_MAX_TO_WTP_INTERPOLATE=0.495
        self.TEA_CT_DEFAULT=0.495
        self.TEA_AF_DEFAULT=0.3

        self.columns_outputs = ['Min_Rate',
                'Interest_Income',
                'Cost_of_Funds',
                'NPV',
                'IRR',
                'ROA',
                'ROE',
                'Net_Profit',
                'ECAP',
                'Loss_Rate',
                'Target_IRR',
                'TT',
                'REQUEST_ID',
                'clv_tea',
                'wtp_tea',
                'cluster',
                'wtp_irr',
                'wtp_npv'
        ]

    def __format_default_result(self, clv_input):
        from pandas import DataFrame, RangeIndex

        df = DataFrame(index=RangeIndex(4),columns=self.columns_outputs)
        df['Min_Rate']=self.TEA_CT_DEFAULT if clv_input['TIPO_CLV'][0]=='CT' else self.TEA_AF_DEFAULT
        df['REQUEST_ID'] =clv_input['REQUEST_ID'].replace(to_replace='[A-Za-z]',value='',regex=True)
        df = df.fillna('NaN')
        return df

    def __format_result(self, clv_result, wtp_result):
        from pandas import DataFrame, concat

        wtp_result['TIPO_TIR_OBJETIVO']='TIR_MINIMA'
        df = clv_result
        df['clv_tea']=df['Min_Rate']

        df_result=df.merge(wtp_result[['codclavecic','tea','cluster','TIPO_TIR_OBJETIVO','tir','van_e']],on=['TIPO_TIR_OBJETIVO','codclavecic'],how='left')
        df_result = df_result.drop('codclavecic', axis=1)
        
        df_result['Min_Rate']=df_result.apply(lambda x: x['tea'] if x['tea']>0 else x['Min_Rate'], axis=1)
        df_result['IRR'] = df_result.apply(lambda x: -1 if float(x['IRR']) > 1000 else x['IRR'], axis=1)
        df_result['NPV'] = df_result.apply(lambda x: 0.00 if float(x['NPV']) < 0.0001 else x['NPV'], axis=1)
        df_result['wtp_irr'] = df_result['tir']
        df_result['wtp_npv'] = df_result['van_e']

        df_result=df_result.rename(columns={'tea':'wtp_tea'})

        # formateo del output
        df = DataFrame(columns=self.columns_outputs)
        df_join = concat([df, df_result], join="inner", ignore_index=True)
        df = df._append(df_join)
        df = df.fillna(-1)
        df['REQUEST_ID'] = df['REQUEST_ID'].replace(to_replace='[A-Za-z]',value='',regex=True)
        return df

    def __format_result_clv(self, clv_result):
        from pandas import DataFrame, concat
        
        clv_result['clv_tea']=clv_result['Min_Rate']
        clv_result.loc[clv_result.IRR.astype(float)>1000,'IRR']=-1
        clv_result.loc[clv_result.NPV.astype(float)<0.0001 ,'NPV']=0

        # formateo del output
        df = DataFrame(columns=self.columns_outputs)
        df_join = concat([df, clv_result], join="inner", ignore_index=True)
        df = df._append(df_join)
        df = df.fillna(-1)
        df['REQUEST_ID'] = df['REQUEST_ID'].replace(to_replace='[A-Za-z]',value='',regex=True)
        df['clv_tea']=df['Min_Rate']

        df['IRR'] = df.apply(lambda x: -1 if float(x['IRR']) > 1000 else x['IRR'], axis=1)
        df['NPV'] = df.apply(lambda x: 0.00 if float(x['NPV']) < 0.0001 else x['NPV'], axis=1)
        df['wtp_irr'] = -1
        df['wtp_npv'] = -1

        return df

    def __format_input(self, clv_input, clv_result):
        from pandas import merge, DataFrame

        # clv_input.drop(columns=['tt_fact','tt_fact_soles','tt_fact_dolares'],inplace=True)
        df_clv = merge(clv_input,clv_result,on='REQUEST_ID',how='inner', suffixes=('','_result'))

        def set_format(df_clv_input:DataFrame):
            df = df_clv_input
            df = df[df['TIPO_TIR_OBJETIVO']=='TIR_MINIMA']
            
            # df['tt']=df['TT_result']
            df['Min_Rate'] = df['Min_Rate'].astype(float)
            df['IRR'] = df['IRR'].astype(float)
            df["IRR"].fillna(df['tir_objetivo'])
            df["Tasa_dscto_tea"].fillna(df['tir_objetivo'])

            df['tt']=df['TT_result']
            df['tir']=df['IRR']
            df['codclavecic']=df['IDC_ULTDIGITO']
            df['escenario']=0
            df['ACT_ECO_FIN']=df['SectorEconomico']
            df['FAD_SOL']=df['MontoFAD']
            df['FADSOL']=df['MontoFAD']
            df['FAD']=df['MontoFAD']
            df['ANTIGUEDAD_MESES']=df['NumMesesAntiguedad']
            df['MONTODESEMBOLSADOSOL']=df['MontoSolicitado']
            return df

        
        df_result = set_format(df_clv)
        
        return df_result

    def __format_input_clv_pre_wtp(self, clv_input, clv_result, clv_first_wrapper):
        from pyme_engine.clv_pyme.clv_pyme_wrapper import ClvPymeWrapper
        from pandas import concat, merge, DataFrame
        from numpy import nan,clip,linspace,array,concatenate,maximum,where
        from pyme_engine.wtp_pyme.wtp_engine.WTP_Engine import WTPEngine


        # formateo
        clv_input.drop(columns=['NroDeltaEntidades','RatioEndeudamiento','RatioEndeudamientoU6MU12M','TieneGarantia','TT','tir_objetivo'], inplace=True)
        clv_input.loc[clv_input.DeltaEntidades=='Incrementa','DeltaEntidades']=2
        clv_input.loc[clv_input.DeltaEntidades!='Incrementa','DeltaEntidades']=-1

        # interpolar tasas
        def set_interpolate_old(clv_input, clv_result):

            def get_mensualizar(value):
                return (1 + value)**(1/12) - 1
            
            def get_anualizado(value):
                return pow(1 + value, 12) - 1 

            df_clv = merge(clv_input,clv_result[['REQUEST_ID','Min_Rate']],on='REQUEST_ID',how='inner', suffixes=('','_result'))
            df = df_clv[df_clv['TIPO_TIR_OBJETIVO']=='TIR_MINIMA']
            df['PREVIOUS_INDEX']=df.index

            # replicando la data 
            new_df = concat([df]*int(2*self.STEPS_NUMBER_TO_WTP_INTERPOLATE+1),ignore_index=True)
            new_df['tea']=nan
            
            # seleccionando las tasas
            tea_objetivo = df_clv[df_clv['TIPO_TIR_OBJETIVO']=='TIR_MINIMA']["Min_Rate"].values[0]
            tea_pizarra = df_clv[df_clv['TIPO_TIR_OBJETIVO']=='TIR_PIZARRA']["Min_Rate"].values[0]
            tea_objetivo = tea_objetivo if tea_objetivo<self.TEA_MAX_TO_WTP_INTERPOLATE else self.TEA_MAX_TO_WTP_INTERPOLATE
            techo = get_mensualizar(self.TEA_MAX_TO_WTP_INTERPOLATE)

            # mensualizando
            tea_objetivo = get_mensualizar(tea_objetivo)
            tea_pizarra = get_mensualizar(tea_pizarra)

            # seteando las tasas
            new_df._set_value(0,'tea', tea_pizarra)
            new_df._set_value(self.STEPS_NUMBER_TO_WTP_INTERPOLATE,'tea', tea_objetivo)
            new_df._set_value(self.STEPS_NUMBER_TO_WTP_INTERPOLATE*2,'tea', techo)

            # realizando la interpolacion            
            new_df['tea'] = new_df['tea'].interpolate(method="linear", limit_direction="forward", axis=0)
            new_df['tea'] = get_anualizado(new_df['tea'])
            

            # reasignando datos
            new_df['MontoTasaEspecial']=new_df['tea']*100 #MS 20230920 probando 
            new_df['TasaEspecial'] = new_df['tea']
            new_df['TIR_OBJETIVO']=-1
            new_df['REQ_TYPE']=3
            new_df['REQUEST_ID']=new_df.index+1
            
            return new_df



        def set_interpolate(clv_input, clv_result):
            # Define las constantes de la segunda lógica
            def format_input(df):

                if "pdapplicant_covid" not in df.columns.values:
                    df["pdapplicant_covid"]=df["MontoPD"]
                    
                if "montodesembolsadosol" not in df.columns.values:
                    df["montodesembolsadosol"]=df["MontoSolicitado"]
   
                return df
            
            #### Constantes ####
            NUM_ESCENARIOS = 15  # Debe ser impar
            SIZE_DF = clv_input.shape[0]*NUM_ESCENARIOS
            PISO = 0.10
            TECHO = 0.50
            MOV_PBS_ABAJO_GLOBAL = 300
            MOV_PBS_ARRIBA_C_1_2 = 300
            MOV_PBS_ARRIBA_C_3_4 = 350
            MOV_PBS_ARRIBA_C_5 = 400
            
            df_clv = merge(clv_input,clv_result[['REQUEST_ID','Min_Rate']],on='REQUEST_ID',how='inner', suffixes=('','_result'))

            tmin_tir19 = df_clv[df_clv['TIPO_TIR_OBJETIVO']=='TIR_PIZARRA']["Min_Rate"]
            tea_tir_objetivo_advisory = df_clv[df_clv['TIPO_TIR_OBJETIVO']=='TIR_MINIMA']["Min_Rate"]
            df=df_clv[df_clv['TIPO_TIR_OBJETIVO']=='TIR_MINIMA']
            df["PREVIOUS_INDEX"]=df.index
            #cluster = clv_input["cluster"].values
            engine = WTPEngine()
            format_input(df)
            df["cluster"]= engine.get_cluster(df)
            
            # Ajusta las tasas según las reglas de negocio
            tmin_tir19 = clip(tmin_tir19, PISO, TECHO)
            tea_tir_objetivo_advisory = clip(tea_tir_objetivo_advisory, PISO, TECHO)
            tasa_piso = maximum(tmin_tir19, PISO)

            # Genera escenarios de tasas
            tasas_abajo = linspace(tea_tir_objetivo_advisory - MOV_PBS_ABAJO_GLOBAL / 10_000, tea_tir_objetivo_advisory, num=7,axis=1)
            tasas_arribas = linspace(tea_tir_objetivo_advisory + 0.005, tea_tir_objetivo_advisory + MOV_PBS_ARRIBA_C_5 / 10_000, num=int(MOV_PBS_ARRIBA_C_5 / 50),axis=1)
            tasas_escenarios_vector = concatenate((tasas_abajo, tasas_arribas),axis=1).reshape(-1,)

            # Genera las columnas adicionales para el DataFrame
            num_escenario_vector = array([x for x in range(-6, 8 + 1)]).T.reshape(-1)
            # codclavecic_np_repeated = array([[x]*NUM_ESCENARIOS for x in df_clv['CODCLAVECIC']]).reshape(-1)
            
            # Crea el DataFrame con los escenarios de tasas
            clv_input['PREVIOUS_INDEX']=clv_input.index
            df = df.loc[df.index.repeat(NUM_ESCENARIOS)].reset_index(drop=True)
            # df['CODCLAVECIC'] = codclavecic_np_repeated
            df['tea'] = tasas_escenarios_vector
            df['Escenario'] = num_escenario_vector
            
            # Filtrando los escenarios que cumplen con las condiciones predefinidas
            cluster = df["cluster"].values
            df_reglas_de_negocio = df[["REQUEST_ID"]]
            df_reglas_de_negocio["Escenario"] = df["Escenario"]
            df_reglas_de_negocio["tasa_clv"] = tea_tir_objetivo_advisory.values[0]
            df_reglas_de_negocio["tasa_piso"] = maximum(tmin_tir19, PISO).values[0]
            df_reglas_de_negocio["tasa_techo"] = TECHO
            df_reglas_de_negocio["pbs_abajo"] = MOV_PBS_ABAJO_GLOBAL / 10_000
            df_reglas_de_negocio["pbs_arriba"] = where(
                cluster == 5, MOV_PBS_ARRIBA_C_5 / 10_000, where(
                    cluster >= 3, MOV_PBS_ARRIBA_C_3_4 / 10_000, MOV_PBS_ARRIBA_C_1_2 / 10_000))
            
            df_esc = merge(df, df_reglas_de_negocio, on=["REQUEST_ID","Escenario"], how="left")
            df_esc = df_esc[(df_esc["tea"] <= df_esc["tasa_techo"]) & (df_esc["tea"] >= df_esc["tasa_piso"])]
            df_esc = df_esc[(df_esc["tea"] <= df_esc["tasa_clv"] + df_esc["pbs_arriba"]) & (df_esc["tea"] >= df_esc["tasa_clv"] - df_esc["pbs_abajo"])]
            df_escenarios = merge(df_esc[["REQUEST_ID","Escenario","tea","tasa_clv","tasa_piso","tasa_techo","pbs_abajo","pbs_arriba"]], df, on=["REQUEST_ID","Escenario"], how='left',suffixes=("_esc",""))
            

            # Repite las filas de entrada para que coincidan con los escenarios
            
            # clv_input_repeated = inputs_escenarios

            # Fusiona las columnas originales de entrada con el DataFrame de escenarios
            # df = concat([df, clv_input_repeated], axis=1)
            # df['PREVIOUS_INDEX'] = clv_input_repeated['PREVIOUS_INDEX']

            # # Aplica las reglas de negocio para filtrar los escenarios
            # df = df[(df["tea"] <= TECHO) & (df["tea"] >= tasa_piso)]
            # df['pbs_arriba'] = where(
            #     df['cluster'] == 5, MOV_PBS_ARRIBA_C_5 / 10_000, where(
            #         df['cluster'] >= 3, MOV_PBS_ARRIBA_C_3_4 / 10_000, MOV_PBS_ARRIBA_C_1_2 / 10_000))

            # df = df[(df["tea"] <= tea_tir_objetivo_advisory + df["pbs_arriba"]) & (df["tea"] >= tea_tir_objetivo_advisory - MOV_PBS_ABAJO_GLOBAL / 10_000)]
            
            # Ajusta las columnas necesarias en el DataFrame resultante
            df_escenarios['MontoTasaEspecial'] = df['tea'] * 100
            df_escenarios['TasaEspecial'] = df['tea']
            df_escenarios['TIR_OBJETIVO'] = -1
            df_escenarios['REQ_TYPE'] = 3

            df_escenarios.reset_index(drop=True, inplace=True)
            df_escenarios['REQUEST_ID'] = df_escenarios.index + 1
            
            return df_escenarios

        # ejecución
        df_clv=set_interpolate(clv_input,clv_result)      
        clv_wrapper = ClvPymeWrapper(df_clv
                                        ,clv_transforms=clv_first_wrapper.clv_transforms
                                        ,clv_curves=clv_first_wrapper.clv_curves
                                        ,change_desembolso=False)
        clv_result, clv_input = clv_wrapper.predict()    
        return clv_result,clv_input

    def predict(self, X, feature_names):
        from pandas import DataFrame
        import logging
        import datetime

        from pyme_engine.clv_pyme.clv_pyme_wrapper import ClvPymeWrapper
        from pyme_engine.wtp_pyme.wtp_pyme_wrapper import WtpPymeWrapper

        
        def calculate_only_clv(df_input):
            # clv
            clv_wrapper = ClvPymeWrapper(df_input, change_desembolso=False)
            clv_result, clv_input = clv_wrapper.predict()
            result = self.__format_result_clv(clv_result)
            return result, clv_result, clv_input, clv_wrapper

        def calculate_only_wtp(clv_result, clv_input, clv_wrapper):

            
            clv_result[['codclavecic','TIPO_TIR_OBJETIVO']]= clv_input[['IDC_ULTDIGITO','TIPO_TIR_OBJETIVO']]
            
            # calculamos los npv de las interpolaciones de tasas
            clv_result_wtp, clv_input = self.__format_input_clv_pre_wtp(clv_input, clv_result,clv_wrapper)


            # envia a calcular wtp
            wtp_input = self.__format_input(clv_input, clv_result_wtp)    
            wtp_wrapper = WtpPymeWrapper(wtp_input)
            wtp_result = wtp_wrapper.predict()            

            # resultados        
            result = self.__format_result(clv_result, wtp_result)
            return result
    
        
        df_input =DataFrame(data=X, columns=feature_names)

        # try:
            #----------- inicio del log    
        df_input['CODCLAVEOPECTA']=df_input['REQUEST_ID']
        
        
        # df_input_log = df_input.to_string(index=False, header=False).replace('\n', ',')
        # logging.error(f"[INFO: BCP-PRICING v2024.03.04] - PYME NoRevolvente Start - df_input:[{df_input_log}] Start time: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')}")
        logging.error(f"[INFO: BCP-PRICING v2024.03.04] - PYME NoRevolvente Start -  Start time: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')}")


        # procesamient
        result, clv_result, clv_input, clv_wrapper = calculate_only_clv(df_input)


        # si es ct y idc par se ejecuta wt
        # if clv_input['TIPO_CLV'][0]=='CT' and int(X["IDC_ULTDIGITO"][0]) % 2 != 0:
        #     result = calculate_only_wtp(clv_result, clv_input, clv_wrapper)

        #----------- cierre del log
        #logging.error("[INFO: BCP-PRICING v2023.09.26] - PYME NoRevolvente End request_ids:[{request_id}]: {start_clv}".
        #        format(start_clv=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
        #                request_id=request_id))s

        #irr_column = result['IRR'].to_string(index=False, header=False)

        logging.error(f"[INFO: BCP-PRICING v2024.03.04] - PYME NoRevolvente Ends result: Endd time: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')}")
        
        return result

        # except Exception as err:
        #     # en caso no se encuentre resultados. MS
        #     msj = str(err)
        #     logging.error("[INFO: BCP-PRICING v2023.11.13] - PYME NoRevolvente Error df_input Prev: Start time: {start_clv} , Mensaje de error: {msj}".
        #           format(msj=msj,
        #                  start_clv=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')))
                    
        #     return self.__format_default_result(df_input)    