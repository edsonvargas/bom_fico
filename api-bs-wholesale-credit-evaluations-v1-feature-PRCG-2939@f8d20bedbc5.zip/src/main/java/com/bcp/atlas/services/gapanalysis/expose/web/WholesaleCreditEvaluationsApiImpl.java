package com.bcp.atlas.services.gapanalysis.expose.web;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.OperationNumberRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleOperationNumberResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesalePostHeaders;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationInfoResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationNumberResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.QuotationRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.WholesaleCreditEvaluationsService;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.WholesaleOperationService;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.WholesaleQuotationService;
import io.reactivex.Maybe;
import io.reactivex.Single;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.server.ServerWebExchange;


/**
 * <br/> Clase service que contiene los metodos necesarios para tramitar la data
 * y logica de negocio que consumira la clase REST WholsaleCreditEvaluationsController<br/>
 * <b>Class</b>: WholesaleCreditEvaluationsApiImpl<br/>
 * Copyright: &copy; 2022 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *     <u>Service Provider</u>: BCP <br/>
 *     <u>Developed by</u>: <br/>
 *     <ul>
 *     <li>Christian Garcia</li>
 *     </ul>
 *     <u>Changes</u>:<br/>
 *     <ul>
 *     <li>Nov 7, 2022 Creaci&oacute;n de Clase.</li>
 *     </ul>
 * @version 1.0
 */

@Component
@Slf4j
public class WholesaleCreditEvaluationsApiImpl implements WholesaleCreditsApiDelegate,
    QuotationsApiDelegate, OperationsApiDelegate {

  @Autowired
  WholesaleCreditEvaluationsService wholsalecreditevaluationsService;

  @Autowired
  WholesaleQuotationService wholesaleQuotationService;

  @Autowired
  WholesaleOperationService wholesaleOperationService;

  @Override
  public Optional<NativeWebRequest> getRequest() {
    return WholesaleCreditsApiDelegate.super.getRequest();
  }

  @Override
  public Maybe<ResponseEntity<PricingWholesaleResponse>> rateWholesaleCredit(
          PricingWholesalePostHeaders headers, Request request,
          ServerWebExchange serverWebExchange) {

    return wholsalecreditevaluationsService
        .response(headers, request)
        .firstElement()
        .map(ResponseEntity::ok)
        .doOnError(Throwable::printStackTrace);

  }

  @Override
  public Maybe<ResponseEntity<PricingWholesaleQuotationNumberResponse>> createQuotation(
      PricingWholesalePostHeaders pricingWholesalePostHeaders, QuotationRequest quotationRequest,
      ServerWebExchange exchange) {

    return wholesaleQuotationService.generateQuotationNumber(quotationRequest)
           .firstElement().flatMapSingle(pricingWholesaleQuotationNumberResponse ->
            Single.just(
                ResponseEntity.ok(pricingWholesaleQuotationNumberResponse)))
        .toMaybe()
        .doOnError(Throwable::printStackTrace);

  }

  @Override
  public Maybe<ResponseEntity<PricingWholesaleQuotationInfoResponse>> getQuotation(
      PricingWholesalePostHeaders pricingWholesalePostHeaders, String quotationNumber,
      ServerWebExchange exchange) {
    return wholesaleQuotationService.getQuotation(quotationNumber)
        .firstElement().flatMapSingle(pricingWholesaleQuotationInfoResponse ->
            Single.just(
                ResponseEntity.ok(pricingWholesaleQuotationInfoResponse)))
        .toMaybe()
        .doOnError(Throwable::printStackTrace);
  }

  @Override
  public Maybe<ResponseEntity<PricingWholesaleOperationNumberResponse>> createOperation(
      PricingWholesalePostHeaders pricingWholesalePostHeaders,
      OperationNumberRequest operationNumberRequest, ServerWebExchange exchange) {

    return wholesaleOperationService.saveOperationNumber(operationNumberRequest)
        .firstElement().flatMapSingle(pricingWholesaleOperationNumberResponse -> Single.just(
            ResponseEntity.ok(pricingWholesaleOperationNumberResponse)))
        .toMaybe()
        .doOnError(Throwable::printStackTrace);
  }
}
