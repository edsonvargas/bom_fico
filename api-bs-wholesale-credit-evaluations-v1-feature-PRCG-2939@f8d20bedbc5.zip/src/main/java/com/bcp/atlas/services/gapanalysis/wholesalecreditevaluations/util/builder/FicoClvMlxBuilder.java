package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.core.constants.ErrorCategory;
import com.bcp.atlas.core.exception.ApiException;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.BankingType;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.BusinessUnit;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.ClassificationRating;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CommercialActivity;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.Currency;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.DefaultProbability;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.EconomicActivities;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.GuaranteeProduct;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.GuaranteeScope;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.Ratio;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.Risk;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.RiskClassificationBcp;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.SubSegment;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.GuarantorInfo;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CommonTransferRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExchangeRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.mlx.MlxRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.Util;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

/**
 * <br/>
 * Clase Interfaz del Servicio para la logica de negocio que consumira la clase REST
 * RateCalculationController<br/>
 * <b>Class</b>: FicoRequest<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>G.CH.J</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Mar 25, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Component
@Slf4j
public class FicoClvMlxBuilder {

  /**
   * Method ()
   *
   * @version 1.0
   */

  public MlxRequest getRequestMlx(
      Request request,
      CustomerGetResponse customerGetResponse,
      CustomerGetResponse guarantorGetResponse,
      CommonTransferRate comTra,
      ExchangeRate exchangeRate) {

    List<String> input = new ArrayList<>();

    input.add(request.getChannelRequestId());
    input.add(request.getCustomerInfo().getIdc());

    DefaultProbability customerDefaultProbability  =
        ObjectUtils.defaultIfNull(customerGetResponse.getDefaultProbability(),
                              new DefaultProbability());

    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getAmountBalanceDebtDollars()));
    input.add(Util.getDefaultZeroFromStringToMlx(request.getCustomerInfo().getSpecificDebt()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getAmountBalanceDebtDollars()));
    input.add(Util.getDefaultValueStringMlx(
        ObjectUtils.defaultIfNull(request.getGuarantorInfo(),
                                  new GuarantorInfo()).getIdc()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getAmountBalanceDebtDollars()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getAmountBalanceDebtDollars()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getAmountBalanceDebtDollars()));

    input.add(request.getCreditInfo().getCreditInfoBase().getCurrency().getCode().getValue());
    input.add(request.getCreditInfo().getCreditInfoBase().getProductCode());
    input.add(Util.getOneDefaultValueToMlx(request.getCreditInfo().getCreditInfoBase().getSofrDays()));
    input.add(Util.getDefaultValueBigdecimalMlx(request.getCreditInfo().getCreditInfoBase().getLoanAmount()));
    input.add(Util.getDefaultValueBigdecimalMlx(request.getCreditInfo().getLoanRenewal()));
    input.add(Util.getDefaultValueStringMlx(request.getCreditInfo().getCreditInfoBase().getTerm()));
    input.add(Util.getDefaultValueStringMlx(request.getCreditInfo().getCreditInfoBase().getRateType().getValue()));
    input.add(Util.getDefaultValueBigdecimalMlx(request.getCreditInfo().getSpecialFundingPercentage()));
    input.add(Util.getDefaultValueStringMlx(request.getCreditInfo().getOperationType().getValue()));
    input.add(Util.getOneDefaultValueToMlx(request.getCreditInfo().getDleaceCount()));  //19
    input.add(Util.getOneDefaultValueToMlx(exchangeRate.getAmmountExchangeCurrencyDestinationOrigin()));
    input.add(Util.getDefaultValueBigdecimalMlx(request.getInterestRate()));


    //**Alexandria**/
    input.add(Util.getDefaultValueBigdecimalMlx(customerGetResponse.getYearsAsClient()));
    input.add(Util.getDefaultValueStringMlx(customerGetResponse.getFlagLinkedCredicorp()));

    input.add(Util.getDefaultValueBigdecimalMlx(
        ObjectUtils.defaultIfNull(customerGetResponse.getRatio(),
                                  new Ratio()).getActiveFinancialMarginRatio()));

    CommercialActivity customerCommercialActivity = ObjectUtils
        .defaultIfNull(customerGetResponse.getCommercialActivity(),new CommercialActivity());

    input.add(Util.getDefaultValueStringMlx(
        customerCommercialActivity.getCommercialSegmentContingentProducts()));
    input.add(Util.getDefaultValueStringMlx(
        customerCommercialActivity.getLongTermProductBusinessSegment()));

    input.add(Util.getDefaultValueBigdecimalMlx(
        ObjectUtils.defaultIfNull(customerCommercialActivity.getBusinessUnit(),
                                  new BusinessUnit()).getBusinessUnitCode()));
    input.add(Util.getDefaultValueStringMlx(
        customerCommercialActivity.getTypeSubcategoryEconomicSectorPortfolio()));
    input.add(Util.getDefaultValueStringMlx(
        ObjectUtils.defaultIfNull(customerCommercialActivity.getEconomicActivities(),
                                  new EconomicActivities()).getEconomicActivitiesCode()));
    input.add(Util.getDefaultValueStringMlx(customerGetResponse.getIdc()));
    input.add(Util.getDefaultValueStringMlx(
        ObjectUtils.defaultIfNull(customerGetResponse.getSubSegment(),
                                  new SubSegment()).getSubSegmentCode()));
    input.add(Util.getDefaultValueStringMlx(
        ObjectUtils.defaultIfNull(customerGetResponse.getBankingType(),
                                  new BankingType()).getBankingTypeCode()));
    Risk customerRisk = ObjectUtils.defaultIfNull(customerGetResponse.getRisk(),
                                                 new Risk());
    input.add(Util.getDefaultValueStringMlx(
        ObjectUtils.defaultIfNull(customerRisk.getRiskClassificationBcp(),
                                  new RiskClassificationBcp()).getRiskClassificationBcpCode()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getAmountBalanceDebtCcfDollar()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getAmountBalanceDebtDiscountLetterDollars()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getAmountBalanceDebtDollars()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        ObjectUtils.defaultIfNull(customerGetResponse.getRatio(),
                                  new Ratio()).getRefinancedDirectDebtVsTotalSbsRatio()));
    input.add(Util.getDefaultValueStringMlx(
        customerDefaultProbability.getAmountCompaniesFinancialSystemCustomerDebt()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getAverageQuantityConditionalDelay18M()));
    input.add(Util.getDefaultValueBigdecimalMlx(customerGetResponse.getParticipationBankFinance()));

    Risk customerOrGuarantorRisk =
        ObjectUtils.defaultIfNull(
            Util.getGuarantorOrCustomerResponse(
                customerGetResponse,guarantorGetResponse).getRisk(),new Risk());

    input.add(Util.getDefaultValueStringMlx(customerOrGuarantorRisk.getDateRatingActivation()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getDefaultProbabilityPit()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getDefaultProbabilityTtcShortTerm()));
    input.add(Util.getDefaultValueBigdecimalMlx(
        customerDefaultProbability.getDefaultProbabilityTtcLongTerm()));

    input.add(Util.getDefaultValueStringMlx(
        Objects.isNull(customerGetResponse.getRisk())
            || Objects.isNull(customerGetResponse.getRisk().getRiskClassificationCovid()) ? null
            : customerGetResponse.getRisk().getRiskClassificationCovid()
            .getRiskClassificationCovidCode()));


    input.add(Util.getDefaultValueStringMlx(
        ObjectUtils.defaultIfNull(customerOrGuarantorRisk.getClassificationRating(),
                                  new ClassificationRating()).getClassificationRatingCode()));
    input.add(Util.getDefaultValueStringMlx(
        Objects.isNull(customerGetResponse.getRisk())
            || Objects.isNull(customerGetResponse.getRisk().getExposureLevelRcc()) ? null
            : customerGetResponse.getRisk().getExposureLevelRcc().getExposureLevelRccCode()));
    input.add(Util.getDefaultValueStringMlx(customerOrGuarantorRisk.getVersionNumberRating()));
    input.add(Util.getDefaultValueBigdecimalMlx(customerGetResponse.getProfitability()));

    addGuarantees(customerGetResponse,input);

    addSpecificCreditLinesWarrantiesInfo(request,input);

    addWarrantiesInfo(request,input);

    addRateForAllDaysOfYear(request,comTra,input);

    //req contingentes inicio
    input.add(request.getQuotationType().getValue()); //TIPOCOTIZACION CP/CONT
    input.add(Util.getDefaultTypeGuaranteeLetter(
        request.getTypeGuaranteeLetter() == null
            ? null : request.getTypeGuaranteeLetter().getValue()));//TIPOCALCULADORA: F/D
    // fin

    List<List<String>> requestList = new ArrayList<>();
    requestList.add(input);

    MlxRequest mlxRequestData = new MlxRequest();
    mlxRequestData.setJsonData(requestList);

    return mlxRequestData;
  }

  /**
   * Method addGuarantees
   *
   * @version 1.0
   */
  public void addGuarantees(
      CustomerGetResponse customerGetResponse,
      List<String> input) {
    int guaranteesCount =
        ObjectUtils.defaultIfNull(customerGetResponse.getGuarantees(), new ArrayList<>()).size();

    for (int i = 0; i < 20; i++) {
      if (guaranteesCount > 0) {

        input.add(
            ObjectUtils.defaultIfNull(
                    customerGetResponse.getGuarantees().get(i).getGuaranteeProduct(),
                    new GuaranteeProduct())
                .getGuaranteeProductCode());
        input.add(
            ObjectUtils.defaultIfNull(
                    customerGetResponse.getGuarantees().get(i).getCurrency(), new Currency())
                .getCurrencyCode());
        input.add(
            Util.getDefaultValueBigdecimalMlx(
                customerGetResponse.getGuarantees().get(i).getMinimumAmountUsed()));
        input.add(
            ObjectUtils.defaultIfNull(
                    customerGetResponse.getGuarantees().get(i).getGuaranteeScope(),
                    new GuaranteeScope())
                .getGuaranteeScopeCode());

        guaranteesCount = guaranteesCount - 1;
      } else {
        input.add("-1");
        input.add("-1");
        input.add("-1");
        input.add("-1");
      }
    }
  }

  /**
   * Method addSpecificCreditLinesWarrantiesInfo
   *
   * @version 1.0
   */
  public void addSpecificCreditLinesWarrantiesInfo(Request request,
                                                   List<String> input) {

    int countCreditInfo =
        ObjectUtils.defaultIfNull(
            request.getCreditInfo().getSpecificCreditLinesWarranties(),
            new ArrayList<>()).size();

    for (int i = 0; i < 10; i++) {
      if (countCreditInfo > 0) {
        input.add(Util.getDefaultValueStringMlx(request.getCreditInfo().getSpecificCreditLinesWarranties()
                                                    .get(i).getWarrantyCode()));
        input.add(Util.getDefaultValueStringMlx(request.getCreditInfo().getSpecificCreditLinesWarranties()
                                                    .get(i).getCurrency().getCode().getValue()));
        input.add(Util.getDefaultValueBigdecimalMlx(request.getCreditInfo().getSpecificCreditLinesWarranties()
                                                        .get(i).getCommercialValue()));
        input.add(Util.getDefaultValueStringMlx(request.getCreditInfo().getSpecificCreditLinesWarranties()
                                                    .get(i).getWarrantyType().getValue()));
        countCreditInfo = countCreditInfo - 1;
      } else {
        input.add("");
        input.add("");
        input.add("-1");
        input.add("");
      }
    }
  }

  /**
   * Method addWarrantiesInfo
   *
   * @version 1.0
   */
  public void addWarrantiesInfo(Request request,
                                List<String> input) {

    int countCreditInfoGuaran =
        ObjectUtils.defaultIfNull(request.getCreditInfo().getWarranties(),
                                  new ArrayList<>()).size();

    for (int i = 0; i < 10; i++) {
      if (countCreditInfoGuaran > 0) {
        input.add(request.getCreditInfo().getWarranties().get(i).getWarrantyCode());
        input.add(request.getCreditInfo().getWarranties().get(i)
                      .getCurrency().getCode().getValue());
        input.add(Util.getDefaultValueBigdecimalMlx(request.getCreditInfo().getWarranties().get(i).getCommercialValue()));
        input.add(Util.getDefaultValueStringMlx(
            Objects.isNull(request.getCreditInfo().getWarranties().get(i).getWarrantyType()) ? null
                : request.getCreditInfo().getWarranties().get(i).getWarrantyType().getValue()));
        countCreditInfoGuaran = countCreditInfoGuaran - 1;
      } else {
        input.add("");
        input.add("");
        input.add("-1");
        input.add("");
      }
    }
  }

  /**
   * Method addRateForAllDaysOfYear
   *
   * @version 1.0
   */
  public void addRateForAllDaysOfYear(Request request,
                            CommonTransferRate comTra,
                            List<String> input) {

    /*int countTra = 0;
    if (CollectionUtils.isNotEmpty(comTra)) {
      CommonTransferRate firstValue = new CommonTransferRate();
      firstValue.setCurrency(
          request.getCreditInfo().getCreditInfoBase()
              .getCurrency().getCode().getValue());
      firstValue.setQuote(1);
      firstValue.setRate(comTra.get(0).getRate());
      comTra.add(0,firstValue);
      countTra = comTra.size();

    }

    for (int i = 0; i < 365; i++) {
      if (countTra > 0) {
        input.add(Util.getDefaultValueStringMlx(comTra.get(i).getRate()));
        countTra = countTra - 1;
      } else {
        input.add("-1");
      }
    }*/
    //req contingentes inicio
    if (comTra == null) {
      // en caso no haya data devuelve un error
      throw ApiException.builder()
          .systemCode(Constantes.ERROR_CODE_PR0011)
          .description(Constantes.MESSAGE_PROCEDURE)
          .errorType(Constantes.ERROR_TYPE_PROCEDURE)
          .cause(new Throwable(Constantes.MESSAGE_PROCEDURE))
          .category(ErrorCategory.UNEXPECTED)
          .build();
    }
    input.add(Util.getDefaultValueStringMlx(comTra.getRate()));
    //fin
  }

}