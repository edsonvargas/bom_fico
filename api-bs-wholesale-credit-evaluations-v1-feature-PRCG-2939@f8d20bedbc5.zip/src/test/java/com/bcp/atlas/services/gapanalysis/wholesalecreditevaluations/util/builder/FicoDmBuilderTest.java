package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesalePostHeaders;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.SpreadComercialAndBlackList;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.mlx.MlxResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.MapperUtils;
import com.google.common.io.Resources;
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FicoDmBuilderTest {

  @InjectMocks FicoDmBuilder ficoDmBuilder;

  @SneakyThrows
  @Test
  void whenMlxResponseDefaultTest() {

    PricingWholesalePostHeaders pricingWholesalePostHeaders = new PricingWholesalePostHeaders();
    pricingWholesalePostHeaders.setCallerName("NB");

    CustomerGetResponse customerGetResponse =
        MapperUtils.convertToObject("AlexandriaResponse" + ".json", CustomerGetResponse.class);

    String clvMlxResponseString =
        new BufferedReader(
                new InputStreamReader(
                    Resources.getResource("ResponseMlxTest.json").openStream(),
                    StandardCharsets.UTF_8))
            .lines()
            .collect(Collectors.joining("\n"));
    Gson gson = new Gson();
    MlxResponse mlxResponse = gson.fromJson(clvMlxResponseString, MlxResponse.class);
    String clvMlxResponseNanString =
        new BufferedReader(
                new InputStreamReader(
                    Resources.getResource("ResponseMlxNanTest.json").openStream(),
                    StandardCharsets.UTF_8))
            .lines()
            .collect(Collectors.joining("\n"));
    Gson gsonNan = new Gson();
    MlxResponse mlxResponseNan = gsonNan.fromJson(clvMlxResponseNanString, MlxResponse.class);
    Request request = MapperUtils.convertToObject("RequestApi" + ".json", Request.class);
    SpreadComercialAndBlackList spreadComercialAndBlackList =
        MapperUtils.convertToObject(
            "RequestSpreadComercialAndBlackList" + ".json", SpreadComercialAndBlackList.class);
    String appCode = "JH";
    Assertions.assertNotNull(
        ficoDmBuilder.getRequestInput(
            request, customerGetResponse, mlxResponseNan, appCode, spreadComercialAndBlackList));
    Assertions.assertNotNull(
        ficoDmBuilder.getRequestInput(
            request, customerGetResponse, mlxResponse, appCode, spreadComercialAndBlackList));
    Assertions.assertNotNull(
        ficoDmBuilder.getRequestInput(
            request, customerGetResponse, null, appCode, spreadComercialAndBlackList));
  }
}
