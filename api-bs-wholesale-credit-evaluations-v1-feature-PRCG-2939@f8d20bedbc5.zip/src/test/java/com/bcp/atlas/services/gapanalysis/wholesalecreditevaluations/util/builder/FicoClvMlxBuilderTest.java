package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CommonTransferRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExchangeRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.MapperUtils;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FicoClvMlxBuilderTest {

  @InjectMocks FicoClvMlxBuilder ficoClvMlxBuilder;

  @Test
  void whenMlxResponseDefaultTest() {

    CommonTransferRate commonTransferRate  = new CommonTransferRate();
    commonTransferRate.setCurrency("PEN");
    commonTransferRate.setQuote(30);
    commonTransferRate.setRate(0.12f);

    CustomerGetResponse customerGetResponse =
        MapperUtils.convertToObject("AlexandriaResponse" + ".json", CustomerGetResponse.class);

    Request request = MapperUtils.convertToObject("RequestApi" + ".json", Request.class);

    ExchangeRate exchangeRate =
        MapperUtils.convertToObject("ResponseExchangeRate" + ".json", ExchangeRate.class);

    Assertions.assertNotNull(
        ficoClvMlxBuilder.getRequestMlx(
            request,
            customerGetResponse,
            customerGetResponse,
            commonTransferRate,
            exchangeRate));

    Assertions.assertNotNull(
        ficoClvMlxBuilder.getRequestMlx(
            request, customerGetResponse, customerGetResponse, commonTransferRate, exchangeRate));
  }
}
