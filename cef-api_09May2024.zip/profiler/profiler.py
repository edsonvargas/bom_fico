
import pandas as pd
import line_profiler
import atexit
import cProfile
import pstats
import io
import time
from pathlib import Path

import os, sys
sys.dont_write_bytecode = True
sys.path.append(os.getcwd())

# export PYTHONPATH="$PYTHONPATH:/Users/masa/Documents/Trabajos/BCP/onedrive/OneDrive - Credicorp/2021/fico/consolidado/"
from source.clv_cef import clv_cef_wrapper as wrapper


profile = line_profiler.LineProfiler()
atexit.register(profile.print_stats)
path_base = Path(__file__).resolve().parent 

def profile_engine_clv():
    # Cargando datos       
    path = path_base / 'input_profiler.csv'
    data = pd.read_csv(path)
    # Ejecutando el codigo
    start1 = time.time()
    output = pd.DataFrame()
    for index, i in data.iterrows(): 
        clv_engine = wrapper.ClvCefWrapper()
        outputClv = clv_engine.predict([i.values], data.columns)
        output = pd.concat([output, outputClv], ignore_index=True)
    output.to_csv(path_base /  "output_profiler.csv")
    
    print('Elapsed time:{tiempo}'.format(tiempo=time.time()-start1))
    print(output['Min_Rate'])


def generate_profile():
    profiler = cProfile.Profile()
    profiler.enable()
    profile_engine_clv()
    profiler.disable()

    result = io.StringIO()
    stats = pstats.Stats(profiler, stream=result).sort_stats('cumtime')
    stats.print_stats()
    data = result.getvalue()

    # chop the string into a csv-like buffer
    data = 'ncalls' + data.split('ncalls')[-1]
    lines = list(filter(lambda line: ('ncalls' in line
                                      or '/utils.py' in line
                                      or '/utils_clv.py' in line
                                      or '/CLV_Engine.py' in line
                                      or '/curves_all.py' in line
                                      or '/clv_cef_wrapper.py' in line
                                      or '/clv_data.py' in line), data.split('\n')))
    data = '\n'.join([','.join([word.strip().replace('    ', ',').replace('  ', ',')
                                for word in line.split('    ')])
                      for line in lines])
    data = '\n'.join([line.replace(',,', ',').replace('ncalls', ',ncalls') for line in data.split('\n')])

    # save it to disk
    with open(path_base / 'profiler.csv', 'w+') as f:
        f.write(data)
        f.close()


if __name__ == '__main__':
    generate_profile()
