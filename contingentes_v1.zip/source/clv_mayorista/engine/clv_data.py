from pandas import read_csv, DataFrame
from pathlib import Path

class ClvData:
    __instance = None
    DataFramesLoaded = dict()

    @staticmethod
    def get_instance():
        """ Static access method. """
        if ClvData.__instance is None:
            ClvData()
        return ClvData.__instance

    def __init__(self):
        self.__load_data()
        """ Virtually private constructor. """
        if ClvData.__instance is None:
            ClvData.__instance = self

    def __load_data(self):
        from threading import Thread

        files = ["param_pd_pit","param_ifrs9","param_lgd_ttc","param_grupo",
                "param_modelo_cobertura","param_modelo_lgd_pit","param_modelo_cascada","param_mfa",
                "param_roe","param_ecap","param_costos","param_costos_agrupacion","bn_param_costos",
                "param_producto"]
        
        parent_path= f"{Path(__file__).resolve().parent}/param/"

        def read_data(file):
            self.DataFramesLoaded[file] = read_csv(f"{parent_path}{file}.csv")
        threads=[]
        def start_thread(key,func):
            thr =  Thread(target=func, args=(key,))
            threads.append(thr)
            thr.start()
        [start_thread(key,read_data) for key in files]
        [t.join() for t in threads]

