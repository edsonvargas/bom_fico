package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Exception;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.DmResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.Util;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;



/**
 * <br/>
 * Clase Interfaz del Servicio para la logica de negocio que consumira la clase REST
 * RateCalculationController<br/>
 * <b>Class</b>: FicoRequest<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Mar 25, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Component
public class WholsaleBuilder {


  /**
   * This method is used to process the response.
   *
   * @param request {@Link LoanRequest}
   * @param dm {@Link LeadsResponse}
   * @return {@Link PricingWholesaleResponse}
   */

  public PricingWholesaleResponse getResponse(Request request, DmResponse dm) {

    PricingWholesaleResponse pricingWholesaleResponse = new PricingWholesaleResponse();
    List<Exception> exceptionList = new ArrayList<>();

    pricingWholesaleResponse.setTransferRate(
        dm.getNoRevPayload().getPayloadOutput()
            .getEvaluacion().getTt());
    pricingWholesaleResponse.setOperationalCost(
        dm.getNoRevPayload().getPayloadOutput()
            .getEvaluacion().getCo());
    pricingWholesaleResponse.setCapitalReturn(
        dm.getNoRevPayload().getPayloadOutput()
            .getEvaluacion().getRk());
    pricingWholesaleResponse.setBusinessSpread(
        dm.getNoRevPayload().getPayloadOutput()
            .getEvaluacion().getSc());
    pricingWholesaleResponse.setExpectedLoss(
        dm.getNoRevPayload().getPayloadOutput()
            .getEvaluacion().getPe());
    pricingWholesaleResponse.setMinimalRate(
        dm.getNoRevPayload().getPayloadOutput()
            .getEvaluacion().getTeamin());
    pricingWholesaleResponse.setRoe(
        dm.getNoRevPayload().getPayloadOutput()
            .getEvaluacion().getRoe());
    pricingWholesaleResponse.setRarorac(
        dm.getNoRevPayload().getPayloadOutput()
            .getEvaluacion().getRarorac());
    pricingWholesaleResponse.setDueDate(
        Util.formatStringToDate(dm.getNoRevPayload().getPayloadOutput()
            .getEvaluacion().getFechaVigencia(),"dd/MM/yyyy"));

    for (int i = 0; i < dm.getNoRevPayload().getPayloadOutput().getExcepciones().size(); i++) {
      Exception exception = new Exception();
      exception.setRoleId(dm.getNoRevPayload().getPayloadOutput()
              .getExcepciones().get(i).getRoleId());
      exception.setRoleDescription(
          dm.getNoRevPayload().getPayloadOutput()
              .getExcepciones().get(i).getDescription());
      exception.setFromRate(dm.getNoRevPayload().getPayloadOutput()
              .getExcepciones().get(i).getFromRate());
      exception.setTypeExcepction(Exception
               .TypeExcepctionEnum.valueOf(
                   dm.getNoRevPayload().getPayloadOutput()
                       .getExcepciones().get(i).getTypeExcepction()));
      exceptionList.add(exception);
    }
    pricingWholesaleResponse.setExceptions(exceptionList);
    return pricingWholesaleResponse;
  }

}
