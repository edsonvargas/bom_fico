package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.Resources;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


/**
 * <br/>
 * Utils. Class: createUri<br/>
 * Copyright: &copy; 2017 Banco de Cr&eacute;dito del Per&uacute;<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis Per&uacute; SAC (EVE) <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>Reibin Charles Quisquiche Siccha (RCQS) From (EVE)</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>20/03/2018:date('dd/MMM/yyyy')} (KGB) Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */

public class MapperUtils {

  /**
   * <br/>
   * Utils. Class: createUri<br/>
   * Copyright: &copy; 2017 Banco de Cr&eacute;dito del Per&uacute;<br/>
   * Company: Banco de Cr&eacute;dito del Per&uacute;<br/>
   *
   * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
   *         <u>Service Provider</u>: Everis Per&uacute; SAC (EVE) <br/>
   *         <u>Developed by</u>: <br/>
   *         <ul>
   *         <li>Reibin Charles Quisquiche Siccha (RCQS) From (EVE)</li>
   *         </ul>
   *         <u>Changes</u>:<br/>
   *         <ul>
   *         <li>20/03/2018:date('dd/MMM/yyyy')} (KGB) Creaci&oacute;n de Clase.</li>
   *         </ul>
   * @version 1.0
   */
  public static <T> T convertToObject(String file, Class<T> cls) {
    T response = null;
    ObjectMapper mapper = new ObjectMapper();
    try {
      response = mapper
          .readValue(Resources.getResource(file).openStream(), cls);
    } catch (IOException e) {
      e.printStackTrace();
    }
    return response;
  }

  /**
   * Method mapJsonFileToObjectList()
   *
   *
   * @version 1.0
   */
  public static <T> List<T> mapJsonFileToObjectList(final String file, final Class<T> value) {
    List<T> lista = new ArrayList<T>();
    ObjectMapper mapper = new ObjectMapper();
    URL url = Resources.getResource(file);
    try {
      lista = mapper.readValue(new File(url.toURI()), new TypeReference<List<T>>() {});

    } catch (JsonParseException e) {
      e.printStackTrace();
    } catch (JsonMappingException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } catch (URISyntaxException e) {
      e.printStackTrace();
    }
    return lista;
  }
}
