package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.impl;

import com.bcp.atlas.core.exception.ApiException;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationInfoResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationNumberResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.QuotationRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.WholesaleQuotationService;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.WholesaleQuotationDao;
import io.reactivex.Observable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * <br/>
 * Clase service que contiene los metodos necesarios para tramitar la data y logica de negocio que
 * <b>Class</b>: WholesaleQuotationServiceImpl<br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: BCP <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>Marco Nolasco</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Apr 27, 2023 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Service
@Slf4j
public class WholesaleQuotationServiceImpl implements WholesaleQuotationService {

  @Autowired
  WholesaleQuotationDao wholesaleQuotationDao;

  @Override
  public Observable<PricingWholesaleQuotationNumberResponse> generateQuotationNumber(
      QuotationRequest quotationRequest) {

    return wholesaleQuotationDao.generateQuotationNumber(quotationRequest)
        .onErrorReturn((Throwable ex) -> ApiException.builder()
            .cause(ex).buildAsMaybe().toString())
        .flatMap(quotationNumber -> {
          PricingWholesaleQuotationNumberResponse pricingQuotationNumber =
              new PricingWholesaleQuotationNumberResponse();
          pricingQuotationNumber.setQuotationNumber(quotationNumber);
          return Observable.just(pricingQuotationNumber);
        });
  }

  @Override
  public Observable<PricingWholesaleQuotationInfoResponse> getQuotation(String quotationNumber) {
    return wholesaleQuotationDao.getQuotation(quotationNumber) ;
  }

}
