package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.impl;

import com.bcp.atlas.core.constants.ErrorCategory;
import com.bcp.atlas.core.exception.ApiException;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationInfoResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.QuotationRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.WholesaleQuotationDao;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.CreditInfoCpResponseRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.GetQuotationInfoRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.GetQuotationInfoBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import io.reactivex.Flowable;
import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.schedulers.Schedulers;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * <br/>
 * Clase service que contiene los metodos necesarios para tramitar la data y logica de negocio que
 * consumira la clase REST WholesaleQuotationDaoImpl<br/>
 * <b>Class</b>: LoanRateServiceImpl<br/>
 * Copyright: &copy; 2023 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 * <u>Service Provider</u>: BCP <br/>
 * <u>Developed by</u>: <br/>
 * <ul>
 * <li>Marco Nolasco</li>
 * </ul>
 * <u>Changes</u>:<br/>
 * <ul>
 * <li>Apr 28, 2023 Creaci&oacute;n de Clase.</li>
 * </ul>
 * @version 1.0
 */
@Component
@Slf4j
@AllArgsConstructor
public class WholesaleQuotationDaoImpl implements WholesaleQuotationDao {

  @Autowired
  private CreditInfoCpResponseRepository creditInfoCpResponseRepository;

  @Autowired
  private GetQuotationInfoRepository getQuotationInfoRepository;

  @Override
  public Observable<String> generateQuotationNumber(QuotationRequest quotationRequest) {

    return Observable.fromCallable(() -> creditInfoCpResponseRepository.generateQuotationNumber(
        String.valueOf(quotationRequest.getQuotationId())))
           .doOnError(Throwable::printStackTrace)
           .flatMapSingle(quotationGenerate -> {
             if (Constantes.MESSAGE.contains(quotationGenerate)) {
               throw ApiException.builder()
                  .description(Constantes.MESSAGE)
                  .errorType(Constantes.ERROR_TYPE_FUNCTIONAL)
                  .cause(new Throwable(Constantes.MESSAGE))
                  .category(ErrorCategory.INVALID_REQUEST)
                  .build();
             } else {
               return Single.just(quotationGenerate);
             }

           });

  }


  @Override
  public Observable<PricingWholesaleQuotationInfoResponse> getQuotation(String quotationNumber) {

    return Flowable.fromCallable(() -> getQuotationInfoRepository
        .searchByQuotationNumber(quotationNumber))
        .toObservable()
        .distinct()
        .subscribeOn(Schedulers.io())
        .doOnError(Throwable::printStackTrace)
        .flatMap(quotationInfo ->
                     Observable.just(
                         GetQuotationInfoBuilder.getQuotationInfo(quotationInfo)));


  }
}
