package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.dto;

import lombok.Data;

/**
 * <b>Class</b>: TokenAppcodeDto.java <br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Ago 1, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Data
public class TokenAppcodeDto {

  private String token;
  private String appCode;
}
