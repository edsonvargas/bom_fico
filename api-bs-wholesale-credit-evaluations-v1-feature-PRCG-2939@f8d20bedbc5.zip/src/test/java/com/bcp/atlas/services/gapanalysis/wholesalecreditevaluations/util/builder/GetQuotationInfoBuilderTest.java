package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.GetQuotationInfoEntity;
import com.google.common.io.Resources;
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * <b>Class</b>: GetQuotationInfoBuilderTest<br>
 * <b>Copyright</b>: &copy; 2022 Banco de Cr&eacute;dito del Per&uacute;.<br>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br>
 *     <u>Service Provider</u>: Everis Peru SAC <br>
 *     <u>Developed by</u>: <br>
 *     <ul>
 *     </ul>
 *     <u>Changes</u>:<br>
 *     <ul>
 *       <li>Nov 11, 2022 Creaci&oacute;n de Clase.
 *     </ul>
 *
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class GetQuotationInfoBuilderTest {

  @InjectMocks GetQuotationInfoBuilder getQuotationInfoBuilder;

  @Test
  void whenGetQuotationInfoBuilderTest() {
    List<GetQuotationInfoEntity> quotationInfoList = new ArrayList<>();
    Assertions.assertNotNull(GetQuotationInfoBuilder.getQuotationInfo(quotationInfoList));
  }

  @Test
  @SneakyThrows
  void whenGetQuotationInfoBuilderTestEmpty() {
    List<GetQuotationInfoEntity> getQuotationInfoEntityList = new ArrayList<>();

    Gson gson = new Gson();

    String quotationJson =
        new BufferedReader(
                new InputStreamReader(
                    Resources.getResource("GetQuotationInfoEntity.json").openStream(),
                    StandardCharsets.UTF_8))
            .lines()
            .collect(Collectors.joining("\n"));

    GetQuotationInfoEntity[] getQuotationInfoArray =
        gson.fromJson(quotationJson, GetQuotationInfoEntity[].class);

    getQuotationInfoEntityList.addAll(Arrays.asList(getQuotationInfoArray));

    Assertions.assertNotNull(GetQuotationInfoBuilder.getQuotationInfo(getQuotationInfoEntityList));
  }
}
