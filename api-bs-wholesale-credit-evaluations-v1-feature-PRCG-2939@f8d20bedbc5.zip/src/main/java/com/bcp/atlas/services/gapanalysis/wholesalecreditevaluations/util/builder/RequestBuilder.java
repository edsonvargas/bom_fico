package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;


import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CreditInfoCpRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import java.time.LocalDateTime;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;



/**
 * <br/>
 * Clase Interfaz del Servicio para la logica de negocio que consumira la clase REST
 * RateCalculationController<br/>
 * <b>Class</b>: FicoRequest<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Mar 25, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Component
@Slf4j
public class RequestBuilder {

  /**
   * Method getModelPrice()
   *
   * @version 1.0
   */
  public static CreditInfoCpRequest generateDbObjectRequest(Request request) {
    CreditInfoCpRequest creditInfoCpRequest = new CreditInfoCpRequest();
    HashBuilder hash = new HashBuilder();
    creditInfoCpRequest.setChannelReqId(request.getChannelRequestId());
    creditInfoCpRequest.setInterestRate(request.getInterestRate());
    creditInfoCpRequest.setExchangeType(request.getExchangeType());
    creditInfoCpRequest.setCustomerInfoIdc(request.getCustomerInfo()
                                               .getIdc());
    creditInfoCpRequest.setCustomerInfoSpecificDebt(request
                .getCustomerInfo().getSpecificDebt());
    creditInfoCpRequest.setCustomerInfoSpecificDebtDleace(request
                .getCustomerInfo().getSpecificDebtDleace());
    creditInfoCpRequest.setFlagBlackList(request
                .getCustomerInfo().getFlagBlackList());

    creditInfoCpRequest.setCreditInfoCpCurrencyCode(
        request.getCreditInfo().getCreditInfoBase()
            .getCurrency().getCode().getValue());
    creditInfoCpRequest.setCreditInfoCpCurrencyDescription(
        request.getCreditInfo().getCreditInfoBase()
            .getCurrency().getDescription().getValue());
    creditInfoCpRequest.setCreditInfoCpProductCode(request.getCreditInfo()
            .getCreditInfoBase().getProductCode());
    creditInfoCpRequest.setCreditInfoCpLiborDays(request.getCreditInfo()
                .getCreditInfoBase().getSofrDays());
    creditInfoCpRequest.setCreditInfoCpLoanAmount(request.getCreditInfo()
                .getCreditInfoBase().getLoanAmount());
    creditInfoCpRequest.setCreditInfoCpTerm(request.getCreditInfo()
                .getCreditInfoBase().getTerm());
    creditInfoCpRequest.setCreditInfoCpRateType(request.getCreditInfo()
                .getCreditInfoBase().getRateType().getValue());

    creditInfoCpRequest.setCreditInfoCpLoanRenewal(request
                 .getCreditInfo().getLoanRenewal());
    creditInfoCpRequest.setCreditInfoSpecialFundingPercentage(request
                .getCreditInfo().getSpecialFundingPercentage());

    creditInfoCpRequest.setCreditInfoCpDleaceCount(request
                .getCreditInfo().getDleaceCount());
    creditInfoCpRequest.setRegisterDate(LocalDateTime.now());
    //req contingentes inicio
    creditInfoCpRequest.setProductType(request.getQuotationType().getValue());
    //fin
    if (Objects.nonNull(request.getGuarantorInfo())) {
      creditInfoCpRequest.setGuarantorInfoIdc(
          request.getGuarantorInfo().getIdc());
    }

    if (Objects.nonNull(request.getCreditInfo().getOperationType())) {
      creditInfoCpRequest.setCreditInfoCpOperationType(
          request.getCreditInfo().getOperationType().getValue());
    }

    //req contingentes inicio
    if (Objects.nonNull(request.getTypeGuaranteeLetter())) {
      creditInfoCpRequest.setTypeGuaranteeLetter(
          request.getTypeGuaranteeLetter().getValue());
    }
    //fin

    return creditInfoCpRequest;

  }




}


