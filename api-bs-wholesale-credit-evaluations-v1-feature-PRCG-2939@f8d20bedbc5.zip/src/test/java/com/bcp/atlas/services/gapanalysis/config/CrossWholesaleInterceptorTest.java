package com.bcp.atlas.services.gapanalysis.config;

import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.bcp.atlas.services.gapanalysis.config.CrossWholsaleInterceptor.CustomHeaders;
import java.io.IOException;
import okhttp3.Interceptor.Chain;
import okhttp3.MediaType;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Interceptor for headers.<br>
 * <b>Class</b>: RequestCrossInterceptor<br>
 * <b>Copyright</b>: &copy; 2018 Banco de Cr&eacute;dito del Per&uacute;.<br>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br>
 *     <ul>
 *       <li>Apr 1, 2019 Creaci&oacute;n de Clase.
 *     </ul>
 *
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class CrossWholesaleInterceptorTest {

  @InjectMocks CrossWholsaleInterceptor crossWholsaleInterceptor;

  @Mock Chain chain;

  @Mock CustomHeaders header;

  @Test
  void interceptTest() throws IOException {
    Chain chain = mock(Chain.class);
    assertThrows(NullPointerException.class, () -> crossWholsaleInterceptor.intercept(chain));
  }

  @Test
  void interceptTwoTest() throws IOException {
    Request request =
        new Request.Builder()
            .url("https://apibs-product-rates.com")
            .method(
                "POST", RequestBody.create(MediaType.get("application/json;charset=UTF-8"), "{}"))
            .addHeader("Authorization", "Bearer hola")
            .build();
    Response response =
        new Response.Builder()
            .request(request)
            .protocol(Protocol.HTTP_1_1)
            .code(200)
            .message("OK")
            .body(ResponseBody.create(MediaType.get("application/json;charset=UTF-8"), "{}"))
            .build();
    when(chain.request()).thenReturn(request);
    when(chain.proceed(any(Request.class))).thenReturn(response);
    Assert.assertNotNull(crossWholsaleInterceptor.intercept(chain));
  }
}
