from pandas import DataFrame, concat, merge
from threading import Thread
from numpy import power, concatenate, ones, ndarray, where, copy, linspace, concatenate, array, clip
from pyme_engine.clv_pyme.clv_engine import utils_clv as clv, curves_all as curves, utils as ut, clv_data
"""
*******************************************************************************************************************************************
PROYECTO    :   CLV PYME NO REVOLVENTE 
TIPO        :   PYTHON

OBJETIVO    :   CALCULAR LOS INDICADORES DE RENTABILIDAD DE LOS DESEMBOLSOS Y REALIZAR LA ASIGNACIÓN DE TASAS.

REPROCESABLE:   SI

LISTADO DE MODELOS: (VALIDAR PARA PYME)
CÓDIGO MODELO       DESCRIPCIÓN MODELO
# MOD-BCP-0002938     CLV Crédito Efectivo
# MOD-BCP-0000008     Cancelaciones Crédito Efectivo
# MOD-BCP-0000009     Prepagos Crédito Efectivo
# MOD-BCP-0000103     LGD CLV - Crédito Efectivo
# MOD-BCP-0000554     Capital Económico para el Pricing Minorista
# MOD-BCP-0000572     PD CLV - Crédito Efectivo

VERSION     ANALISTA            RESPONSABLE TECNICO      FECHA          ESTADO                  DESCRIPCIÓN
2.2.2       JUAN JOSE GUILLEN   JUAN JOSE GUILLEN        31/08/2022     PENDIENTE               AGREGA FUNCIONALIDAD ALPHA.
2.2.1       JUAN JOSE GUILLEN   GONZALO LEZMA            01/05/2021     EN PRODUCCIÓN           PYTHONIZACION CLV EN EXCEL PARA CAMPAÑAS.

*******************************************************************************************************************************************
"""
class SetPath:

    def __init__(self): 

        self.hyperparams = {}
        self.clv_data = clv_data.ClvData.get_instance()

        self.set_path_product_codes()
        self.set_path_can()
        self.set_path_pd()
        self.set_path_pre()
        self.set_path_lgd()
        self.set_path_rr()
        self.set_path_ecap()
        self.set_path_costos()
        self.set_path_inof()
        self.set_path_tt_desc()
        
    def set_path_producto(self):
        producto_code=self.clv_data.data_frame_loaded['producto_code']
        producto_code_campaign=self.clv_data.data_frame_loaded['producto_code_campaign']
        hyperparams={
            "producto_code": producto_code,
            "producto_code_campaign": producto_code_campaign
        }
        self.hyperparams['PRODUCT']=hyperparams

    def set_path_product_codes(self):
        """ Carga en memoria los params para determinar el codigo de producto en evaluacion """
        producto_code = self.clv_data.data_frame_loaded['producto_code']
        producto_code_campaign = self.clv_data.data_frame_loaded['producto_code_campaign']

        # Asignando los params
        self.hyperparams["PRODUCT_CODE"] = {
            "producto_code": producto_code,
            "producto_code_campaign": producto_code_campaign
            }    

    def set_path_can(self):
        # param_tt = self.clv_data.data_frame_loaded['can_thetaTt']
        # param_bestfit = self.clv_data.data_frame_loaded['can_bestfit']
        param_tt = self.clv_data.data_frame_loaded['can_thetaTt']
        hyperparams={
            # "param_Tt": param_tt,
            # "param_bestfit": param_bestfit,
            "param_Tt": param_tt
        }
        self.hyperparams['CAN']=hyperparams

    def set_path_pd(self):
        param_tt = self.clv_data.data_frame_loaded['pd_thetaTt']
        param_t = self.clv_data.data_frame_loaded['pd_thetaT']
        param_scalar = self.clv_data.data_frame_loaded['pd_scalars']
        param_rangott = self.clv_data.data_frame_loaded['pd_rango_Tt']
        # filtering data
        #param_tt = param_tt[param_tt['product_code_final'].isin(self.__producto)]

        hyperparams = {
            "param_Tt": param_tt,
            "param_T": param_t,
            "param_scalar": param_scalar,
            "param_rangoTt": param_rangott
        }
        self.hyperparams['PD']=hyperparams

    def set_path_pre(self):
        # param_tt = self.clv_data.data_frame_loaded['pre_thetaTt']
        # param_bestfit = self.clv_data.data_frame_loaded['pre_bestfit']
        param_tt = self.clv_data.data_frame_loaded['pre_thetaTt']
        hyperparams = {
            # "param_Tt": param_tt,
            # "param_bestfit": param_bestfit,
            "param_Tt": param_tt
        }
        self.hyperparams['PRE']=hyperparams
    
    def set_path_lgd(self):
        param_t = self.clv_data.data_frame_loaded['lgd_thetaT']
        param_t_final = self.clv_data.data_frame_loaded['lgd_thetaT_final']
        # param_t_t_final = self.clv_data.data_frame_loaded['lgd_thetaT_T_final']
        param_localidad_zona = self.clv_data.data_frame_loaded['param_localidad_zona']
        # param_lgd_missing = self.clv_data.data_frame_loaded['param_lgd_missings']
        # param_lgd_values = self.clv_data.data_frame_loaded['param_lgd_values']
        param_lgd_for_ecap_map = self.clv_data.data_frame_loaded['lgd_for_ecap_map']
        param_lgd_wo = self.clv_data.data_frame_loaded['param_lgd_wo']
        hyperparams = {
            "param_coefs_curva_base":param_t,
            "param_coefs_curva_final":param_t_final,
            # "param_T_T_final":param_t_t_final,
            "param_localidad_zona":param_localidad_zona,
            # "param_lgd_missing":param_lgd_missing,
            # "param_lgd_values":param_lgd_values,
            "param_lgd_for_ecap_map":param_lgd_for_ecap_map,
            "param_lgd_wo":param_lgd_wo
        }
        self.hyperparams['LGD']=hyperparams

    def set_path_rr(self):
        param_t1 = self.clv_data.data_frame_loaded['roll1_coef']
        param_t2 = self.clv_data.data_frame_loaded['roll2_coef']
        param_factor1 = self.clv_data.data_frame_loaded['roll1_factor']
        param_factor2 = self.clv_data.data_frame_loaded['roll2_factor']
        # param_rr1 = self.clv_data.data_frame_loaded['roll1']
        # param_rr2 = self.clv_data.data_frame_loaded['roll2']
        producto_code_campaign = self.clv_data.data_frame_loaded['producto_code_campaign']
        # filtering data
        # param_t1 = param_t1[(param_t1['max_plazo'].isin(self.__terms))&(param_t1['product_code_final'].isin(self.__producto))]
        # param_t2 = param_t2[(param_t2['max_plazo'].isin(self.__terms))&(param_t1['product_code_final'].isin(self.__producto))]

        hyperparams1 = {
            "param_T1": param_t1,
            "param_factor1": param_factor1,
            # "param_rr1":param_rr1,
            "producto_code_campaign": producto_code_campaign}
        self.hyperparams['RR1']=hyperparams1

        hyperparams2 = {
            "param_T2": param_t2,
            "param_factor2": param_factor2,
            # "param_rr2":param_rr2,
            "producto_code_campaign": producto_code_campaign}
        self.hyperparams['RR2']=hyperparams2

    def set_path_ecap(self):
        param_scalar = self.clv_data.data_frame_loaded['ecap_scalars']
        param_pdttc = self.clv_data.data_frame_loaded['ecap_pd_ttc']
        hyperparams = {
            "param_scalar": param_scalar, 
            "param_PDTTC": param_pdttc
        }
        self.hyperparams['CAP']=hyperparams
    
    def set_path_cost(self):
        param_costos_t_0 = self.clv_data.data_frame_loaded['costos_t_0']
        param_costos_t_1_t = self.clv_data.data_frame_loaded['costos_t_1_T']

        hyperparams = {
            "param_costos_t_0":param_costos_t_0,
            "param_costos_t_1_T":param_costos_t_1_t
        }
        self.hyperparams['COST'] = hyperparams

    def set_path_costos(self):
        """ Carga en memoria los params del calculo de los costos """
        param_costos_t_0 = self.clv_data.data_frame_loaded['costos_t_0']
        param_costos_lifetime = self.clv_data.data_frame_loaded['costos_lifetime']

        # Asignando los params
        self.hyperparams["COST"] = {
            "param_costos_t_0": param_costos_t_0,
            "param_costos_lifetime": param_costos_lifetime
            }

    def set_path_inof(self):
        param_ixs = self.clv_data.data_frame_loaded['ingresos_x_servicios']
        hyperparams = {"param_ixs":param_ixs}
        self.hyperparams['INOF']=hyperparams

    def set_path_dscto(self):
        
        param_tasadescuento_tmin = self.clv_data.data_frame_loaded['descuentos_tasadescuento_tmin']
        param_tasadescuento_reactivo = self.clv_data.data_frame_loaded['descuentos_tasadescuento_reactivo']
        param_tasadescuento_cen = self.clv_data.data_frame_loaded['descuentos_tasadescuento_cen']
        param_tasadescuento_afi = self.clv_data.data_frame_loaded['descuentos_tasadescuento_afi']
        param_tasadescuento_alpha = self.clv_data.data_frame_loaded['descuentos_tasadescuento_alpha']
        param_remcap = self.clv_data.data_frame_loaded['param_remcap']
        param_prepagos = self.clv_data.data_frame_loaded['tt_prepagos']
        param_tt_factor = self.clv_data.data_frame_loaded['tt_zdf']

        
        # Asignando los params
        hyperparams = {
            "param_tasadescuento_tmin": param_tasadescuento_tmin,
            "param_tasadescuento_reactivo": param_tasadescuento_reactivo,
            "param_tasadescuento_cen": param_tasadescuento_cen,
            "param_tasadescuento_afi": param_tasadescuento_afi,
            "param_tasadescuento_alpha": param_tasadescuento_alpha,
            "param_remcap": param_remcap,
            "param_prepagos": param_prepagos,
            "param_tt_factor": param_tt_factor
            }

        self.hyperparams['TT_DSCTO']=hyperparams
    
    def set_external_data(self, input_clv):
        def set_param_tt_factor():
            param_tt_fact = self.clv_data.set_data_ttzdf(input_clv).data_frame_loaded["tt_zdf"]
            self.hyperparams['TT_DSCTO']["param_tt_factor"] = param_tt_fact

        def set_param_prepagos():
            param_tt_prepago = self.clv_data.set_data_prepagos(input_clv).data_frame_loaded["tt_prepagos"]
            self.hyperparams['TT_DSCTO']["param_prepagos"] = param_tt_prepago

        #MS: Para pruebas de verificacion se recomienda deshabilitar estas funciones
        #    para trabajar con la curvas de los archivos
        set_param_prepagos()
        set_param_tt_factor()

        return self

    def set_path_tt_desc(self):
        """Carga en memoria los params del calculo de la tasa de transferencia y las tasas de descuento"""
        param_tasadescuento_tmin = self.clv_data.data_frame_loaded['descuentos_tasadescuento_tmin']
        param_tasadescuento_reactivo = self.clv_data.data_frame_loaded['descuentos_tasadescuento_reactivo']
        param_tasadescuento_cen = self.clv_data.data_frame_loaded['descuentos_tasadescuento_cen']
        param_tasadescuento_afi = self.clv_data.data_frame_loaded['descuentos_tasadescuento_afi']
        param_tasadescuento_alpha = self.clv_data.data_frame_loaded['descuentos_tasadescuento_alpha']
        param_remcap = self.clv_data.data_frame_loaded['param_remcap']
        param_prepagos = self.clv_data.data_frame_loaded['tt_prepagos']
        param_tt_factor = self.clv_data.data_frame_loaded['tt_zdf']

        # Asignando los params
        self.hyperparams["TT_DSCTO"] = {
            "param_tasadescuento_tmin": param_tasadescuento_tmin,
            "param_tasadescuento_reactivo": param_tasadescuento_reactivo,
            "param_tasadescuento_cen": param_tasadescuento_cen,
            "param_tasadescuento_afi": param_tasadescuento_afi,
            "param_tasadescuento_alpha": param_tasadescuento_alpha,
            "param_remcap": param_remcap,
            "param_prepagos": param_prepagos,
            "param_tt_factor": param_tt_factor
            }

class CLVEngine():
    """ 
    Clase que permite calcular:
        - Tasas de interes optimizadas sujeto a criterios de tasa interna de retorno objetivo (Pricing)
        - Indicadores de rentabilidad de créditos sujeto a una tasa de interes especifica (Reporting)
    """

    def __init__(self, hyperparams=None, data=None,target_profitability_indicator=None, flag_monitoreo=False):
        setpath = SetPath()
        self.hyperparams = setpath.set_external_data(data).hyperparams if data is not None else setpath.hyperparams
        self.target_profitability_indicator = target_profitability_indicator
        self.flag_monitoreo = flag_monitoreo
        
        for key in self.hyperparams:
            setattr(self, key, self.hyperparams[key])

        for key in self.hyperparams['PRODUCT_CODE']:
            setattr(self, key, self.hyperparams['PRODUCT_CODE'][key])

        self.m, self.param, = None, None
        self.rmin = [None]
        self.curves = {
            "PD": None,
            "PRE": None,
            "CAN": None,
            "LGD": None,
            "RR1": None,
            "RR2": None,
            "CAP": None
            }
        self.X_tr = {
            "PD": None,
            "PRE": None,
            "CAN": None,
            "LGD": None,
            "RR1": None,
            "RR2": None,
            "CAP": None,
            "COST": None,
            "INOF": None,
            "TT_DSCTO": None,
            "descuentos": None,
            "desembolsos": None,
            "r": None,
            "T": None}
        self.curves_instances = { 
            "PD": curves.CurvePD(hyperparams=self.hyperparams['PD']),
            "PRE": curves.CurvePre(hyperparams=self.hyperparams['PRE']),
            "CAN": curves.CurveCan(hyperparams=self.hyperparams['CAN']),
            "LGD": curves.CurveLGD(hyperparams=self.hyperparams['LGD']),
            "RR1": curves.CurveRR1(hyperparams=self.hyperparams['RR1']),
            "RR2": curves.CurveRR2(hyperparams=self.hyperparams['RR2']),
            "CAP": curves.CurveCAP(hyperparams=self.hyperparams['CAP']),
            "COST": curves.CurveCostos(hyperparams=self.hyperparams['COST']),
            "INOF": curves.CurveInoF(hyperparams=self.hyperparams['INOF']),
            "TT_DSCTO": curves.CurvesTT_Desc(hyperparams=self.hyperparams["TT_DSCTO"],
					flag_monitoreo=self.flag_monitoreo)
		}


    def transform(self, X):
        """ Apply the transform methods of every curve
        """
        # Param producto code campaign
        self.producto_code_campaign = self.hyperparams["PRODUCT_CODE"]["producto_code_campaign"]

        # Se obtiene el código de producto
        # >> 1: WKC | 2: AFI | 3: AFM | 4: Multi | 5: WKC Alpha

        X = ut.get_product_code(X, self)
        self.product_code_final = X.product_code_final

        # Prueba para el producto AFI
        # X["product_code_final"] = 2
        # self.product_code_final = X["product_code_final"].values 

        if self.flag_monitoreo==False:
            if self.target_profitability_indicator == "ROA":
                self.X_tr['roa_target'] = X['roa_target'].values
                print("Profitability Target: ROA (Return on Assets)")
            elif self.target_profitability_indicator == "IRR":
                self.X_tr['descuentos_tea'] = power(1 + X["Tasa_dscto_tea"].values, 1/12) - 1 
                print("Profitability Target: IRR (Internal Rate of Return)")
            else:
                print("Profitability Target not defined by user")
 
        # Preproc Score 
        X.loc[:, "ScoreApplicantVendida"] = clip(X["ScoreApplicantVendida"].values, 0, 1000)
        X.loc[:, "ScoreApplicant"] = clip(X["ScoreApplicant"].values, 0, 1000)

        # Preproc Plazo 
        X.loc[:, "CantidadPlazo"] = clip(X["CantidadPlazo"].values, 1, 
                                    where(X["product_code_final"].values == 1, 36, 
                                    where(X["product_code_final"].values == 2, 144,
                                    where(X["product_code_final"].values == 3, 60,
                                    where(X["product_code_final"].values == 4, 72,
                                    where(X["product_code_final"].values == 5, 24, 144
                                    ))))))

        # Segmento Ortogonal 14 y missings
        b_menor1 = X["NumSegmentoOrtogonal"].values < 1
        X.loc[b_menor1, "NumSegmentoOrtogonal"] = 14
        X.loc[:, "NumSegmentoOrtogonal"] = clip(X.loc[:,"NumSegmentoOrtogonal"].values, 1, 14)
        X.loc[X['NumSegmentoOrtogonal'].values == 14, 'NumSegmentoOrtogonal'] = 5

        # Missings Antiguedad Pyme
        # AFI y Multi --> 69
        # AFM --> 59
        X.loc[:, "NumMesesAntiguedad"] = where(
            X['product_code_final'].isin([2, 4]), X["NumMesesAntiguedad"].fillna(69), where(
                X['product_code_final'].values == 3, X["NumMesesAntiguedad"].fillna(59), X["NumMesesAntiguedad"].values))

        # DeltaEntidades con tilde
        X.loc[:, "DeltaEntidades"] = where(X["DeltaEntidades"] == "0 ó menos", "0 o menos", X["DeltaEntidades"])

        # Transform de cada curva
        for key in self.curves_instances:
            self.X_tr[key] = self.curves_instances[key].transform(X)

        # Tasa de descuento para tasa minima y VAN 
        self.X_tr["descuentos_tmin"] = power(1 + self.X_tr["TT_DSCTO"]["Tasa_dscto"].values, 1/12) - 1  

        # Parametros para el cronograma
        self.X_tr["desembolsos"], self.X_tr["r"], self.X_tr["T"] = clv.get_tt_dscto_parameters_transform(X)
        self.m = X.shape[0]
        
        ## Otros valores
        self.monto_solicitado = X["MontoSolicitado"].values		
        if "CODCLAVECIC" in X.columns:
            self.operation = X["CODCLAVECIC"].values
        elif "NUMSOLICITUD" in X.columns:
            self.operation = X["NUMSOLICITUD"].values
        elif "CODCLAVEOPECTA" in X.columns:
            self.operation = X["CODCLAVEOPECTA"].values

        # TIR Objetivo como dato
        if "tir_objetivo" in X.columns:
            self.tir_input = power(1 + X["tir_objetivo"].values, 1/12) - 1 
        
        self.request_id = X["REQUEST_ID"].values if 'REQUEST_ID' in X.columns else X["NUMSOLICITUD"].values

        return self.X_tr


    def predict(self):
        """ Apply the predict methods of every curve
        """
        # Predict de cada curva
        for key in self.curves:
            if key == "CAP":  # Capital necesita PD12 & LGD_TTC
                self.X_tr[key]["PD12"] = self.curves_instances["PD"].pd12
                self.X_tr[key]["lgd_ttc"] = self.curves_instances["LGD"].lgd21
            self.curves[key] = self.curves_instances[key].predict(self.X_tr[key])
        
        return self.curves


    def get_parameters_pv(self):
        """ 
        Pack curves and values for the cash flow projection
        Returns: 
            self.param: python dictionary with curves and values for the cash flow projection
        """
        if self.param is None:
            self.param = clv.get_pv_param(self.X_tr, self.curves, self.X_tr["T"])


    def get_rmin(self, flag_monitoreo=False):
        """ 
        Compute the interest rate that yields an 19% annual internal rate of return (IRR) given the projected cash flows

        Parameters:
            flag_monitoreo: boolean that indicates if the transfer rate (TT) is known at the moment of the evaluation (True)
        
        Returns:
            self.rmin: numpy array with optmized monthly interest rates subject to an objective IRR
        """
        if self.param == None: self.get_parameters_pv()

        def funct(x): return clv.pv_structure(
            self.X_tr["descuentos_tmin"],
            self.X_tr["desembolsos"],
            x,
            self.X_tr["T"],
            self.param,
            flag_monitoreo).reshape(
            self.m,
        )

        def compute():
            r0 = ones((1, self.m))*0.16/12
            tmin = clv.pbroyden(funct, r0)
            return tmin.reshape(self.m,)

        self.rmin = compute()

        return self.rmin
    

    def get_tea_irr_target(self):
        """ 
        Compute the monthly interest rate that yields an objective IRR (different from the 19% annual internal rate of return - IRR) given the projected cash flows

        Returns:
            self.tea: numpy array with optmized monthly interest rates subject to an objective internal rate of return (IRR)
        """
        if self.param == None: self.get_parameters_pv()

        def funct(x): return clv.pv_structure(
            self.X_tr["descuentos_tea"],
            self.X_tr["desembolsos"],
            x,
            self.X_tr["T"],
            self.param).reshape(
            self.m,
        )

        def compute():
            r0 = ones((1, self.m))*0.16/12
            tea = clv.pbroyden(funct, r0)
            return tea.reshape(self.m,)

        self.tea = compute()

        return self.tea

    def get_tea_roa_target(self):
        """ 
        TODO: change the description
        Compute the monthly interest rate that yields an objective IRR (different from the 19% annual internal rate of return - IRR) given the projected cash flows

        Returns:
            self.tea: numpy array with optmized monthly interest rates subject to an objective internal rate of return (IRR)
        """
        if self.param == None: self.get_parameters_pv()

        def funct(x): return clv.roa_estimator(
            self.X_tr["roa_target"],
            self.X_tr["desembolsos"],
            x,
            self.X_tr["T"],
            self.param).reshape(
            self.m,
        )

        def compute():
            r0 = ones((1, self.m))*0.16/12
            tea = clv.pbroyden(funct, r0)
            return tea.reshape(self.m,)

        self.tea = compute()

        return self.tea

    def get_irr(self, r=None, flag_monitoreo=False):
        """ 
        Compute the monthly internal rate of return (IRR) given a monthly interest rate and its respective projected cash flows

        Parameters:
            r: Monthly interest rate for the cash flow projection
            flag_monitoreo: boolean that indicates if the transfer rate (TT) is known at the moment of the evaluation (True)

        Returns:
            self.irr: numpy array with the monthly internal rate of return
        """
        if self.param == None: self.get_parameters_pv()
        if not isinstance(r, ndarray): r = self.X_tr["r"]

        def funct(x): return clv.pv_structure(
            x,
            self.X_tr["desembolsos"],
            r,
            self.X_tr["T"],
            self.param,
            flag_monitoreo).reshape(
            self.m,
        )

        def compute():
            d0 = ones((1, self.m))*((1 + 0.19)**(1/12) - 1)
            tirs = clv.pbroyden(funct, d0)
            return tirs.reshape(self.m,)

        self.irr = compute()

        return self.irr


    def get_components(self, r, discount, dict_comp, flag_monitoreo=False, diff_meses=None):
        if self.param == None: self.get_parameters_pv()
        df = clv.get_components(discount, self.X_tr["desembolsos"], r, self.X_tr["T"], self.param, dict_comp, flag_monitoreo, diff_meses)
        return df


    def get_profitability_indicators(self):
        """ Returns: pandas DataFrame with profitability indicators
        >>> VAN, TIR, Rmin, Rmin decomposition, Average Capital, Average Balance
        """
        if self.param == None: self.get_parameters_pv()

        # Tmin
        self.get_rmin(flag_monitoreo=self.flag_monitoreo)
        rmins = power((1 + self.rmin), 12) - 1  # Se anualiza la Tmin

        if (self.flag_monitoreo==False) & (self.target_profitability_indicator!=None):
            # TEA
            if self.target_profitability_indicator == "IRR":
                self.get_tea_irr_target()
            elif self.target_profitability_indicator == "ROA":
                self.get_tea_roa_target()

            teas = power((1 + self.tea), 12) - 1  # Se anualiza la TEA

            # Profitabiity Indicators
            teas_mensual = power(1 + teas, 1/12) - 1

        # dict_comp = ["Componentes VAN Negativo", "Componentes VAN Positivo", "ROE",'ECAP','Margen - 24M']
        dict_comp = ["Net Present Value", "Net Profit", "ROE", "ECAP", "ROA", "Avg Balance", "TT"]
        # df_components = self.get_components(r=teas_mensual, discount=self.X_tr["descuentos"], dict_comp=dict_comp, flag_monitoreo=flag_monitoreo)
        # df_components = self.get_components(r=self.rmin, discount=self.X_tr["descuentos"], dict_comp=dict_comp, flag_monitoreo=flag_monitoreo)
        df_components = self.get_components(r=self.X_tr['r'], discount=self.X_tr["descuentos"], dict_comp=dict_comp, flag_monitoreo=flag_monitoreo)

        # Internal Rate of Return of TEA (IRR)
        self.get_irr(r=teas_mensual, flag_monitoreo=self.flag_monitoreo)   # ACTIVAR CUANDO ES PRICING
        # self.get_irr(r=self.rmin, flag_monitoreo=self.flag_monitoreo)      # Para reportar la TIR de Tmin, ejercicio 0.5 y 0.01
        # self.get_irr(flag_monitoreo=self.flag_monitoreo)                     # ACTIVAR CUANDO ES RENTABILIDAD
        tirs = power((1 + self.irr), 12) - 1  # Se anualiza la TIR

        # Minimum Rate Decomposition - NPV
        # dict_comp = ["Componentes VAN Negativo", "Componentes VAN Positivo"]
        # df_rmin_decomp = self.get_components(r=self.rmin, discount=self.X_tr["descuentos"], dict_comp=dict_comp, flag_monitoreo=flag_monitoreo)
        # df_rmin_decomp.columns = [col + "_Tmin" for col in df_rmin_decomp.columns]

        # Reporting 

        if (self.flag_monitoreo) | (self.target_profitability_indicator==None): 
            df = DataFrame({
                "CODCLAVECIC": self.operation,
                "RMIN": rmins,
                "Target IRR - Tmin": (power(1 + self.X_tr["descuentos_tmin"], 12) - 1).reshape(-1,),
                "IRR": tirs,
                "producto": self.product_code_final
            })
        else: 
            if self.target_profitability_indicator == "IRR":
                df = DataFrame({
                    "CODCLAVECIC": self.operation,
                    "RMIN": rmins,
                    "Target IRR - Tmin": (power(1 + self.X_tr["descuentos_tmin"], 12) - 1).reshape(-1,),
                    "TEA": teas,
                    "Target IRR - TEA": (power(1 + self.X_tr["descuentos_tea"], 12) - 1).reshape(-1,),
                    "IRR": tirs,
                    "producto": self.product_code_final
                })
            elif self.target_profitability_indicator == "ROA":
                df = DataFrame({
                    "CODCLAVECIC": self.operation,
                    "RMIN": rmins,
                    "Target IRR - Tmin": (power(1 + self.X_tr["descuentos_tmin"], 12) - 1).reshape(-1,),
                    "TEA": teas,
                    "Target ROA - TEA": self.X_tr["roa_target"].reshape(-1,),
                    "IRR": tirs,
                    "producto": self.product_code_final
                })
        
        # df_final = concat([df, df_components, df_rmin_decomp], axis=1) 
        df_final = concat([df, df_components], axis=1)

        return df_final


    def get_tasas_campana_azul_afi(self):
        """
        
        """
        if self.param == None: self.get_parameters_pv()

        # Tasa de la Campaña Azul (Tmin)
        self.get_rmin()
        rmins = power((1 + self.rmin), 12) - 1  # Se anualiza la Tmin
        
        # Reporte de Componentes de la Tmin
        dict_comp = ["Net Present Value", "ROE", "ECAP", "ROA", "Avg Balance", "TT"]
        df_components = self.get_components(r=self.rmin, discount=self.X_tr["descuentos_tmin"], dict_comp=dict_comp, flag_monitoreo=self.flag_monitoreo)

        # Reporting    
        df = DataFrame({
            "CODCLAVECIC": self.operation,
            "TEA": rmins,
            "Target IRR - TEA": (power(1 + self.X_tr["descuentos_tmin"], 12) - 1).reshape(-1,)
        })

        df_final = concat([df, df_components], axis=1)

        return df_final


    def get_profitability_datamart(self, flag_monitoreo=True):
        """ Returns: pandas DataFrame with profitability indicators
        >>> VAN, TIR, Rmin, Rmin decomposition, Average Capital, Average Balance
        """
        if self.param == None: self.get_parameters_pv()

        # Tmin
        self.get_rmin(flag_monitoreo=flag_monitoreo)
        rmins = power((1 + self.rmin), 12) - 1  # Se anualiza la Tmin

        # Minimum Rate Decomposition - NPV
        dict_comp = ["Componentes VAN Negativo", "Componentes VAN Positivo"]
        df_rmin_decomp = self.get_components(r=self.rmin, discount=self.X_tr["descuentos"], dict_comp=dict_comp, flag_monitoreo=flag_monitoreo)
        df_rmin_decomp.columns = [col + "_Tmin" for col in df_rmin_decomp.columns]

        # Profitabiity Indicators
        dict_comp = ["Net Present Value", "Net Profit", "ROE", "ECAP", "ROA", "Avg Balance"]
        # dict_com8p = ["Net Present Value", "ROE", "ECAP", "ROA", "Avg Balance", "Suma aritmetica costos", "Suma aritmetica saldos"]
        # dict_comp = ["PRE Curve", "CAN Curve"]
        # dict_comp = [
        #     "Net Present Value", "Net Profit", "ROE", "ECAP", "ROA", "Avg Balance", 
        #     "Costo venta", "Costo lifetime promedio", "Ingreso no financiero promedio",
        #     "Ingreso financiero promedio", "Egresos financieros promedio", "Impuestos promedio"
        #     ]
        df_components = self.get_components(r=self.X_tr["r"], discount=self.X_tr["descuentos"], dict_comp=dict_comp, flag_monitoreo=flag_monitoreo)

        # Internal Rate of Return (IRR)
        self.get_irr(flag_monitoreo=flag_monitoreo)
        tirs = power((1 + self.irr), 12) - 1  # Se anualiza la TIR

        # Reporting    
        df = DataFrame({
            "CODCLAVEOPECTA": self.operation,
            "RMIN": rmins,
            "Target IRR - Tmin": (power(1 + self.X_tr["descuentos"], 12) - 1).reshape(-1,),
            "IRR": tirs
        })

        df_final = concat([df, df_components, df_rmin_decomp], axis=1)
        # df_final = concat([df, df_components], axis=1)

        return df_final


    def getMinRate(self):

        self.get_parameters_pv()
        self.get_rmin()

        # b_null = isnan(self.rmin)
        # self.rmin[b_null] = (1 + 0.349)**(1/12) - 1
        # self.rmin = clip(self.rmin, (1 + 0.01)**(1/12) - 1, (1 + 0.349)**(1/12) - 1)

        df = DataFrame({
            "Min_Rate": power(1 + self.rmin, 12) - 1,
            "Target_IRR": (power(1 + self.X_tr["descuentos_tmin"], 12) - 1).reshape(-1, ),
            "REQUEST_ID": self.request_id
        })

        return df


    def getAggProfitability(self):

        self.get_parameters_pv()
        self.get_tea_irr_target()

        # b_null = isnan(self.tea)
        # self.tea[b_null] = (1 + 0.349)**(1/12) - 1
        # self.tea = clip(self.tea, (1 + 0.01)**(1/12) - 1, (1 + 0.349)**(1/12) - 1)

        self.get_irr()
        # b_null = isnan(self.irr)
        # self.irr[b_null] = (1 + 1)**(1/12) - 1
        # self.irr = clip(self.irr, (1 - 1)**(1/12) - 1, (1 + 1)**(1/12) - 1)

        dict_comp = [
            "Interest Income", "Cost of Funds", "NPV", "ROA", "ROE", "Net Profit",
            "ECAP", "Loss Rate", "Avg Balance"
        ]

        df = self.get_components(self.tea, self.X_tr["descuentos"], dict_comp)
        df.loc[:, "IRR"] = (power(1 + self.irr, 12) - 1).reshape(-1, )
      
        return df


    def getAllOutputs(self):

        self.get_parameters_pv()
        self.get_rmin(flag_monitoreo=self.flag_monitoreo)

        # b_null = isnan(self.rmin)
        # self.rmin[b_null] = (1 + 0.349)**(1/12) - 1
        # self.rmin = clip(self.rmin, (1 + 0.01)**(1/12) - 1, (1 + 4)**(1/12) - 1)

        self.get_irr(flag_monitoreo=self.flag_monitoreo)
        # b_null = isnan(self.irr)
        # self.irr[b_null] = (1 + 1)**(1/12) - 1
        # self.irr = clip(self.irr, (1 - 4)**(1/12) - 1, (1 + 4)**(1/12) - 1)

        df1 = DataFrame({
            "REQUEST_ID": self.request_id,
            # "CODCLAVEOPECTA": self.operation,
            "Min_Rate": power(1+ self.rmin, 12) - 1,
            "Target_IRR": (power(1 + self.X_tr["descuentos_tmin"], 12) - 1).reshape(-1,)
            })

        dict_comp = [
            "ECAP", "PD Curve", "PRE Curve", "CAN Curve", "Saldo Curve", "IF Curve", "EF Curve", "RemEC Curve", "EL Curve", 
            "INOF Curve", "LGD Curve", "TT"
            ]

        df2 = self.get_components(self.X_tr["r"], self.X_tr["descuentos_tmin"], dict_comp, flag_monitoreo=flag_monitoreo)

        df = concat((df1, df2), axis=1)

        df["IRR"] = (power(1 + self.irr, 12) - 1).reshape(-1,)
        df[["ROA", "Avg_Balance"]] = self.get_components(
            self.X_tr["r"], self.X_tr["descuentos_tmin"], dict_comp=["ROA", "Avg Balance"], flag_monitoreo=self.flag_monitoreo
            )[["ROA", "Avg_Balance"]]

        #### Impacto en PD ####

        # Temporales
        param_pd_acum_temp = self.param["cif_PD"]
        param_pd_cond_temp = self.param["PD"]
        param_can_cond_temp = self.param["CAN"]

        # Stress a la PD Acumulada (10%)
        self.param["cif_PD"] = clip(self.param["cif_PD"] * 1.1, 0, 1)
        # Actualizacion de las curvas condicionales
        self.param["PD"] , _ = clv.cif_to_cond_prob(clv.shift(self.param["cif_PD"], -2), clv.shift(self.param["cif_CAN"], 1), 1 , 1)
        self.param["CAN"] , _ = clv.cif_to_cond_prob(clv.shift(self.param["cif_CAN"], 0), clv.shift(self.param["cif_PD"], -2), 1, 1)

        # Calculo de nuevos indicadores dado el stress de la curva
        df[["PD_ECAP", "PD_ROA", "PD_Avg_Balance"]] = self.get_components(
            self.X_tr["r"], self.X_tr["descuentos_tmin"], dict_comp=["ECAP", "ROA", "Avg Balance"], flag_monitoreo=self.flag_monitoreo
            )[["ECAP", "ROA", "Avg_Balance"]]        
        df["PD_Min_Rate"] = power(1 + self.get_rmin(flag_monitoreo=self.flag_monitoreo), 12) - 1
        df["PD_IRR"] = power(1 + self.get_irr(flag_monitoreo=self.flag_monitoreo), 12) - 1

        # Eliminando el stress     
        self.param["cif_PD"] = param_pd_acum_temp
        self.param["PD"] = param_pd_cond_temp
        self.param["CAN"] = param_can_cond_temp 

        #### Impacto en PRE ####

        # Temporales
        param_pre_aux_tir = self.param["PRE"]

        # Stress al PRE (10%)
        self.param["PRE"] = clip(self.param["PRE"] * 1.1, 0, 1)

        # Calculo de nuevos indicadores dado el stress de la curva
        df[["PRE_ECAP", "PRE_ROA", "PRE_Avg_Balance"]] = self.get_components(
            self.X_tr["r"], self.X_tr["descuentos_tmin"], dict_comp=["ECAP", "ROA", "Avg Balance"], flag_monitoreo=self.flag_monitoreo
            )[["ECAP", "ROA", "Avg_Balance"]]
        df["PRE_Min_Rate"] = power(1 + self.get_rmin(flag_monitoreo=self.flag_monitoreo), 12) - 1
        df["PRE_IRR"] = power(1 + self.get_irr(flag_monitoreo=self.flag_monitoreo), 12) - 1 

        # Eliminando el stress 
        self.param["PRE"] = param_pre_aux_tir

        #### Impacto en CAN ####
        # Notese que ya no es necesario almacenar temporales porque es la ultima ejecucion de indicadores de rentabilidad

        # Stress a la Cancelacion Acumulada (10%)
        self.param["cif_CAN"] = clip(self.param["cif_CAN"] * 1.1, 0, 1)
        # Actualizacion de las curvas condicionales
        self.param["PD"] , _ = clv.cif_to_cond_prob(clv.shift(self.param["cif_PD"], -2), clv.shift(self.param["cif_CAN"], 1), 1 , 1)
        self.param["CAN"] , _ = clv.cif_to_cond_prob(clv.shift(self.param["cif_CAN"], 0), clv.shift(self.param["cif_PD"], -2), 1, 1)

        # Calculo de nuevos indicadores dado el stress de la curva
        df[["CAN_ECAP", "CAN_ROA", "CAN_Avg_Balance"]] = self.get_components(
            self.X_tr["r"], self.X_tr["descuentos_tmin"], dict_comp=["ECAP", "ROA", "Avg Balance"], flag_monitoreo=self.flag_monitoreo
            )[["ECAP", "ROA", "Avg_Balance"]]
        df["CAN_Min_Rate"] = power(1 + self.get_rmin(flag_monitoreo=self.flag_monitoreo), 12) - 1
        df["CAN_IRR"]  = power(1 + self.get_irr(flag_monitoreo=self.flag_monitoreo), 12) - 1

        # Limpiando observaciones con errores
        b_drop = (df['IRR'] > 4) | (df['IRR'] < -1) | (df['Min_Rate'] > 4) | (df['PD_IRR'] > 4) | (df['PD_IRR'] < -1) | (df['PD_Min_Rate'] > 4) \
            | (df['PRE_IRR'] > 4) | (df['PRE_IRR'] < -1) | (df['PRE_Min_Rate'] > 4) | (df['CAN_IRR'] > 4) | (df['CAN_IRR'] < -1) | (df['CAN_Min_Rate'] > 4)

        df.drop(df[b_drop].index, inplace=True)
        df.dropna(inplace=True)

        return df

    
    def get_wtp_afi_process(self, X, param_dscto_competencia, param_rn_afi):
        """
        """
        X = X.copy()
        
        # Variables relevantes
        # df_escenarios = X[["CODCLAVECIC", "Escenario", "Escenario2", "ID", "Cluster", "T_PD", "T_MTO", "MontoSolicitado", "MontoTasaEspecial", "Prob"]]
        df_escenarios = X.copy()
        # df_escenarios.sort_values(by=["CODCLAVECIC", "Escenario_mto_order"], axis=0, inplace=True, ignore_index=True)
        df_escenarios["TEA"] = df_escenarios.loc[:,"MontoTasaEspecial"].values
        # df_escenarios.rename(columns={"MontoTasaEspecial": "TEA"}, inplace=True)
        
        # VAN de la Tasa de la Base Inicial
        self.transform(df_escenarios)
        self.predict()
        self.get_parameters_pv()  # Actualizando el self.param con shape = escenarios
        df_escenarios["VAN"] = self.get_components(self.X_tr["r"], self.X_tr["descuentos_tmin"], dict_comp=["Net Present Value"])["NPV"].values

        # Elección de escenario que maximice VAN Esperado
        df_escenarios["VAN Esperado"] = df_escenarios["Prob"]*df_escenarios["VAN"]
        df_escenarios_piv = df_escenarios.pivot_table(index=["CODCLAVECIC"], values=["VAN Esperado"], aggfunc="max").reset_index()
        # df_winners contiene solo el escenario ganador para cada cliente (CODCLAVECIC)
        df_winners = merge(df_escenarios_piv, df_escenarios, on=["CODCLAVECIC", "VAN Esperado"], how="left")

        # Calculando TEA Promedio (Escenario Base / Escenario Winners)
        tea_pred = df_escenarios[df_escenarios["Escenario"]=="L5"][["CODCLAVECIC", "TEA"]]  # Escenario Base = L5
        tea_pred.rename(columns={"TEA": "TEA_Pred"}, inplace=True)
        df_winners = merge(df_winners, tea_pred, on=["CODCLAVECIC"], how="left")
        df_winners["TEA_Prom"] = (df_winners["TEA"] + df_winners["TEA_Pred"]) / 2

        # Agregando Descuento de la Competencia al df_winners
        df_winners = merge(df_winners, param_dscto_competencia, on=["cluster", "T_PD", "T_MTO"], how="left")
        df_winners["TEA_Prom_ConDscto"] = where(df_winners["Prob"] < df_winners["Prob_Prom"], df_winners["TEA_Prom"] - df_winners["Dscto_Tasa_Competencia"], df_winners["TEA_Prom"])

        # Cálculo de la PD 12 CLV
        self.transform(df_winners)
        self.predict()
        self.get_parameters_pv()  # Actualizando el param con shape = winners     
        # df_winners_pd12 = self.curves_instances["PD"].pd12_covid
        df_winners_pd12 = self.curves_instances["PD"].pd12

        # TEA Con Reglas de Negocio Sin Dscto de la Competencia (Comentar)
        # df_winners["TEA_CRN_SinDscto"] = ut.reglas_de_negocio(df_winners["MontoSolicitado"], param_rn_afi, df_winners_pd12, df_winners["TEA_Prom"], self.flag_cen, self.flag_afi)
        df_winners["TEA_CRN_SinDscto"] = ut.reglas_de_negocio_afi(df_winners["MontoSolicitado"], param_rn_afi, df_winners_pd12, df_winners["TEA_Prom"])

        # TEA Con Reglas de Negocio CON Dscto de la Competencia
        # df_winners["TEA_CRN_ConDscto"] = ut.reglas_de_negocio(df_winners["MontoSolicitado"], param_rn_afi, df_winners_pd12, df_winners["TEA_Prom_ConDscto"], self.flag_cen, self.flag_afi)
        df_winners["TEA_CRN_ConDscto"] = ut.reglas_de_negocio_afi(df_winners["MontoSolicitado"], param_rn_afi, df_winners_pd12, df_winners["TEA_Prom_ConDscto"])

        # CAP MIN TIR 19% - TEA CRN CON DSCTO
        tea_crn_mensual = power(1 + df_winners["TEA_CRN_ConDscto"].values, 1/12) - 1
        self.get_irr(r=tea_crn_mensual.reshape(1,-1))  # Recibe tea_crn mensual
        tir_tea_crn = power(1 + self.irr, 12) - 1
        b = tir_tea_crn <= 0.19

        # CAP MIN TIR 19% - TEA CRN SIN DSCTO
        tea_crn_mensual_sd = power(1 + df_winners["TEA_CRN_SinDscto"].values, 1/12) - 1
        self.get_irr(r=tea_crn_mensual_sd.reshape(1,-1))  # Recibe tea_crn mensual
        tir_tea_crn_sd = power(1 + self.irr, 12) - 1
        b_sd = tir_tea_crn_sd <= 0.19

        # Cálculo de la Rmin 19%
        self.get_rmin()

        # Imputando la Rmin a las operaciones con TIR < 19%
        tea_crn_mensual[b] = self.rmin[b]
        tea_crn_mensual_sd[b_sd] = self.rmin[b_sd]

        # TEA Final Anual CRN, SIN DSCTO Y CON CAP
        tea_crn_anual_sd = power(1 + tea_crn_mensual_sd, 12) - 1
        df_winners["TEA_CRN_SinDscto"] = tea_crn_anual_sd
        # TIR TEA Final Sin Dscto
        self.get_irr(r=tea_crn_mensual_sd)
        tir_tea_crn_sindscto = power(1 + self.irr, 12) - 1
        df_winners["TIR - TEA_CRN_SinDscto"] = tir_tea_crn_sindscto.reshape(-1,)

        # TEA Final Anual CRN, CON DSCTO, Y CON CAP
        tea_final_mensual = copy(tea_crn_mensual)
        tea_final = power(1 + tea_final_mensual, 12) - 1
        df_winners["TEA_Final"] = tea_final.reshape(-1,)
        # TIR de la TEA Final Con Dscto
        self.get_irr(r=tea_final_mensual)  # Recibe tea_final_mensual
        irr_tea_final = power(1 + self.irr, 12) - 1
        df_winners["TIR - TEA_Final"] = irr_tea_final

        # # Proceso Habitual
        self.get_rmin_tea()
        tea_leads_habitual = power(1 + self.tea, 12) - 1
        tea_leads_habitual = ut.reglas_de_negocio(df_winners["MontoSolicitado"], param_rn_afi, df_winners_pd12, tea_leads_habitual, self.flag_cen, self.flag_afi)
        df_winners["TEA - CLV Habitual"] = tea_leads_habitual

        # # TIR Tasa Proceso Habitual
        tea_leads_habitual_mensual = power(1 + tea_leads_habitual, 1/12) - 1
        self.get_irr(r=tea_leads_habitual_mensual)
        irr_tea_habitual = power(1 + self.irr, 12) - 1
        df_winners["TIR - TEA_Habitual"] = irr_tea_habitual.reshape(-1,)

        # Reportando la TT ZC de la tasa mínima
        df_winners['TT_ZC_Tmin'] = self.get_components(self.rmin, self.X_tr['descuentos'], dict_comp=['TT'])['TT']
        df_winners['TT_ZC_TFinal'] = self.get_components(tea_final_mensual, self.X_tr['descuentos'], dict_comp=['TT'])['TT']

        return df_winners


    def get_wtp_cen_scenarios(self, inputs):
        """ Genera los distintos escenarios de tasa que insume el WTP de Capital de Trabajo

        Args:
            pandas DataFrame con formato CLV (debe incluir el monto real y el monto sombra para el cálculo de tasa)

        Returns: 
            pandas DataFrame que contiene el CODCLAVECIC, N° Escenario de Tasa, Tasa, VAN, TT (ZC)

        --> RN:
        - Redondeo de la tasa base clv (.0 o .5)
        - Step de tasa debe ser .5
        - 13 escenarios (Piso debe ser el redondeo de la tmin a tir 19% / Tope sería 50%)
        - Global 300 hacia abajo (con el limite de tmin)
        - cluster 3 y 4 hasta 400 hacia arriba, 5 hasta 500 hacia arriba (probarlo)
        """

        #### Constantes ####
        NUM_ESCENARIOS = 15  # Debe ser impar
        SIZE_DF = inputs.shape[0]*NUM_ESCENARIOS
        PISO = 0.10
        TECHO = 0.50
        MOV_PBS_ABAJO_GLOBAL = 300
        MOV_PBS_ARRIBA_C_1_2 = 300
        MOV_PBS_ARRIBA_C_3_4 = 350
        MOV_PBS_ARRIBA_C_5 = 400

        #### Proceso ####
        inputs = inputs.copy()
        self.transform(inputs)
        self.predict()
        self.get_parameters_pv()

        # Calculando la Tasa Minima para el piso de tasa de los escenarios
        self.get_rmin()
        tmin_tir19 = power(1 + self.rmin, 12) - 1
        tmin_tir19 = ut.get_redondeo(tmin_tir19, step=0.005)
        tmin_tir19 = clip(tmin_tir19, PISO, TECHO)

        # Calculando la Tasa apuntando a TIR Objetivo de campañas (Por definir)
        if self.target_profitability_indicator == "IRR":
            self.get_tea_irr_target()
        elif self.target_profitability_indicator == "ROA":
            self.get_tea_roa_target()
        else:
            print("Profitability Target not define correctly")

        tea_tir_objetivo_advisory = power(1 + self.tea, 12) - 1
        tea_tir_objetivo_advisory = ut.get_redondeo(tea_tir_objetivo_advisory, step=0.005)
        tea_tir_objetivo_advisory = clip(tea_tir_objetivo_advisory, PISO, TECHO)

        # Creando los escenarios de tasa
        
        cluster = inputs["cluster"].values
        df_reglas_de_negocio = inputs[["CODCLAVECIC"]]
        df_reglas_de_negocio["tasa_clv"] = tea_tir_objetivo_advisory
        df_reglas_de_negocio["tasa_piso"] = maximum(tmin_tir19, PISO)
        df_reglas_de_negocio["tasa_techo"] = TECHO
        df_reglas_de_negocio["pbs_abajo"] = MOV_PBS_ABAJO_GLOBAL / 10_000
        df_reglas_de_negocio["pbs_arriba"] = where(
            cluster == 5, MOV_PBS_ARRIBA_C_5 / 10_000, where(
                cluster >= 3, MOV_PBS_ARRIBA_C_3_4 / 10_000, MOV_PBS_ARRIBA_C_1_2 / 10_000))

        # Generando 17 escenarios de tasa para luego filtrarlos en base a reglas de negocio
        tasas_abajo = linspace(tea_tir_objetivo_advisory - MOV_PBS_ABAJO_GLOBAL / 10_000, tea_tir_objetivo_advisory, num=7, axis=1)
        tasas_arribas = linspace(tea_tir_objetivo_advisory + 0.005, tea_tir_objetivo_advisory + MOV_PBS_ARRIBA_C_5 / 10_000, num=int(MOV_PBS_ARRIBA_C_5 / 50), axis=1)
        tasas_escenarios_vector = concatenate((tasas_abajo, tasas_arribas), axis=1).reshape(-1,)

        # Generando las columnas adicionales
        num_escenario_vector = array([[x]*inputs.shape[0] for x in range(-6, 8 + 1)]).T.reshape(-1,)
        codclavecic_np_repeated = array([[x]*NUM_ESCENARIOS for x in inputs['CODCLAVECIC']]).reshape(-1,)

        # Generando el df de reporte con todos los escenarios posibles
        df = DataFrame(index=range(SIZE_DF))
        df['CODCLAVECIC'] = codclavecic_np_repeated
        df['tea'] = tasas_escenarios_vector
        df['Escenario'] = num_escenario_vector

        # Filtrando los escenarios que cumplen con las condiciones predefinidas
        df_esc = merge(df, df_reglas_de_negocio, on=["CODCLAVECIC"], how="left")
        df_esc = df_esc[(df_esc["tea"] <= df_esc["tasa_techo"]) & (df_esc["tea"] >= df_esc["tasa_piso"])]
        df_esc = df_esc[(df_esc["tea"] <= df_esc["tasa_clv"] + df_esc["pbs_arriba"]) & (df_esc["tea"] >= df_esc["tasa_clv"] - df_esc["pbs_abajo"])]
        inputs_escenarios = merge(df_esc, inputs, on=['CODCLAVECIC'], how='left')

        # Reemplazamos el monto real para calcular los indicadores de rentabilidad
        # inputs_escenarios.loc[:, "MontoSolicitado"] = inputs_escenarios["monto_ofertado_real"].values
        self.transform(inputs_escenarios)
        self.predict()
        self.get_parameters_pv()

        # Mensualizando
        tasas_mensual_escenarios = power(1 + inputs_escenarios["tea"].values, 1/12) - 1
        self.get_irr(r=tasas_mensual_escenarios)

        # TIR
        inputs_escenarios['TIR'] = (power(1 + self.irr, 12) - 1).reshape(-1,)

        # Calculando la TT (ZC) y VAN de cada tasa
        df_components = self.get_components(tasas_mensual_escenarios, self.X_tr['descuentos_tmin'], dict_comp=['Net Present Value', 'TT'])

        # Concatenando el df final de los escenarios
        df_escenarios = concat((inputs_escenarios, df_components), axis=1)

        return df_escenarios


    def get_rates_with_tir_input(self):
        """ Calcula una tasa de interés con una TIR Objetivo Dato

        Returns:
            1-dimensional ndarray with the effective annual rate (TEA)
        """
        self.X_tr['descuentos_tea'] = self.tir_input  # Actualiza la TIR Objetivo al valor que venga en X
        self.get_tea_irr_target()  # Calcula Tasa con la TIR Obj Actualizada
        return (power(1 + self.tea, 12) - 1).reshape(-1,)  # Reporta la tasa anualizada


    def get_board_and_autonomy_interest_rates(self):
        """ 

        Returns:
            pandas DataFrame with interest rates and their profitability indicators
                > Interest rate 1: Board interest rate 
                > Interest rate 2: Minimum interest rate to trigger autonomy exception 
        """

        self.get_parameters_pv()

        # Tasa Pizarra y Tasa Autonomía
        self.get_rates_with_tir_input()

        # Reporting    
        df1 = DataFrame({
            # "CODCLAVEOPECTA": self.operation,
            "REQUEST_ID": self.request_id,
            "Min_Rate": (power((1 + self.tea), 12) - 1).reshape(-1,),
            "Target_IRR": (power(1 + self.X_tr["descuentos_tea"], 12) - 1).reshape(-1,)
        })

        # Reportando componentes
        dict_comp = ["NPV", "Net Profit", "ECAP"]
        df_comp = self.get_components(self.tea, self.X_tr["descuentos_tmin"], dict_comp)

        df = concat((df1, df_comp), axis=1)
        
        return df


    def get_irr_of_input_rate(self):
        """ 

        Returns:
            pandas DataFrame with Internal Rate of Return (IRR) and profitability indicators of the input rate
        """

        self.get_parameters_pv()

        # TIR
        # TODO: No está actualizando TT (REVISAR) 
        self.get_irr()

        # Reporting    
        df1 = DataFrame({
            # "CODCLAVEOPECTA": self.operation,
            "REQUEST_ID": self.request_id,
            "IRR": (power((1 + self.irr), 12) - 1).reshape(-1,),
        })

        # Reportando componentes
        dict_comp = ["NPV", "Net Profit", "ECAP", "TT"]
        df_comp = self.get_components(self.X_tr["r"], self.X_tr["descuentos_tmin"], dict_comp)

        df = concat((df1, df_comp), axis=1)
        
        return df