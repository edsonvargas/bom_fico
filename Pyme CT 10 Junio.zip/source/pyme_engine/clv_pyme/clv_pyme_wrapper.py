from pandas import DataFrame, concat, merge

from pyme_engine.clv_pyme.clv_engine import clv_data
from math import ceil
from numpy import nan, log
# from threading import Thread


class ClvPymeWrapper(object):

    def __init__(self, X, clv_transforms=None, clv_curves=None, change_desembolso=True):
        self.clv_data_instance=clv_data.ClvData.get_instance()
        X["MESAPERTURA"]=X["REQUEST_ID"]
        self.df_input=X      
        self.clv_transforms=clv_transforms
        self.clv_curves=clv_curves
        self.change_desembolso=change_desembolso
        self.__homologateInputs(self.df_input)
        # self.th = Thread(target=self.__homologateInputs, args=(self.df_input,))
        # self.th.start()

    def __format_result(self, clv_result, clv_input):
        columns_outputs = ['Min_Rate', 'Interest_Income', 'Cost_of_Funds', 'NPV',
                           'IRR', 'ROA', 'ROE', 'Net_Profit', 'ECAP',
                           'Loss_Rate', 'Avg_Balance', 'Avg_Balance_Yr1', 'Avg_Balance_Yr2', 'Avg_Balance_Yr3',
                           'Avg_Balance_Yr4', 'Avg_Balance_Yr5', 'Target_IRR', 'Capital_Flow_Yr1',
                           'Capital_Remuneration_Yr1', 'Interest_Income_Yr1',
                           'Non_Financial_Income_Yr1', 'Cost_of_Funds_Yr1', 'Losses_Yr1',
                           'Direct_Costs_Yr1', 'Indirect_Costs_Yr1', 'Income_Tax_Yr1',
                           'Capital_Flow_NPV_Yr1',
                           'Capital_Remuneration_NPV_Yr1', 'Interest_Income_NPV_Yr1',
                           'Non_Financial_Income_NPV_Yr1', 'Cost_of_Funds_NPV_Yr1', 'Losses_NPV_Yr1',
                           'Direct_Costs_NPV_Yr1', 'Indirect_Costs_NPV_Yr1', 'Income_Tax_NPV_Yr1',
                           'Capital_Flow_Yr2', 'Capital_Remuneration_Yr2',
                           'Interest_Income_Yr2',
                           'Non_Financial_Income_Yr2', 'Cost_of_Funds_Yr2', 'Losses_Yr2',
                           'Direct_Costs_Yr2', 'Indirect_Costs_Yr2', 'Income_Tax_Yr2',
                           'Capital_Flow_NPV_Yr2',
                           'Capital_Remuneration_NPV_Yr2', 'Interest_Income_NPV_Yr2',
                           'Non_Financial_Income_NPV_Yr2', 'Cost_of_Funds_NPV_Yr2', 'Losses_NPV_Yr2',
                           'Direct_Costs_NPV_Yr2', 'Indirect_Costs_NPV_Yr2', 'Income_Tax_NPV_Yr2',
                           'Capital_Flow_Yr3', 'Capital_Remuneration_Yr3',
                           'Interest_Income_Yr3',
                           'Non_Financial_Income_Yr3', 'Cost_of_Funds_Yr3', 'Losses_Yr3',
                           'Direct_Costs_Yr3', 'Indirect_Costs_Yr3', 'Income_Tax_Yr3',
                           'Capital_Flow_NPV_Yr3',
                           'Capital_Remuneration_NPV_Yr3', 'Interest_Income_NPV_Yr3',
                           'Non_Financial_Income_NPV_Yr3', 'Cost_of_Funds_NPV_Yr3', 'Losses_NPV_Yr3',
                           'Direct_Costs_NPV_Yr3', 'Indirect_Costs_NPV_Yr3', 'Income_Tax_NPV_Yr3',
                           'Capital_Flow_Yr4', 'Capital_Remuneration_Yr4',
                           'Interest_Income_Yr4',
                           'Non_Financial_Income_Yr4', 'Cost_of_Funds_Yr4', 'Losses_Yr4',
                           'Direct_Costs_Yr4', 'Indirect_Costs_Yr4', 'Income_Tax_Yr4',
                           'Capital_Flow_NPV_Yr4',
                           'Capital_Remuneration_NPV_Yr4', 'Interest_Income_NPV_Yr4',
                           'Non_Financial_Income_NPV_Yr4', 'Cost_of_Funds_NPV_Yr4', 'Losses_NPV_Yr4',
                           'Direct_Costs_NPV_Yr4', 'Indirect_Costs_NPV_Yr4', 'Income_Tax_NPV_Yr4',
                           'Capital_Flow_Yr5', 'Capital_Remuneration_Yr5',
                           'Interest_Income_Yr5',
                           'Non_Financial_Income_Yr5', 'Cost_of_Funds_Yr5', 'Losses_Yr5',
                           'Direct_Costs_Yr5', 'Indirect_Costs_Yr5', 'Income_Tax_Yr5',
                           'Capital_Flow_NPV_Yr5',
                           'Capital_Remuneration_NPV_Yr5', 'Interest_Income_NPV_Yr5',
                           'Non_Financial_Income_NPV_Yr5', 'Cost_of_Funds_NPV_Yr5', 'Losses_NPV_Yr5',
                           'Direct_Costs_NPV_Yr5', 'Indirect_Costs_NPV_Yr5', 'Income_Tax_NPV_Yr5',
                           'PD1', 'PD2', 'PD3', 'PD4', 'PD5', 'PD6',
                           'PD7', 'PD8', 'PD9', 'PD10', 'PD11', 'PD12',
                           'PD13', 'PD14', 'PD15', 'PD16', 'PD17', 'PD18',
                           'PD19', 'PD20', 'PD21', 'PD22', 'PD23', 'PD24',
                           'PD25', 'PD26', 'PD27', 'PD28', 'PD29', 'PD30',
                           'PD31', 'PD32', 'PD33', 'PD34', 'PD35', 'PD36',
                           'CAN1', 'CAN2', 'CAN3', 'CAN4', 'CAN5', 'CAN6',
                           'CAN7', 'CAN8', 'CAN9', 'CAN10', 'CAN11',
                           'CAN12', 'CAN13', 'CAN14', 'CAN15', 'CAN16',
                           'CAN17', 'CAN18', 'CAN19', 'CAN20', 'CAN21',
                           'CAN22', 'CAN23', 'CAN24', 'CAN25', 'CAN26',
                           'CAN27', 'CAN28', 'CAN29', 'CAN30', 'CAN31',
                           'CAN32', 'CAN33', 'CAN34', 'CAN35', 'CAN36',
                           'PRE1', 'PRE2', 'PRE3', 'PRE4', 'PRE5', 'PRE6',
                           'PRE7', 'PRE8', 'PRE9', 'PRE10', 'PRE11',
                           'PRE12', 'PRE13', 'PRE14', 'PRE15', 'PRE16',
                           'PRE17', 'PRE18', 'PRE19', 'PRE20', 'PRE21',
                           'PRE22', 'PRE23', 'PRE24', 'PRE25', 'PRE26',
                           'PRE27', 'PRE28', 'PRE29', 'PRE30', 'PRE31',
                           'PRE32', 'PRE33', 'PRE34', 'PRE35', 'PRE36',
                           'SALDOPROM1', 'SALDOPROM2', 'SALDOPROM3', 'SALDOPROM4',
                           'SALDOPROM5', 'SALDOPROM6', 'SALDOPROM7', 'SALDOPROM8',
                           'SALDOPROM9', 'SALDOPROM10', 'SALDOPROM11', 'SALDOPROM12',
                           'SALDOPROM13', 'SALDOPROM14', 'SALDOPROM15', 'SALDOPROM16',
                           'SALDOPROM17', 'SALDOPROM18', 'SALDOPROM19', 'SALDOPROM20',
                           'SALDOPROM21', 'SALDOPROM22', 'SALDOPROM23', 'SALDOPROM24',
                           'SALDOPROM25', 'SALDOPROM26', 'SALDOPROM27', 'SALDOPROM28',
                           'SALDOPROM29', 'SALDOPROM30', 'SALDOPROM31', 'SALDOPROM32',
                           'SALDOPROM33', 'SALDOPROM34', 'SALDOPROM35', 'SALDOPROM36',
                           'IF1', 'IF2', 'IF3', 'IF4', 'IF5', 'IF6',
                           'IF7', 'IF8', 'IF9', 'IF10', 'IF11', 'IF12',
                           'IF13', 'IF14', 'IF15', 'IF16', 'IF17', 'IF18',
                           'IF19', 'IF20', 'IF21', 'IF22', 'IF23', 'IF24',
                           'IF25', 'IF26', 'IF27', 'IF28', 'IF29', 'IF30',
                           'IF31', 'IF32', 'IF33', 'IF34', 'IF35', 'IF36',
                           'EF1', 'EF2', 'EF3', 'EF4', 'EF5', 'EF6',
                           'EF7', 'EF8', 'EF9', 'EF10', 'EF11', 'EF12',
                           'EF13', 'EF14', 'EF15', 'EF16', 'EF17', 'EF18',
                           'EF19', 'EF20', 'EF21', 'EF22', 'EF23', 'EF24',
                           'EF25', 'EF26', 'EF27', 'EF28', 'EF29', 'EF30',
                           'EF31', 'EF32', 'EF33', 'EF34', 'EF35', 'EF36',
                           'TT',
                           'REQUEST_ID']
        
        clv_input['MontoSolicitado']=clv_input['MontoSolicitadoOriginal']
        clv_result = merge(clv_result,clv_input[['REQUEST_ID','ColchonTt']],on=['REQUEST_ID'])

        # colchon adicional para plazos mayores a 24 para CT
        if 'Min_Rate' in clv_result.columns:
            clv_result['Min_Rate']=clv_result['Min_Rate']+clv_result['ColchonTt']
        else:
            clv_result['Min_Rate']=nan

        # formateando la salida
        df_result = DataFrame(columns=columns_outputs)
        df_join = concat([df_result, clv_result], join="inner", ignore_index=True)
        df_result = df_result._append(df_join)
        df_result = df_result.fillna("NaN")
    
        return df_result

    def __preprocessing(self, df_input):
        from pyme_engine.clv_pyme.clv_engine import CLV_Engine as pricing
        from pyme_engine.clv_pyme.clv_engine import utils_clv as clv
        from numpy import array

        def preprocessing(clv_transforms, clv_curves, df_input, engine):

            # --------------------------------
            # transform
            # --------------------------------
            engine.m = len(df_input)
            def pre_transform(name ,xtr):
                if name not in ['COST','descuentos','desembolsos','r','T','descuentos_tea','descuentos_tmin']:
                    print(name)
                    df_xtr = merge(xtr, df_input['PREVIOUS_INDEX'],left_index=True, right_on='PREVIOUS_INDEX')
                    engine.X_tr[name] = df_xtr.drop(columns=['PREVIOUS_INDEX'])
                    return

                if name in ['COST']:
                    index=df_input['PREVIOUS_INDEX'][0]

                    costos_t_0_fact = [xtr[0][index]]*engine.m
                    costos_lifetime_fact=[]
                    for i in range(len(xtr[1])):
                        costos_lifetime_fact.append([xtr[1][i][0]]*engine.m)

                    engine.X_tr[name] = array(costos_t_0_fact), array(costos_lifetime_fact)
            [pre_transform(name,xtr) for name,xtr in clv_transforms.items()]
                
            engine.X_tr["desembolsos"], engine.X_tr["r"], engine.X_tr["T"] = clv.get_tt_dscto_parameters_transform(df_input)
            engine.request_id = df_input['REQUEST_ID']

            # --------------------------------
            # predict
            # --------------------------------
            def pre_predict(name, curva):
                curva = merge(curva, df_input['PREVIOUS_INDEX'],left_index=True, right_on='PREVIOUS_INDEX')
                engine.curves[name] = curva.drop(columns=['PREVIOUS_INDEX'])
            [pre_predict(name,curva) for name,curva in clv_curves.items()]

            engine.X_tr["descuentos"], engine.X_tr["descuentos_tea"] = clv.get_tt_dscto_parameters_predict(engine.m, engine.curves["TT_DSCTO"])

        # procesamiento
        if "TIPO_TIR_OBJETIVO" in df_input.columns:
            target_value_indicator =  "IRR"
            
        # if self.clv_transforms is None:
        #     engine = pricing.CLVEngine(data=df_input, target_profitability_indicator=target_value_indicator)
        #     engine.transform(df_input)
        #     engine.predict()
        # else:
        #     engine = pricing.CLVEngine(target_profitability_indicator=target_value_indicator)
        #     preprocessing(self.clv_transforms,self.clv_curves, df_input, engine)

        # self.clv_transforms=engine.X_tr
        # self.clv_curves=engine.curves
        
        engine = pricing.CLVEngine(data=df_input, target_profitability_indicator=target_value_indicator)
        engine.transform(df_input)
        engine.predict()

        return engine

    def __chooseImpl(self, df_input):
        from pyme_engine.clv_pyme.clv_engine import utils as ut

        # dado se deben realizar distintos calculos dependiento del req_type se crea el for 
        df_final = DataFrame()  
        req_types = df_input["REQ_TYPE"].drop_duplicates()
        engine = self.__preprocessing(df_input)

        for req_type in req_types:
            if req_type == 1:
                clv_result = engine.getMinRate()
            elif req_type == 3:
                clv_result = engine.get_irr_of_input_rate()
            elif req_type == 7:
                clv_result = engine.getAllOutputs()
            else:
                clv_result = engine.get_board_and_autonomy_interest_rates()

            requests_id = df_input[df_input["REQ_TYPE"]==req_type]["REQUEST_ID"]
            clv_result = clv_result[clv_result["REQUEST_ID"].isin(requests_id)]
            df_final = df_final._append(clv_result, ignore_index=True)
            if "Min_Rate" in df_final.columns:
                df_final["Min_Rate"]=ut.get_redondeo(df_final["Min_Rate"],step=0.005)
        
        return df_final

    def __homologateInputs(self, df_input): 
        from pyme_engine.clv_pyme.clv_engine import utils

        equivalent = {
            'CAMPANA_MIC':'CampanaMic',
            'CANAL_EVALUACION':'canal_venta',
            'CANTIDAD_PLAZO':'CantidadPlazo',
            'CODIGO_CAMPANAMIC':'CodigoCampanaMic',
            # 'COMPRA_DEUDA':'CompraDeuda',
            'DELTA_ENTIDADES':'DeltaEntidades',
            'DEUDA_BCP':'DeudaBCP',
            'ESTADO_ACTIVO':'EstadoActivo',
            # The above code is importing the module 'clv_data' from the package
            # 'lv_pyme.pyme_engine'.
            'FLG_COMPORTAMIENTO_PERSONA':'FlgComportamientoPersona',
            'FLG_TENENCIA_PASIVO':'FlgTenenciaPasivo',
            'LOCALIDAD_MIC':'LocalidadMic',
            'MESES_ANTIGUEDAD':'NumMesesAntiguedad',
            'MONEDA':'Moneda',
            'MONTO_APORTE_PRODUCTO':'MontoAporteProducto',
            'MONTO_FAD':'MontoFAD',
            'MONTO_GARANTIA_AFECTACION':'MontoGarantiaAfectacion',
            'MONTO_GARANTIA_BCP':'MontoGarantiaBCP',
            'MONTO_GARANTIA_COMERCIAL':'MontoGarantiaComercial',
            # 'MONTO_LIBRE_GARANTIA_AF':'MontoLibreGarantiaAF',
            # 'MONTO_LIBRE_GARANTIA_CT':'MontoLibreGarantiaCT',
            'MONTO_SOLICITADO':'MontoSolicitado',
            'TASA_ESPECIAL':'MontoTasaEspecial',
            # 'NIVEL_RIESGO':'CodNivelRiesgo',
            'PD':'MontoPD',
            'PD_MAXIMA':'PDMaxima',
            'PD_VENDIDA':'NumPDVendida',
            'PERIODO_GRACIA':'PeriodoGracia',
            'PRODUCTO_MIC':'ProductoMic',
            'MTO_DEU_RCC_PRM_U6M':'MtoDeuRccPrmU6m',
            'MTO_DEU_RCC_PRM_U12M':'MtoDeuRccPrmU12m',
            'MTO_DEU_RCC_PRM_U24M':'MtoDeuRccPrmU24m',
            # 'RATIO_ENDEUDAMIENTO':'RatioEndeudamiento',
            # 'RATIO_ENDEUDAMIENTO_U6MU12M':'RatioEndeudamientoU6MU12M',
            'RESEGMENTO_COMERCIAL':'ResegmentoComercial',
            'SCORE_APPLICANT':'ScoreApplicant',
            'SCORE_APPLICANT_VENDIDA':'ScoreApplicantVendida',
            'SECTOR_ECONOMICO':'SectorEconomico',
            'SEGMENTO_MGR':'NumSegmentoMGR',
            'SEGMENTO_ORTOGONAL':'NumSegmentoOrtogonal',
            'TIPO_ACTIVO':'TipoActivo',
            'TIPO_CAMBIO':'MontoTipoCambio',
            'TIPO_CREDITO_MIC':'TipoCreditoMic',
            'V_CODLOCALIDAD':'V_CodLocalidad',
            'VALOR_ACTIVO':'ValorActivo',
            'ZONA':'Zona',
            'TIR_OBJETIVO':'tir_objetivo'
        }

        column_type = {
            'MESAPERTURA':str,
            'REQUEST_ID':str,
            'CampanaMic':str,
            'CantidadPlazo':int,
            'CodigoCampanaMic':str,
            # 'CompraDeuda':str,
            'DeltaEntidades':str,
            'DeudaBCP':float,
            'EstadoActivo':str,
            # 'FlgComportamientoPersona':int,
            'FlgTenenciaPasivo':int,
            'LocalidadMic':str,
            'NumMesesAntiguedad':int,
            'Moneda':str,
            'MontoAporteProducto':float,
            'MontoFAD':float,
            'MontoGarantiaAfectacion':float,
            'MontoGarantiaBCP':float,
            'MontoGarantiaComercial':float,
            # 'MontoLibreGarantiaAF':float,
            # 'MontoLibreGarantiaCT':float,
            'MontoSolicitado':float,
            'MontoTasaEspecial':float,
            # 'CodNivelRiesgo':int,
            'MontoPD':float,
            'PDMaxima':float,
            'NumPDVendida':float,
            'PeriodoGracia':int,
            'ProductoMic':str,
            'MtoDeuRccPrmU6m':float,
            'MtoDeuRccPrmU12m':float,
            'MtoDeuRccPrmU24m':float,
            'ResegmentoComercial':str,
            'ScoreApplicant':int,
            'ScoreApplicantVendida':int,
            'SectorEconomico':str,
            'NumSegmentoMGR':int,
            'NumSegmentoOrtogonal':int,
            'TipoActivo':str,
            'MontoTipoCambio':float,
            'TipoCreditoMic':str,
            'V_CodLocalidad':int,
            'ValorActivo':float,
            'REQ_TYPE':int,
            'tir_objetivo':float
            # 'TieneGarantia': str
        }
        
        df = df_input.rename(columns=equivalent).astype(column_type)
        df = df.copy()

        # realizar ajustes para q funcione el CLV
        df["PDMaxima"]=0.08
        df['ScoreMinimo']='OK'
        nroDeltaEntidades = df['DeltaEntidades'].astype(float).astype(int).values
        #nroDeltaEntidades = df['DeltaEntidades'].astype(int).values
        nuevasColumnas = [["SIN",nroDeltaEntidades[x],-1] for x in range(len(df.index))]
        df = concat([df,DataFrame(nuevasColumnas,columns=['TieneGarantia','NroDeltaEntidades','TT'])],axis=1)
        df.loc[df["MontoGarantiaBCP"] > 0, 'TieneGarantia'] = "CON"
        # reglas adicionales para pasar al clv
        df.loc[(df.NroDeltaEntidades)>=1,'DeltaEntidades']='Incrementa'
        df.loc[(df.NroDeltaEntidades)<1,'DeltaEntidades']='0 o menos'
        
        RatioEndeudamientoVal = df[['MtoDeuRccPrmU12m','MtoDeuRccPrmU24m']].values
        RatioEndeudamiento = [0 if RatioEndeudamientoVal[i][1]<=0 else  \
                                        RatioEndeudamientoVal[i][0]/RatioEndeudamientoVal[i][1] \
                                        for i in range(len(RatioEndeudamientoVal))]
        df = concat([df,DataFrame(RatioEndeudamiento,columns=['RatioEndeudamiento'])],axis=1)
        RatioEndeudamientoU6MU12MVal = df[['MtoDeuRccPrmU6m','MtoDeuRccPrmU12m']].values
        RatioEndeudamientoU6MU12M = [0 if RatioEndeudamientoU6MU12MVal[i][1]<=0 else  \
                                        RatioEndeudamientoU6MU12MVal[i][0]/RatioEndeudamientoU6MU12MVal[i][1] \
                                        for i in range(len(RatioEndeudamientoU6MU12MVal))]
        df = concat([df,DataFrame(RatioEndeudamientoU6MU12M,columns=['RatioEndeudamientoU6MU12M'])],axis=1)
        
        #MS: Para pruebas se recomienda que el tratamiento de ratios de endeudamiento sea directo para que cuadre
        #    con modelo

        #df['RatioEndeudamiento'] = df['MtoDeuRccPrmU6m']
        #df['RatioEndeudamientoU6MU12M'] = df['MtoDeuRccPrmU12m']

        df.loc[df.NumSegmentoMGR.isin([3,6]),'FlgComportamientoPersona']=1
        #df['FlgComportamientoPersona'].fillna(0)
        df['FlgComportamientoPersona'] = df['FlgComportamientoPersona'].fillna(0)

        self.producto_code_campaign = self.clv_data_instance.data_frame_loaded['producto_code_campaign']
        df_product_code = utils.get_product_code(df,self)
        df["product_code_final"] = df_product_code["product_code_final"]

        df.loc[df.Moneda=='PEN','Moneda']='SOLES'
        df.loc[df.Moneda=='USD','Moneda']='DOLARES'

        # MS: Esta transformacion no permite cuadrar con modelos
        # se acota a plazo 24 para CT, MS 20230803 : se acota el plazo a 36
        df['PlazoOriginal']=df["CantidadPlazo"]
        df.loc[(df.CantidadPlazo>36) & (df.TIPO_CLV=='CT'), 'CantidadPlazo']=36
        #df.loc[(df.CantidadPlazo>36) & (df.TIPO_CLV=='AF'), 'CantidadPlazo']=36
        #AF
        df.loc[(df.product_code_final==2) & (df.CantidadPlazo>144) & (df.TIPO_CLV=='AF'), 'CantidadPlazo']=144
        df.loc[(df.product_code_final==3) & (df.CantidadPlazo>60) & (df.TIPO_CLV=='AF'), 'CantidadPlazo']=60
        df.loc[(df.product_code_final==4) & (df.CantidadPlazo>72) & (df.TIPO_CLV=='AF'), 'CantidadPlazo']=72

        df['ColchonTt']=df.apply(lambda x: max(x['TT36']-x['TT24'],0) if x['TIPO_CLV']=='CT' and x['PlazoOriginal']>24 else 0, axis=1)

        df['NumSegmentoOrtogonal']=df['NumSegmentoOrtogonal'].fillna(5)

        # se acota el monto para CT
        df['MontoSolicitadoOriginal']=df['MontoSolicitado']
        df_monto_pd = self.clv_data_instance.data_frame_loaded["param_monto_pd"]
        def filter_by_monto(row):
            monto_pd_filtered = df_monto_pd[(row.product_code_final==df_monto_pd.product_code ) & \
                                          (row.MontoPD<=df_monto_pd.pd) &\
                                          (row.MontoSolicitado<=df_monto_pd.monto)]
            result = monto_pd_filtered.iloc[0]['monto_nuevo'] if len(monto_pd_filtered)>0 else row.MontoSolicitado
            return result
        
        #MS: Esta transformacion no permite cuadrar con modelos
        if self.change_desembolso:
            df['MontoSolicitado'] = df.apply(lambda x: filter_by_monto(x), axis=1)

        ###################################


        # transformacion de pd a score
        df.loc[df.MontoPD>0.95,'ScoreApplicantVendida']=3
        df.loc[df.MontoPD<=0.95,'ScoreApplicantVendida']=round(-57.707801636*log(df['MontoPD']/(1-df['MontoPD']))+174.24575241, 0)
        df['ScoreApplicant']=df['ScoreApplicantVendida']
        ###################################

        #asignar valroes default
        #df["DeltaEntidades"] = 'Incrementa'
        #df["FlgTenenciaPasivo"] = 1
        #df["NumMesesAntiguedad"] = 80
        #SegmentoOrtogonalInputs = df[['TIPO_CLV','MontoPD']].values
        #TempSegmentoOrtogonal = [5 if (SegmentoOrtogonalInputs[i][1]<=0.05 and SegmentoOrtogonalInputs[i][0] == 'CT') \
        #                            else 3 if (SegmentoOrtogonalInputs[i][0] == 'CT') 
        #                            else 5 if (SegmentoOrtogonalInputs[i][1]<=0.04 and SegmentoOrtogonalInputs[i][0] == 'AF') \
        #                            else 3 if (SegmentoOrtogonalInputs[i][1]<=0.06 and SegmentoOrtogonalInputs[i][0] == 'AF') \
        #                            else 2 if (SegmentoOrtogonalInputs[i][1]<=0.08 and SegmentoOrtogonalInputs[i][0] == 'AF') \
        #                            else 14
        #                                for i in range(len(SegmentoOrtogonalInputs))]
        #df["NumSegmentoOrtogonal"] = TempSegmentoOrtogonal

        #MS 20230814 - Temporal hasta que se envie el dato en decimales
        df["MontoTasaEspecial"] = df["MontoTasaEspecial"]/100
        df["Tasa_dscto_tea"]=df["tir_objetivo"]
        df["canal_venta"]="TRADICIONAL" #TODO: esto se asigna pq actualmente no se envia el campo por parte del

        self.df_input= df

    # Main prediction function
    def predict(self):
        # self.th.join() 

        df = self.df_input
        df_clv_result = self.__chooseImpl(df)
        df_final = self.__format_result(df_clv_result, df)

        return df_final, df
