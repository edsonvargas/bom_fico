package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;




/**
 * <b>Class</b>: Product.java <br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Ago 1, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Data
@Entity
@Table(name = "credit_info_cp_req",schema = "prcg_mayorista")
public class CreditInfoCpRequest {

  @Column(name = "credit_info_cp_req_id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Id
  private Integer creditInfoCpReqId;

  @Column(name = "channel_req_id")
  private String channelReqId;

  @Column(name = "interest_rate")
  private BigDecimal interestRate;

  @Column(name = "exchange_type")
  private BigDecimal exchangeType;

  @Column(name = "customer_info_idc")
  private String customerInfoIdc;

  @Column(name = "customer_info_specific_debt")
  private BigDecimal customerInfoSpecificDebt;

  @Column(name = "customer_info_specific_debt_dleace")
  private BigDecimal customerInfoSpecificDebtDleace;

  @Column(name = "flag_black_list")
  private Boolean flagBlackList;

  @Column(name = "guarantor_info_idc")
  private String guarantorInfoIdc;

  @Column(name = "credit_info_cp_currency_code")
  private String creditInfoCpCurrencyCode;

  @Column(name = "credit_info_cp_currency_description")
  private String creditInfoCpCurrencyDescription;

  @Column(name = "credit_info_cp_product_code")
  private String creditInfoCpProductCode;

  @Column(name = "credit_info_cp_libor_days")
  private Integer creditInfoCpLiborDays;

  @Column(name = "credit_info_cp_loan_amount")
  private BigDecimal creditInfoCpLoanAmount;

  @Column(name = "credit_info_cp_term")
  private Integer creditInfoCpTerm;

  @Column(name = "credit_info_cp_rate_type")
  private String creditInfoCpRateType;

  @Column(name = "credit_info_cp_loan_renewal")
  private BigDecimal creditInfoCpLoanRenewal;

  @Column(name = "credit_info_special_funding_percentage")
  private BigDecimal creditInfoSpecialFundingPercentage;

  @Column(name = "credit_info_cp_operation_type")
  private String creditInfoCpOperationType;

  @Column(name = "credit_info_cp_dleace_count")
  private Integer creditInfoCpDleaceCount;

  @Column(name = "register_date")
  private LocalDateTime registerDate;

  @Column(name = "product_type")
  private String productType;

  @Column(name = "type_guarantee_letter")
  private String typeGuaranteeLetter;

}
