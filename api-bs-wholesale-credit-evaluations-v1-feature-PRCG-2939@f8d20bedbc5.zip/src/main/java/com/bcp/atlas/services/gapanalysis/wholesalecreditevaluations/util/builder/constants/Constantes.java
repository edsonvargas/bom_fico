package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants;

/**
 * <b>Class</b>: Util<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis Peru SAC <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Feb 24, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
public class Constantes {

  public static final String MENSAJE_ERROR_ID_NO_EXISTE = "El valor ingresado no existe." ;


  private Constantes() { }

  public static final String SHA_256 = "SHA-256";
  public static final String CORTO_PLAZO = "CP";
  public static final String SAVE_OK_OPERATION_NUMBER =
      "Número de operación generado correctamente";

  public static final String MESSAGE = "El quotationId ingresado no es correcto.";
  public static final String MESSAGE_TL0006 = "El customer no se encuentra en Alexandria";
  public static final String CODE_TL0006 = "TL0006";
  public static final String ERROR_TYPE_FUNCTIONAL = "FUNCTIONAL";
  public static final String ERROR_TYPE = "FUNCTIONAL ALEXANDRIA";
  public static final int DEFAULT_ZERO_VALUE = 0;
  public static final int DEFAULT_PROUDCT_GAIN_SIZE = 3;
  public static final int DEFAULT_GUARANTEE_SIZE = 20;
  public static final String FECHA_YYYY_MM_DD = "yyyy-MM-dd";
  public static final String BANKING_TYPE_CODE_E = "E";
  public static final String BEARER = "Bearer ";
  public static final String SALESFORCE_APPCODE = "JH";

  public static final String ERROR_TYPE_FICO_DM = "FUNCTIONAL FICO_DM";
  public static final String ERROR_TYPE_FICO_MLX = "FUNCTIONAL FICO_MLX";

  //req contingentes
  public static final String ERROR_TYPE_PROCEDURE = "FUNCTIONAL PROCEDURE PRCG";
  public static final String MESSAGE_PROCEDURE = "La consulta al procedimiento no retorna ningun registro";
  //fin
  public static final String ERROR_CODE_PR0001 = "PR0001";
  public static final String ERROR_CODE_PR0002 = "PR0002";
  public static final String ERROR_CODE_PR0003 = "PR0003";
  public static final String ERROR_CODE_PR0004 = "PR0004";
  public static final String ERROR_CODE_PR0005 = "PR0005";
  public static final String ERROR_CODE_PR0006 = "PR0006";
  public static final String ERROR_CODE_PR0007 = "PR0007";
  public static final String ERROR_CODE_PR0008 = "PR0008";
  public static final String ERROR_CODE_PR0009 = "PR0009";
  public static final String ERROR_CODE_PR0010 = "PR0010";
  //req. contingentes
  public static final String ERROR_CODE_PR0011 = "PR0011";


  public static final String MESSAGE_ERROR_400 = "El request body enviado es incorrecto";
  public static final String MESSAGE_ERROR_401 = "No se puede autenticar";
  public static final String MESSAGE_ERROR_403 = "No se encuentra autorizado";
  public static final String MESSAGE_ERROR_404 = "El servidor no pudo encontrar el servicio "
      + "solicitado";
  public static final String MESSAGE_ERROR_409 = "La petición tiene un conflicto con el estdo "
      + "actual"
      + " del servidor";
  public static final String MESSAGE_ERROR_412 = "No cumplen las precondiciones del servidor";
  public static final String MESSAGE_ERROR_503 = "Servicio no se encuentra disponible en este "
      + "momento";
  public static final String MESSAGE_ERROR_408 = "Se produjo un timeout";
  public static final String MESSAGE_ERROR_500 = "Se produjo un error interno";

}
