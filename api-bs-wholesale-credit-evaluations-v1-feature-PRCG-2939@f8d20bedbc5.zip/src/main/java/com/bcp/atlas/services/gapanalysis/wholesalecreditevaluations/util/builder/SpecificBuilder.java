package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.SpecificClWarrantiesReq;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * <br/>
 * Clase Interfaz del Servicio para la logica de negocio que consumira la clase REST
 * RateCalculationController<br/>
 * <b>Class</b>: FicoRequest<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Mar 25, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Component
@Slf4j
public class SpecificBuilder {

  /**
   * Method getIncentives()
   *
   * @version 1.0
   */
  public List<SpecificClWarrantiesReq> generateDbObjectSpecific(
          Integer reqId, Request request) {
    List<SpecificClWarrantiesReq> specificClWarrantiesReqList = new ArrayList<>();
    for (int i = 0; i < request.getCreditInfo()
            .getSpecificCreditLinesWarranties().size(); i++) {
      SpecificClWarrantiesReq specificClWarrantiesReq = new SpecificClWarrantiesReq();
      specificClWarrantiesReq.setCreditInfoCpReqId(reqId);
      specificClWarrantiesReq.setWarrantiesCode(request.getCreditInfo()
              .getSpecificCreditLinesWarranties().get(i).getWarrantyCode());
      specificClWarrantiesReq.setCurrencyCode(request.getCreditInfo()
              .getSpecificCreditLinesWarranties().get(i).getCurrency().getCode().getValue());
      specificClWarrantiesReq.setCurrencyDesc(request.getCreditInfo()
              .getSpecificCreditLinesWarranties().get(i).getCurrency().getDescription().getValue());
      specificClWarrantiesReq.setWarrantyType(
          request.getCreditInfo()
              .getSpecificCreditLinesWarranties().get(i).getWarrantyType().getValue());

      specificClWarrantiesReq.setCommercialValue(request.getCreditInfo()
              .getSpecificCreditLinesWarranties().get(i).getCommercialValue());
      specificClWarrantiesReq.setAffectedValue(
          request.getCreditInfo().getSpecificCreditLinesWarranties().get(i).getAffectedValue());
      specificClWarrantiesReq.setRealizationValue(
          request.getCreditInfo().getSpecificCreditLinesWarranties().get(i).getRealizationValue());
      specificClWarrantiesReq.setUtilizationLine(
          request.getCreditInfo().getSpecificCreditLinesWarranties().get(i).getUtilizationLine());

      specificClWarrantiesReq.setRegisterDate(LocalDateTime.now());
      specificClWarrantiesReqList.add(specificClWarrantiesReq);

    }

    return specificClWarrantiesReqList;
  }

}


