
import os
import pandas as pd
import clv_pyme.clv_pyme_wrapper as pricing

######################  

path = './inputMock.csv'
sample_df = pd.read_csv(path, nrows = 10)
sample_input = sample_df.head(100)
sample_input

######################

from clv_cef.clv_cef_wrapper import ClvCefWrapper
import pandas as pd

path = './inputMock.csv'
wrapper = ClvCefWrapper()

sample_input = pd.read_csv(path)
sample_output = wrapper.predict(sample_input.values, sample_input.columns)


class_pack = ClassPack.prepare(ClvCefWrapper, sample_input, sample_output)
print('termino')
sample_output.head()

######################

from fico.mlxp import load_mlxctl_config
load_mlxctl_config()

pip_excludes_list = ['torch', 'tensor', 'jupyter', 'keras', 'opencv-python', 'mkl-fft', 'mkl-random', 'mkl-service','pywin32', 'brotlipy']
pip_includes_config = [ 'seaborn', 'clv-cef']

#Adding clv package
path_whl = os.path.abspath('clv_pyme-1.0-py3-none-any.whl')
print(path_whl)
class_pack.add_whl(path_whl)
model_submission = class_pack.submit(name='bcp-clv-cef-v1', pip_excludes=pip_excludes_list, pip_includes=pip_includes_config)
                                    
model_submission.status()