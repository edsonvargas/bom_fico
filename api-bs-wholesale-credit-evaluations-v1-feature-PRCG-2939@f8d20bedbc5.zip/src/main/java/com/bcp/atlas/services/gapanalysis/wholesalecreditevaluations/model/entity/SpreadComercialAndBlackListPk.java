package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;

/**
 * <b>Class</b>: SpreadComercialAndBlackListPk<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis Peru SAC <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Feb 24, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */

@Data
public class SpreadComercialAndBlackListPk implements Serializable {

  private BigDecimal spreadComercial;

  private BigDecimal blacklistRate;

}
