package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.core.constants.ErrorCategory;
import com.bcp.atlas.core.exception.ApiException;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import io.vavr.Tuple3;
import java.util.Map;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

/**
 * <b>Class</b>: ErrorHandlerBuilder<br>
 * <b>Copyright</b>: &copy; 2018 Banco de Cr&eacute;dito del Per&uacute;.<br>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br>
 *     <u>Service Provider</u>: Everis <br>
 *     <u>Developed by</u>: <br>
 *     <ul>
 *     </ul>
 *     <u>Changes</u>:<br>
 *     <ul>
 *       <li>Jul 26 2019 Creaci&oacute;n de Clase.
 *     </ul>
 *
 * @version 1.0
 */
@Component
@Slf4j
public class ErrorHandlerBuilder extends RuntimeException {

  @Autowired
  private Map<Integer, Tuple3<String, String, String>> errorCategoriesMap;

  /**
   * Method buildApiException
   *
   * @version 1.0
   */
  public ApiException buildApiException(int code, String errorType, String trace) {
    log.error(trace);
    if (Objects.nonNull(errorCategoriesMap.get(code))) {
      return ApiException.builder()
          .description(errorCategoriesMap.get(code)._3)
          .errorType(errorType)
          .cause(new Throwable(errorCategoriesMap.get(code)._3))
          .category(ErrorCategory.valueOf(errorCategoriesMap.get(code)._1))
          .systemCode(errorCategoriesMap.get(code)._2)
          .build();
    } else {
      return ApiException.builder().errorType(Constantes.ERROR_TYPE).build();
    }
  }

  /**
   * Method validateStatusCode
   *
   * @version 1.0
   */
  public <T> T validateStatusCode(final T object, int code, String errorType, String trace) {

    if (HttpStatus.OK.value() == code) {
      return object;
    } else {
      throw buildApiException(code, errorType, trace);
    }
  }

  /**
   * Method validateAlexandriaException
   *
   * @version 1.0
   */
  public CustomerGetResponse validateAlexandriaException(
      CustomerGetResponse customerGetResponse, int code) {

    if (HttpStatus.OK.value() == code) {
      return ObjectUtils.defaultIfNull(customerGetResponse, new CustomerGetResponse());
    } else if (HttpStatus.NO_CONTENT.value() == code) {
      throw ApiException.builder()
          .description(Constantes.MESSAGE_TL0006)
          .errorType(Constantes.ERROR_TYPE)
          .cause(new Throwable(Constantes.MESSAGE_TL0006))
          .category(ErrorCategory.CONFLICT)
          .systemCode(Constantes.CODE_TL0006)
          .build();
    } else {
      throw buildApiException(code, Constantes.ERROR_TYPE, StringUtils.EMPTY);
    }
  }
}
