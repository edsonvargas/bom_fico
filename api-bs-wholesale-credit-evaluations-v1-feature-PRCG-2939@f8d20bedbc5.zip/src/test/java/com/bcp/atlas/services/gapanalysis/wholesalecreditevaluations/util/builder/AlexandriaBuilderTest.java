package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.MapperUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * <b>Class</b>: Util<br>
 * <b>Copyright</b>: &copy; 2022 Banco de Cr&eacute;dito del Per&uacute;.<br>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br>
 *     <u>Service Provider</u>: Everis Peru SAC <br>
 *     <u>Developed by</u>: <br>
 *     <ul>
 *     </ul>
 *     <u>Changes</u>:<br>
 *     <ul>
 *       <li>Nov 11, 2022 Creaci&oacute;n de Clase.
 *     </ul>
 *
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class AlexandriaBuilderTest {

  @InjectMocks AlexandriaBuilder alexandriaBuilder;

  @Test
  void whenAlexandriaResponseDefaultTest() {
    CustomerGetResponse customerGetResponse =
        MapperUtils.convertToObject("AlexandriaResponse" + ".json", CustomerGetResponse.class);
    Assertions.assertNull(alexandriaBuilder.getAlexandria(null, true));
    Assertions.assertNotNull(alexandriaBuilder.getAlexandria(customerGetResponse, true));
    Assertions.assertNotNull(alexandriaBuilder.getAlexandria(customerGetResponse, false));
    Assertions.assertNotNull(alexandriaBuilder.getAlexandria(null, false));
  }
}
