package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.BankingType;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.BusinessUnit;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.ClassificationRating;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CommercialActivity;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.Currency;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.DefaultProbability;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.EconomicActivities;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.ExposureLevelRcc;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.Guarantee;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.GuaranteeProduct;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.GuaranteeScope;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.ProductRate;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.ProductRateGain;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.Ratio;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.Risk;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.RiskClassificationBcp;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.RiskClassificationCovid;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.SubSegment;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.Util;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;




/**
 * <b>Class</b>: AlexandriaBuilder<br/>
 * <b>Copyright</b>: &copy; 2018 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Jul 26 2019 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Component
@Slf4j
public class AlexandriaBuilder {

  /**
   * This method is used to process the response.
   *
   * @param alexandriaCustomer {@Link CreditAdmissionGetResponse}
   * @return {@Link CreditAdmissionGetResponse}
   */
  public CustomerGetResponse getAlexandria(
      CustomerGetResponse alexandriaCustomer,
      boolean isCustomer) {

    if ((Objects.nonNull(alexandriaCustomer))
        && (Objects.nonNull(alexandriaCustomer.getIdc()))) {
      return getCustomerData(alexandriaCustomer);
    } else if (!isCustomer) {
      return getGuarantorDefaultData();
    } else {
      return alexandriaCustomer;
    }

  }

  /**
   * Method getCustomerData
   *
   * @version 1.0
   */
  public CustomerGetResponse getCustomerData(CustomerGetResponse alex) {
    CustomerGetResponse customerGetResponse = new CustomerGetResponse();
    customerGetResponse.setCustomerId(alex.getCustomerId());
    customerGetResponse.setYearsAsClient(Util.getDefaultValueBig(alex.getYearsAsClient()));
    customerGetResponse.setFlagLinkedCredicorp(
        Util.getDefaultValueString(alex.getFlagLinkedCredicorp()));

    Ratio ratio = new Ratio();
    ratio.setActiveFinancialMarginRatio(
        Util.getDefaultValueBig(
            ObjectUtils.defaultIfNull(alex.getRatio(),new Ratio())
                .getActiveFinancialMarginRatio()));
    ratio.setRefinancedDirectDebtVsTotalSbsRatio(
        Util.getDefaultValueBig(
            ObjectUtils.defaultIfNull(alex.getRatio(),new Ratio())
                .getRefinancedDirectDebtVsTotalSbsRatio()));

    customerGetResponse.setRatio(ratio);

    CommercialActivity commercialActivity = ObjectUtils.defaultIfNull(alex.getCommercialActivity(),
                                                                      new CommercialActivity());

    Util.getDefaultValueString(
        ObjectUtils.defaultIfNull(alex.getCommercialActivity(),
                                  new CommercialActivity()).getCommercialSegmentContingentProducts());

    commercialActivity.setLongTermProductBusinessSegment(
        Util.getDefaultValueString(
            alex.getCommercialActivity().getLongTermProductBusinessSegment()));

    commercialActivity.setTypeSubcategoryEconomicSectorPortfolio(
        Util.getDefaultValueString(
            alex.getCommercialActivity().getTypeSubcategoryEconomicSectorPortfolio()));

    BusinessUnit businessUnit = new BusinessUnit();
    businessUnit.setBusinessUnitCode(
        Util.getDefaultValueString(
            alex.getCommercialActivity().getBusinessUnit().getBusinessUnitCode()));
    commercialActivity.setBusinessUnit(businessUnit);
    EconomicActivities economicActivities = new EconomicActivities();
    economicActivities.setEconomicActivitiesCode(
        Util.getDefaultValueString(
            alex.getCommercialActivity().getEconomicActivities()
                .getEconomicActivitiesCode()));
    commercialActivity.setEconomicActivities(economicActivities);

    customerGetResponse.setCommercialActivity(commercialActivity);
    customerGetResponse.setIdc(Util.getDefaultValueString(alex.getIdc()));

    SubSegment subSegment = new SubSegment();
    subSegment.setSubSegmentCode(
        Util.getDefaultValueString(alex.getSubSegment().getSubSegmentCode()));

    customerGetResponse.setSubSegment(subSegment);

    BankingType bankingType = new BankingType();
    bankingType.setBankingTypeCode(
        Util.getDefaultValueString(alex.getBankingType().getBankingTypeCode()));

    customerGetResponse.setBankingType(bankingType);

    Risk risk = new Risk();
    RiskClassificationBcp riskClassificationBcp = new RiskClassificationBcp();
    riskClassificationBcp.setRiskClassificationBcpCode(
        Util.getDefaultValueString(
            Objects.nonNull(alex.getRisk().getRiskClassificationBcp())
                ? alex.getRisk()
                .getRiskClassificationBcp()
                .getRiskClassificationBcpCode() : null));
    risk.setRiskClassificationBcp(riskClassificationBcp);
    risk.setDateRatingActivation(
        Util.getDefaultValueString(alex.getRisk().getDateRatingActivation()));
    risk.setVersionNumberRating(
        Util.getDefaultValueInt(alex.getRisk().getVersionNumberRating()));

    RiskClassificationCovid riskClassificationCovid = new RiskClassificationCovid();

    riskClassificationCovid.setRiskClassificationCovidCode(
        Util.getDefaultValueString(
            alex.getRisk().getRiskClassificationCovid()
                .getRiskClassificationCovidCode()));

    risk.setRiskClassificationCovid(riskClassificationCovid);

    ClassificationRating classificationRating = new ClassificationRating();
    classificationRating.setClassificationRatingCode(
        Util.getDefaultValueString(
            alex.getRisk().getClassificationRating().getClassificationRatingCode()));

    risk.setClassificationRating(classificationRating);

    ExposureLevelRcc exposureLevelRcc = new ExposureLevelRcc();
    exposureLevelRcc.setExposureLevelRccCode(
        Util.getDefaultValueString(
            Objects.isNull(
                alex.getRisk().getExposureLevelRcc()) ? null
                : alex.getRisk()
                .getExposureLevelRcc().getExposureLevelRccCode()));
    risk.setExposureLevelRcc(exposureLevelRcc);
    customerGetResponse.setRisk(risk);

    DefaultProbability defaultProbability = new DefaultProbability();
    defaultProbability.setAmountBalanceDebtCcfDollar(
        Util.getDefaultValueBig(
            alex.getDefaultProbability().getAmountBalanceDebtCcfDollar()));
    defaultProbability.setAmountBalanceDebtDiscountLetterDollars(
        Util.getDefaultValueBig(
            alex.getDefaultProbability().getAmountBalanceDebtDiscountLetterDollars()));

    defaultProbability.setAmountBalanceDebtDollars(
        Util.getDefaultValueBig(
            alex.getDefaultProbability().getAmountBalanceDebtDollars()));
    defaultProbability.setAmountCompaniesFinancialSystemCustomerDebt(
        Util.getDefaultValueInt(
            alex.getDefaultProbability().getAmountCompaniesFinancialSystemCustomerDebt()));
    defaultProbability.setAverageQuantityConditionalDelay18M(
        Util.getDefaultValueBig(
            alex.getDefaultProbability().getAverageQuantityConditionalDelay18M()));
    defaultProbability.setDefaultProbabilityPit(
        Util.getDefaultValueBig(alex.getDefaultProbability().getDefaultProbabilityPit()));
    defaultProbability.setDefaultProbabilityTtcShortTerm(
        Util.getDefaultValueBig(alex.getDefaultProbability().getDefaultProbabilityTtcShortTerm()));
    defaultProbability.setDefaultProbabilityTtcLongTerm(
        Util.getDefaultValueBig(alex.getDefaultProbability().getDefaultProbabilityTtcLongTerm()));

    customerGetResponse.setDefaultProbability(defaultProbability);

    customerGetResponse.setParticipationBankFinance(
        Util.getDefaultValueBig(alex.getParticipationBankFinance()));

    customerGetResponse.setProfitability(Util.getDefaultValueBig(alex.getProfitability()));

    int countGuarantee = ObjectUtils.defaultIfNull(
        alex.getGuarantees(), new ArrayList<>()).size();

    List<Guarantee> guaranteeList = new ArrayList<>();

    for (int i = 0; i < 20; i++) {
      if (countGuarantee > 0) {
        Guarantee guarantee = new Guarantee();
        Currency currency = new Currency();
        currency.setCurrencyCode(
            Util.getDefaultValueString(
                ObjectUtils.defaultIfNull(alex.getGuarantees().get(i).getCurrency(),
                                          new Currency()).getCurrencyCode()));
        guarantee.setCurrency(currency);
        GuaranteeProduct guaranteeProduct = new GuaranteeProduct();
        guaranteeProduct.setGuaranteeProductCode(
            Util.getDefaultValueString(
                ObjectUtils.defaultIfNull(alex.getGuarantees().get(i).getGuaranteeProduct(),
                                          new GuaranteeProduct()).getGuaranteeProductCode()));
        guarantee.setGuaranteeProduct(guaranteeProduct);
        GuaranteeScope guaranteeScope = new GuaranteeScope();
        guaranteeScope.setGuaranteeScopeCode(
            Util.getDefaultValueString(
                ObjectUtils.defaultIfNull(alex.getGuarantees().get(i).getGuaranteeScope(),
                                          new GuaranteeScope()).getGuaranteeScopeCode()));
        guarantee.setGuaranteeScope(guaranteeScope);
        guarantee.setFeeTradeAmount(
            Util.getDefaultValueBig(alex.getGuarantees().get(i).getFeeTradeAmount()));
        guarantee.setAmountAffected(
            Util.getDefaultValueBig(alex.getGuarantees().get(i).getAmountAffected()));
        guarantee.setAmountExecuted(
            Util.getDefaultValueBig(alex.getGuarantees().get(i).getAmountExecuted()));
        guarantee.setMinimumAmountUsed(
            Util.getDefaultValueBig(alex.getGuarantees().get(i).getMinimumAmountUsed()));
        guaranteeList.add(guarantee);
        countGuarantee = countGuarantee - 1;
      } else {
        Guarantee guarantia = new Guarantee();
        Currency currency = new Currency();
        currency.setCurrencyCode("-1");
        guarantia.setCurrency(currency);
        GuaranteeProduct guaranteeProduct = new GuaranteeProduct();
        guaranteeProduct.setGuaranteeProductCode("-1");
        guarantia.setGuaranteeProduct(guaranteeProduct);
        GuaranteeScope guaranteeScope = new GuaranteeScope();
        guaranteeScope.setGuaranteeScopeCode("-1");
        guarantia.setGuaranteeScope(guaranteeScope);
        guarantia.setFeeTradeAmount(BigDecimal.ONE.negate());
        guarantia.setAmountAffected(BigDecimal.ONE.negate());
        guarantia.setAmountExecuted(BigDecimal.ONE.negate());
        guarantia.setMinimumAmountUsed(BigDecimal.ONE.negate());
        guaranteeList.add(guarantia);
      }
    }
    customerGetResponse.setGuarantees(guaranteeList);

    int countProductRateGain = ObjectUtils.defaultIfNull(
        alex.getProductsRateGain(), new ArrayList<>()).size();

    List<ProductRateGain> productRateGainList = new ArrayList<>();

    for (int i = 0; i < countProductRateGain; i++) {
      ProductRateGain productRateGain = new ProductRateGain();
      ProductRate productRate = new ProductRate();
      productRate.setProductRateCode(
          Util.getDefaultValueString(
              ObjectUtils.defaultIfNull(
                  alex.getProductsRateGain().get(i).getProductRate(),
                  new ProductRate()).getProductRateCode()));
      productRateGain.setProductRate(productRate);
      Currency currency = new Currency();
      currency.setCurrencyCode(
          Util.getDefaultValueString(
              ObjectUtils.defaultIfNull(
                  alex.getProductsRateGain().get(i)
                      .getProfitRateCurrency(),
                  new Currency()).getCurrencyCode()));
      productRateGain.setProfitRateCurrency(currency);
      productRateGain.setWeightedAverageEarningRatePercentageL3M(
          Util.getDefaultValueBig(
              alex.getProductsRateGain().get(i)
                  .getWeightedAverageEarningRatePercentageL3M()));
      productRateGain.setWeightedAverageEarningRatePercentageL6M(
          Util.getDefaultValueBig(
              alex.getProductsRateGain().get(i)
                  .getWeightedAverageEarningRatePercentageL6M()));
      productRateGain.setWeightedAverageEarningRatePercentageL12M(
          Util.getDefaultValueBig(
              alex.getProductsRateGain().get(i)
                  .getWeightedAverageEarningRatePercentageL12M()));
      productRateGain.setWeightedAverageRatePercentageL3M(
          Util.getDefaultValueBig(
              alex.getProductsRateGain().get(i)
                  .getWeightedAverageRatePercentageL3M()));
      productRateGain.setWeightedAverageRatePercentageL6M(
          Util.getDefaultValueBig(
              alex.getProductsRateGain().get(i)
                  .getWeightedAverageRatePercentageL6M()));
      productRateGain.setWeightedAverageRatePercentageL12M(
          Util.getDefaultValueBig(
              alex.getProductsRateGain().get(i)
                  .getWeightedAverageRatePercentageL12M()));
      productRateGain.setDisbursementAmountTotalSolesL3M(
          Util.getDefaultValueBig(
              alex.getProductsRateGain().get(i)
                  .getDisbursementAmountTotalSolesL3M()));
      productRateGain.setDisbursementAmountTotalSolesL6M(
          Util.getDefaultValueBig(
              alex.getProductsRateGain().get(i)
                  .getDisbursementAmountTotalSolesL6M()));
      productRateGain.setDisbursementAmountTotalSolesL12M(
          Util.getDefaultValueBig(
              alex.getProductsRateGain().get(i)
                  .getDisbursementAmountTotalSolesL12M()));
      productRateGainList.add(productRateGain);

    }

    customerGetResponse.setProductsRateGain(productRateGainList);
    return customerGetResponse;

  }

  /**
   * Method getGuarantorDefaultData
   *
   * @version 1.0
   */
  public CustomerGetResponse getGuarantorDefaultData() {
    CustomerGetResponse customerGetResponse = new CustomerGetResponse();
    customerGetResponse.setYearsAsClient(BigDecimal.ONE.negate());
    customerGetResponse.setFlagLinkedCredicorp("-1");
    Ratio ratio = new Ratio();
    ratio.setActiveFinancialMarginRatio(BigDecimal.ONE.negate());
    ratio.setRefinancedDirectDebtVsTotalSbsRatio(BigDecimal.ONE.negate());
    customerGetResponse.setRatio(ratio);
    CommercialActivity commercialActivity = new CommercialActivity();
    commercialActivity.setCommercialSegmentContingentProducts(StringUtils.EMPTY);
    commercialActivity.setLongTermProductBusinessSegment(StringUtils.EMPTY);
    commercialActivity.setTypeSubcategoryEconomicSectorPortfolio("1");
    BusinessUnit businessUnit = new BusinessUnit();
    businessUnit.setBusinessUnitCode("1");
    commercialActivity.setBusinessUnit(businessUnit);
    EconomicActivities economicActivities = new EconomicActivities();
    economicActivities.setEconomicActivitiesCode("1");
    commercialActivity.setEconomicActivities(economicActivities);

    customerGetResponse.setCommercialActivity(commercialActivity);


    customerGetResponse.setIdc("0");

    SubSegment subSegment = new SubSegment();
    subSegment.setSubSegmentCode(StringUtils.EMPTY);

    customerGetResponse.setSubSegment(subSegment);

    BankingType bankingType = new BankingType();
    bankingType.setBankingTypeCode(Constantes.BANKING_TYPE_CODE_E);

    customerGetResponse.setBankingType(bankingType);

    Risk risk = new Risk();

    RiskClassificationBcp riskClassificationBcp = new RiskClassificationBcp();
    riskClassificationBcp.setRiskClassificationBcpCode(StringUtils.EMPTY);
    risk.setRiskClassificationBcp(riskClassificationBcp);
    risk.setDateRatingActivation(StringUtils.EMPTY);
    risk.setVersionNumberRating(-1);

    RiskClassificationCovid riskClassificationCovid = new RiskClassificationCovid();

    riskClassificationCovid.setRiskClassificationCovidCode(StringUtils.EMPTY);

    risk.setRiskClassificationCovid(riskClassificationCovid);

    ClassificationRating classificationRating = new ClassificationRating();
    classificationRating.setClassificationRatingCode("A");

    risk.setClassificationRating(classificationRating);

    ExposureLevelRcc exposureLevelRcc = new ExposureLevelRcc();
    exposureLevelRcc.setExposureLevelRccCode("-1");

    risk.setExposureLevelRcc(exposureLevelRcc);

    customerGetResponse.setRisk(risk);

    DefaultProbability defaultProbability = new DefaultProbability();
    defaultProbability.setAmountBalanceDebtCcfDollar(BigDecimal.ONE.negate());
    defaultProbability.setAmountBalanceDebtDiscountLetterDollars(BigDecimal.ONE.negate());
    defaultProbability.setAmountBalanceDebtDollars(BigDecimal.ONE.negate());
    defaultProbability.setAmountCompaniesFinancialSystemCustomerDebt(-1);
    defaultProbability.setAverageQuantityConditionalDelay18M(BigDecimal.ONE.negate());
    defaultProbability.setDefaultProbabilityPit(BigDecimal.ONE.negate());
    defaultProbability.setDefaultProbabilityTtcShortTerm(BigDecimal.ONE.negate());
    defaultProbability.setDefaultProbabilityTtcLongTerm(BigDecimal.ONE.negate());

    customerGetResponse.setDefaultProbability(defaultProbability);

    customerGetResponse.setParticipationBankFinance(BigDecimal.ONE.negate());

    customerGetResponse.setProfitability(BigDecimal.ZERO);

    List<Guarantee> guaranteeList = new ArrayList<>();

    for (int i = 0; i < Constantes.DEFAULT_GUARANTEE_SIZE; i++) {
      Guarantee guarantee = new Guarantee();
      Currency currency = new Currency();
      currency.setCurrencyCode("-1");
      guarantee.setCurrency(currency);
      GuaranteeProduct guaranteeProduct = new GuaranteeProduct();
      guaranteeProduct.setGuaranteeProductCode("-1");
      guarantee.setGuaranteeProduct(guaranteeProduct);
      GuaranteeScope guaranteeScope = new GuaranteeScope();
      guaranteeScope.setGuaranteeScopeCode("-1");
      guarantee.setGuaranteeScope(guaranteeScope);
      guarantee.setFeeTradeAmount(BigDecimal.ONE.negate());
      guarantee.setAmountAffected(BigDecimal.ONE.negate());
      guarantee.setAmountExecuted(BigDecimal.ONE.negate());
      guarantee.setMinimumAmountUsed(BigDecimal.ONE.negate());
      guaranteeList.add(guarantee);
    }
    customerGetResponse.setGuarantees(guaranteeList);

    List<ProductRateGain> productRateGainList = new ArrayList<>();

    for (int i = 0; i < Constantes.DEFAULT_PROUDCT_GAIN_SIZE; i++) {
      ProductRateGain productRateGain = new ProductRateGain();
      ProductRate productRate = new ProductRate();
      productRate.setProductRateCode("-1");
      productRateGain.setProductRate(productRate);
      Currency currency = new Currency();
      currency.setCurrencyCode("-1");
      productRateGain.setProfitRateCurrency(currency);
      productRateGain.setWeightedAverageEarningRatePercentageL3M(BigDecimal.ZERO);
      productRateGain.setWeightedAverageEarningRatePercentageL6M(BigDecimal.ZERO);
      productRateGain.setWeightedAverageEarningRatePercentageL12M(BigDecimal.ZERO);
      productRateGain.setWeightedAverageRatePercentageL3M(BigDecimal.ZERO);
      productRateGain.setWeightedAverageRatePercentageL6M(BigDecimal.ZERO);
      productRateGain.setWeightedAverageRatePercentageL12M(BigDecimal.ZERO);
      productRateGain.setDisbursementAmountTotalSolesL3M(BigDecimal.ZERO);
      productRateGain.setDisbursementAmountTotalSolesL6M(BigDecimal.ZERO);
      productRateGain.setDisbursementAmountTotalSolesL12M(BigDecimal.ZERO);
      productRateGainList.add(productRateGain);
    }

    customerGetResponse.setProductsRateGain(productRateGainList);
    return customerGetResponse;
  }


}