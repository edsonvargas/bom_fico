from pandas import DataFrame
from numpy import clip, minimum, maximum
from source.clv_mayorista.engine import curves as curves, clv_data

class SetPath():
    def __init__(self, path='param'):
        """
        Clase que carga los parámetros necesarios para el CLV Engine
        """
        self.path = path
        self.hyperparams = {}
        self.clv_data = clv_data.ClvData.get_instance()

        #self.path_tt()
        self.path_pd()
        self.path_costos()
        self.path_lgd()
        self.path_capital()
        
    # Probabilidad of Default (PD)
    def path_pd(self):
        param_pd_pit = self.clv_data.DataFramesLoaded["param_pd_pit"]
        param_producto = self.clv_data.DataFramesLoaded["param_producto"]
        self.hyperparams["pd"] = {
            "param_pd_pit": param_pd_pit,
            "param_producto":param_producto
            }

    # Loss Given Default (LGD)
    def path_lgd(self):

        param_ifrs9 = self.clv_data.DataFramesLoaded["param_ifrs9"]
        param_lgd_ttc = self.clv_data.DataFramesLoaded["param_lgd_ttc"]
        param_grupo = self.clv_data.DataFramesLoaded["param_grupo"]
        param_modelo_cobertura = self.clv_data.DataFramesLoaded["param_modelo_cobertura"]
        param_modelo_lgd_pit = self.clv_data.DataFramesLoaded["param_modelo_lgd_pit"]
        param_modelo_cascada = self.clv_data.DataFramesLoaded["param_modelo_cascada"]
        self.hyperparams['lgd'] = {
            "param_ifrs9": param_ifrs9,
            "param_lgd_ttc": param_lgd_ttc,
            "param_grupo": param_grupo,
            "param_modelo_cobertura": param_modelo_cobertura,
            "param_modelo_lgd_pit": param_modelo_lgd_pit,
            "param_modelo_cascada": param_modelo_cascada
            }  

    # Capital
    def path_capital(self):

        param_mfa = self.clv_data.DataFramesLoaded["param_mfa"]
        param_roe = self.clv_data.DataFramesLoaded["param_roe"]
        param_ecap = self.clv_data.DataFramesLoaded["param_ecap"]
        self.hyperparams['capital'] = {
            "param_mfa": param_mfa,
            "param_roe": param_roe,
            "param_ecap": param_ecap,
            }
    
    # Costos
    def path_costos(self):

        param_costos = self.clv_data.DataFramesLoaded["param_costos"]
        param_costos_agrupacion = self.clv_data.DataFramesLoaded["param_costos_agrupacion"]
        bn_param_costos = self.clv_data.DataFramesLoaded["bn_param_costos"]
        self.hyperparams["costos"] = {
            "param_costos": param_costos,
            "param_costos_agrupacion": param_costos_agrupacion,
            "bn_param_costos": bn_param_costos
            }

class CLVEngine():
    """
    Clase que nos permite calcular la tasa mínima y sus componentes
    """
    def __init__(self, hyperparams = SetPath().hyperparams): #

        self.param = None
        self.components = None

        # Diccionario de parámetros
        #self.hyperparams = hyperparams
        #setpath = SetPath()
        self.hyperparams = hyperparams 
        
        for key in self.hyperparams:
            setattr(self, key, self.hyperparams[key])
            
        # Diccionario de objetos
        self.curves_instance = {
            "pd": curves.CurvePD(self.hyperparams["pd"]),
            "lgd": curves.CurveLGD(self.hyperparams["lgd"]),
            "costos": curves.CurveCostos(self.hyperparams["costos"]),
            "capital": curves.CurveCapital(self.hyperparams["capital"]),
            }
        
        # Diccionario de inputs transformados
        self.X_tr = {
            "pd": None,
            "lgd": None,
            "capital": None,
            "costos": None,
            }
        
        # Diccionario de curvas finales
        self.curves = {
            "pd": None,
            "lgd": None,
            "capital": None,
            "costos": None,
            }            

    def transform(self, X, X_g):
        """
        Método que permite aplicar transformaciones a los inputs, es
        decir, información de la operación, cliente y garantías del
        cliente, para que sean insumidos por el método 'predict'.
        
        Parameters
        ----------
        X: DataFrame,
            The method expects minimally the following columns: 
            TODO: Add column names
        X_g: Dataframe,
            The method expects minimally the following columns: 
            "CODUNICOCLI", "CODMONEDA", "CODPRODUCTO" 
            "MTOCOMERCIAL", "MTOAFECTACION", "MTOREALIZACION"

        Returns
        -------
        Dictionary
            TODO: Add more info
        """
        #X = preprocess(X)
        #X_g = preprocess(X_g)
        for key in self.curves_instance:
            """
            Se requiere las garantías del cliente para calcular las curvas
            Loss Given Default Point in Time (LGDPIT) y Loss Given Default
            Through the Cycle (LGDTTC), por eso se utiliza el condicional.
            """
            if key == "lgd":
                self.X_tr[key] = self.curves_instance[key].transform(X, X_g)
            else:
                self.X_tr[key] = self.curves_instance[key].transform(X)

        self.X_tr["plazo"] = clip(X["numvencimiento"], 30, 365)

        #self.X_tr["plazo"] = min(max(X["numvencimiento"][0],30),365)
        self.X_tr["tipo_cambio"] = X["tipo_cambio"].copy()
        mask = X["codmoneda"] == "1001"
        X.loc[mask, "tipo_cambio"] = 1
        self.X_tr["mto_importe_dol"] = X["mtoimporte"].div(X["tipo_cambio"], axis=0)
        self.X_tr["codmoneda"] = X["codmoneda"]
        self.X_tr["tipbanca"] = X["tipbanca"]

        return self.X_tr
          
    def predict(self):
        """
        Método que permite predecir a partir de los inputs transformados
        calculados por el método 'transform'
        Returns
        -------
        Dictionary
            TODO: Add more info
        """
        for key in self.curves:
            if key == "capital":               
                self.X_tr["capital"]["lgd_ttc"] = self.curves["lgd"]["lgd_ttc"].copy()
                self.curves[key] = self.curves_instance[key].predict(self.X_tr[key])
            else:
                self.curves[key] = self.curves_instance[key].predict(self.X_tr[key])
        
        return self.curves

    def get_parameters(self): 
        """
        Método que reordena los parámetros
        """
        self.param = {
            'fijo_mant' : self.curves["costos"]["fijo_mant"],
            'fijo_vta' : self.curves["costos"]["fijo_vta"],
            'variable_mant' : self.curves["costos"]["variable_mant"],
            'variable_vta' : self.curves["costos"]["variable_vta"],
            'costo_min' : self.curves["costos"]["piso"],
            'costo_max' : self.curves["costos"]["techo"],
            'pd_pit'  : self.curves["pd"]["pd_pit"],
            'pd_ttc' : self.curves["pd"]["pd_ttc"],
            'impmin' : self.curves["costos"]["impmin"],
            'lgd_pit'  : self.curves["lgd"]["lgd_pit"],
            'lgd_ttc'  : self.curves["lgd"]["lgd_ttc"],
            'roe' : self.curves["capital"]["roe"],
            'mfa' : self.curves["capital"]["mfa"],
            'ecap' : self.curves["capital"]["ecap"],
            'num_letras' : self.curves["costos"]["num_letras"],
            'pctcostoventa' : self.curves["costos"]["pctcostoventa"],
            'pctcostomant' : self.curves["costos"]["pctcostomant"],
            'ccf' : self.curves["pd"]["pctccf"],
            'tipocobro' : self.curves["pd"]["tipocobro"],
            'tipcalculadora': self.curves["pd"]["tipcalculadora"]
            }

    def compute_min_rate(self, tt_input):
        """
        Método que calcula la tasa mínima
        """
        
        if self.param == None: 
            self.get_parameters()
                   
        plazo = self.X_tr["plazo"]
        tipbanca = self.X_tr["tipbanca"]
        mto_importe_dol = self.X_tr["mto_importe_dol"]
        fijo_mant = self.param["fijo_mant"]
        fijo_vta = self.param["fijo_vta"]
        variable_mant = self.param["variable_mant"]
        variable_vta = self.param["variable_vta"]
        costo_min = self.param["costo_min"]
        costo_max = self.param["costo_max"]
        num_letras = self.param["num_letras"]
        pct_vta = self.param["pctcostoventa"]
        pct_mant = self.param["pctcostomant"]
        tt = tt_input
        pd_pit = self.param["pd_pit"]
        lgd_pit = self.param["lgd_pit"]
        ecap = self.param["ecap"]
        roe = self.param["roe"]
        mfa = self.param["mfa"]
        ccf = self.param["ccf"]
        tipocobro = self.param["tipocobro"]
        impmin = self.param["impmin"]
        tipcalculadora = self.param["tipcalculadora"]
        
        #Cálculo del componente COSTO (co)
        if any(tipbanca == "N"):
            i_c = (1 + pct_vta)*((1 + tt)**(plazo/365)) + pct_mant*(plazo/365) - 1
            i_c = (1 + i_c)**(365/plazo) - 1
            co = i_c - tt
        else:
            #Cálculo del componente COSTO (co)
            pct_vta = fijo_vta*num_letras/mto_importe_dol + variable_vta
            pct_mant = fijo_mant*num_letras/mto_importe_dol + variable_mant
            i_c = (1 + pct_vta)*((1 + tt)**(plazo/365)) + pct_mant*(plazo/365) - 1
            i_c = (1 + i_c)**(365/plazo) - 1
            co = i_c - tt
            co = maximum(minimum(co, costo_max), costo_min)
            
        #coImporte = mto_importe_dol*((1 + co)**(plazo/365)-1)
        #co = co if coImporte < impmin else (1+impmin/mto_importe_dol)**(365/plazo) - 1
        #co = max(min(co[0], costo_max[0]),costo_min[0])

        #Cálculo del componente PÉRDIDA ESPERADA (pe)
        pe = pd_pit*lgd_pit*ccf     
        
        #Cálculo del componente RK (rk)
        rk = ecap*roe*mfa*ccf
      
          
        #Cálculo de la TASA MÍNIMA (Tmin)
        if tipcalculadora[0] == 'F' :
            if any(tipocobro == "A"):   #any(tipbanca == "N"):
                tv = co + pe + rk
                ta = (1 - (1/(tv+1)))
                co = co*ta/tv
                pe = pe*ta/tv
                rk = rk*ta/tv  
            tasa_min = co + pe + rk
        else:
            tasa_min = tt + co + pe + rk

        self.components = {
            "co": co,
            "pe": pe,
            "tt": tt,
            "rk": rk,
            }

        return tasa_min

    def get_rate_components(self):
        """
        Método que calcula los componentes de la tasa mínima
        """
        return DataFrame.from_dict(self.components)