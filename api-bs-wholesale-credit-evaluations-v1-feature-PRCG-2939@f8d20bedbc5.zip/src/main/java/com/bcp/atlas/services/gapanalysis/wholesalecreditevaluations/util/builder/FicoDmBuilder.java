package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.SpreadComercialAndBlackList;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.Cliente;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.DetalleClienteProducto;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.DmRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.NoRevPayload;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.NoRevPayloadAudit;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.NoRevPayloadInput;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.NoRevPayloadOutput;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.NoRevSolicitud;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.Prestamo;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.mlx.MlxResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.Util;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;






/**
 * <br/>
 * Clase Interfaz del Servicio para la logica de negocio que consumira la clase REST
 * RateCalculationController<br/>
 * <b>Class</b>: FicoRequest<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Mar 25, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Component
@Slf4j
public class FicoDmBuilder {

  /**
   * Method getRequestInput()
   *
   * @version 1.0
   */
  public DmRequest getRequestInput(
      Request request,
      CustomerGetResponse alexandria,
      MlxResponse mlxResponse,
      String appCode,
      SpreadComercialAndBlackList spreadComercialAndBlackList) {

    NoRevPayloadInput dmInput = new NoRevPayloadInput();
    dmInput.setDatosSolicitud(
        getDataSol(alexandria, request, mlxResponse, appCode, spreadComercialAndBlackList));

    NoRevPayloadOutput dmOutput = new NoRevPayloadOutput();
    NoRevPayloadAudit dmAudit = new NoRevPayloadAudit();
    NoRevPayload payload = new NoRevPayload();

    payload.setPayloadInput(dmInput);
    payload.setPayloadOutput(dmOutput);
    payload.setPayloadAudit(dmAudit);

    DmRequest dmRequest = new DmRequest();
    dmRequest.setPayload(payload);

    return dmRequest;
  }

  /**
   * Method getDataSol()
   *
   * @version 1.0
   */
  private NoRevSolicitud getDataSol(
      CustomerGetResponse alexandria,
      Request request,
      MlxResponse mlxResponse,
      String appCode,
      SpreadComercialAndBlackList spreadComercialAndBlackList) {

    if (Objects.nonNull(mlxResponse)) {
      return getDataSolWhenNoListaNegra(
          appCode,alexandria, request, mlxResponse, spreadComercialAndBlackList);
    } else {
      return getDataSolWhenExistListaNegra(appCode,request, spreadComercialAndBlackList);
    }
  }

  /**
   * Method getDataSolWhenNoListaNegra()
   *
   * @version 1.0
   */
  private NoRevSolicitud getDataSolWhenNoListaNegra(
      String appCode,
      CustomerGetResponse alexandria,
      Request request,MlxResponse mlxResponse,
      SpreadComercialAndBlackList spreadComercialAndBlackList) {

    Cliente cliente = new Cliente();
    cliente.setTipBanca(
        alexandria.getBankingType().getBankingTypeCode());
    cliente.setTipRating(
        alexandria.getRisk().getClassificationRating().getClassificationRatingCode());
    cliente.setPctmargenfinancieroactivo(Util.getDefaultValueBigFicoDm(
        alexandria.getRatio().getActiveFinancialMarginRatio()));
    cliente.setRaroRac(alexandria.getProfitability());
    cliente.setSow(Util.getDefaultValueBigFicoDm(
        alexandria.getParticipationBankFinance()));
    cliente.setFlagBlackList(Util.getDefautltFlagBLackList(
        request.getCustomerInfo().getFlagBlackList()));

    NoRevSolicitud revSolicitud = new NoRevSolicitud();
    revSolicitud.setCliente(cliente);
    revSolicitud.setChannelId(appCode);
    Prestamo prestamo = new Prestamo();
    prestamo.setMoneda(request.getCreditInfo()
                           .getCreditInfoBase().getCurrency().getCode().getValue());

    if (mlxResponse.getData().getTensor().getValues().get(0).equals("NaN")) {
      prestamo.setCo(BigDecimal.valueOf(0.0));
    } else {
      prestamo.setCo(new BigDecimal(mlxResponse.getData().getTensor().getValues().get(0)));
    }
    if (mlxResponse.getData().getTensor().getValues().get(1).equals("NaN")) {
      prestamo.setPe(BigDecimal.valueOf(0.0));
    } else {
      prestamo.setPe(new BigDecimal(mlxResponse.getData().getTensor().getValues().get(1)));
    }
    if (mlxResponse.getData().getTensor().getValues().get(2).equals("NaN")) {
      prestamo.setTt(BigDecimal.valueOf(0.0));
    } else {
      prestamo.setTt(new BigDecimal(mlxResponse.getData().getTensor().getValues().get(2)));
    }
    if (mlxResponse.getData().getTensor().getValues().get(3).equals("NaN")) {
      prestamo.setRk(BigDecimal.valueOf(0.0));
    } else {
      prestamo.setRk(new BigDecimal(mlxResponse.getData().getTensor().getValues().get(3)));
    }

    prestamo.setCodproducto(request.getCreditInfo().getCreditInfoBase().getProductCode());
    prestamo.setTasaListaNegra(Util.getDefaultBigDecimal(spreadComercialAndBlackList.getBlacklistRate()));
    prestamo.setSc(Util.getDefaultBigDecimal(spreadComercialAndBlackList.getSpreadComercial()));
    //req contingente dm, envio CP/CONT
    prestamo.setTipocredito(request.getQuotationType().getValue());
    //fin
    int countProductRateGain = ObjectUtils.defaultIfNull(alexandria.getProductsRateGain(),
                                                         new ArrayList<>()).size();
    List<DetalleClienteProducto> clienteProductoList = new ArrayList<>();
    for (int i = 0; i < countProductRateGain; i++) {

      DetalleClienteProducto detalleClienteProducto = new DetalleClienteProducto();
      detalleClienteProducto.setCodUnicoCli(alexandria.getIdc());
      detalleClienteProducto.setCodProducto(
          alexandria.getProductsRateGain().get(i).getProductRate().getProductRateCode());
      detalleClienteProducto.setSpreadProm3M(
          alexandria.getProductsRateGain().get(i).getWeightedAverageEarningRatePercentageL3M());
      detalleClienteProducto.setSpreadProm6M(
          alexandria.getProductsRateGain().get(i).getWeightedAverageEarningRatePercentageL6M());
      detalleClienteProducto.setSpreadProm12M(
          alexandria.getProductsRateGain().get(i).getWeightedAverageEarningRatePercentageL12M());

      detalleClienteProducto.setTasaProm3M(
          alexandria.getProductsRateGain().get(i).getWeightedAverageRatePercentageL3M());
      detalleClienteProducto.setTasaProm6M(
          alexandria.getProductsRateGain().get(i).getWeightedAverageRatePercentageL6M());
      detalleClienteProducto.setTasaProm12M(
          alexandria.getProductsRateGain().get(i).getWeightedAverageRatePercentageL12M());

      detalleClienteProducto.setImporte3M(
          alexandria.getProductsRateGain().get(i).getDisbursementAmountTotalSolesL3M());
      detalleClienteProducto.setImporte6M(
          alexandria.getProductsRateGain().get(i).getDisbursementAmountTotalSolesL6M());
      detalleClienteProducto.setImporte12M(
          alexandria.getProductsRateGain().get(i).getDisbursementAmountTotalSolesL12M());

      detalleClienteProducto.setCodMoneda(
          alexandria.getProductsRateGain().get(i).getProfitRateCurrency().getCurrencyCode());

      clienteProductoList.add(detalleClienteProducto);

    }

    revSolicitud.setDetalleClienteProducto(clienteProductoList);
    revSolicitud.setPrestamo(prestamo);
    revSolicitud.setTasaPropuesta(Util.getDefaultBigDecimal(request.getInterestRate()));
    return revSolicitud;
  }

  /**
   * Method getDataSolWhenExistListaNegra()
   *
   * @version 1.0
   */
  private NoRevSolicitud getDataSolWhenExistListaNegra(
      String appCode,
      Request request,
      SpreadComercialAndBlackList spreadComercialAndBlackList) {

    Cliente cliente = new Cliente();
    cliente.setTipBanca(BigDecimal.ONE.negate().toString());

    cliente.setTipRating(BigDecimal.ONE.negate().toString());

    cliente.setPctmargenfinancieroactivo(BigDecimal.ONE.negate());
    cliente.setRaroRac(BigDecimal.ONE.negate());
    cliente.setSow(BigDecimal.ONE.negate());
    cliente.setFlagBlackList(Util.getDefautltFlagBLackList(
        request.getCustomerInfo().getFlagBlackList()));
    NoRevSolicitud noRevSolicitud = new NoRevSolicitud();
    noRevSolicitud.setCliente(cliente);
    noRevSolicitud.setChannelId(appCode);
    Prestamo prestamo = new Prestamo();
    prestamo.setMoneda(request.getCreditInfo()
                           .getCreditInfoBase().getCurrency().getCode().getValue());

    // mlx nulo
    prestamo.setCo(BigDecimal.ONE.negate());
    prestamo.setPe(BigDecimal.ONE.negate());
    prestamo.setTt(BigDecimal.ONE.negate());
    prestamo.setRk(BigDecimal.ONE.negate());

    prestamo.setCodproducto(request.getCreditInfo().getCreditInfoBase().getProductCode());
    prestamo.setTasaListaNegra(Util.getDefaultBigDecimal(spreadComercialAndBlackList.getBlacklistRate()));
    prestamo.setSc(Util.getDefaultBigDecimal(spreadComercialAndBlackList.getSpreadComercial()));
    //req contingente dm, envio CP/CONT
    prestamo.setTipocredito(request.getQuotationType().getValue());
    //fin
    List<DetalleClienteProducto> detalleClienteProductoList = new ArrayList<>();

    detalleClienteProductoList.add(getDefaultDetalleClienteProducto());

    noRevSolicitud.setDetalleClienteProducto(detalleClienteProductoList);
    noRevSolicitud.setPrestamo(prestamo);
    noRevSolicitud.setTasaPropuesta(Util.getDefaultBigDecimal(request.getInterestRate()));
    return noRevSolicitud;
  }

  /**
   * Method getDefaultDetalleClienteProducto()
   *
   * @version 1.0
   */
  public DetalleClienteProducto getDefaultDetalleClienteProducto() {

    DetalleClienteProducto detalleClienteProducto = new DetalleClienteProducto();

    detalleClienteProducto.setCodUnicoCli(String.valueOf(0));
    detalleClienteProducto.setCodProducto(String.valueOf(0));
    detalleClienteProducto.setSpreadProm3M(BigDecimal.ZERO);
    detalleClienteProducto.setSpreadProm6M(BigDecimal.ZERO);
    detalleClienteProducto.setSpreadProm12M(BigDecimal.ZERO);

    detalleClienteProducto.setTasaProm3M(BigDecimal.ZERO);
    detalleClienteProducto.setTasaProm6M(BigDecimal.ZERO);
    detalleClienteProducto.setTasaProm12M(BigDecimal.ZERO);

    detalleClienteProducto.setImporte3M(BigDecimal.ZERO);
    detalleClienteProducto.setImporte6M(BigDecimal.ZERO);
    detalleClienteProducto.setImporte12M(BigDecimal.ZERO);

    detalleClienteProducto.setCodMoneda(String.valueOf(0));

    return detalleClienteProducto;
  }
}