package com.bcp.atlas.services.gapanalysis.expose.web;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.OperationNumberRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleOperationNumberResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesalePostHeaders;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationInfoResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationNumberResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.QuotationRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.WholesaleCreditEvaluationsService;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.WholesaleOperationService;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.WholesaleQuotationService;
import io.reactivex.Observable;
import io.reactivex.observers.TestObserver;
import java.util.Optional;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.server.ServerWebExchange;

/**
 * <br>
 * Clase service que contiene los metodos necesarios para tramitar la data y logica de negocio que
 * consumira la clase REST ProductRatesController<br>
 * <b>Class</b>: ProductRatesServiceImpl<br>
 * Copyright: &copy; 2022 Banco de Cr&eacute;dito del Per&uacute;.<br>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br>
 *     <u>Service Provider</u>: nttdata <br>
 *     <u>Developed by</u>: <br>
 *     <ul>
 *       <li>marco
 *     </ul>
 *     <u>Changes</u>:<br>
 *     <ul>
 *       <li>Nov 2, 2022 Creaci&oacute;n de Clase.
 *     </ul>
 *
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class WholesaleCreditEvaluationsApiImplTest {

  @InjectMocks private WholesaleCreditEvaluationsApiImpl wholsaleCreditEvaluationsApi;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private WholesaleCreditEvaluationsService wholesaleCreditEvaluationsService;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private WholesaleOperationService wholesaleOperationService;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private WholesaleQuotationService wholesaleQuotationService;

  @Test
  void calculateProductRateTest() {
    PricingWholesaleResponse response = Mockito.mock(PricingWholesaleResponse.class);
    PricingWholesalePostHeaders headers = Mockito.mock(PricingWholesalePostHeaders.class);
    Request request = Mockito.mock(Request.class);
    ServerWebExchange serverWebExchange = mock(ServerWebExchange.class);

    when(wholesaleCreditEvaluationsService.response(
            any(PricingWholesalePostHeaders.class), any(Request.class)))
        .thenReturn(Observable.just(response));

    TestObserver<ResponseEntity<PricingWholesaleResponse>> testObserver =
        wholsaleCreditEvaluationsApi
            .rateWholesaleCredit(headers, request, serverWebExchange)
            .test();
    testObserver.awaitTerminalEvent();
    testObserver.assertComplete();
  }

  @Test
  void whengetRequestTest() {
    Optional<NativeWebRequest> expect = Optional.empty();
    Assert.assertEquals(expect, wholsaleCreditEvaluationsApi.getRequest());
  }

  @Test
  void createQuotationNumberTest() {
    PricingWholesaleQuotationNumberResponse response =
        Mockito.mock(PricingWholesaleQuotationNumberResponse.class);
    PricingWholesalePostHeaders headers = Mockito.mock(PricingWholesalePostHeaders.class);
    QuotationRequest request = Mockito.mock(QuotationRequest.class);
    ServerWebExchange serverWebExchange = mock(ServerWebExchange.class);

    when(wholesaleQuotationService.generateQuotationNumber(request))
        .thenReturn(Observable.just(response));

    TestObserver<ResponseEntity<PricingWholesaleQuotationNumberResponse>> testObserver =
        wholsaleCreditEvaluationsApi.createQuotation(headers, request, serverWebExchange).test();
    testObserver.awaitTerminalEvent();
    testObserver.assertComplete();
  }

  @Test
  void searchByQuotationIdTest() {
    PricingWholesaleQuotationInfoResponse response =
        Mockito.mock(PricingWholesaleQuotationInfoResponse.class);
    PricingWholesalePostHeaders headers = Mockito.mock(PricingWholesalePostHeaders.class);
    ServerWebExchange serverWebExchange = mock(ServerWebExchange.class);
    String quotationNumber = "CP20230423100";

    when(wholesaleQuotationService.getQuotation(quotationNumber))
        .thenReturn(Observable.just(response));

    TestObserver<ResponseEntity<PricingWholesaleQuotationInfoResponse>> testObserver =
        wholsaleCreditEvaluationsApi
            .getQuotation(headers, quotationNumber, serverWebExchange)
            .test();
    testObserver.awaitTerminalEvent();
    testObserver.assertComplete();
  }

  @Test
  void saveOperationNumberTest() {
    PricingWholesaleOperationNumberResponse response =
        Mockito.mock(PricingWholesaleOperationNumberResponse.class);
    PricingWholesalePostHeaders headers = Mockito.mock(PricingWholesalePostHeaders.class);
    OperationNumberRequest request = Mockito.mock(OperationNumberRequest.class);
    ServerWebExchange serverWebExchange = mock(ServerWebExchange.class);

    when(wholesaleOperationService.saveOperationNumber(request))
        .thenReturn(Observable.just(response));

    TestObserver<ResponseEntity<PricingWholesaleOperationNumberResponse>> testObserver =
        wholsaleCreditEvaluationsApi.createOperation(headers, request, serverWebExchange).test();
    testObserver.awaitTerminalEvent();
    testObserver.assertComplete();
  }
}
