cd ..

# borramos carpetas del build
rm -rvf build/lib/cef_engine
printf 'lib/cef_engine eliminado'

# compilamos
python setup.py bdist_wheel --universal
printf 'compilado'

# instalamos 
pip install dist/clv_cef-1.0-py2.py3-none-any.whl --force
printf 'instalado'
