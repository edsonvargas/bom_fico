package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.OperationNumberRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleOperationNumberResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.CreditInfoCpResponseRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.MapperUtils;
import io.reactivex.observers.TestObserver;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class WholesaleOperationDaoImplTest {
  @InjectMocks WholesaleOperationDaoImpl wholesaleOperationDaoImpl;

  @Mock PricingWholesaleOperationNumberResponse pricingWholesaleOperationNumberResponse;

  @Mock CreditInfoCpResponseRepository creditInfoCpResponseRepository;

  @Mock OperationNumberRequest operationNumberRequest2;

  @Test
  void whenSaveOperationNumberWithOkOperationNumber() {
    when(creditInfoCpResponseRepository.saveOperationNumber(any(), any()))
        .thenReturn("Número de operación generado correctamente");
    OperationNumberRequest operationNumberRequest =
        MapperUtils.convertToObject("RequestOperationNumber.json", OperationNumberRequest.class);
    Assert.assertNotNull(operationNumberRequest);
    TestObserver<PricingWholesaleOperationNumberResponse> testObserver =
        wholesaleOperationDaoImpl.saveOperationNumber(operationNumberRequest).test();
    testObserver.awaitTerminalEvent();
  }

  @Test
  void whenSaveOperationNumberWithouthOkOperationNumber() {
    when(creditInfoCpResponseRepository.saveOperationNumber(any(), any()))
        .thenReturn("SHA-256");
    OperationNumberRequest operationNumberRequest =
        MapperUtils.convertToObject("RequestOperationNumber.json", OperationNumberRequest.class);
    Assert.assertNotNull(operationNumberRequest);
    TestObserver<PricingWholesaleOperationNumberResponse> testObserver =
        wholesaleOperationDaoImpl.saveOperationNumber(operationNumberRequest).test();
    testObserver.awaitTerminalEvent();
  }
}
