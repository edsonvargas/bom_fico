package com.bcp.atlas.services.gapanalysis.config;

import com.bcp.atlas.core.http.annotation.HttpComponentScan;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import java.util.concurrent.TimeUnit;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <b>Class</b>: CacheConfiguration.java <br/>
 * <b>Copyright</b>: &copy; 2020 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u> Service Provider: Everis Perú SAC (EVE)</u>: <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>2020-08-01 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */

@Configuration
@HttpComponentScan(
    basePackages = {"com.bcp.atlas.services.gapanalysis"})
public class CacheConfiguration {

  /**
   * Method globalCache
   *
   * @version 1.0
   */
  @Bean
  public Cache<Integer, String> globalCache() {

    return Caffeine.newBuilder().expireAfterWrite(45, TimeUnit.MINUTES)
        .maximumSize(10).build();
  }
}