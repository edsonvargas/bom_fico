package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;




/**
 * <b>Class</b>: Product.java <br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Ago 1, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Data
@Entity
@Table(name = "credit_info_cp_res",schema = "prcg_mayorista")
public class CreditInfoCpResponse {

  @Column(name = "credit_info_cp_res_id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Id
  private Integer creditInfoCpResId;

  @Column(name = "credit_info_cp_req_id")
  private Integer creditInfoCpReqId;

  @Column(name = "transfer_rate")
  private BigDecimal transferRate;

  @Column(name = "operational_cost")
  private BigDecimal operationalCost;

  @Column(name = "capital_return")
  private BigDecimal capitalReturn;

  @Column(name = "business_spread")
  private BigDecimal businessSpread;

  @Column(name = "expected_loss")
  private BigDecimal expectedLoss;

  @Column(name = "minimal_rate")
  private BigDecimal minimalRate;

  @Column(name = "register_date")
  private LocalDateTime registerDate;

  @Column(name = "quotation_number")
  private String quotationNumber;

  @Column(name = "operation_number")
  private String operationNumber;

  @Column(name = "alexandria_mfa")
  private BigDecimal alexandriaMfa;

  @Column(name = "classification_rating_code")
  private String classificationRatingCode;

  @Column(name = "roe")
  private BigDecimal roe;

  @Column(name = "rarorac")
  private BigDecimal rarorac;

  @Column(name = "due_date")
  private LocalDate dueDate;


}
