package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesalePostHeaders;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.WholesaleCreditEvaluationsDao;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.ExchangeRateRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.GetCommercialSpreadAndBlackListRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.GetTransferRateRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CommonTransferRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExchangeRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.SpreadComercialAndBlackList;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.token.TokenRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy.AlexandriaApi;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy.GeneratorApi;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.MapperUtils;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.AlexandriaBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.ErrorHandlerBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.observers.TestObserver;
import io.vavr.Tuple3;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class WholesaleCreditEvaluationsServiceImplTest {

  @InjectMocks private WholesaleCreditEvaluationsServiceImpl wholesaleCreditEvaluationsServiceImpl;

  @InjectMocks private ErrorHandlerBuilder errorHandlerBuilder;

  @Mock private WholesaleCreditEvaluationsDao wholesaleCreditEvaluationsDao;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private AlexandriaApi alexandriaApi;

  @Mock private AlexandriaBuilder alexandriaBuilder;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private GeneratorApi generatorApi;

  @Mock private PricingWholesalePostHeaders headers;

  @Mock private GetTransferRateRepository getTransferRateRepository;

  @Mock private GetCommercialSpreadAndBlackListRepository getCommercialSpreadAndBlackListRepository;

  @Mock private ExchangeRateRepository exchangeRateRepository;

  private Map<Integer, Tuple3<String, String, String>> errorCategoriesMap;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    errorCategoriesMap = errorCategoriesMap();
  }

  @Test
  void getTest() {

    final CustomerGetResponse alexandriaResponse =
        MapperUtils.convertToObject("AlexandriaResponse.json", CustomerGetResponse.class);
    final Request request = MapperUtils.convertToObject("RequestApi.json", Request.class);
    final CustomerGetResponse alexandriaResponseDefault =
        MapperUtils.convertToObject("AlexandriaResponse.json", CustomerGetResponse.class);
    final PricingWholesaleResponse productRatesResponse =
        MapperUtils.convertToObject("ResponseWholFinal.json", PricingWholesaleResponse.class);

    final SpreadComercialAndBlackList spreadComercialAndBlackList =
        MapperUtils.convertToObject(
            "ResponseSpreadComercialAndBlackList.json", SpreadComercialAndBlackList.class);

    final ExchangeRate exchangeRate =
        MapperUtils.convertToObject("ResponseExchangeRate.json", ExchangeRate.class);

    CommonTransferRate commonTransferRate = new CommonTransferRate();
    commonTransferRate.setRate(0.12f);

    when(alexandriaBuilder.getAlexandria(any(), anyBoolean())).thenReturn(alexandriaResponseDefault);
    when(generatorApi.executeProcessTokenUsingPost(any(TokenRequest.class)))
        .thenReturn(Single.just("Token"));
    lenient().when(getTransferRateRepository.getTransferRate(
            any(String.class), any(Integer.class), any(String.class), any(String.class)))
        .thenReturn(commonTransferRate);

    when(getCommercialSpreadAndBlackListRepository.getSpreadComercialAndBlackList(
            any(String.class), any(String.class)))
        .thenReturn(spreadComercialAndBlackList);

    when(exchangeRateRepository.getExchangeType()).thenReturn(exchangeRate);

    when(alexandriaApi.search(any(), anyString())).thenReturn(Observable.empty());
    alexandriaApi.search(any(), anyString()).subscribe();
    verify(alexandriaApi).search(any(), anyString());

    TestObserver<PricingWholesaleResponse> testObserver =
        wholesaleCreditEvaluationsServiceImpl.response(headers, request).test();
    testObserver.awaitTerminalEvent();
  }

  @Test
  void requestOpcionalesSalesforceHeaderTest() {
    final CustomerGetResponse alexandriaResponse =
        MapperUtils.convertToObject("AlexandriaResponse.json", CustomerGetResponse.class);
    final Request request = MapperUtils.convertToObject("RequestApiOpcionales2Test.json", Request.class);
    final CustomerGetResponse alexandriaResponseDefault =
        MapperUtils.convertToObject("AlexandriaResponse.json", CustomerGetResponse.class);
    final PricingWholesaleResponse productRatesResponse =
        MapperUtils.convertToObject("ResponseWholFinal.json", PricingWholesaleResponse.class);

    final SpreadComercialAndBlackList spreadComercialAndBlackList =
        MapperUtils.convertToObject(
            "ResponseSpreadComercialAndBlackList.json", SpreadComercialAndBlackList.class);

    final ExchangeRate exchangeRate =
        MapperUtils.convertToObject("ResponseExchangeRate.json", ExchangeRate.class);

    CommonTransferRate commonTransferRate = new CommonTransferRate();
    commonTransferRate.setRate(0.12f);

    when(alexandriaBuilder.getAlexandria(any(), anyBoolean())).thenReturn(alexandriaResponseDefault);
    when(generatorApi.executeProcessTokenUsingPost(any(TokenRequest.class)))
        .thenReturn(Single.just("Token"));
    lenient().when(getTransferRateRepository.getTransferRate(
            any(String.class), any(Integer.class), any(String.class), any(String.class)))
        .thenReturn(commonTransferRate);

    lenient().when(getCommercialSpreadAndBlackListRepository.getSpreadComercialAndBlackList(
            any(String.class), any(String.class)))
        .thenReturn(spreadComercialAndBlackList);

    lenient().when(exchangeRateRepository.getExchangeType()).thenReturn(exchangeRate);

    when(alexandriaApi.search(any(), anyString())).thenReturn(Observable.empty());
    alexandriaApi.search(any(), anyString()).subscribe();
    verify(alexandriaApi).search(any(), anyString());



    PricingWholesalePostHeaders pricingWholesalePostHeaders = new PricingWholesalePostHeaders();
    pricingWholesalePostHeaders.setAppCode("JH");
    TestObserver<PricingWholesaleResponse> testObserver =
        wholesaleCreditEvaluationsServiceImpl.response(pricingWholesalePostHeaders, request).test();
    testObserver.awaitTerminalEvent();
  }



  @Test
  void validateCustomerStatusOkTest() {
    Request request = MapperUtils.convertToObject("RequestApi.json", Request.class);
    request.getCreditInfo().getCreditInfoBase().setTerm(366);
    assertNotNull(errorHandlerBuilder.validateStatusCode(
        new CustomerGetResponse(), 200, "",""));
  }

  @Test
  void validateAlexandriaExceptionOkTest() {
    Request request = MapperUtils.convertToObject("RequestApi.json", Request.class);
    request.getCreditInfo().getCreditInfoBase().setTerm(366);
    assertNotNull(errorHandlerBuilder.validateAlexandriaException(
        new CustomerGetResponse(), 200));
  }

  @Test
  @SneakyThrows
  void validateEmptyCustomerTest() {
    assertThrows(
        NullPointerException.class,this::validateStatusCode);
  }

  @Test
  @SneakyThrows
  void testValidateSpreadAndCustomerNoBlackListTest() {

    final CustomerGetResponse alexandriaResponse =
        MapperUtils.convertToObject("AlexandriaResponse.json", CustomerGetResponse.class);
    final Request request = MapperUtils.convertToObject("RequestApi.json", Request.class);
    final CustomerGetResponse alexandriaResponseDefault =
        MapperUtils.convertToObject("AlexandriaResponse.json", CustomerGetResponse.class);
    final PricingWholesaleResponse productRatesResponse =
        MapperUtils.convertToObject("ResponseWholFinal.json", PricingWholesaleResponse.class);

    final SpreadComercialAndBlackList spreadComercialAndBlackList =
        MapperUtils.convertToObject(
            "ResponseSpreadComercialAndBlackList.json", SpreadComercialAndBlackList.class);

    final ExchangeRate exchangeRate =
        MapperUtils.convertToObject("ResponseExchangeRate.json", ExchangeRate.class);

    CommonTransferRate commonTransferRate = new CommonTransferRate();
    commonTransferRate.setRate(0.12f);

    TestObserver<PricingWholesaleResponse> testObserver =
        wholesaleCreditEvaluationsServiceImpl.validateSpreadAndCustomer(
            headers,
            request,
            "",
            exchangeRate,
            new CustomerGetResponse(),
            Observable.just(new CustomerGetResponse()),
            spreadComercialAndBlackList,
            Observable.just(commonTransferRate)).test();
    testObserver.awaitTerminalEvent();
  }

  @Test
  void validateAlexandriaExceptionTest() {
    Request request = MapperUtils.convertToObject("RequestApi.json", Request.class);
    request.getCreditInfo().getCreditInfoBase().setTerm(366);
    assertThrows(
        NullPointerException.class,
        this::validateAlexandriaException);
  }

  @Test
  void validateAlexandriaConflicStatusTest() {
    Request request = MapperUtils.convertToObject("RequestApi.json", Request.class);
    request.getCreditInfo().getCreditInfoBase().setTerm(366);
    assertThrows(
        NullPointerException.class,
        this::validateAlexandriaConflicStatusException);
  }

  void validateAlexandriaException() {
    errorHandlerBuilder.validateAlexandriaException(new CustomerGetResponse(), 400);
  }

  void validateAlexandriaConflicStatusException() {
    errorHandlerBuilder.validateAlexandriaException(new CustomerGetResponse(), 204);
  }

  void validateStatusCode() {
    errorHandlerBuilder.validateStatusCode(new CustomerGetResponse(), 0, "","");
  }

  Map<Integer, Tuple3<String, String,String>>  errorCategoriesMap() {

    Map<Integer, Tuple3<String,String, String>> errorCodeFicoDm = new HashMap<>();

    errorCodeFicoDm.put(400, new Tuple3<>("INVALID_REQUEST",
                                          Constantes.ERROR_CODE_PR0002,
                                          Constantes.MESSAGE_ERROR_400));
    errorCodeFicoDm.put(401, new Tuple3<>("UNAUTHORIZED",Constantes.ERROR_CODE_PR0003,
                                          Constantes.MESSAGE_ERROR_401));
    errorCodeFicoDm.put(403, new Tuple3<>("FORBIDDEN",Constantes.ERROR_CODE_PR0004,
                                          Constantes.MESSAGE_ERROR_403));
    errorCodeFicoDm.put(404, new Tuple3<>("RESOURCE_NOT_FOUND",Constantes.ERROR_CODE_PR0005,
                                          Constantes.MESSAGE_ERROR_404));
    errorCodeFicoDm.put(409, new Tuple3<>("CONFLICT",Constantes.ERROR_CODE_PR0006,
                                          Constantes.MESSAGE_ERROR_409));
    errorCodeFicoDm.put(412, new Tuple3<>("PRECONDITION_FAILED",Constantes.ERROR_CODE_PR0007,
                                          Constantes.MESSAGE_ERROR_412));
    errorCodeFicoDm.put(503, new Tuple3<>("SERVICE_UNAVAILABLE",Constantes.ERROR_CODE_PR0008,
                                          Constantes.MESSAGE_ERROR_503));
    errorCodeFicoDm.put(408, new Tuple3<>("EXTERNAL_TIMEOUT",Constantes.ERROR_CODE_PR0009,
                                          Constantes.MESSAGE_ERROR_408));
    errorCodeFicoDm.put(500, new Tuple3<>("UNEXPECTED",Constantes.ERROR_CODE_PR0010,
                                          Constantes.MESSAGE_ERROR_500));

    return errorCodeFicoDm;
  }
}
