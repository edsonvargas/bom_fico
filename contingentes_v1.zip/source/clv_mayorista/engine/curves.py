import source.clv_mayorista.engine.utils as ut

class CurvePD():
    def __init__(self, hyperparams):
        for key in hyperparams:
            setattr(self, key, hyperparams[key])

    def transform(self, X):
        X_transformed = ut.pd_transform(X)
        return X_transformed

    def predict(self, X_transformed):
        X_predict = ut.pd_predict(X_transformed, self.param_pd_pit, self.param_producto)
        return X_predict


class CurveLGD():
    def __init__(self, hyperparams):
        for key in hyperparams:
            setattr(self, key, hyperparams[key])

    def transform(self, X, X_g):
        X_transformed = ut.lgd_transform(X, X_g, self.param_ifrs9, self.param_grupo)
        return X_transformed

    def predict(self, X_transformed):
        X_predict = ut.lgd_predict(
            X_transformed, self.param_lgd_ttc, self.param_modelo_lgd_pit, 
            self.param_modelo_cobertura, self.param_modelo_cascada
            )
        return X_predict


class CurveCapital():
    def __init__(self, hyperparams):
        for key in hyperparams:
            setattr(self, key, hyperparams[key])

    def transform(self, X):
        X_transformed = ut.capital_transform(X)
        return X_transformed

    def predict(self, X_transformed):
        X_predict = ut.capital_predict(X_transformed, self.param_ecap, self.param_roe, self.param_mfa)
        return X_predict


class CurveCostos():
    def __init__(self, hyperparams):
        for key in hyperparams:
            setattr(self, key, hyperparams[key])

    def transform(self, X):
        X_transformed = ut.costos_transform(X)
        return X_transformed

    def predict(self, X_transformed):
        X_predict = ut.costos_predict(X_transformed, self.param_costos, self.param_costos_agrupacion, self.bn_param_costos)
        return X_predict
