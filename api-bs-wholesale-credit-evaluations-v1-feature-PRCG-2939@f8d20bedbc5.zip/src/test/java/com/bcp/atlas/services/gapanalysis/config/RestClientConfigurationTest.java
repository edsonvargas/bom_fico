package com.bcp.atlas.services.gapanalysis.config;

import static org.mockito.Mockito.mock;

import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import okhttp3.Interceptor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.autoconfigure.web.ServerProperties;

/**
 * Spring configuration for external Rest endpoints using <b>Retrofit</b>.<br>
 * <b>Class</b>: RestClientConfiguration<br>
 * <b>Copyright</b>: &copy; 2020 Banco de Cr&eacute;dito del Per&uacute;<br>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;<br>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br>
 *     <u>Service Provider</u>: BCP <br>
 *     <u>Changes</u>:<br>
 *     <ul>
 *       <li>Jun 7, 2021 Creaci&oacute;n de Clase.
 *     </ul>
 *
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class RestClientConfigurationTest {

  @InjectMocks private RestClientConfiguration restClientConfiguration;

  @Mock SSLSocketFactory socketFactory;

  @Mock X509TrustManager trustManager;

  @Test
  void customOkHttpClientBuilderTest() {
    ServerProperties serverProperties = mock(ServerProperties.class);
    Interceptor requestCrossInterceptor = mock(Interceptor.class);

    Assertions.assertNotNull(
        restClientConfiguration.customOkHttpClientBuilder(
            serverProperties, socketFactory, trustManager, null, requestCrossInterceptor));
  }
}
