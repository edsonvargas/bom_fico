# Libraries
from math import erf
from numpy import array, isinf, isnan, indices, divide, concatenate, log, minimum, exp \
    , zeros, sum, maximum, arange, multiply, power, copy, select, clip, log \
    , round, where, dot
from pandas import DataFrame, cut, merge, pivot_table
from scipy.stats import norm


def transf_gar(X):
    """ Calcula el monto de garantía considerando el tipo de cambio, monto comercial de tasación y monto de afectación
        Arguments:
        x -- x es un DataFrame
    """
    # moneda = X["Moneda"].values
    # tc = X["MontoTipoCambio"].values
    mtotasacion = X["MontoGarantiaComercial"].values
    mtoafectacion = X["MontoGarantiaAfectacion"].values

    # Multiplicando por el tipo de cambio de ser necesario
    mtotasacion_sol = where(X["Moneda"].values == "SOLES", mtotasacion, mtotasacion * X["MontoTipoCambio"].values)
    mtoafectacion_sol = where(X["Moneda"].values == "SOLES", mtoafectacion, mtoafectacion * X["MontoTipoCambio"].values)
    
    gar_Transf = minimum(0.8*mtotasacion_sol, mtoafectacion_sol)
    
    return gar_Transf


def flg_zona1(X):
    
    b = X.isin([7, 16, 17, 18, 19, 20, 21])  # Condition

    return where(b, 1, 0)  # flg_zona1


def flg_zona2(X):

    b = X.isin([3, 4, 5, 9, 12, 24, 26, 28])  # Condition

    return where(b, 1, 0)  # flg_zona2


def flg_zona4(X):
    
    b = X.isin([8, 10, 11, 13])  # Condition

    return where(b, 1, 0)  # flg_zona4


def get_product_code(X, self):
    codigo_prod = get_codigo_prod(X, self)
    X = get_product_code_final(X, codigo_prod) # final product_code_final
    return X


def get_codigo_prod(X, self):
    """
    """
    sub_X= X[['ProductoMic','TipoCreditoMic','CampanaMic']].copy()
    sub_X.rename(
        columns={
            "ProductoMic": "product_name_long", 
            "TipoCreditoMic": "tipo_credito", 
            "CampanaMic": "campania"},
        inplace=True)
    # Start: by default any codigo_prod will be "NOT" (sub_X['tipo_credito']=="")
    sub_X['codigo_prod'] = "NOT"

    #sub_X.loc[:, 'codigo_prod'] = "NOT" 
    # Optimizado?

    # Second: Look for (producto, tipo_credito, campania) in table
    table = self.producto_code_campaign
    sub_X = merge(sub_X, table, how='left') # matching to add product_code
    sub_X["product_code"].fillna("ERR", inplace=True) # if not in table then "ERR"
    # if tipo_credito not empty then fill codigo_prod with the field product_code
    codigo_prod_notempty = sub_X['codigo_prod'] != ""
    # sub_X['codigo_prod'][codigo_prod_notempty] = sub_X[codigo_prod_notempty]['product_code']
    sub_X.loc[codigo_prod_notempty, 'codigo_prod'] = sub_X.loc[codigo_prod_notempty, 'product_code']
    return sub_X['codigo_prod']


def get_product_code_final(X, codigo_prod):
    tipo_inmueble = X['TipoActivo']
    X['product_code_final'] = 'ERR'

    others_af = codigo_prod.isin(['AF', 'LEA', 'AFV'])
    mueble = tipo_inmueble == 'Mueble'
    inmueble = tipo_inmueble == 'Inmueble'

    X.loc[codigo_prod == 'CT', 'product_code_final'] = 1
    X.loc[others_af & inmueble, 'product_code_final'] = 2
    X.loc[others_af & mueble, 'product_code_final'] = 3
    X.loc[codigo_prod == 'NCMP', 'product_code_final'] = 4
    X.loc[codigo_prod == "ALPHA", "product_code_final"] = 5

    return X    


def can_transform(X):
    """ Genera el input necesario para el calculo de la curva de cancelaciones (CAN)

    Args:
        X: pandas DataFrame

    Returns:
        X: pandas DataFrame
    
    """
    # Variables necesarias para el calculo
    X = X[["product_code_final", "MontoPD"]].copy()

    return X

    

def can_predict(X, param_Tt):
    """ Calcula la curva de cancelaciones (CAN)

    Args:
        X: pandas DataFrame
        param_Tt: pandas DataFrame
        param_bestfit: pandas DataFrame

    Returns:
        X["curve"]: Curva de cancelaciones
    """
    # MS20270717: Considerar que el best_fit ya esta multiplicado en el formato can_thetaTt
    curve_can = param_Tt.copy()
    X = X.copy()

    curve_can["curve"] = [*curve_can.loc[:, "1":].values]
    curve_can["curve"] = curve_can["curve"] * curve_can["best_fit"]

    curve_can['range_pd'] = None
    X['range_pd'] = None

    for producto in X.product_code_final.unique():
        bins_pd = [0] + list(curve_can[curve_can['product_code_final'] == producto].max_pd.unique())
        curve_can.loc[curve_can.product_code_final == producto ,'range_pd'] = cut(curve_can.loc[curve_can.product_code_final == producto ,'min_pd'], bins=bins_pd, right=False)
        X.loc[X.product_code_final == producto ,'range_pd'] = cut(X.loc[X.product_code_final == producto ,'MontoPD'], bins=bins_pd, right=False)

    X = merge(X, curve_can[["product_code_final","range_pd", "curve"]], on=["product_code_final","range_pd"], how='left')

    return X["curve"].to_frame()


def pd_transform(X):
    """ Genera el input necesario para el calculo de la curva de probabilidad de default (PD)

    Args:
        X: pandas DataFrame

    Returns:
        X: pandas DataFrame
    """
    # Variables necesarias para el calculo
    X = X[["ScoreApplicantVendida", "ScoreApplicant", "product_code_final", "CantidadPlazo"]].copy()
    return X


def pd_predict(X, param_scalar, param_T, param_Tt, param_rangoTt):
    """ Calcula la curva de probabilidad de default (PD)

    Args:
        X: pandas DataFrame
        param_scalar: pandas DataFrame
        param_T: pandas DataFrame
        param_Tt: pandas DataFrame
        param_rangoTt: pandas DataFrame

    Returns:
        X["curve"]: Curva de probabilidad de default
    """
    X = X.copy()

    # Score
    score = X["ScoreApplicantVendida"].values

    # Params para la estimacion
    offset = param_scalar[param_scalar["param"] == "offset"]["value"].values[0]
    factor = param_scalar[param_scalar["param"] == "factor"]["value"].values[0]

    # Escalares Alpha y Beta por producto y rango de plazo
    X = merge(X[["product_code_final", "CantidadPlazo"]], param_T, on=["product_code_final"], how="left")
    X["b_rango_plazo"] = (X["CantidadPlazo"] >= X["min"]) & (X["CantidadPlazo"] <= X["max"])  # boolean
    X = X[X["b_rango_plazo"] == True][["product_code_final", "CantidadPlazo", "alpha", "beta"]]
    alpha, beta = X["alpha"].values.reshape(-1, 1), X["beta"].values.reshape(-1, 1)

    # Array de Alphas y Betas para cada periodo de tiempo por producto y rango de plazo
    X = merge(X, param_rangoTt, on=["product_code_final"], how="left")
    X["b_rango_plazo"] = (X["CantidadPlazo"] >= X["min"]) & (X["CantidadPlazo"] <= X["max"])
    X = X[X["b_rango_plazo"] == True]

    param_alphas_betas_lifetime = param_Tt.groupby(["product_code_final", "rango_plazo"])
    param_alphas_betas_lifetime = param_alphas_betas_lifetime[["alpha","beta"]].agg(lambda x: list(x)).reset_index()
    
    X = merge(X[["product_code_final", "rango_plazo"]], param_alphas_betas_lifetime, on=["product_code_final", "rango_plazo"], how="left")
    alpha_t0, beta_t0 = X["alpha"].values.reshape(-1, 1), X["beta"].values.reshape(-1, 1)
    alpha_t,beta_t = concatenate(alpha_t0.tolist(), axis=0), concatenate(beta_t0.tolist(), axis=0)

    # Calculo 
    xBeta = - (score - offset) / factor
    xBetaCalibrado = alpha + beta * xBeta.reshape(-1, 1) 
    valueT = -1 * (alpha_t + beta_t * xBetaCalibrado.reshape(-1, 1))
    pdTemporal = 1 / (1 + exp(valueT))
    zeros_array = zeros((pdTemporal.shape[0], 2))  # No existe PD en los dos primeros periodos de tiempo
    curve = concatenate((zeros_array, pdTemporal), axis=1)
  
    marginal_24 = (curve[:,23] - curve[:,22]).reshape(-1,1)
    ajuste_36_wkc = marginal_24 * arange(1, 13)
    curve[:,24:36] = where((X["product_code_final"].values == 1).reshape(-1, 1),
        curve[:, 23].reshape(-1, 1) + ajuste_36_wkc, curve[:,24:36])

    # Ajuste particular para WKC Reactivo
    marginal_12 = abs((curve[:,11] - curve[:,10])).reshape(-1, 1)
    ajuste_marginal_12_fwl = marginal_12 * arange(9, 0, -1)
    curve_ajuste = maximum(curve[:,11].reshape(-1, 1) - ajuste_marginal_12_fwl, 0)
    curve[:,2:11] = where(
        (X["product_code_final"].values == 1).reshape(-1, 1) & (score > 300).reshape(-1, 1) & (curve[:,2:11] > curve_ajuste), 
        curve_ajuste, curve[:,2:11])

    X["curve"] = curve.tolist()

    pd12 = pdTemporal[:, 9]  # Sin covid (para Capital)
    
    return X["curve"].to_frame(), pd12


def pre_transform(X):
    """ Genera el input necesario para el calculo de la curva de prepagos (PRE)

    Args:
        X: pandas DataFrame

    Returns:
        X: pandas DataFrame
    """
    # Variables necesarias para el calculo
    X = X[["product_code_final", "CantidadPlazo","MontoPD"]].copy()


    return X


def pre_predict(X, param_Tt):
    """ Calcula la curva de prepagos (PRE)

    Args:
        X: pandas DataFrame
        param_Tt: pandas DataFrame
        param_bestfit: pandas DataFrame

    Returns:
        X["curve"]: Curva de prepagos
    """  
    curve_pre = param_Tt.copy() 

    curve_pre["curve"] = [*curve_pre.loc[:, "1":].values]
    curve_pre["curve"] = curve_pre["curve"] * curve_pre["best_fit"]
    # curve_pre["key"] = curve_pre["product_code_final"].astype(str) + "," + curve_pre["min_plazo"].astype(str) + "," + curve_pre["max_plazo"].astype(str)

    curve_pre['range_plazo'] = None
    curve_pre['range_pd'] = None
    X['range_plazo'] = None
    X['range_pd'] = None

    for producto in X.product_code_final.unique():
        bins_plazo = [0] + list(curve_pre[curve_pre['product_code_final'] == producto].max_plazo.unique())
        curve_pre.loc[curve_pre.product_code_final == producto ,'range_plazo'] = cut(curve_pre.loc[curve_pre.product_code_final == producto ,'min_plazo'], bins=bins_plazo, right=False)
        X.loc[X.product_code_final == producto ,'range_plazo'] = cut(X.loc[X.product_code_final == producto ,'CantidadPlazo'], bins=bins_plazo, right=False)

        bins_pd = [0] + list(curve_pre[curve_pre['product_code_final'] == producto].max_pd.unique()) 
        curve_pre.loc[curve_pre.product_code_final == producto ,'range_pd'] = cut(curve_pre.loc[curve_pre.product_code_final == producto ,'min_pd'], bins=bins_pd, right=False)
        X.loc[X.product_code_final == producto ,'range_pd'] = cut(X.loc[X.product_code_final == producto ,'MontoPD'], bins=bins_pd, right=False)

    X = merge(X, curve_pre[["product_code_final","range_plazo","range_pd", "curve"]], on=["product_code_final","range_plazo","range_pd"], how='left')

    return X["curve"].to_frame()


def lgd_transform(X, param_localidad_zona):
    """ Genera el input necesario para el calculo de la curva de loss given default (LGD)

    Args:
        X: pandas DataFrame
        param_lgd_missing: pandas DataFrame
        param_localidad_zona: pandas DataFrame
        param_lgd_values: pandas DataFrame

    Returns:
        X: pandas DataFrame
    """
    X = X.copy()
    X.loc[:, "NumMesesAntiguedad"].fillna(80, inplace=True)

    param_localidad_zona.loc[:, "V_CodLocalidad"] = param_localidad_zona["V_CodLocalidad"].astype(int).astype(str).str.zfill(4) 
    X.loc[:, "V_CodLocalidad"] = X["V_CodLocalidad"].astype(int).astype(str).str.zfill(4) 
    X.loc[:, "Mto_gar"] = transf_gar(X[["Moneda", "MontoTipoCambio", "MontoGarantiaComercial", "MontoGarantiaAfectacion"]])
    X.loc[:, "ltv_ajust"] = (X["MontoSolicitado"] / X["Mto_gar"]).fillna(0.6440342)
    X.loc[:, "ltv_ajust"] = where(isinf(X["ltv_ajust"]), 0.6440342, X["ltv_ajust"])

    X.loc[:, 'flg_garantia'] = where(X['MontoGarantiaBCP'].fillna(0) > 0, 1, 0) 
    X.loc[:, 'flg_plazo_m_84'] = where(X['CantidadPlazo'].fillna(0) <= 84, 1, 0)  # AFI, Multi
    X = merge(X, param_localidad_zona[["V_CodLocalidad", "CodZona"]], on=["V_CodLocalidad"], how="left")
    X.loc[:, "CodZona"].fillna(0, inplace=True)

    # Variables de la LGD de Activo Fijo Inmueble y de Multiproposito
    X.loc[:, "flg_zona1"] = flg_zona1(X["CodZona"])
    X.loc[:, "flg_zona2"] = flg_zona2(X["CodZona"])
    X.loc[:, "flg_zona4"] = flg_zona4(X["CodZona"])

    X.loc[:, 'flg_plazo_m_12'] = where(X['CantidadPlazo'] <= 12, 1, 0)
    X.loc[:, 'FlgTenenciaPasivo'] = where(X['FlgTenenciaPasivo'] != 1, 0, X['FlgTenenciaPasivo'])
    X.loc[:,'intercept'] = 1

    return X


def lgd_predict(X, param_coefs_curva_base, lgd_for_ecap_map, param_coefs_curva_final, param_lgd_wo):
    """ Calcula la curva de loss given default (LGD)

    Args:
        X: pandas DataFrame
        param_T: pandas DataFrame
        lgd_for_ecap_map: pandas DataFrame
        param_T_final: pandas DataFrame
        param_lgd_wo: pandas DataFrame

    Returns:
        X["curve"]: Curva de loss given default
    """
    X = X.copy()
    X = merge(X, param_coefs_curva_base , on=["product_code_final"], how="left")

    # ====================================
    # ========== Curva base (*) ==========
    # ====================================
    # (*) Para CT es la curva final.
    #     Para Alpha, AFI, AFM y Multi es la curva base

    betas_list = [*set(param_coefs_curva_base.columns).difference(set(['product_code_final','maturity']))]
    varnames_list = [varname[2:] for varname in betas_list]

    t = arange(3, 145).reshape(1,-1)
    base_curve = sum(X[varnames_list].values*X[betas_list].values, axis=1).reshape(-1,1) + X["maturity"].values.reshape(-1,1)*t

    zeros_array = zeros((base_curve.shape[0], 2))
    base_curve = maximum(base_curve, 0)

    # ======================================
    # ========== Curva final (**) ==========
    # ======================================
    # (**) Este ajuste solo afecta a la LGD de Alpha, AFI, AFM y Multi
    
    betas_list = [*set(param_coefs_curva_final.columns).difference(set(['product_code_final','b_lgd_base']))]
    varnames_list = [varname[2:] for varname in betas_list]

    X = X[['product_code_final'] + varnames_list]
    X = merge(X, param_coefs_curva_final , on=["product_code_final"], how="left")

    curve_final = maximum(sum(X[varnames_list].values*X[betas_list].values, axis=1).reshape(-1,1) +  base_curve*X['b_lgd_base'].values.reshape(-1,1), 0)
    curve_final = concatenate((zeros_array, curve_final), axis=1)

    # Cap 60
    curve_final[:, 59:] = curve_final[:, 58].reshape(-1, 1)

    # =========================================
    # ========== Ajustes Covid (***) ==========
    # =========================================
    # (***) Solo afecta a la curva de LGD de AFI, AFM y Multi
    # El efecto covid de CT se desactivo en ~2Q 2022.
    # La LGD de Alpha nunca tuvo efecto covid desde su concepcion ~3Q 2022.
    curve_final_ct = copy(curve_final)

    # Variaciones dependiendo del producto
    product_code = X["product_code_final"].values
    b1 = ((product_code == 1) | (product_code == 5))  # Si es CT o Alpha no hay efecto covid
    b2 = ((product_code == 2) | (product_code == 4))
    b3 = (product_code == 3)  

    # Cap para los no CT
    covid2 = copy(curve_final)
    covid2[:, 12:18] = curve_final[:, 3:9]
    covid2[:, 3:12] = curve_final[:, 2].reshape(-1, 1)

    # Cap para los CT
    covid2_ct = copy(curve_final_ct) 

    covid2[b1] = covid2_ct[b1]

    # Factor NC
    a = divide(sum(curve_final[:, 2:12], axis=1), 10)
    b = divide(sum(covid2[:, 2:12], axis=1), 10)

    factor_wo = merge(X[["product_code_final"]], param_lgd_wo, on=["product_code_final"], how="left")["factor_wo"].values

    # Factores distintos por producto
    factor_nc_1 = 1  # No afecta a CT --> factor = 1
    factor_nc_2_4 = factor_wo - divide(b, a) + 1  # Factor AFI y Multi
    factor_nc_3 = maximum(divide(b, a) - factor_wo, 1)  # Factor AFM

    factor_nc = b1*factor_nc_1 + b2*factor_nc_2_4 + b3*factor_nc_3

    curve_new_lgd_final = copy(covid2)
    curve_new_lgd_final[:, 2:12] = curve_new_lgd_final[:, 2:12]*factor_nc.reshape(-1, 1)

    # No puede ser mayor a 1
    curve_new_lgd_final = minimum(curve_new_lgd_final, 1)

    # =========================================
    # Calculo de la LGD TTC (Through the cycle)
    # =========================================
    # LGD TTC: Se usa en el calculo del capital economico
    # Nota: El periodo de la LGD PIT (Point in time) que se usa como LGD TTC depende del producto y de la existencia de garantia
    df = merge(X[['product_code_final', 'flg_garantia']], lgd_for_ecap_map, on=['product_code_final', 'flg_garantia'], how='left')
    lgd_for_ecap = curve_new_lgd_final[range(len(curve_new_lgd_final)), df['lgd_point'].values]    
    # lgd_for_ecap = curve_final[range(len(curve_final)), df['lgd_point'].values]  # version sin covid

    X["curve"] = curve_new_lgd_final.tolist()
    lgd12 = curve_new_lgd_final[:, 11]
    
    return X["curve"].to_frame(), lgd_for_ecap.reshape(-1, 1), lgd12


def rr1_transform(X, param_T1, param_factor1):
    """ Genera el input necesario para el calculo de la curva de roll-rates 1 (RR1)

    Args:
        X: pandas DataFrame
        param_T1: pandas DataFrame
        producto_code_campaign: pandas DataFrame

    Returns:
        X: pandas DataFrame
    """
    X = X[["product_code_final", "CantidadPlazo", "ScoreApplicantVendida", "DeltaEntidades", "FlgComportamientoPersona"]].copy()

    # Merge de parametros, ya se maneja desde la fuente
    param_alpha_beta_factor = merge(param_T1, param_factor1, on=["product_code_final", "min_score", "max_score"], how="left")

    # Generacion de llaves para el cruce parametros (delta_entidades | tipo_cliente)
    X["delta_entidades"] = where(X["product_code_final"].isin([1, 5]), "No aplica", X["DeltaEntidades"].values)
    X["tipo_cliente"] = where(X["FlgComportamientoPersona"] == 0, "No Cliente", "Cliente")

    # Cruce de parametros
    X = merge(X, param_alpha_beta_factor, on=["product_code_final", "tipo_cliente", "delta_entidades"], how="left")    

    b_plazo_score = (X["CantidadPlazo"] >= X["min_plazo"]) & (X["CantidadPlazo"] <= X["max_plazo"]) &  \
        (X["ScoreApplicantVendida"] >= X["min_score"]) & (X["ScoreApplicantVendida"] <= X["max_score"])
    X = X[b_plazo_score][["product_code_final", "ScoreApplicantVendida", "alpha", "beta", "factor_1_30"]].reset_index()
    

    return X


def rr1_predict(X):
    """ Calcula la curva de roll-rates 1 (RR1)

    Args:
        X: pandas DataFrame
        param_factor1: pandas DataFrame

    Returns:
        X["curve"]: Curva de roll-rates 1
    """
    X = X.copy()

    # Calculo de la curva
    alpha, beta, factor = X["alpha"].values.reshape(-1, 1), X["beta"].values.reshape(-1, 1), X["factor_1_30"].values.reshape(-1, 1)
    t = arange(1, 145).reshape(1, -1)
    curve = multiply(multiply(alpha, log(t)) + beta, factor)
    columns = indices((curve.shape[0], curve.shape[1]))[1]

    # Cap del periodo 16 en adelante     
    mask_value = sum((columns == 15)*curve, axis=1).reshape(-1, 1)  
    curve = (columns < 16)*curve + (columns >= 16)*mask_value
    curve[:,:1] = 0 

    X["curve"] = curve.tolist()

    return X["curve"].to_frame()


def rr2_transform(X, param_T2, param_factor2):
    """ Genera el input necesario para el calculo de la curva de roll-rates 2 (RR2)

    Args:
        X: pandas DataFrame
        param_T2: pandas DataFrame
        producto_code_campaign: pandas DataFrame

    Returns:
        X: pandas DataFrame
    """
    X = X[["product_code_final", "CantidadPlazo", "ScoreApplicantVendida", "DeltaEntidades", "FlgComportamientoPersona"]].copy()

    # Merge de parametros
    param_alpha_beta_factor = merge(param_T2, param_factor2, on=["product_code_final", "min_score", "max_score"], how="left")

    # Generacion de llaves para el cruce parametros (delta_entidades | tipo_cliente)
    X["delta_entidades"] = where(X["product_code_final"].isin([1,5]), "No aplica", X["DeltaEntidades"].values)
    X["tipo_cliente"] = where(X["FlgComportamientoPersona"] == 0, "No Cliente", "Cliente")

    # Cruce de parametros
    X = merge(X, param_alpha_beta_factor, on=["product_code_final", "tipo_cliente", "delta_entidades"], how="left")    

    b_plazo_score = (X["CantidadPlazo"] >= X["min_plazo"]) & (X["CantidadPlazo"] <= X["max_plazo"]) &  \
        (X["ScoreApplicantVendida"] >= X["min_score"]) & (X["ScoreApplicantVendida"] <= X["max_score"])
    X = X[b_plazo_score][["product_code_final", "ScoreApplicantVendida", "alpha", "beta", "factor_31_60"]].reset_index()

    return X


def rr2_predict(X):
    """ Calcula la curva de roll-rates 2 (RR2)

    Args:
        X: pandas DataFrame
        param_factor2: pandas DataFrame

    Returns:
        X["curve"]: Curva de roll-rates 2
    """

    X = X.copy()

    # Calculo de la curva
    alpha, beta, factor = X["alpha"].values.reshape(-1, 1), X["beta"].values.reshape(-1, 1), X["factor_31_60"].values.reshape(-1, 1)
    t = arange(1, 145).reshape(1, -1)
    curve = multiply(multiply(alpha, log(t)) + beta, factor)
    columns = indices((curve.shape[0], curve.shape[1]))[1]

    # Cap del periodo 16 en adelante     
    mask_value = sum((columns == 15)*curve, axis=1).reshape(-1, 1)  
    curve = (columns < 16)*curve + (columns >= 16)*mask_value
    curve[:,:1] = 0 

    X["curve"] = curve.tolist()

    return X["curve"].to_frame()

def cap_transform(X):
    """ Genera el input necesario para el calculo del capital economico (CAP)

    Args:
        X: pandas DataFrame
        param_PDTTC: pandas DataFrame

    Returns:
        X: pandas DataFrame
    """
    X = X[["product_code_final", "NumSegmentoOrtogonal"]].copy()

    return X


def cap_predict(X, param_PDTTC, param_scalar):
    """ Calcula el capital economico (CAP)

    Args:
        X: pandas DataFrame
        param_scalar: pandas DataFrame

    Returns:
        X["curve"]: Capital economico
    """

    X = X.copy()

    # Score asociado a la PD 12 PIT
    pd12 = X["PD12"].values 
    
    ## NEW CURVE ###
    X = merge(X, param_scalar, on=["product_code_final"], how="left")
    
    X["score_pdpit12"] = clip(round(X["scalar_slope"].values * log(pd12/(1 - pd12)) + X["scalar_intercept"].values, 0), 0, 1000)

    # PD TTC desde parametro
    X = merge(X, param_PDTTC, left_on=["product_code_final", "NumSegmentoOrtogonal"], right_on=["product_code_final", "segmento_ortogonal"], how="left")
    b_rango_score = (X["score_pdpit12"] >= X["min_score"]) & (X["score_pdpit12"] <= X["max_score"])
    X = X[b_rango_score] 

    # Especificacion para el calculo (X)
    X["intercepto"] = 1
    X["pd_ttc_2"] = power(X["pd_ttc"].values, 2)
    X["lgd_ttc_2"] = power(X["lgd_ttc"].values, 2)
    X["pd_x_lgd"] = X["pd_ttc"].values * X["lgd_ttc"].values
    X_vars = X[["intercepto", "pd_ttc", "lgd_ttc", "pd_ttc_2", "lgd_ttc_2", "pd_x_lgd"]].copy()

    # Coeficientes (B)
    coeficientes = X[["b_intercept", "b_pd", "b_lgd", "b_pd2", "b_lgd2", "b_pdxlgd"]].copy()

    # Computation (X * B)
    X["curve"] = norm.cdf(sum(array(X_vars)*array(coeficientes), axis=1)) * X["escalar_banca"].values

    return X["curve"].to_frame(), X['pd_ttc'].values, X['lgd_ttc'].values, X["curve"].values


def costos_transform(X, param_costos_t_0, param_costos_lifetime):
    """ Calcula los factores de costos del cronograma

    Args:
        X: pandas DataFrame
        param_costos_t_0: pandas DataFrame
        param_costos_lifetime: pandas DataFrame

    Returns:
        costos_t_0_fact:
        costos_lifetime_fact:     
    """

    X = X.copy()

    # Costos t=0:
    X = merge(X, param_costos_t_0, on=["product_code_final"], how="left")

    # Costo por canal (en lugar del ponderado):
    X.loc[:, "costo_ffnn"] = where(X["canal_venta"] == "TRADICIONAL", X["ffnn_tradicional"].values, 
                                   where( X["canal_venta"] == "DIGITAL", X["ffnn_digital"].values, X["ffnn_outbound"].values))
    
    # Validar qué costo es el que se va a usar
    # costos_t_0_fact = X["FFNN_fijo"].values + X["CBM"].values  # Costo Ponderado
    costos_t_0_fact = X["costo_ffnn"].values + X["CBM"].values  # Costo por canal

    # Costos lifetime:
    X = merge(X, param_costos_lifetime, on=["product_code_final"], how="left")
    rr1_factor = X["costos_cob_1_30"].values
    rr2_factor = X["costos_cob_31_60"].values
    # Todos los valores entre costos_adm y costos_indirectos se agregan para multiplicar en cada t al % CH
    # CH_factor = sum(X.loc[:, "costos_adm":"costos_indirectos"], axis=1).values
    CH_factor = sum(X.loc[:, ['costos_adm_unidades', 'costos_procesos_op_y_trans_unidades', 'costos_twow_unidades','costos_indirectos_unidades']], axis=1).values #New
    B_factor = sum(X.loc[:, ['costos_adm_saldo', 'costos_indirectos_saldo','costos_twow_saldo']], axis=1).values # New
    costo_mant_sbs_factor = X["costos_mantSBS"].values

    moneda = X["Moneda"].values
    tc = X["MontoTipoCambio"].values
    b_moneda = (moneda == "DOLARES")
    costos_t_0_fact[b_moneda] = divide(costos_t_0_fact[b_moneda], tc[b_moneda])
    
    rr1_factor[b_moneda] = divide(rr1_factor[b_moneda], tc[b_moneda])
    rr2_factor[b_moneda] = divide(rr2_factor[b_moneda], tc[b_moneda])
    CH_factor[b_moneda] = divide(CH_factor[b_moneda], tc[b_moneda])

    # costos_lifetime_fact = [rr1_factor, rr2_factor, costo_mant_sbs_factor, CH_factor]
    costos_lifetime_fact = [rr1_factor, rr2_factor, costo_mant_sbs_factor, CH_factor, B_factor] # New

    return costos_t_0_fact, costos_lifetime_fact


def inof_transform(X, param_ixs):
    """ Calcula los factores de los ingresos no financieros del cronograma

    Args:
        X: pandas DataFrame
        param_ixs: pandas DataFrame con los params de ingresos por servicios

    Returns:
        inof_fact:     
    """
    X = X.copy()

    #X = merge(X, param_ixs, on=["product_code_final"], how="left")
    #inof_fact = X[["portes","desgravamen","cobranza"]]

    #tc_portes = X["tc_mov_u12"].values
    #moneda = X["Moneda"].values
    #b_moneda = (moneda == "DOLARES")
    #inof_fact["portes"][b_moneda] = divide(inof_fact["portes"][b_moneda], tc_portes[b_moneda])
    
    bins_desembolso = [0] + list(param_ixs.monto_max.unique())
    param_ixs['range_monto'] = cut(param_ixs.monto_min, bins=bins_desembolso, right=False)
    X['range_monto'] = cut(X.MontoSolicitado, bins=bins_desembolso, right=False)
    X = merge(X, param_ixs, on=["product_code_final", "range_monto"], how="left")
    X.drop(columns=['range_monto'], inplace=True)

    # X = merge(X, param_ixs, on=["product_code_final"], how="left")
    inof_fact = X.loc[:, "portes":"cobranza"]

    tc_portes = X["tc_mov_u12"].values
    moneda = X["Moneda"].values
    b_moneda = (moneda == "DOLARES")
    inof_fact["portes"][b_moneda] = divide(inof_fact["portes"][b_moneda], tc_portes[b_moneda])

    return inof_fact


def tt_desc_transform(X, param_remcap, param_prepagos, param_tt_factor, param_tasadescuento_tmin, flag_monitoreo):
    """ Calcula los params de tasa de transferencia, remuneracion del capital y tasas de descuento del cronograma

    Args:
        X: pandas DataFrame
        param_remcap: pandas DataFrame con los params de la remuneracion de capital
        param_prepagos: pandas DataFrame con los params de los prepagos de riesgos de mercado para el calculo de la tt zero cupon
        param_tt_factor: pandas DataFrame con los params de la tt para el calculo de la tt zero cupon

    Returns:
        df_tt_desc: pandas DataFrame  
    """
    # X = X[["product_code_final", "CantidadPlazo", "Moneda", "MontoSolicitado"]].copy()

    X = X.copy()

    # Check if TT Dato (Para Pricing quizás no viene el dato, para monitoreo debe estar en X)
    X.loc[:, 'TT'] = 0.07 if 'TT' not in X.columns else X['TT'].values
    if 'TT' not in X.columns: print("La TT no es dato. Se calcula con los params TT ZC.")

    # RemCap
    # X.loc[:, "RemCap"] = array(param_remcap["Anual"])[0]  

    if flag_monitoreo==True:
        param_remcap = param_remcap.rename(columns={'Anual':'RemCap'})
        X = merge(X, param_remcap[['MESAPERTURA','RemCap']], on=["MESAPERTURA"], how="left")
        X['RemCap'].fillna(param_remcap[param_remcap.MESAPERTURA == param_remcap.MESAPERTURA.max()]["RemCap"].values[0], inplace=True)
    elif flag_monitoreo==False:
        X.loc[:, "RemCap"] = array(param_remcap[param_remcap.MESAPERTURA == param_remcap.MESAPERTURA.max()]["Anual"])[0]
    else:
        print("Revisar RemCap")

    # # NEW REBATE CURVE 
    # X['MES_MIN_REBATE'] = param_remcap.MESAPERTURA.min()
    # X['MESAPERTURA_DATE'] = to_datetime(X['MESAPERTURA'], format='%Y%m')
    # X['MES_MIN_REBATE_DATE'] = to_datetime(X['MES_MIN_REBATE'], format='%Y%m')
    # X['diff_meses_rebate'] = (X['MESAPERTURA_DATE'].dt.year - X['MES_MIN_REBATE_DATE'].dt.year)*12 + X['MESAPERTURA_DATE'].dt.month - X['MES_MIN_REBATE_DATE'].dt.month

    # diff_meses_rebate = X['diff_meses_rebate'].values
    # curva_base_rebate = param_remcap.Anual.values
    # curva_base_rebate = repeat(curva_base_rebate[:, newaxis], X.shape[0], axis=1).T # Iniciamos con la misma curva base del rebate para todos los desembolsos
    # X.drop(columns=['MES_MIN_REBATE','MESAPERTURA_DATE','MES_MIN_REBATE_DATE','diff_meses_rebate'], inplace=True)

    # pos = where(arange(curva_base_rebate.shape[1]) >= diff_meses_rebate[:, newaxis]) # Guardamos las posiciones de los elementos que se utilizaran para cada curva
    # y_index = pos[0]
    # x_index = pos[1] - repeat(diff_meses_rebate, curva_base_rebate.shape[1]-abs(where(diff_meses_rebate>=0, diff_meses_rebate, 0)))
    # mask_index = (x_index < curva_base_rebate.shape[1])
    # curva_rebate_final = zeros_like(curva_base_rebate)
    # curva_rebate_final[y_index[mask_index], x_index[mask_index]] = curva_base_rebate[pos[0][mask_index], pos[1][mask_index]]

    # curva_rebate_final = curva_rebate_final[:,:144]
    # curva_rebate_final = curva_base_rebate[:,:144]
    # X['RemCap'] = curva_rebate_final.tolist()

    ########################################################
    #### Params TT Zero Cupon (Curva TT + Prepagos RDM) ####
    ########################################################

    # Mask plazo para el cruce de params
    temp = X['CantidadPlazo'].values
    mask_plazo = where(temp>132, 144, where(temp>120, 132, where(temp>108, 120, where(temp>96, 108,
        where(temp>84, 96, where(temp>72, 84, where(temp>60, 72, where(temp>48, 60, where(temp>36, 48,
        where(temp>24, 36, where(temp>12, 24, 12)))))))))))
    # Si el producto es Capital de Trabajo y plazo>24, entonces se toma la curva a plazo 24 (no existe curva >24)
    mask_plazo = where((X["product_code_final"].values == 1) & (mask_plazo > 24), 36, mask_plazo)
    X.loc[:, 'CantidadPlazo'] = mask_plazo

    # 1. Curva TT
    X["tt_fact_soles"] = [param_tt_factor[param_tt_factor["Moneda"] == "SOLES"]["tt_fact"].values] * X.shape[0]
    X["tt_fact_dolares"] = [param_tt_factor[param_tt_factor["Moneda"] == "DOLARES"]["tt_fact"].values] * X.shape[0]
    X["tt_fact"] = where(X["Moneda"] == "SOLES", X["tt_fact_soles"].values, X["tt_fact_dolares"].values)
    # Nominalizando la curva de TT's
    X["tt_fact"] = (power(1 + X['tt_fact'], 1/12) - 1)*12  # OFSAA

    # 2. Prepagos RDM
    param_prepagos_piv = pivot_table(param_prepagos, index=["CantidadPlazo", "Moneda", "product_code_final"], columns="t", values="prepagoRDM")
    col = param_prepagos_piv.apply(lambda x: x.values, axis=1)
    col.name = "prepagoRDM"
    col = col.reset_index()
    X = merge(X, col, on=["CantidadPlazo", "Moneda", "product_code_final"], how="left")

    # 3. Tasa de descuento para tasa mínima (TIR 19)
    X.loc[:, "Tasa_dscto"] = param_tasadescuento_tmin["Tasa_dscto"].values[0]

    # Reportando
    df_tt_desc = X[["product_code_final", "MontoSolicitado", "TT", "RemCap", "prepagoRDM", "tt_fact", "Tasa_dscto"]]
    # df_tt_desc = X.copy()

    return df_tt_desc

def get_df_azul(BaseAzul, synth_Azul, data_vars):
    """

    Args:
        BaseAzul: Usamos PD_PRE_COVID (Va a cambiar a PD_FWL), MTO_NETO
        --> Puede llegar el plazo?
        synth_Azul:
        data_vars:
        codmes: Fecha de la Campaña en Formato YYYYMM

    Returns:
        pandas DataFrame with CLV format   
    """

    BaseAzul = BaseAzul.copy()
    synth_Azul = synth_Azul.copy()

    ######## KEY

    ###### AZUL
    BaseAzul.loc[(BaseAzul['PD_COVID_2_0'] < 0.008088451), 'RANPD'] = 1
    BaseAzul.loc[(BaseAzul['PD_COVID_2_0'] < 0.013601354) & (BaseAzul['PD_COVID_2_0'] >= 0.008088451), 'RANPD'] = 2
    BaseAzul.loc[(BaseAzul['PD_COVID_2_0'] < 0.01979524225) & (BaseAzul['PD_COVID_2_0'] >= 0.013601354), 'RANPD'] = 3
    BaseAzul.loc[(BaseAzul['PD_COVID_2_0'] >= 0.01979524225), 'RANPD'] = 4

    BaseAzul.loc[(BaseAzul['MTO_NETO'] < 295000), 'RANMONTO'] = 1
    BaseAzul.loc[(BaseAzul['MTO_NETO'] < 397000) & (BaseAzul['MTO_NETO'] >= 295000), 'RANMONTO'] = 2
    BaseAzul.loc[(BaseAzul['MTO_NETO'] < 650000) & (BaseAzul['MTO_NETO'] >= 397000), 'RANMONTO'] = 3
    BaseAzul.loc[(BaseAzul['MTO_NETO'] < 1000000) & (BaseAzul['MTO_NETO'] >= 650000), 'RANMONTO'] = 4
    BaseAzul.loc[(BaseAzul['MTO_NETO'] >= 1000000), 'RANMONTO'] = 5

    BaseAzul.KEY = BaseAzul.RANPD.astype(int).astype(str) + BaseAzul.RANMONTO.astype(int).astype(str)

    BaseAzul['SC_PRE_COVID'] = round(-57.707801636*log(BaseAzul['PD_COVID_2_0']/(1-BaseAzul['PD_COVID_2_0']))+174.24575241, 0)
    BaseAzul['SC_COVID_2_0'] = round(-57.707801636*log(BaseAzul['PD_COVID_2_0']/(1-BaseAzul['PD_COVID_2_0']))+174.24575241, 0)
    
    BaseAzul['TEA'] = 0.12  # Valor auxiliar
    
    #### EDITING LEADS

    BaseAzulf = DataFrame({
        'CODCLAVECIC':BaseAzul.CODCLAVECIC,
        'MontoPD':BaseAzul.PD_COVID_2_0,
        'ScoreApplicantVendida':BaseAzul.SC_PRE_COVID,
        'NumPDVendida':BaseAzul.PD_COVID_2_0,
        'ScoreApplicant':BaseAzul.SC_COVID_2_0, 
        'MontoSolicitado':BaseAzul.MTO_NETO,
        'KEY':BaseAzul.KEY})

    BaseAzulf.dropna(subset=['MontoPD'])

    BaseAzulf = BaseAzulf[BaseAzulf.MontoPD > 0]

    BaseAzulf.KEY = BaseAzulf.KEY.astype(int)

    ########## MERGE

    Azulpv = merge(BaseAzulf, synth_Azul, how='left', on='KEY')

    Azulpv.loc[Azulpv['MontoSolicitado'] <= 8000, 'MontoSolicitado'] = Azulpv['MontoSolicitadopivot']

    ###### DATA COMPLETA A FUSIONAR

    BaseAzulf2 = DataFrame({
        'CODCLAVECIC': Azulpv['CODCLAVECIC'], 
        'MontoPD': Azulpv['MontoPD'], 
        'ScoreApplicantVendida': Azulpv['ScoreApplicantVendida'], 
        'MontoSolicitado': Azulpv['MontoSolicitado'], 
        'ProductoMic': Azulpv['ProductoMic'], 
        'TipoCreditoMic': Azulpv['TipoCreditoMic'],
        'TipoActivo': Azulpv['TipoActivo'],
        'CampanaMic': Azulpv['CampanaMic'],
        'CantidadPlazo': Azulpv['CantidadPlazo'],
        'PeriodoGracia': Azulpv['PeriodoGracia'],
        'MontoTipoCambio': Azulpv['MontoTipoCambio'],
        'NumPDVendida': Azulpv['NumPDVendida'],
        'ScoreApplicant': Azulpv['ScoreApplicant'],
        'MontoGarantiaBCP2': Azulpv['MontoGarantiaBCP'],
        'MontoGarantiaComercial2': Azulpv['MontoGarantiaComercial'],
        'MontoGarantiaAfectacion2': Azulpv['MontoGarantiaAfectacion']})

    ###### DATA 1x1

    data_vars = data_vars.copy()
   
    data_vars['Moneda'] = 'SOLES'
 
    data_vars['TieneGarantia'] = data_vars['TIENEGARANTIA'].fillna('SIN')
    data_vars['NumSegmentoOrtogonal'] = data_vars['NUMSEGMENTOOTORGONAL_NOREV'].fillna(5)
    data_vars['RatioEndeudamiento'] = data_vars['RATIOENDEUDAMIENTO_12_24M'].fillna(1.12)
    data_vars['RatioEndeudamientoU6MU12M'] = data_vars['RATIOENDEUDAMIENTO_6_12M'].fillna(0)
    data_vars['NumMesesAntiguedad'] = data_vars['NUMMESESANTIGUEDAD'].fillna(115)

    data_vars["CODLOCALIDAD"].fillna("1782", inplace=True)  # Missing Values
    data_vars['V_CodLocalidad'] = data_vars['CODLOCALIDAD'].astype(int).astype(str).str.zfill(4)  # Convirtiendo a char(4)

    data_vars['FlgTenenciaPasivo'] = data_vars['FLG_PASIVO'].fillna(0)

    data_vars.loc[data_vars['FLGCOMPORTAMIENTOPERSONA'] == 'CON COMPORTAMIENTO', 'FlgComportamientoPersona'] = 1
    data_vars.loc[data_vars['FLGCOMPORTAMIENTOPERSONA'] == 'SIN COMPORTAMIENTO', 'FlgComportamientoPersona'] = 0
    data_vars['FlgComportamientoPersona'] = data_vars['FlgComportamientoPersona'].fillna(0)

    data_vars.loc[data_vars['DELTAENTIDADES'] == '0 o menos', 'DeltaEntidades'] = '0 o menos'
    data_vars.loc[data_vars['DELTAENTIDADES'] != '0 o menos', 'DeltaEntidades'] = data_vars['DELTAENTIDADES']
    data_vars['DeltaEntidades'] = data_vars['DeltaEntidades'].fillna('0 o menos')
   
    BaseOtrasVar2 = data_vars[[
        "CODCLAVECIC", "Moneda", "TieneGarantia", "NumSegmentoOrtogonal", "RatioEndeudamiento", "RatioEndeudamientoU6MU12M",
        "NumMesesAntiguedad", "V_CodLocalidad", "FlgTenenciaPasivo", "FlgComportamientoPersona", "DeltaEntidades"
    ]]

    BaseAzulf2prevfin = merge(BaseOtrasVar2, BaseAzulf2, on=['CODCLAVECIC'], how='right')

    BaseAzulf2prevfin['MontoGarantiaBCP'] = BaseAzulf2prevfin['MontoGarantiaBCP2']
    BaseAzulf2prevfin['MontoGarantiaComercial'] = BaseAzulf2prevfin['MontoGarantiaComercial2']
    BaseAzulf2prevfin['MontoGarantiaAfectacion'] = BaseAzulf2prevfin['MontoGarantiaAfectacion2']
    BaseAzulf2prevfin['TieneGarantia'] = BaseAzulf2prevfin['TieneGarantia'].fillna('SIN')
    BaseAzulf2prevfin['MontoGarantiaBCP'] = BaseAzulf2prevfin['MontoGarantiaBCP'].fillna(0)
    BaseAzulf2prevfin['NumSegmentoOrtogonal'] = BaseAzulf2prevfin['NumSegmentoOrtogonal'].fillna(5)
    BaseAzulf2prevfin['FlgComportamientoPersona'] = BaseAzulf2prevfin['FlgComportamientoPersona'].fillna(0)
    BaseAzulf2prevfin['RatioEndeudamiento'] = BaseAzulf2prevfin['RatioEndeudamiento'].fillna(1.12)
    BaseAzulf2prevfin['Moneda'] = BaseAzulf2prevfin['Moneda'].fillna('SOLES')
    BaseAzulf2prevfin['DeltaEntidades'] = BaseAzulf2prevfin['DeltaEntidades'].fillna('0 o menos')
    BaseAzulf2prevfin['NumMesesAntiguedad'] = BaseAzulf2prevfin['NumMesesAntiguedad'].fillna(115)
    BaseAzulf2prevfin['V_CodLocalidad'] = BaseAzulf2prevfin['V_CodLocalidad'].fillna("1782")
    BaseAzulf2prevfin['RatioEndeudamientoU6MU12M'] = BaseAzulf2prevfin['RatioEndeudamientoU6MU12M'].fillna(0)
    BaseAzulf2prevfin['FlgTenenciaPasivo'] = BaseAzulf2prevfin['FlgTenenciaPasivo'].fillna(0)
    BaseAzulf2prevfin['MontoGarantiaComercial'] = BaseAzulf2prevfin['MontoGarantiaComercial'].fillna(0)
    BaseAzulf2prevfin['MontoGarantiaAfectacion'] = BaseAzulf2prevfin['MontoGarantiaAfectacion'].fillna(0)
    BaseAzulf2prevfin['MontoTasaEspecial'] = 0.15

    # Reporte
    Azulvf = BaseAzulf2prevfin[[
        "CODCLAVECIC", "MontoPD", "ScoreApplicantVendida", "TieneGarantia", "MontoGarantiaBCP", "NumSegmentoOrtogonal",
        "FlgComportamientoPersona", "MontoSolicitado", "ProductoMic", "TipoCreditoMic", "TipoActivo", "CampanaMic",
        "RatioEndeudamiento", "CantidadPlazo", "Moneda", "DeltaEntidades", "PeriodoGracia", "MontoTasaEspecial",
        "NumMesesAntiguedad", "V_CodLocalidad", "RatioEndeudamientoU6MU12M", "FlgTenenciaPasivo", "MontoTipoCambio",
        "MontoGarantiaComercial", "MontoGarantiaAfectacion", "NumPDVendida", "ScoreApplicant"
    ]]

    return Azulvf


def limpiezaseguimiento(data_vars):
    """

    Args:
        data_vars:

    Returns: 
        pandas DataFrame
    """
    data_vars = data_vars.copy()   

    # data_vars['CODCLAVECIC'] = data_vars['CODCLAVECIC']
    # data_vars['MontoPD'] = data_vars['MONTOPD']
    # data_vars['NumPDVendida'] = data_vars['NUMPDVENDIDA']
    # data_vars['TieneGarantia'] = data_vars['TIENEGARANTIA']
    # data_vars['MontoGarantiaBCP'] = data_vars['MONTOGARANTIABCP']
    # data_vars['NumSegmentoOrtogonal'] = data_vars['NUMSEGMENTOORTOGONAL']
    # data_vars['FlgComportamientoPersona'] = data_vars['FLGCOMPORTAMIENTOPERSONA']
    # data_vars['MontoSolicitado'] = data_vars['MONTOSOLICITADO']
    # data_vars['ProductoMic'] = data_vars['PRODUCTOMIC']
    # data_vars['TipoCreditoMic'] = data_vars['TIPOCREDITOMIC']
    # data_vars['TipoActivo'] = data_vars['TIPOACTIVO']
    # data_vars['CampanaMic'] = data_vars['CAMPANAMIC']
    # data_vars['RatioEndeudamiento'] = data_vars['RATIOENDEUDAMIENTO']
    # data_vars['CantidadPlazo'] = data_vars['CANTIDADPLAZO']
    # data_vars['Moneda'] = data_vars['MONEDA']
    # data_vars['DeltaEntidades'] = data_vars['DELTAENTIDADES']
    # data_vars['PeriodoGracia'] = data_vars['PERIODOGRACIA']
    # data_vars['MontoTasaEspecial']= data_vars['MONTOTASAESPECIAL']  
    # data_vars['NumMesesAntiguedad']= data_vars['NUMMESESANTIGUEDAD']
    # data_vars['V_CodLocalidad']= data_vars['V_CODLOCALIDAD']
    # data_vars['RatioEndeudamientoU6MU12M']= data_vars['RATIOENDEUDAMIENTOU6MU12M']
    # data_vars['FlgTenenciaPasivo'] = data_vars['FLGTENENCIAPASIVO']
    # data_vars['MontoTipoCambio'] = data_vars['MONTOTIPOCAMBIO']
    # data_vars['MontoGarantiaComercial'] = data_vars['MONTOGARANTIACOMERCIAL']
    # data_vars['MontoGarantiaAfectacion'] = data_vars['MONTOGARANTIAAFECTACION']
    # data_vars['MontoAporteProducto'] = data_vars['MONTOAPORTEPRODUCTO'] 

    data_vars['DeltaEntidades'] = 'Incrementa'
    data_vars['PeriodoGracia'] = 0
    data_vars['MontoGarantiaBCP'] = data_vars['MontoGarantiaBCP'].fillna(0)
    data_vars['MontoGarantiaComercial'] = data_vars['MontoGarantiaBCP']
    data_vars['MontoGarantiaAfectacion'] = data_vars['MontoGarantiaBCP']
    data_vars['ScoreApplicantVendida'] = round(-57.707801636*log(data_vars['MontoPD']/(1-data_vars['MontoPD']))+174.24575241, 0)
    data_vars['ScoreApplicant'] = round(-57.707801636*log(data_vars['NumPDVendida']/(1-data_vars['NumPDVendida']))+174.24575241, 0)
    data_vars["V_CodLocalidad"].fillna("1782", inplace=True)  # Missing Values
    data_vars['V_CodLocalidad'] = data_vars['V_CodLocalidad'].astype(int).astype(str).str.zfill(4)  # Convirtiendo a char(4)
    data_vars['RatioEndeudamiento'] = data_vars['RatioEndeudamiento'].fillna(0)
    data_vars[data_vars['NumMesesAntiguedad'] < 0]["NumMesesAntiguedad"] = 0
    b = (data_vars["TipoActivo"]=="NOT")&(data_vars["CantidadPlazo"]>24)
    data_vars["CantidadPlazo"][b] = 24
    b = (data_vars["TipoActivo"]=="Inmueble")&(data_vars["CantidadPlazo"]>144)
    data_vars["CantidadPlazo"][b] = 144
    b = (data_vars["TipoActivo"]=="Mueble")&(data_vars["CantidadPlazo"]>60)
    data_vars["CantidadPlazo"][b] = 60
    b = (data_vars["TipoActivo"]=="Multiproposito")&(data_vars["CantidadPlazo"]>72)
    data_vars["CantidadPlazo"][b] = 72
    data_vars2 = data_vars.copy()

    data_final = data_vars2[[
        "CODCLAVECIC", "MontoPD", "ScoreApplicantVendida", "TieneGarantia", "MontoGarantiaBCP", "NumSegmentoOrtogonal",
        "FlgComportamientoPersona", "MontoSolicitado", "ProductoMic", "TipoCreditoMic", "TipoActivo", "CampanaMic",
        "RatioEndeudamiento", "CantidadPlazo", "Moneda", "DeltaEntidades", "PeriodoGracia", "MontoTasaEspecial",
        "NumMesesAntiguedad", "V_CodLocalidad", "RatioEndeudamientoU6MU12M", "FlgTenenciaPasivo", "MontoTipoCambio",
        "MontoGarantiaComercial", "MontoGarantiaAfectacion", "NumPDVendida", "ScoreApplicant",
        # "CAMPANIA_PYME", "Tasa_Pizarra", "Tasa_10D"    
    ]]
    
    return data_final


def get_formato_clv(inputs):
    """
    Agrega valores restantes del csv de desembolsos del datamart para tener el csv con todas las variables input del clv
    Input: Base --> T03833.INPUT_CLV_PYMENR_MENSUAL

    Args:
        inputs: T03833.INPUT_CLV_PYMENR_MENSUAL

    Returns:
        pandas DataFrame with CLV format     
    """
    
    inputs = inputs.copy()

    # Renombrando variables
    inputs.rename(
        columns={
            'CODCLAVEOPECTA': 'CODCLAVECIC', 'MONTOPD': 'MontoPD', 'NUMPDVENDIDA': 'NumPDVendida', 'TIENEGARANTIA': 'TieneGarantia',
            'MONTOGARANTIABCP': 'MontoGarantiaBCP', 'NUMSEGMENTOORTOGONAL': 'NumSegmentoOrtogonal', 'FLGCOMPORTAMIENTOPERSONA': 'FlgComportamientoPersona',
            'MONTOSOLICITADO': 'MontoSolicitado', 'PRODUCTOMIC': 'ProductoMic', 'TIPOCREDITOMIC': 'TipoCreditoMic', 'TIPOACTIVO': 'TipoActivo',
            'CAMPANAMIC': 'CampanaMic', 'RATIOENDEUDAMIENTO': 'RatioEndeudamiento', 'CANTIDADPLAZO': 'CantidadPlazo', 'MONEDA': 'Moneda', 
            'DELTAENTIDADES': 'DeltaEntidades', 'NUMMESESANTIGUEDAD': 'NumMesesAntiguedad', 
            'V_CODLOCALIDAD': 'V_CodLocalidad', 'RATIOENDEUDAMIENTOU6MU12M': 'RatioEndeudamientoU6MU12M', 'FLGTENENCIAPASIVO': 'FlgTenenciaPasivo',
            'MONTOTIPOCAMBIO': 'MontoTipoCambio', 'TEA': 'MontoTasaEspecial', 'CODMES': 'MESAPERTURA', 'CANAL_VENTA':'canal_venta','MONTOFAD':'fad'
        },
        inplace=True
    )

    # Completando variables
    inputs.loc[:, 'PeriodoGracia'] = 0
    inputs.loc[:, 'MontoGarantiaBCP'] = inputs['MontoGarantiaBCP'].fillna(0)
    inputs.loc[:, 'MontoGarantiaComercial'] = inputs['MontoGarantiaBCP']
    inputs.loc[:, 'MontoGarantiaAfectacion'] = inputs['MontoGarantiaBCP']
    inputs.loc[:, 'ScoreApplicantVendida'] = round(-57.707801636 * log(inputs['MontoPD'] / (1 - inputs['MontoPD'])) + 174.24575241, 0)
    inputs.loc[:, 'ScoreApplicant'] = round(-57.707801636 * log(inputs['NumPDVendida'] / (1 - inputs['NumPDVendida'])) + 174.24575241, 0)

    inputs["V_CodLocalidad"].fillna("1782", inplace=True)  # Missing Values
    inputs['V_CodLocalidad'] = inputs['V_CodLocalidad'].astype(int).astype(str).str.zfill(4)  # Convirtiendo a char(4)

    inputs['RatioEndeudamiento'].fillna(0, inplace=True)
    inputs.loc[inputs['NumMesesAntiguedad'] < 0, "NumMesesAntiguedad"] = 0

    # Controlando los plazos máximos por tipo de producto
    b = (inputs["TipoActivo"] == "NOT") & (inputs["CantidadPlazo"] > 36)
    inputs.loc[b, "CantidadPlazo"] =  36
    b = (inputs["TipoActivo"] == "Inmueble") & (inputs["CantidadPlazo"] > 144)
    inputs.loc[b, "CantidadPlazo"] = 144
    b = (inputs["TipoActivo"] == "Mueble") & (inputs["CantidadPlazo"] > 60)
    inputs.loc[b, "CantidadPlazo"] = 60
    b = (inputs["TipoActivo"] == "Multiproposito") & (inputs["CantidadPlazo"] > 72)
    inputs.loc[b, "CantidadPlazo"] = 72

    return inputs[[
        'CODCLAVECIC', 'TT', 'MontoPD', 'ScoreApplicantVendida', 'TieneGarantia', 'MontoGarantiaBCP', 'NumSegmentoOrtogonal', 
        'FlgComportamientoPersona', 'MontoSolicitado', 'ProductoMic', 'TipoCreditoMic', 'TipoActivo', 'CampanaMic',  
        'RatioEndeudamiento', 'CantidadPlazo', 'Moneda', 'DeltaEntidades',  'PeriodoGracia', 'MontoTasaEspecial', 
        'NumMesesAntiguedad', 'V_CodLocalidad', 'RatioEndeudamientoU6MU12M', 'FlgTenenciaPasivo', 'MontoTipoCambio', 'MontoGarantiaComercial', 
        'MontoGarantiaAfectacion', 'NumPDVendida', 'ScoreApplicant', 'CAMPANIA_PYME', 'TEA_PIZARRA', 'TEA_10DD', 'MESAPERTURA','canal_venta'
        # 'CANAL_VENTA'
    ]]


def get_df_cen(data_leads, data_vars, synth_costos, flag_costos_tacticos=False):
    """

    Args:
        data_leads:
        data_vars:
        synth_costos:
        codmes: Fecha de la Campaña en Formato YYYYMM
        flag_costos_tacticos:
            i) Si flag_costos_tacticos=True -> El script se ejecuta para hacer Pricing
            --> Se usa el MontoPromedio (Sintético) para proyectar los flujos de caja y asignar tasa.
            ii) Si flag_costos_tacticos=False -> El script se ejecuta para calcular rentabilidad
            --> Se usa el MTOFINALOFERADO (Real) para proyectar los flujos de caja y calcular rentabilidades.

    Returns:
        pandas DataFrame with CLV format
    """

    data_vars = data_vars.copy()    
    data_vars['ProductoMic'] = 'EFECTIVO DE NEGOCIO'
    data_vars['TipoCreditoMic'] = 'CATR'
    data_vars['TipoActivo'] = 'NOT'
    data_vars['CampanaMic'] = 'CREDITO FLEXIBLE'
    data_vars['Moneda'] = 'SOLES'
    data_vars['PeriodoGracia'] = 0
    data_vars['MontoTasaEspecial'] = 0.18
    data_vars['MontoTipoCambio'] = 3.80

    data_vars['TieneGarantia'] = data_vars['TIENEGARANTIA'].fillna('SIN')
    data_vars['MontoGarantiaBCP'] = data_vars['MONTOGARANTIA'].fillna(0)
    data_vars['NumSegmentoOtorgonal'] = data_vars['NUMSEGMENTOOTORGONAL_NOREV'].fillna(5)
    data_vars['RatioEndeudamiento'] = data_vars['RATIOENDEUDAMIENTO_12_24M'].fillna(1.12)
    data_vars['RatioEndeudamientoU6MU12M'] = data_vars['RATIOENDEUDAMIENTO_6_12M'].fillna(0)
    data_vars['NumMesesAntiguedad'] = data_vars['NUMMESESANTIGUEDAD'].fillna(115)

    data_vars["CODLOCALIDAD"].fillna("1782", inplace=True)  # Missing Values
    data_vars['V_CodLocalidad'] = data_vars['CODLOCALIDAD'].astype(int).astype(str).str.zfill(4)  # Convirtiendo a char(4)

    data_vars['FlgTenenciaPasivo'] = data_vars['FLG_PASIVO'].fillna(0)

    data_vars.loc[data_vars['FLGCOMPORTAMIENTOPERSONA'] == 'CON COMPORTAMIENTO', 'FlgComportamientoPersona'] = 1
    data_vars.loc[data_vars['FLGCOMPORTAMIENTOPERSONA'] == 'SIN COMPORTAMIENTO', 'FlgComportamientoPersona'] = 0
    data_vars['FlgComportamientoPersona'] = data_vars['FlgComportamientoPersona'].fillna(0)

    data_vars.loc[data_vars['DELTAENTIDADES'] == '0 o menos', 'DeltaEntidades'] = '0 o menos'
    data_vars.loc[data_vars['DELTAENTIDADES'] != '0 o menos', 'DeltaEntidades'] = data_vars['DELTAENTIDADES']
    data_vars['DeltaEntidades'] = data_vars['DeltaEntidades'].fillna('0 o menos')

    data_vars['MontoGarantiaComercial'] = data_vars['MontoGarantiaBCP']
    data_vars['MontoGarantiaAfectacion'] = data_vars['MontoGarantiaBCP']

    data_leads = data_leads[~isnan(data_leads["PD_APROBADOCEN_FINAL"].values)]
    data_leads = data_leads[~isnan(data_leads["MTOFINALOFERTADO"].values)]
    data_leads['MontoPD'] = data_leads['PD_APROBADOCEN_COVID_FINAL']
    data_leads['NumPDVendida'] = data_leads['PD_APROBADOCEN_COVID_FINAL']

    data_leads['ScoreApplicantVendida'] = round(-57.707801636 * log(data_leads['MontoPD'] / (1 - data_leads['MontoPD'])) + 174.24575241, 0)
    data_leads['ScoreApplicant'] = round(-57.707801636 * log(data_leads['NumPDVendida'] / (1 - data_leads['NumPDVendida'])) + 174.24575241, 0)

    # ARMANDO EL MONTO SOMBRA
    bins = [-inf, 0.0106626451 , 0.019790469152189 , 0.033561209249168 , inf]
    labels = arange(1, 5)
    bins2 = [-inf, 70000, 90000, 102000, 130000, 150000, 162726, 180000, 194000, 250000, inf]
    labels2 = arange(1, 11)
    data_leads['CUARTILPD'] = cut(data_leads['MontoPD'], bins = bins, labels = labels)
    data_leads['DECILMONTO'] = cut(data_leads['MTOFINALOFERTADO'], bins = bins2, labels = labels2)
    data_leads['KEY'] = data_leads.CUARTILPD.astype(int).astype(str) + data_leads.DECILMONTO.astype(int).astype(str)
    data_leads['KEY']= data_leads.KEY.astype(int)

    data_leads = merge(data_leads, synth_costos, how='left', on='KEY')

    # Monto Solicitado depende del flag_costos_tacticos
    if flag_costos_tacticos:
        # Si flag_costos_tacticos=True -> El script se ejecuta para hacer Pricing
        # --> Se usa el MontoPromedio (Sintético) para proyectar los flujos de caja y asignar tasa.
        print("El ajuste de monto por costos tácticos está activo.")
        print("--> MontoSolicitado se está reemplazando por un Monto Sintético.")
        data_leads['MontoSolicitado'] = data_leads['MontoPromedio']  # Monto Sombra
        data_leads.loc[:, "monto_ofertado_real"] = data_leads["MTOFINALOFERTADO"].values  # Monto Real
    else:
        # Si flag_costos_tacticos=False -> El script se ejecuta para calcular rentabilidad
        # --> Se usa el MTOFINALOFERADO (Real) para proyectar los flujos de caja y calcular rentabilidades.
        print("El ajuste de monto por costos tácticos está apagado.")    
        print(" --> MontoSolicitado es el monto real.")
        data_leads['MontoSolicitado'] = data_leads["MTOFINALOFERTADO"].values  # Monto Real
        data_leads.loc[:, "monto_ofertado_real"] = data_leads["MTOFINALOFERTADO"].values  # Monto Real

    data_leads['MontoGarantiaBCP2'] = data_leads['MONTOLIBREGARANTIASOL']
    data_leads['MontoGarantiaComercial2'] = data_leads['MontoGarantiaBCP2']
    data_leads['MontoGarantiaAfectacion2'] = data_leads['MontoGarantiaBCP2']
    data_leads['CantidadPlazo'] = data_leads['PLAZO']

    data_vars2 = merge(data_vars, data_leads, how='right', on='CODCLAVECIC')

    data_vars2['MontoGarantiaBCPf'] = data_vars2['MontoGarantiaBCP2'].fillna(data_vars2['MontoGarantiaBCP'])
    data_vars2['MontoGarantiaComercialf'] = data_vars2['MontoGarantiaComercial2'].fillna(data_vars2['MontoGarantiaComercial'])
    data_vars2['MontoGarantiaAfectacionf'] = data_vars2['MontoGarantiaAfectacion2'].fillna(data_vars2['MontoGarantiaAfectacion'])
    
    data_vars2['MontoTasaEspecial2'] = data_vars2['TASA']

    data_final = DataFrame({
        'CODCLAVECIC': data_vars2['CODCLAVECIC'],
        'MontoPD': data_vars2['MontoPD'],
        'ScoreApplicantVendida': data_vars2['ScoreApplicantVendida'],
        'TieneGarantia': data_vars2['TieneGarantia'],
        'MontoGarantiaBCP': data_vars2['MontoGarantiaBCPf'],
        'NumSegmentoOrtogonal': data_vars2['NumSegmentoOtorgonal'],
        'FlgComportamientoPersona': data_vars2['FlgComportamientoPersona'],
        'MontoSolicitado': data_vars2['MontoSolicitado'],
        'ProductoMic': data_vars2['ProductoMic'],
        'TipoCreditoMic': data_vars2['TipoCreditoMic'],
        'TipoActivo': data_vars2['TipoActivo'],
        'CampanaMic': data_vars2['CampanaMic'],
        'RatioEndeudamiento': data_vars2['RatioEndeudamiento'],
        'CantidadPlazo': data_vars2['CantidadPlazo'],
        'Moneda': data_vars2['Moneda'],
        'DeltaEntidades': data_vars2['DeltaEntidades'],
        'PeriodoGracia': data_vars2['PeriodoGracia'],
        'MontoTasaEspecial': data_vars2['MontoTasaEspecial2'],
        'NumMesesAntiguedad': data_vars2['NumMesesAntiguedad'],
        'V_CodLocalidad': data_vars2['V_CodLocalidad'],
        'RatioEndeudamientoU6MU12M': data_vars2['RatioEndeudamientoU6MU12M'],
        'FlgTenenciaPasivo': data_vars2['FlgTenenciaPasivo'],
        'MontoTipoCambio': data_vars2['MontoTipoCambio'],
        'MontoGarantiaComercial': data_vars2['MontoGarantiaComercialf'],
        'MontoGarantiaAfectacion': data_vars2['MontoGarantiaAfectacionf'],
        'NumPDVendida': data_vars2['NumPDVendida'],
        'ScoreApplicant': data_vars2['ScoreApplicant'],
        'monto_ofertado_real': data_vars2['monto_ofertado_real']
        })

    # Ajuste por incongruencias entre el campo TieneGarantia y MontoGarantiaBCP
    data_final['MontoGarantiaBCP'] = where(data_final['TieneGarantia']=='CON', data_final['MontoGarantiaBCP'], 0)
    
    return data_final


def get_df_afi(BaseAFI, synth_AFInmueble, data_vars):
    """ Da formato CLV a las ofertas de la campana TOP AFI
    
    Args:
        BaseAFI: pandas DataFrame con el universo de la campana TOP AFI
        Usamos CODCLAVECIC, PD_COVID_TOP_AFI (Va a cambiar a PD_FWL), MONTO_APROBAR_INPUT_276
        --> Puede llegar el plazo?
        synth_AFInmueble: pandas DataFrame que contiene los valores sinteticos promedio de Garantia y Plazo por cortes de PD y Monto
        data_vars: pandas DataFrame que contiene las variables CLV

    Returns:
        pandas DataFrame with CLV format
    """

    df_afi = BaseAFI[["CODCLAVECIC", "PD_CAL_TOP_AFI_276", "PD_COVID_TOP_AFI", "MONTO_APROBAR_INPUT_276"]].copy()

    # Missings = Promedio de la base
    df_afi.fillna({
        "PD_COVID_TOP_AFI": BaseAFI["PD_COVID_TOP_AFI"].mean(), 
        "MONTO_APROBAR_INPUT_276": BaseAFI["MONTO_APROBAR_INPUT_276"].mean()}, 
        inplace=True)
    
    df_afi['PD_COVID_TOP_AFI_2'] = df_afi['PD_COVID_TOP_AFI'].copy()
    
    df_afi.rename(columns={"PD_COVID_TOP_AFI":"MontoPD", "MONTO_APROBAR_INPUT_276":"MontoSolicitado", "PD_COVID_TOP_AFI_2": "NumPDVendida"}, inplace=True)

    ## KEY para el sintetico (synth_AFInmueble)
    puntos_corte_pd = synth_AFInmueble["max_pd"].unique()
    puntos_corte_pd.sort()
    puntos_corte_monto = synth_AFInmueble["max_monto"].unique()
    puntos_corte_monto.sort()

    # Generando cuartiles de pd en base a distribucion historica
    df_afi.loc[(df_afi['NumPDVendida'] < puntos_corte_pd[0]), 'cuartil_pd'] = 1
    df_afi.loc[(df_afi['NumPDVendida'] < puntos_corte_pd[1]) & (df_afi['NumPDVendida'] >= puntos_corte_pd[0]), 'cuartil_pd'] = 2
    df_afi.loc[(df_afi['NumPDVendida'] < puntos_corte_pd[2]) & (df_afi['NumPDVendida'] >= puntos_corte_pd[1]), 'cuartil_pd'] = 3
    df_afi.loc[(df_afi['NumPDVendida'] >= puntos_corte_pd[2]), 'cuartil_pd'] = 4

    # Generando quintiles de monto en base a distribucion historica
    df_afi.loc[(df_afi['MontoSolicitado'] < puntos_corte_monto[0]), 'quintil_monto'] = 1
    df_afi.loc[(df_afi['MontoSolicitado'] < puntos_corte_monto[1]) & (df_afi['MontoSolicitado'] >= puntos_corte_monto[0]), 'quintil_monto'] = 2
    df_afi.loc[(df_afi['MontoSolicitado'] < puntos_corte_monto[2]) & (df_afi['MontoSolicitado'] >= puntos_corte_monto[1]), 'quintil_monto'] = 3
    df_afi.loc[(df_afi['MontoSolicitado'] < puntos_corte_monto[3]) & (df_afi['MontoSolicitado'] >= puntos_corte_monto[2]), 'quintil_monto'] = 4
    df_afi.loc[(df_afi['MontoSolicitado'] >= puntos_corte_monto[3]), 'quintil_monto'] = 5

    # Armando la llave para el sintetico
    df_afi["key"] = (df_afi["cuartil_pd"].astype(int).astype(str) + df_afi["quintil_monto"].astype(int).astype(str)).astype(int)

    #### EDITING LEADS

    # Agregando Garantia, Monto Historico y Plazo desde sintetico (Monto Historico solo se usa en caso el desembolso de la oferta sea menor a 8000) 
    df_afi = merge(
        df_afi, synth_AFInmueble.drop(columns=["min_pd", "max_pd", "min_monto", "max_monto"]), 
        on=["key"], how='left')

    # Si el monto de la oferta es menor a 8000 --> Se usa el promedio historico del sintetico
    df_afi.loc[df_afi['MontoSolicitado'] <= 8000, 'MontoSolicitado'] = df_afi['MontoSolicitado_Historico']

    # Generando Score en base a PD input
    df_afi['ScoreApplicantVendida'] = round(-57.707801636*log(df_afi['MontoPD']/(1-df_afi['MontoPD']))+174.24575241, 0)
    df_afi['ScoreApplicant'] = round(-57.707801636*log(df_afi['NumPDVendida']/(1-df_afi['NumPDVendida']))+174.24575241, 0)

    # Merge con variables CLV por cliente
    df_afi = merge(df_afi, data_vars, on=["CODCLAVECIC"], how="left")

    # Renombrando variables
    df_afi.rename(
        columns={
            "TIENEGARANTIA": "TieneGarantia", "NUMSEGMENTOOTORGONAL_NOREV": "NumSegmentoOrtogonal", 
            "RATIOENDEUDAMIENTO_12_24M": "RatioEndeudamiento", "RATIOENDEUDAMIENTO_6_12M": "RatioEndeudamientoU6MU12M",
            "NUMMESESANTIGUEDAD": "NumMesesAntiguedad", "CODLOCALIDAD": "V_CodLocalidad", "FLG_PASIVO": "FlgTenenciaPasivo",
            "FLGCOMPORTAMIENTOPERSONA": "FlgComportamientoPersona", "DELTAENTIDADES": "DeltaEntidades",
            "MONTOGARANTIA":"MontoGarantiaBCP"}, inplace=True)

    # Completando missing values
    df_afi.fillna({
            "TieneGarantia": "SIN", "NumSegmentoOrtogonal": 5, "RatioEndeudamiento": 1.12, "RatioEndeudamientoU6MU12M": 0, "NumMesesAntiguedad": 115,
            "V_CodLocalidad": "1782", "FlgTenenciaPasivo": 0, "FlgComportamientoPersona": "SIN COMPORTAMIENTO", "DeltaEntidades": "0 o menos"}, 
        inplace=True)

    df_afi["MontoGarantiaComercial"] = df_afi["MontoGarantiaBCP"].values
    df_afi["MontoGarantiaAfectacion"] = df_afi["MontoGarantiaBCP"].values

    # Completando missing values con sinteticos
    # Si tenemos la Garantia en data_vars usamos esa, sino usamos la del sintetico
    df_afi["MontoGarantiaBCP"] = where(df_afi["MontoGarantiaBCP"].isna(), df_afi["MontoGarantiaBCP_sintetico"], df_afi["MontoGarantiaBCP"])
    df_afi["MontoGarantiaComercial"] = where(df_afi["MontoGarantiaComercial"].isna(), df_afi["MontoGarantiaComercial_sintetico"], df_afi["MontoGarantiaComercial"])
    df_afi["MontoGarantiaAfectacion"] = where(df_afi["MontoGarantiaAfectacion"].isna(), df_afi["MontoGarantiaAfectacion_sintetico"], df_afi["MontoGarantiaAfectacion"])

    # Adicionales
    df_afi['V_CodLocalidad'] = df_afi['V_CodLocalidad'].astype(int).astype(str).str.zfill(4)  # Convirtiendo a char(4)
    df_afi["FlgComportamientoPersona"] = where(df_afi["FlgComportamientoPersona"] == "CON COMPORTAMIENTO", 1, 0)

    # Completando variables CLV adicionales
    df_afi["Moneda"] = "SOLES"
    df_afi["MontoTipoCambio"] = 3.9
    df_afi[["ProductoMic", "TipoCreditoMic", "TipoActivo", "CampanaMic"]] = ["NEGOCIO COMERCIAL", "ACFI", "Inmueble", "AFI 750M 1200M"] 
    df_afi["PeriodoGracia"] = 0
    df_afi["MontoTasaEspecial"] = 0.1

    """
    TODO: hacer un select de las variables que se utilizaran y quitar las de los merge 
    """

    return df_afi


def get_df_wtp_afi(BaseAFI, synth_AFInmueble, data_vars, data_escenarios):
    """

    Args:
        BaseAFI:
        synth_AfInmueble:
        data_vars:
        data_escenarios:
        codmes: Fecha de la Campaña en Formato YYYYMM

    Returns:
        pandas DataFrame with CLV format
    """

    # Preprocesamiento del df de la campaña AFI
    AFIvf = get_df_afi(BaseAFI, synth_AFInmueble, data_vars)

    # Agregando variables a los escenarios
    data_escenarios = data_escenarios.copy()
    # data_escenarios.drop(columns=["T_PD", "T_MTO"], inplace=True)
    # data_escenarios.drop(columns=["TEA_TT", "TEA_TT_Pred_Final", "TT"], inplace=True)
    data_escenarios["MontoSolicitado2"] = data_escenarios["MONTOSOLICITADO"]
    data_escenarios["MontoGarantiaBCP2"] = data_escenarios["MIC_GARANTIA_UM"]
    data_escenarios["MontoGarantiaComercial2"] = data_escenarios["MIC_GARANTIA_UM"]
    data_escenarios["MontoGarantiaAfectacion2"] = data_escenarios["MIC_GARANTIA_UM"]
    data_escenarios["MontoTasaEspecial2"] = data_escenarios["TEA"]

    AFIvf2 = merge(data_escenarios, AFIvf, on=["CODCLAVECIC"], how="left")

    AFIvf2["V_CodLocalidad"].fillna("1782", inplace=True)  # Missing Values
    AFIvf2['V_CodLocalidad'] = AFIvf2['V_CodLocalidad'].astype(int).astype(str).str.zfill(4)  # Convirtiendo a char(4)

    AFIvf2.drop(columns=["MontoSolicitado", "MontoGarantiaBCP", "MontoGarantiaComercial", "MontoGarantiaAfectacion",
        "MontoTasaEspecial"], inplace=True)

    AFIvf2.rename(columns={"MontoSolicitado2": "MontoSolicitado", "MontoGarantiaBCP2": "MontoGarantiaBCP",
        "MontoGarantiaComercial2": "MontoGarantiaComercial", "MontoGarantiaAfectacion2": "MontoGarantiaAfectacion",
        "MontoTasaEspecial2": "MontoTasaEspecial", "T_PD_agg": "T_PD", "T_MTO_agg": "T_MTO"}, inplace=True)

    AFIvf3 = AFIvf2[[
        "CODCLAVECIC", "MontoPD", "ScoreApplicantVendida", "TieneGarantia", "MontoGarantiaBCP", "NumSegmentoOrtogonal", 
        "FlgComportamientoPersona", "MontoSolicitado", "ProductoMic", "TipoCreditoMic", "TipoActivo", "CampanaMic", 
        "RatioEndeudamiento", "CantidadPlazo", "Moneda", 'DeltaEntidades', 'PeriodoGracia',
        'MontoTasaEspecial','NumMesesAntiguedad','V_CodLocalidad', 'RatioEndeudamientoU6MU12M', 'FlgTenenciaPasivo',
        'MontoTipoCambio', 'MontoGarantiaComercial', 'MontoGarantiaAfectacion', 'NumPDVendida', 'ScoreApplicant', 
        "cluster", "Escenario", "T_PD", "T_MTO", "Prob"]]

    AFIvf3.sort_values(by=['CODCLAVECIC','Escenario'], inplace=True)

    return AFIvf3


def get_alpha_formato_clv(inputs):
    """
    Converts DM_PYMENR_ORIGINACION_DETALLE to CLV format for alpha pyme purposes

    Args:
        inputs: pandas DataFrame without CLV format --> T03833.DM_PYMENR_ORIGINACION_DETALLE

    Returns:
        pandas DataFrame with CLV format
    """

    inputs = inputs.copy()

    # Renombrando variables (formato clv) de la base input
    inputs.rename(
        columns={
            "CODMES": "MESAPERTURA", "MONEDA": "Moneda", "MONTO": "MontoSolicitado", "PLAZO": "CantidadPlazo", "TEA": "MontoTasaEspecial",
            "TT_DWH": "TT", "PD_APPLICANT": "MontoPD", "GARANTIA": "TieneGarantia"},
        inplace=True
    )
    inputs.loc[:, 'TieneGarantia'] = inputs['TieneGarantia'].str.upper()
    inputs.loc[:, 'Moneda'] = where(inputs['Moneda'].values == 'PEN', 'SOLES', 'DOLARES')

    # Para generar el product_code_final = 1 (Capital de Trabajo)
    inputs.loc[:, 'ProductoMic'] = 'EFECTIVO DE NEGOCIO'
    inputs.loc[:, 'TipoCreditoMic'] = 'CATR'
    inputs.loc[:, 'TipoActivo'] = 'NOT'
    inputs.loc[:, 'CampanaMic'] = 'CREDITO FLEXIBLE'

    # Mismo Score pre y post
    inputs.loc[:, 'NumPDVendida'] = inputs['MontoPD'].values
    inputs.loc[:, 'ScoreApplicantVendida'] = round(-57.707801636 * log(inputs['MontoPD'] / (1 - inputs['MontoPD'])) + 174.24575241, 0)
    inputs.loc[:, 'ScoreApplicant'] = round(-57.707801636 * log(inputs['NumPDVendida'] / (1 - inputs['NumPDVendida'])) + 174.24575241, 0)
    
    # Variables que se usan para CT (Debemos ver si las tenemos para alpha pyme)
    inputs.loc[:, 'FlgTenenciaPasivo'] = 0  # Variable se usa para LGD de CT
    inputs.loc[:, 'MontoTipoCambio'] = 3.7  # Variable de Tipo de Cambio en caso sea desembolso en dólares
    inputs.loc[:, 'PeriodoGracia'] = 0  # No se usa de momento, debería usarse
    inputs.loc[:, 'NumSegmentoOrtogonal'] = 14  # 
    inputs.loc[:, 'FlgComportamientoPersona'] = 0  # Variable se usa para RR1 y RR2 (Bucket 1 y 2)
    inputs.loc[:, 'DeltaEntidades'] = "0 o menos"  # Variable se usa para RR1 y RR2 (Bucket 1 y 2)
    inputs.loc[:, 'MontoGarantiaBCP'] = 0  # Variable se usa solo para LGD de AFM y CT

    # Variables que no se usan (El valor es irrelevante para una corrida de alpha pyme)
    inputs.loc[:, 'RatioEndeudamientoU6MU12M'] = 0.5  # Variable se usa solo para LGD de AFI y MPP
    inputs.loc[:, 'V_CodLocalidad'] = '1330'  # Variable se usa solo para LGD de AFI y MPP
    inputs.loc[:, 'NumMesesAntiguedad'] = 200  # Variable se usa solo para LGD de AFI y MPP
    inputs.loc[:, 'RatioEndeudamiento'] = 1  # Variable se usa solo para LGD de AFI y MPP
    inputs.loc[:, 'MontoGarantiaComercial'] = 0  # Variable se usa para LGD de AFM (Loan To Value)
    inputs.loc[:, 'MontoGarantiaAfectacion'] = 0  # Variable se usa para LGD de AFM (Loan To Value)

    inputs.rename(columns={'CANAL_VENTA': 'canal_venta'}, inplace=True)
    inputs = inputs[inputs['CantidadPlazo'] <= 24]
    inputs.dropna(subset=['MontoPD', 'TT', 'ScoreApplicantVendida', 'CantidadPlazo'], inplace=True)

    df = inputs[[
        'CODCLAVECIC', 'TT', 'MontoPD', 'ScoreApplicantVendida', 'TieneGarantia', 'MontoGarantiaBCP', 'NumSegmentoOrtogonal', 
        'FlgComportamientoPersona', 'MontoSolicitado', 'ProductoMic', 'TipoCreditoMic', 'TipoActivo', 'CampanaMic',
        'RatioEndeudamiento', 'CantidadPlazo', 'Moneda', 'DeltaEntidades', 'PeriodoGracia', 'MontoTasaEspecial', 
        'NumMesesAntiguedad', 'V_CodLocalidad', 'RatioEndeudamientoU6MU12M', 'FlgTenenciaPasivo', 'MontoTipoCambio', 'MontoGarantiaComercial',
        'MontoGarantiaAfectacion', 'NumPDVendida', 'ScoreApplicant', 'MESAPERTURA', 'canal_venta'
        ]]

    return df


def get_alpha_formato_clv_3(inputs):
    """
    Converts DM_PYMENR_ORIGINACION_DETALLE to CLV format for alpha pyme purposes

    Args:
        inputs: pandas DataFrame without CLV format --> T03833.DM_PYMENR_ORIGINACION_DETALLE

    Returns:
        pandas DataFrame with CLV format
    """

    inputs = inputs.copy()

    # Renombrando variables (formato clv) de la base input
    inputs.rename(
        columns={
            "CODMES": "MESAPERTURA", "MONEDA": "Moneda", "MONTOSOLICITADO": "MontoSolicitado", "CANTIDADPLAZO": "CantidadPlazo", "TEA": "MontoTasaEspecial",
            "NUMPDVENDIDA": "NumPDVendida", "TIENEGARANTIA": "TieneGarantia", "FLGTENENCIAPASIVO": "FlgTenenciaPasivo", "MONTOTIPOCAMBIO": "MontoTipoCambio",
            "NUMSEGMENTOORTOGONAL": "NumSegmentoOrtogonal", "FLGCOMPORTAMIENTOPERSONA": "FlgComportamientoPersona", "DELTAENTIDADES": "DeltaEntidades",
            "MONTOGARANTIABCP": "MontoGarantiaBCP", 
            "RATIOENDEUDAMIENTOU6MU12M":"RatioEndeudamientoU6MU12M", "V_CODLOCALIDAD": "V_CodLocalidad", "NUMMESESANTIGUEDAD": 'NumMesesAntiguedad',
            "RATIOENDEUDAMIENTO": "RatioEndeudamiento"},
        inplace=True
    )

    inputs.loc[:, 'TieneGarantia'] = inputs['TieneGarantia'].str.upper()
    inputs.loc[:, 'TieneGarantia'].fillna("SIN", inplace=True)
    inputs.loc[:, 'Moneda'].fillna("SOLES", inplace=True)

    # Para generar el product_code_final = 1 (Capital de Trabajo)
    inputs.loc[:, 'ProductoMic'] = 'EFECTIVO DE NEGOCIO'
    inputs.loc[:, 'TipoCreditoMic'] = 'CATR'
    inputs.loc[:, 'TipoActivo'] = 'NOT'
    inputs.loc[:, 'CampanaMic'] = 'CREDITO FLEXIBLE'

    # Mismo Score pre y post
    
    inputs.loc[:, 'MontoPD'] = inputs['NumPDVendida'].values
    inputs.loc[:, 'ScoreApplicantVendida'] = round(-57.707801636 * log(inputs['MontoPD'] / (1 - inputs['MontoPD'])) + 174.24575241, 0)
    inputs.loc[:, 'ScoreApplicant'] = round(-57.707801636 * log(inputs['NumPDVendida'] / (1 - inputs['NumPDVendida'])) + 174.24575241, 0)
    
    # Variables que se usan para CT (Debemos ver si las tenemos para alpha pyme)
    inputs.loc[:, 'FlgTenenciaPasivo'].fillna(0, inplace=True)  # Variable se usa para LGD de CT
    inputs.loc[:, 'MontoTipoCambio'].fillna(3.8, inplace=True)  # Variable de Tipo de Cambio en caso sea desembolso en dólares
    inputs.loc[:, 'PeriodoGracia'] = 0  # No se usa de momento, debería usarse
    inputs.loc[:, 'NumSegmentoOrtogonal'].fillna(3, inplace=True)  # 
    inputs.loc[:, 'FlgComportamientoPersona'].fillna(1, inplace=True)  # Variable se usa para RR1 y RR2 (Bucket 1 y 2)
    inputs.loc[:, 'DeltaEntidades'].fillna("Incrementa", inplace=True)  # Variable se usa para RR1 y RR2 (Bucket 1 y 2)
    inputs.loc[:, "MontoGarantiaBCP"] = where(inputs["TieneGarantia"] == "SIN", 0, 1)
    inputs.loc[:, 'MontoGarantiaBCP'].fillna(0, inplace=True)  # Variable se usa solo para LGD de AFM y CT

    # Variables que no se usan (El valor es irrelevante para una corrida de alpha pyme)
    inputs.loc[:, 'RatioEndeudamientoU6MU12M'].fillna(0.5, inplace=True)  # Variable se usa solo para LGD de AFI y MPP
    inputs.loc[:, 'V_CodLocalidad'].fillna('1330', inplace=True)  # Variable se usa solo para LGD de AFI y MPP
    inputs.loc[:, 'NumMesesAntiguedad'].fillna(200, inplace=True)  # Variable se usa solo para LGD de AFI y MPP
    inputs.loc[:, 'RatioEndeudamiento'].fillna(1, inplace=True)  # Variable se usa solo para LGD de AFI y MPP
    inputs.loc[:, 'MontoGarantiaComercial'] = inputs['MontoGarantiaBCP']  # Variable se usa para LGD de AFM (Loan To Value)
    inputs.loc[:, 'MontoGarantiaAfectacion'] = inputs['MontoGarantiaBCP'] # Variable se usa para LGD de AFM (Loan To Value)

    # inputs.rename(columns={'CANAL_VENTA': 'canal_venta'}, inplace=True)
    inputs = inputs[inputs['CantidadPlazo'] <= 24]
    inputs.dropna(subset=['MontoPD', 'TT', 'ScoreApplicantVendida', 'CantidadPlazo'], inplace=True)

    df = inputs[[
        'CODCLAVEOPECTA', 
        'TT', 'MontoPD', 'ScoreApplicantVendida', 'TieneGarantia', 'MontoGarantiaBCP', 'NumSegmentoOrtogonal', 
        'FlgComportamientoPersona', 'MontoSolicitado', 'ProductoMic', 'TipoCreditoMic', 'TipoActivo', 'CampanaMic',
        'RatioEndeudamiento', 'CantidadPlazo', 'Moneda', 'DeltaEntidades', 'PeriodoGracia', 'MontoTasaEspecial', 
        'NumMesesAntiguedad', 'V_CodLocalidad', 'RatioEndeudamientoU6MU12M', 'FlgTenenciaPasivo', 'MontoTipoCambio', 'MontoGarantiaComercial',
        'MontoGarantiaAfectacion', 'NumPDVendida', 'ScoreApplicant', 'MESAPERTURA', 
        # 'canal_venta'
        ]]

    return df


def reglas_de_negocio(monto_solicitado, param_rn, pd12_covid, r, flag_cen=False, flag_afi=False):

    X = DataFrame()

    if flag_cen:
        X['cut_monto'] = cut(
            monto_solicitado, 
            [0, 20000, 80000, 120000, 160000, 240000, 900000000],
            labels=[
                "[0, 20000)", "[20000, 80000)", "[80000, 120000)", "[120000, 160000)", "[160000, 240000)", "[240000, 900000000)"
                ],
            right=False,
            ordered=False
            )

        pd12_covid_temp = pd12_covid * 100

        X['cut_pd'] = cut(
            pd12_covid_temp, 
            [0, 1, 2, 3, 4, 5, 6, 7, 8, 100],
            labels=[
                "[0, 0.01)", "[0.01, 0.02)", "[0.02, 0.03)", "[0.03, 0.04)", "[0.04, 0.05)",
                "[0.05, 0.06)", "[0.06, 0.07)", "[0.07, 0.08)", "[0.08, 1)"
                ],
            right=False,
            ordered=False
            )

    elif flag_afi:

        X['cut_monto'] = cut(
            monto_solicitado, 
            [0, 250000, 400000, 600000, 900000000],
            labels=[
                "[0, 250000)", "[250000, 400000)", "[400000, 600000)", "[600000, 900000000)"
                ],
            right=False,
            ordered=False
            )

        pd12_covid_temp = pd12_covid * 100

        X['cut_pd'] = cut(
            pd12_covid_temp, 
            [0, 1, 2, 3, 4, 100],
            labels=[
                "[0, 0.01)", "[0.01, 0.02)", "[0.02, 0.03)", "[0.03, 0.04)", "[0.04, 1)"
                ],
            right=False,
            ordered=False
            )

    X = merge(X, param_rn[["cut_monto", "cut_pd", "piso", "techo"]], on=["cut_pd", "cut_monto"], how="left")
    
    piso = X["piso"].values
    techo = X["techo"].values

    r[r<piso] = piso[r<piso]
    r[r>techo] = techo[r>techo]

    if flag_afi:
        b = monto_solicitado < 20_000
        r[b] = techo[b]

    return r

def reglas_de_negocio_afi(monto_solicitado, param_rn, pd12_covid, r):

    X = DataFrame()

    X['cut_monto'] = cut(
        monto_solicitado, 
        [0, 250000, 400000, 600000, 900000000],
        labels=[
            "[0, 250000)", "[250000, 400000)", "[400000, 600000)", "[600000, 900000000)"
            ],
        right=False,
        ordered=False
        )

    pd12_covid_temp = pd12_covid * 100

    X['cut_pd'] = cut(
        pd12_covid_temp, 
        [0, 1, 2, 3, 4, 100],
        labels=[
            "[0, 0.01)", "[0.01, 0.02)", "[0.02, 0.03)", "[0.03, 0.04)", "[0.04, 1)"
            ],
        right=False,
        ordered=False
        )

    X = merge(X, param_rn[["cut_monto", "cut_pd", "piso", "techo"]], on=["cut_pd", "cut_monto"], how="left")
    
    piso = X["piso"].values
    techo = X["techo"].values

    r[r<piso] = piso[r<piso]
    r[r>techo] = techo[r>techo]

    b = monto_solicitado < 20_000
    r[b] = techo[b]

    return r 


def get_alpha_formato_clv_leads(inputs):
    """

    """

    inputs = inputs.copy()

    inputs.rename(columns={'MTOFINALOFERTADOSOL':'MontoSolicitado',
                    'NUMPLAZO':'CantidadPlazo',
                    'PD_ORIG':'MontoPD',
                    'MONTOGARANTIA':'MontoGarantiaBCP',
                    'TIENEGARANTIA':'TieneGarantia',
                    'DELTAENTIDADES':'DeltaEntidades',
                    'FLGCOMPORTAMIENTOPERSONA':'FlgComportamientoPersona',
                    'NUMSEGMENTOOTORGONAL_NOREV':'NumSegmentoOrtogonal',
                    'FLG_TENENCIA_PASIVO':'FlgTenenciaPasivo',
                    'CANAL':'canal_venta'
                    }, inplace=True)
    

    inputs['NumPDVendida'] = inputs['MontoPD'].values
    inputs['ScoreApplicantVendida'] = round(-57.707801636 * log(inputs['MontoPD'] / (1 - inputs['MontoPD'])) + 174.24575241, 0)
    inputs['ScoreApplicant'] = round(-57.707801636 * log(inputs['NumPDVendida'] / (1 - inputs['NumPDVendida'])) + 174.24575241, 0)

    inputs['MontoGarantiaBCP'].fillna(0, inplace=True) # Variable se usa solo para LGD de AFM y CT
    inputs['DeltaEntidades'].fillna('0 o menos', inplace=True) # Variable se usa para RR1 y RR2 (Bucket 1 y 2)
    inputs['FlgTenenciaPasivo'].fillna(0, inplace=True)  # Variable se usa para LGD de CT
    inputs['NumSegmentoOrtogonal'].fillna(3, inplace=True)
    inputs['FlgComportamientoPersona'].fillna("SIN COMPORTAMIENTO", inplace=True)  # Variable se usa para RR1 y RR2 (Bucket 1 y 2)
    inputs['TieneGarantia'] = inputs['TieneGarantia'].str.upper()
    inputs['TieneGarantia'].fillna("SIN", inplace=True)

    # Para generar el product_code_final = 1 (Capital de Trabajo)
    inputs['ProductoMic'] = 'EFECTIVO DE NEGOCIO'
    inputs['TipoCreditoMic'] = 'CATR'
    inputs['TipoActivo'] = 'NOT'
    inputs['CampanaMic'] = 'ALPHA'

    inputs['MontoTipoCambio'] = 3.8  # Variable de Tipo de Cambio en caso sea desembolso en dólares
    inputs['PeriodoGracia'] = 0  # No se usa de momento, debería usarse
    inputs['MontoTasaEspecial'] = 0.18 # Dummy
    inputs['Moneda'] = "SOLES" 

    # Variables que no se usan (El valor es irrelevante para una corrida de alpha pyme)
    inputs['RatioEndeudamientoU6MU12M'] = 0 # Variable se usa solo para LGD de AFI y MPP
    inputs['V_CodLocalidad'] = 0 # Variable se usa solo para LGD de AFI y MPP
    inputs['NumMesesAntiguedad'] = 0 # Variable se usa solo para LGD de AFI y MPP
    inputs['RatioEndeudamiento'] = 0 # Variable se usa solo para LGD de AFI y MPP
    inputs['MontoGarantiaComercial'] = inputs['MontoGarantiaBCP'] # Variable se usa para LGD de AFM (Loan To Value)
    inputs['MontoGarantiaAfectacion'] = inputs['MontoGarantiaBCP'] # Variable se usa para LGD de AFM (Loan To Value)

    inputs['FlgComportamientoPersona'] = where(inputs['FlgComportamientoPersona']=='SIN COMPORTAMIENTO', 0,1)

    df = inputs[['CODCLAVECIC','MontoSolicitado','CantidadPlazo','MontoPD','ScoreApplicantVendida','NumPDVendida',
            'ScoreApplicant','MontoGarantiaBCP','TieneGarantia','DeltaEntidades','FlgComportamientoPersona','NumSegmentoOrtogonal',
            'FlgTenenciaPasivo','Moneda','ProductoMic','TipoCreditoMic','TipoActivo','CampanaMic','MontoTipoCambio','PeriodoGracia',
            'RatioEndeudamientoU6MU12M','V_CodLocalidad','NumMesesAntiguedad','RatioEndeudamiento','MontoGarantiaComercial',
            'MontoGarantiaAfectacion','MontoTasaEspecial','canal_venta'
        ]]

    return df

def get_synth_update(input):
    """
    TODO: Docstring 
    """
    input = input.copy(deep=True)
    input.columns = input.columns.str.lower()

    pd_c1 = input['numpdvendida'].describe(percentiles=[0.25])['25%']
    pd_c2 = input['numpdvendida'].describe(percentiles=[0.5])['50%']
    pd_c3 = input['numpdvendida'].describe(percentiles=[0.75])['75%']

    monto_q1 = input['montosolicitado'].describe(percentiles=[0.2])['20%']
    monto_q2 = input['montosolicitado'].describe(percentiles=[0.4])['40%']
    monto_q3 = input['montosolicitado'].describe(percentiles=[0.6])['60%']
    monto_q4 = input['montosolicitado'].describe(percentiles=[0.8])['80%']

    input['c_pd'] = where(input['numpdvendida']<=pd_c1, 1,
                        where(input['numpdvendida']<=pd_c2, 2,  
                            where(input['numpdvendida']<=pd_c3, 3, 4)))

    input['q_monto'] = where(input['montosolicitado']<=monto_q1, 1,
                            where(input['montosolicitado']<=monto_q2, 2,  
                                where(input['montosolicitado']<=monto_q3, 3,
                                    where(input['montosolicitado']<=monto_q4, 4, 5))))
    
    input['key'] = input['c_pd'].astype(str)+input['q_monto'].astype(str)

    df_synth = input.groupby(['key']).agg(
                    MontoGrantiaBCP = ('montogarantiabcp','mean'), 
                    MontoGrantiaComercial = ('montogarantiabcp','mean'), 
                    MontoGrantiaAfectacion = ('montogarantiabcp','mean'), 
                    CantidadPlazo = ('cantidadplazo','mean'),
                    MontoSolicitado_Historico = ('montosolicitado','sum')).reset_index().round(0).astype(int)

    df_synth['min_pd'] = where(df_synth['key'].astype(str).str[:1] == '1', 0,
                            where(df_synth['key'].astype(str).str[:1] == '2', pd_c1.round(4),
                                where(df_synth['key'].astype(str).str[:1] == '3', pd_c2.round(4), pd_c3.round(4))))

    df_synth['max_pd'] = where(df_synth['key'].astype(str).str[:1] == '1', pd_c1.round(4),
                            where(df_synth['key'].astype(str).str[:1] == '2', pd_c2.round(4),
                                where(df_synth['key'].astype(str).str[:1] == '3', pd_c3.round(4), 1)))

    df_synth['min_monto'] = where(df_synth['key'].astype(str).str[1:] == '1', 0,
                                where(df_synth['key'].astype(str).str[1:] == '2', monto_q1.round(0),
                                    where(df_synth['key'].astype(str).str[1:] == '3', monto_q2.round(0),
                                        where(df_synth['key'].astype(str).str[1:] == '4', monto_q3.round(0), monto_q4.round(0)))))

    df_synth['max_monto'] = where(df_synth['key'].astype(str).str[1:] == '1', monto_q1.round(0),
                                where(df_synth['key'].astype(str).str[1:] == '2', monto_q2.round(0),
                                    where(df_synth['key'].astype(str).str[1:] == '3', monto_q3.round(0),
                                        where(df_synth['key'].astype(str).str[1:] == '4', monto_q4.round(0), 9000000000))))

    df_synth = df_synth[['key','min_pd','max_pd','min_monto','max_monto',
                        'MontoGrantiaBCP', 'MontoGrantiaComercial', 'MontoGrantiaAfectacion', 
                        'CantidadPlazo', 'MontoSolicitado_Historico']]

    return df_synth


def get_redondeo(tasas, step=0.005):
    """ Redondea las tasas segun el step definido

    Args:
        tasas: numpy array con tasas anuales sin redondear
        step: float que indica el valor a redondear
    
    Returns:
        numpy array con tasas anuales redondeadas segun el step definido
    """
    return step * round(tasas / step, 0)

def get_target_profitability(df_inputs, param_target_profitability):
    """Carga en memoria las tasas de descuento"""
    param_target_profitability.sort_values(by=['max_pd','max_des'], inplace=True)

    bins_pd = [0] + list(param_target_profitability.max_pd.unique())
    bins_desembolso = [0] + list(param_target_profitability.max_des.unique())

    param_target_profitability['range_pd'] = cut(param_target_profitability.min_pd, bins=bins_pd, right=False)
    param_target_profitability['range_desembolso'] = cut(param_target_profitability.min_des, bins=bins_desembolso, right=False)
    param_target_profitability.drop(columns=['min_pd', 'max_pd', 'min_des', 'max_des'],inplace=True)

    df_inputs['range_pd'] = cut(df_inputs.MontoPD, bins=bins_pd, right=False)
    df_inputs['range_desembolso'] = cut(df_inputs.MontoSolicitado, bins=bins_desembolso, right=False)

    df_inputs = df_inputs.merge(param_target_profitability, on=['range_pd','range_desembolso'], how='left')
    df_inputs.drop(columns=['range_pd', 'range_desembolso'], inplace=True)

    return df_inputs

def get_target_profitability_cen(df_inputs, param_target_profitability):
    """Carga en memoria las tasas de descuento"""
    param_target_profitability.sort_values(by=['max_pd','max_des'], inplace=True)

    bins_pd = [0] + list(param_target_profitability.max_pd.unique())
    bins_desembolso = [0] + list(param_target_profitability.max_des.unique())

    param_target_profitability['range_pd'] = cut(param_target_profitability.min_pd, bins=bins_pd, right=False)
    param_target_profitability['range_desembolso'] = cut(param_target_profitability.min_des, bins=bins_desembolso, right=False)
    param_target_profitability.drop(columns=['min_pd', 'max_pd', 'min_des', 'max_des'],inplace=True)

    df_inputs['range_pd'] = cut(df_inputs.MontoPD, bins=bins_pd, right=False)
    df_inputs['range_desembolso'] = cut(df_inputs.MontoSolicitado, bins=bins_desembolso, right=False)

    df_inputs = df_inputs.merge(param_target_profitability, on=['range_pd','range_desembolso'], how='left')
    df_inputs.drop(columns=['range_pd', 'range_desembolso'], inplace=True)

    return df_inputs


def get_target_profitability_product(df_inputs, param_target_profitability):
    """Carga en memoria las tasas de descuento"""
    param_target_profitability.sort_values(by=['product_code','max_pd','max_des'], inplace=True)

    param_target_profitability['range_pd'] = 0
    param_target_profitability['range_desembolso'] = 0
    df_inputs['range_pd'] = 0
    df_inputs['range_desembolso'] = 0  

    for product in range(1,6):

        bins_pd = [0] + list(param_target_profitability.loc[param_target_profitability.product_code == product, 'max_pd'].unique())
        bins_desembolso = [0] + list(param_target_profitability.loc[param_target_profitability.product_code == product, 'max_des'].unique())

        param_target_profitability.loc[param_target_profitability.product_code == product,'range_pd'] = cut(param_target_profitability.loc[param_target_profitability.product_code == product,'min_pd'], bins=bins_pd, right=False)
        param_target_profitability.loc[param_target_profitability.product_code == product,'range_desembolso'] = cut(param_target_profitability.loc[param_target_profitability.product_code == product,'min_des'], bins=bins_desembolso, right=False)
        
        # param_target_profitability.drop(columns=['min_pd', 'max_pd', 'min_des', 'max_des'],inplace=True)

        df_inputs.loc[df_inputs.product_code==product, 'range_pd'] = cut(df_inputs.loc[df_inputs.product_code==product,'MontoPD'], bins=bins_pd, right=False)
        df_inputs.loc[df_inputs.product_code==product, 'range_desembolso'] = cut(df_inputs.loc[df_inputs.product_code==product, 'MontoSolicitado'], bins=bins_desembolso, right=False)

    df_inputs = df_inputs.merge(param_target_profitability[['product_code','range_pd','range_desembolso', 'Tasa_dscto_tea']], on=['product_code','range_pd','range_desembolso'], how='left')
    # df_inputs.drop(columns=['range_pd', 'range_desembolso'], inplace=True)
    return df_inputs

def norm_cdf(x):
    # print(sqrt(2.0))
    def cdf1(value):
        return (1.0 + erf(value / 1.4142135623730951)) / 2.0 # (1.0 + erf(value / sqrt(2.0))) / 2.0

    if len(x)==1:
        #'Cumulative distribution function for the standard normal distribution'
        return cdf1(x)
    else:
        return array([[cdf1(item)] for item in x])