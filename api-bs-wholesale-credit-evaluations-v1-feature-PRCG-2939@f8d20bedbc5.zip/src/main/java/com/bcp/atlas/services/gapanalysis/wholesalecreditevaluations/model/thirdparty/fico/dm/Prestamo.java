package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;


/**
 * <br/>
 * Clase Interfaz del Servicio para la logica de negocio que consumira la clase REST
 * RateCalculationController<br/>
 * <b>Class</b>: RateCalculationService<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>G.CH.J</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Mar 25, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */

@Data
public class Prestamo implements Serializable {

  private static final long serialVersionUID = 1L;

  @JsonProperty("rk")
  private BigDecimal rk;

  @JsonProperty("pe")
  private BigDecimal pe;

  @JsonProperty("co")
  private BigDecimal co;

  @JsonProperty("tt")
  private BigDecimal tt;

  @JsonProperty("moneda")
  private String moneda;

  @JsonProperty("sc")
  private BigDecimal sc;

  //New Data
  @JsonProperty("codproducto")
  private String codproducto;

  @JsonProperty("diaslibor")
  private int diaslibor;

  @JsonProperty("importe")
  private BigDecimal importe;

  @JsonProperty("mtorenovacion")
  private BigDecimal mtorenovacion;

  @JsonProperty("plazo")
  private int plazo;

  @JsonProperty("tipotasa")
  private String tipotasa;

  @JsonProperty("fondeoespecial")
  private BigDecimal fondeoespecial;

  @JsonProperty("tipooperacion")
  private String tipooperacion;

  @JsonProperty("numletras")
  private int numletras;

  @JsonProperty("tipocambio")
  private BigDecimal tipocambio;

  @JsonProperty("tipocredito")
  private String tipocredito;

  @JsonProperty("tasaListaNegra")
  private BigDecimal tasaListaNegra;
}
