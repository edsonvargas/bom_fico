package com.bcp.atlas.services.gapanalysis.config;

import static java.util.Arrays.asList;
import static java.util.Objects.nonNull;
import static okhttp3.ConnectionSpec.CLEARTEXT;
import static okhttp3.ConnectionSpec.MODERN_TLS;

import com.bcp.atlas.core.header.HttpHeaderProperties;
import com.bcp.atlas.core.http.annotation.HttpComponentScan;
import com.bcp.atlas.core.http.client.interceptor.ApiExceptionInterceptor;
import com.bcp.atlas.core.http.client.interceptor.AtlasOkHttpLoggingInterceptor;
import com.bcp.atlas.core.http.client.interceptor.AuditHeadersInterceptor;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.web.server.Ssl;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

/**
 * Spring configuration for external Rest endpoints using <b>Retrofit</b>.<br/>
 * <b>Class</b>: RestClientConfiguration<br/>
 * <b>Copyright</b>: &copy; 2020 Banco de Cr&eacute;dito del Per&uacute;<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 * <u>Service Provider</u>: BCP <br/>
 * <u>Changes</u>:<br/>
 * <ul>
 * <li>Jun 7, 2021 Creaci&oacute;n de Clase.</li>
 * </ul>
 * @version 1.0
 */
@Slf4j
@SuppressFBWarnings(value = "CE_CLASS_ENVY", justification = "There are only configuration methods")
@Lazy
@Configuration
@RefreshScope
@HttpComponentScan(
    basePackages = {"com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy"})
public class RestClientConfiguration {

  @Bean
  @Scope("prototype")
  @ConditionalOnMissingBean(name = "customOkHttpClientBuilder")
  @SuppressWarnings("java:S5332")
  OkHttpClient.Builder customOkHttpClientBuilder(
      final ServerProperties serverProperties,
      @Autowired(required = false) final SSLSocketFactory socketFactory,
      @Autowired(required = false) final X509TrustManager trustManager,
      HttpHeaderProperties httpHeaderProperties,
      @Qualifier(CrossWholsaleInterceptor.BEAN_NAME) Interceptor requestCrossInterceptor) {

    OkHttpClient.Builder builder = new OkHttpClient.Builder();

    builder.addInterceptor(new AuditHeadersInterceptor(httpHeaderProperties));
    builder.addInterceptor(requestCrossInterceptor);
    builder.addInterceptor(new AtlasOkHttpLoggingInterceptor(() -> true));

    Ssl ssl = serverProperties.getSsl();
    if (nonNull(ssl) && ssl.isEnabled()) {
      builder
          .connectionSpecs(asList(CLEARTEXT, MODERN_TLS))
          .sslSocketFactory(socketFactory, trustManager);
      log.debug("Configuring custom Atlas OkHttpClient.Builder with SSL Context");
    } else {
      log.debug("Configuring custom Atlas OkHttpClient.Builder without SSL Context");
    }
    return builder;
  }

}
