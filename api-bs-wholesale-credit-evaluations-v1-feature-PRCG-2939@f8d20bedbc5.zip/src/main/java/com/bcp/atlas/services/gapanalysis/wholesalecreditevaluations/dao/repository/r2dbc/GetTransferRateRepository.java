package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc;


import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CommonTransferRate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


/**
 * <b>Class</b>: CreditInfoRepository<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis Peru SAC <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Feb 24, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */

@Repository
public interface GetTransferRateRepository
        extends JpaRepository<CommonTransferRate, Integer> {

  @Query(value = "exec prcg_common.usp_get_transfer_rate @currency = :currency, @quote = :quote, "
      + "@type_quote = :typequote, @flag_mayorista = 1, @quotation_type = :quotationtype", nativeQuery = true)
  CommonTransferRate getTransferRate(
      @Param("currency") String currency,
      @Param("quote") Integer quote,
      @Param("typequote") String typequote,
      @Param("quotationtype") String quotationtype); //req contingentes quotationtype:CP/CONT



}
