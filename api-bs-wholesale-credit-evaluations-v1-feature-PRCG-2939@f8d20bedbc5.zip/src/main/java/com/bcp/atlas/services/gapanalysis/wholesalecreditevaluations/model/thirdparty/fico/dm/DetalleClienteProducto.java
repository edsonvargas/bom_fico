package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;



/**
 * <br/>
 * Clase Interfaz del Servicio para la logica de negocio que consumira la clase REST
 * RateCalculationController<br/>
 * <b>Class</b>: RateCalculationService<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>G.CH.J</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Mar 25, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */

@Data
public class DetalleClienteProducto implements Serializable {
  private static final long serialVersionUID = 1L;

  @JsonProperty("codunicocli")
  private String codUnicoCli;

  @JsonProperty("codproducto")
  private String codProducto;

  @JsonProperty("spreadProm3M")
  private BigDecimal spreadProm3M;

  @JsonProperty("spreadProm6M")
  private BigDecimal spreadProm6M;

  @JsonProperty("spreadProm12M")
  private BigDecimal spreadProm12M;

  @JsonProperty("tasaProm3M")
  private BigDecimal tasaProm3M;

  @JsonProperty("tasaProm6M")
  private BigDecimal tasaProm6M;

  @JsonProperty("tasaProm12M")
  private BigDecimal tasaProm12M;

  @JsonProperty("importe3M")
  private BigDecimal importe3M;

  @JsonProperty("importe6M")
  private BigDecimal importe6M;

  @JsonProperty("importe12M")
  private BigDecimal importe12M;

  @JsonProperty("codmoneda")
  private String codMoneda;

}

