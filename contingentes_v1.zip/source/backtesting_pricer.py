from pandas import read_csv, DataFrame, Index, Series
# import pandas as pd
from source.clv_mayorista.engine import engine
from pathlib import Path
import time
# from datetime import timedelta

path = Path().resolve() / "data"

data = read_csv(path / "test_MyLP_13_jun_2023_TipCambio.csv")
# data = data[data['TIPRATING']!='F']
data_g = read_csv(path / "test_garantias_13_jun_2023.csv")

dict_translate_vars = {
    'MTOTOTALDEUDACCF':'SALDOCCF_DOL',
    'Tasa_Pactada':'TIPO_CAMBIO',
    'MESPERIODICIDAD':'PERIODICIDAD',
    # 'NUMVENCIMIENTOMOD':'PLAZO_MESES',
    # 'NUMVENCIMIENTO_MESES':'PLAZO_MESES',    
    'CUOTASGRACIA':'CUOTAS_GRACIA',
    'ESTPAGO':'ESTRUCTURA_PAGO',
    'MTOTOTALDEUDA_dol':'SALDODOL',
    'TIPOPERACION':'TIPO_OPERACION',
    'RATIOACTIVOS': 'RATIO_DDR_DDT',
    'PCTFONDEOESPECIAL':'TT_ESPECIAL',
}
data = data.rename(columns=dict_translate_vars)
# data = data[data['CODREGISTRO']==1184310].reset_index()

n = len(data.index)
# n = 500

index = Index(range(0, n))
columns = ["codregistro", "plazo_meses", "periodicidad", "cuotas_gracia", "deuda_inicial", "moneda", "tasa_minima", "tt", "co", "pe", "rk", "pd_pit", "lgd_pit", "lgd_pit_periodica", "pd_ttc", "lgd_ttc", "time"]
df_output = DataFrame(data = None, index=index, columns=columns)
list_errores = []

for i in range(0, n):
    if i != -1:
        start = time.time()
        X = data.iloc[[i],:].reset_index(drop=True)
        codregistro = data.at[i, "CODREGISTRO"]
        X_g = data_g[data_g["CODREGISTRO"] == codregistro].reset_index(drop=True).copy()

        print(str(i)+'-'+str(codregistro))

        pricer = CLVEngine()
        X_tr = pricer.transform(X, X_g)
        X_predict = pricer.predict()

        df_output.at[i, "codregistro"] = X.at[0, 'CODREGISTRO']

        try:
            # Calcula la tasa minima y sus componentes
            tmin = pricer.compute_min_rate()*100
            # elapsed = (time.time() - start)

            d = pricer.get_rate_components()
            tt = d["tt"]*100
            pe = d["pe"]*100
            co = d["co"]*100
            rk = d["rk"]*100

            term = pricer.X_tr["plazo_meses"]
            freq = (X.at[0, "PERIODICIDAD"])
            grace = pricer.X_tr["num_cuotas_gracia"]

            # Storing
            
            df_output.at[i, "raiting"] = X.at[0, 'TIPRATING']
            df_output.at[i, "plazo_meses"] = term
            df_output.at[i, "periodicidad"] = freq
            df_output.at[i, "cuotas_gracia"] = grace
            df_output.at[i, "deuda_inicial"] = X.at[0, 'SALDODOL']
            df_output.at[i, "moneda"] = X.at[0, 'CODMONEDA']
            df_output.at[i, "tasa_minima"] = tmin
            df_output.at[i, "tt"] = tt
            df_output.at[i, "co"] = co
            df_output.at[i, "pe"] = pe
            df_output.at[i, "rk"] = rk
            df_output.at[i, "pd_pit"] = pricer.param["pd_pit"]
            df_output.at[i, "lgd_pit"] = pricer.param["lgd_pit"]
            df_output.at[i, "pd_ttc"] = pricer.param["pd_ttc"]
            df_output.at[i, "lgd_pit_periodica"] = pricer.X_tr["lgd_pit_periodica"]
            df_output.at[i, "lgd_ttc"] = pricer.param["lgd_ttc"]
            end = time.time()
            run_time = end - start
            df_output.at[i, "time"] = run_time
            # print(run_time)
        
        except:
            list_errores.append(codregistro)
            print(str(codregistro)+" Error")


df_output.to_csv("output_excel.csv")
df_curves = DataFrame(df_output['pd_pit'])
df_curves = df_curves.pd_pit.apply(Series)
df_curves = df_curves.transpose()
df_curves.rename(df_output['codregistro'])
df_curves.to_csv("output_curva_pd.csv")

df_curves_1 = DataFrame(df_output['lgd_pit_periodica'])
df_curves_1 = df_curves_1.lgd_pit_periodica.apply(Series)
df_curves_1 = df_curves_1.transpose()
df_curves_1.rename(columns=df_output['codregistro'])
df_curves_1.to_csv("output_curva_lgd_pit.csv")

df_errores = DataFrame(list_errores)
df_errores.to_csv("errores.csv")

