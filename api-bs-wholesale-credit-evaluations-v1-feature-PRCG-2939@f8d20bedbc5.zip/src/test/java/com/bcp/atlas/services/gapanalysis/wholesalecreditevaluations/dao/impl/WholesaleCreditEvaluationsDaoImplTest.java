package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.Guarantee;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesalePostHeaders;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.CreditInfoCpRequestRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.CreditInfoCpResponseRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.ExceptionRoleRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.GetTransferRateRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.GuaranteeAlexandriaRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.SpecificClWarrantiesReqRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.WarrantiesReqRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.dto.TokenAppcodeDto;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CommonTransferRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CreditInfoCpRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CreditInfoCpResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExceptionRole;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.GuaranteeAlexandria;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.SpecificClWarrantiesReq;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.SpreadComercialAndBlackList;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.WarrantiesReq;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.DmResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.NoRevExcepcion;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.NoRevPayload;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.NoRevPayloadOutput;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.mlx.MlxResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.token.TokenRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy.AlexandriaApi;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy.FicoClvMlxApi;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy.FicoDmApi;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy.GeneratorApi;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.MapperUtils;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.AlexandriaBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.ErrorHandlerBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.FicoDmBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.ResponseBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.SpecificBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.WarrantyBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.WholsaleBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import com.google.common.io.Resources;
import com.google.gson.Gson;
import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.observers.TestObserver;
import io.vavr.Tuple3;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import retrofit2.Response;

@ExtendWith(MockitoExtension.class)
class WholesaleCreditEvaluationsDaoImplTest {

  @InjectMocks private WholesaleCreditEvaluationsDaoImpl wholesaleCreditEvaluationsDaoImpl;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private AlexandriaApi alexandriaApi;

  @Mock private AlexandriaBuilder alexandriaBuilder;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private GeneratorApi generatorApi;

  @Mock private PricingWholesalePostHeaders headers;

  @Mock private GetTransferRateRepository getTransferRateRepository;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private CreditInfoCpRequestRepository creditInfoCpRequestRepository;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private CreditInfoCpResponseRepository creditInfoCpResponseRepository;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private ExceptionRoleRepository exceptionRoleRepository;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private SpecificClWarrantiesReqRepository specificClWarrantiesReqRepository;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private WarrantiesReqRepository warrantiesReqRepository;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private GuaranteeAlexandriaRepository guaranteeAlexandriaRepository;

  @Mock private WholsaleBuilder wholsaleBuilder;

  @Mock private FicoClvMlxApi ficoClvMlxApi;

  @Mock private SpecificBuilder specificBuilder;

  @Mock private WarrantyBuilder warrantyBuilder;

  @Mock FicoDmApi ficoDmApi;
  @Mock FicoDmBuilder ficoDmBuilder;
  @Mock Request request2;

  @Mock private Map<Integer, Tuple3<String, String, String>> errorCategoriesMap;

  @Mock private ErrorHandlerBuilder errorHandlerBuilder;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  @SneakyThrows
  void getTest() {

    final CustomerGetResponse alexandriaResponse =
        MapperUtils.convertToObject("AlexandriaResponse.json", CustomerGetResponse.class);
    final Request request = MapperUtils.convertToObject("RequestApi.json", Request.class);
    final CustomerGetResponse alexandriaResponseDefault =
        MapperUtils.convertToObject("AlexandriaResponse.json", CustomerGetResponse.class);
    final PricingWholesaleResponse productRatesResponse =
        MapperUtils.convertToObject("ResponseWholFinal.json", PricingWholesaleResponse.class);


    String dmRequestJson =
        new BufferedReader(
                new InputStreamReader(
                    Resources.getResource("DmRequest.json").openStream(), StandardCharsets.UTF_8))
            .lines()
            .collect(Collectors.joining("\n"));

    Assert.assertNotNull(productRatesResponse);

    CommonTransferRate commonTransferRate = new CommonTransferRate();
    commonTransferRate.setRate(0.12f);

    when(generatorApi.executeProcessTokenUsingPost(any(TokenRequest.class)))
        .thenReturn(Single.just("Token"));
    CreditInfoCpRequest creditInfoCpRequest = new CreditInfoCpRequest();
    CreditInfoCpResponse creditInfoCpResponse =
        MapperUtils.convertToObject("ResponseCreditInfoCp.json", CreditInfoCpResponse.class);
    ExceptionRole exceptionRole = new ExceptionRole();
    SpecificClWarrantiesReq specificClWarrantiesReq = new SpecificClWarrantiesReq();
    WarrantiesReq warrantiesReq = new WarrantiesReq();
    GuaranteeAlexandria guaranteeAlexandria = new GuaranteeAlexandria();
    List<Guarantee> guarantees = new ArrayList<>();
    ResponseBuilder responseBuilder = new ResponseBuilder();

    lenient().when(creditInfoCpRequestRepository.save(any(CreditInfoCpRequest.class)))
        .thenReturn(creditInfoCpRequest);
    lenient().when(creditInfoCpResponseRepository.save(any(CreditInfoCpResponse.class)))
        .thenReturn(creditInfoCpResponse);
    lenient().when(exceptionRoleRepository.save(any(ExceptionRole.class)))
        .thenReturn(exceptionRole);
    lenient().when(specificClWarrantiesReqRepository.save(any(SpecificClWarrantiesReq.class)))
        .thenReturn(specificClWarrantiesReq);
    lenient().when(warrantiesReqRepository.save(any(WarrantiesReq.class)))
        .thenReturn(warrantiesReq);
    lenient().when(guaranteeAlexandriaRepository.save(any(GuaranteeAlexandria.class)))
        .thenReturn(guaranteeAlexandria);

    SpecificClWarrantiesReq specificClWarrantiesReq1 = new SpecificClWarrantiesReq();
    specificClWarrantiesReq1.setSpecificClWarrantiesReqId(1);
    specificClWarrantiesReq1.setAffectedValue(new BigDecimal(1));
    specificClWarrantiesReq.setCreditInfoCpReqId(1);
    specificClWarrantiesReq.setCurrencyCode("x");
    lenient()
        .when(specificClWarrantiesReqRepository.save(specificClWarrantiesReq1))
        .thenReturn(specificClWarrantiesReq1);
    Gson gson = new Gson();

    String quotationJson =
        new BufferedReader(
            new InputStreamReader(
                Resources.getResource("ResponseMlxTest.json").openStream(),
                StandardCharsets.UTF_8))
            .lines()
            .collect(Collectors.joining("\n"));

    MlxResponse mlxResponse = gson.fromJson(quotationJson, MlxResponse.class);


    String dmResponseJson =
        new BufferedReader(
            new InputStreamReader(
                Resources.getResource("ResponseDm.json").openStream(), StandardCharsets.UTF_8))
            .lines()
            .collect(Collectors.joining("\n"));

    List<SpecificClWarrantiesReq> listspecificClWarrantiesReq1 = new ArrayList<>();
    listspecificClWarrantiesReq1.add(specificClWarrantiesReq1);

    lenient().when(specificBuilder.generateDbObjectSpecific(1, request))
        .thenReturn(listspecificClWarrantiesReq1);
    when(specificClWarrantiesReqRepository.save(specificClWarrantiesReq1))
        .thenReturn(specificClWarrantiesReq1);

    specificClWarrantiesReqRepository.save(specificClWarrantiesReq1);
    SpreadComercialAndBlackList spreadComercialAndBlackList = new SpreadComercialAndBlackList();
    spreadComercialAndBlackList.setSpreadComercial(BigDecimal.valueOf(2.4));
    spreadComercialAndBlackList.setBlacklistRate(BigDecimal.valueOf(0.024));

    SpreadComercialAndBlackList spreadComercialAndBlackList2 = new SpreadComercialAndBlackList();
    spreadComercialAndBlackList2.setSpreadComercial(BigDecimal.valueOf(-1));
    spreadComercialAndBlackList2.setBlacklistRate(BigDecimal.valueOf(-1));

    TokenAppcodeDto tokenAppCode = new TokenAppcodeDto();
    tokenAppCode.setToken(Constantes.BEARER + "token");
    tokenAppCode.setAppCode(headers.getAppCode());

    TokenAppcodeDto tokenAppCode2 = new TokenAppcodeDto();
    tokenAppCode2.setToken(Constantes.BEARER + "token");
    tokenAppCode2.setAppCode("JH");

    Observable<CommonTransferRate> observable = Observable.just(commonTransferRate);

    TestObserver<PricingWholesaleResponse> testObserver =
        wholesaleCreditEvaluationsDaoImpl
            .wholeInfo(
                request,
                tokenAppCode,
                alexandriaResponse,
                alexandriaResponse,
                observable,
                spreadComercialAndBlackList,
                null)
            .test();
    testObserver.awaitTerminalEvent();

    TestObserver<PricingWholesaleResponse> testObserver2 =
        wholesaleCreditEvaluationsDaoImpl
            .wholeInfo(
                request,
                tokenAppCode2,
                alexandriaResponse,
                alexandriaResponse,
                observable,
                spreadComercialAndBlackList2,
                null)
            .test();
    testObserver2.awaitTerminalEvent();
  }

  @Test
  void whenGetResponseFinal() {
    PricingWholesaleResponse response =
        MapperUtils.convertToObject("ResponseWholFinal.json", PricingWholesaleResponse.class);
    CreditInfoCpResponse creditInfoCpResponse =
        MapperUtils.convertToObject("ResponseCreditInfoCp.json", CreditInfoCpResponse.class);
    Assert.assertNotNull(creditInfoCpResponse);
    Observable<CreditInfoCpResponse> infoCpResponse = Observable.just(creditInfoCpResponse);

    TestObserver<PricingWholesaleResponse> testObserver =
        wholesaleCreditEvaluationsDaoImpl.getResponseFinal(response, creditInfoCpResponse).test();
    testObserver.awaitTerminalEvent();
  }

  @Test
  @SneakyThrows
  void whenGetSaveData() {
    final CustomerGetResponse alexandriaResponse =
        MapperUtils.convertToObject("AlexandriaResponse.json", CustomerGetResponse.class);
    final Request request = MapperUtils.convertToObject("RequestApi.json", Request.class);
    final CustomerGetResponse alexandriaResponseDefault =
        MapperUtils.convertToObject("AlexandriaResponse.json", CustomerGetResponse.class);
    final PricingWholesaleResponse productRatesResponse =
        MapperUtils.convertToObject("ResponseWholFinal.json", PricingWholesaleResponse.class);

    CreditInfoCpResponse creditInfoCpResponse =
        MapperUtils.convertToObject("ResponseCreditInfoCp.json", CreditInfoCpResponse.class);
    Assert.assertNotNull(creditInfoCpResponse);
    Observable<CreditInfoCpResponse> infoCpResponse = Observable.just(creditInfoCpResponse);



    String dmRequestJson =
        new BufferedReader(
            new InputStreamReader(
                Resources.getResource("DmRequest.json").openStream(), StandardCharsets.UTF_8))
            .lines()
            .collect(Collectors.joining("\n"));

    NoRevPayload noRevPayload = new NoRevPayload();
    List<NoRevExcepcion> exceptions = new ArrayList<>();
    NoRevExcepcion exception = new NoRevExcepcion();
    exceptions.add(exception);
    NoRevPayloadOutput noRevPayloadOutput = new NoRevPayloadOutput();
    noRevPayloadOutput.setExcepciones(exceptions);
    noRevPayload.setPayloadOutput(noRevPayloadOutput);

    String dmResponseJson =
        new BufferedReader(
            new InputStreamReader(
                Resources.getResource("ResponseDm.json").openStream(), StandardCharsets.UTF_8))
            .lines()
            .collect(Collectors.joining(""));

    Gson gson = new Gson();
    DmResponse dmResponse = gson.fromJson(dmResponseJson, DmResponse.class);
    dmResponse.setNoRevPayload(noRevPayload);
    Response<DmResponse> dmResponseResponse =  Response.success(dmResponse);
    dmResponseResponse.body().setNoRevPayload(dmResponse.getNoRevPayload());



    PricingWholesaleResponse response =
        MapperUtils.convertToObject("ResponseWholFinal.json", PricingWholesaleResponse.class);



    when(errorHandlerBuilder.validateStatusCode(
        dmResponseResponse.body(),
        dmResponseResponse.code(),
        Constantes.ERROR_TYPE_FICO_DM,
        String.valueOf(dmResponseResponse.errorBody())))
        .thenReturn(dmResponse);

    when(wholsaleBuilder.getResponse(request,dmResponse)).thenReturn(response);

    CreditInfoCpRequest creditInfoCpRequest = new CreditInfoCpRequest();
    creditInfoCpRequest.setCreditInfoCpReqId(1);
    when(creditInfoCpRequestRepository.save(any(CreditInfoCpRequest.class)))
        .thenReturn(creditInfoCpRequest);
    lenient().when(creditInfoCpResponseRepository.save(any(CreditInfoCpResponse.class)))
        .thenReturn(creditInfoCpResponse);
    ExceptionRole exceptionRole = new ExceptionRole();
    lenient().when(exceptionRoleRepository.save(any(ExceptionRole.class)))
        .thenReturn(exceptionRole);

    SpecificClWarrantiesReq specificClWarrantiesReq = new SpecificClWarrantiesReq();
    List<SpecificClWarrantiesReq> specificClWarrantiesReqList = new ArrayList<>();
    specificClWarrantiesReqList.add(specificClWarrantiesReq);
    when(specificBuilder.generateDbObjectSpecific(1, request))
        .thenReturn(specificClWarrantiesReqList);
    when(specificClWarrantiesReqRepository.save(specificClWarrantiesReq))
        .thenReturn(specificClWarrantiesReq);
    specificClWarrantiesReqRepository.saveAll(specificClWarrantiesReqList);

    lenient().when(specificClWarrantiesReqRepository.save(new SpecificClWarrantiesReq()))
        .thenReturn(specificClWarrantiesReq);

    List<ExceptionRole> exceptionRoles = new ArrayList<>();
    exceptionRoleRepository.saveAll(exceptionRoles);
    when(ResponseBuilder.generateDbObjectExceptionRole(1,response))
        .thenReturn(exceptionRoles);
    lenient().when(exceptionRoleRepository.saveAll(exceptionRoles))
        .thenReturn(exceptionRoles);

    WarrantiesReq warrantiesReq = new WarrantiesReq();
    List<WarrantiesReq> warranties = new ArrayList<>();
    warranties.add(warrantiesReq);
    when(warrantyBuilder
             .generateDbObjectWarranty(1, request)).thenReturn(warranties);
    warrantiesReq.setAffectedValue(new BigDecimal(1));
    when(warrantiesReqRepository.save(any(WarrantiesReq.class)))
        .thenReturn(warrantiesReq);
    warrantiesReqRepository.saveAll(warranties);
    lenient().when(warrantiesReqRepository.save(new WarrantiesReq()))
        .thenReturn(warrantiesReq);

    List<GuaranteeAlexandria> guaranteeAlexandrias = new ArrayList<>();
    guaranteeAlexandriaRepository.saveAll(guaranteeAlexandrias);
    List<Guarantee> guaranteeLis = new ArrayList<>();
    when(ResponseBuilder.generateDbObjectGuarantee(1,guaranteeLis))
        .thenReturn(guaranteeAlexandrias);
    GuaranteeAlexandria guaranteeAlexandria = new GuaranteeAlexandria();
    lenient().when(guaranteeAlexandriaRepository.save(any(GuaranteeAlexandria.class)))
        .thenReturn(guaranteeAlexandria);



    lenient().when(creditInfoCpResponseRepository.save(new CreditInfoCpResponse()))
        .thenReturn(creditInfoCpResponse);

    TestObserver<PricingWholesaleResponse> testObserver =
        wholesaleCreditEvaluationsDaoImpl.saveData(request, dmResponseResponse, alexandriaResponse).test();
    testObserver.awaitTerminalEvent();
  }
}
