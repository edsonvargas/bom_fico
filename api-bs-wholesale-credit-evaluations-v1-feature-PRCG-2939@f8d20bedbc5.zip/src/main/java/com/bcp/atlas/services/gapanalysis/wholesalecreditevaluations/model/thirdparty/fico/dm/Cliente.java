package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;


/**
 * <br/>
 * Clase Interfaz del Servicio para la logica de negocio que consumira la clase REST
 * RateCalculationController<br/>
 * <b>Class</b>: RateCalculationService<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>G.CH.J</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Mar 25, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */

@Data
public class Cliente implements Serializable {

  private static final long serialVersionUID = 1L;

  @JsonProperty("channelRequestId")
  private int channelRequestId;

  @JsonProperty("maxantiguedad")
  private BigDecimal maxantiguedad;

  @JsonProperty("esvinculado")
  private int esvinculado;

  @JsonProperty("pctmargenfinancieroactivo")
  private BigDecimal pctmargenfinancieroactivo;

  @JsonProperty("segmento_cfz")
  private String segmentoCfz;

  @JsonProperty("segmento_lp")
  private int segmentoLp;

  @JsonProperty("bu")
  private int bu;

  @JsonProperty("subcategory")
  private int subcategory;

  @JsonProperty("codacteconomica")
  private int codacteconomica;

  @JsonProperty("codunicocli")
  private String codunicocli;

  @JsonProperty(value = "codsubsegmento", defaultValue = "-1")
  private String codsubsegmento;

  @JsonProperty("tipbanca")
  private String tipBanca;

  @JsonProperty("tipclasifriesgobcp")
  private String tipclasifriesgobcp;

  @JsonProperty("saldoccf_dol")
  private BigDecimal saldoccfDol;

  @JsonProperty("saldodleace_dol")
  private BigDecimal saldodleaceDol;

  @JsonProperty("saldodol")
  private BigDecimal saldodol;

  @JsonProperty("rt_deudirref_deudirtot_sbs")
  private BigDecimal rtDeudirrefDeudirtotSbs;

  @JsonProperty("cantfinancieras")
  private int cantfinancieras;

  @JsonProperty("ctdmaxatrcond_med_18")
  private int ctdmaxatrcondMed18;

  @JsonProperty("sow")
  private BigDecimal sow;

  @JsonProperty("fecha_activacion_final")
  private String fechaActivacionFinal;

  @JsonProperty(value = "pd_pit", defaultValue = "-1")
  private BigDecimal pdPit;

  @JsonProperty("pd_ttc_cp")
  private BigDecimal pdTtcCp;

  @JsonProperty("pd_ttc_mp")
  private BigDecimal pdTtcMp;

  @JsonProperty("sector_covid")
  private String sectorCovid;

  @JsonProperty("tiprating")
  private String tipRating;

  @JsonProperty("grado_exposicion_cambiaria")
  private int gradoExposicionCambiaria;

  @JsonProperty("version")
  private int version;

  @JsonProperty("rarorac")
  private BigDecimal raroRac;

  @JsonProperty("flgListaNegra")
  private Boolean flagBlackList;

  @JsonProperty("x1")
  private String x1;

  @JsonProperty("pd_pid")
  private BigDecimal pdPid;





}
