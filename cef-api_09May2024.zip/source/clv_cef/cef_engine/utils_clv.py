from numpy import (arange, array, clip, concatenate, count_nonzero, cumprod,
                   cumsum, diff, divide, empty_like, inf, isnan, max, maximum,
                   minimum, multiply, nansum, ones, ones_like, power, stack,
                   sum, zeros_like, select)
from pandas import DataFrame

import warnings
warnings.filterwarnings("ignore")
 

def Bfactor2(rate, T, Tmax=60):
    rate = rate.reshape(1, -1)
    # Input validation
    _, m = rate.shape
    _, m1 = T.shape
    assert (m == m1), "rate and T should be of the same shape"
    T_m = max(T)
    if Tmax < T_m:
        Tmax = T_m
    # Building inputs
    t = arange(1, Tmax + 1).reshape(-1, 1)
    r = rate
    # Vectorized computation
    arr = (power(1 + r, T) - power(1 + r, t - 1)) / \
        (power(1 + r, T) - 1)
    return maximum(arr, 0)


def Afactor1(rate, T, Tmax=60):
    t = arange(1, Tmax + 1).reshape(-1, 1)
    Den = power(1 + rate, T-t+1) - 1
    Af = divide(rate , Den, out=ones_like(Den),where=(Den!=0))
    Af[(Af==inf)|(isnan(Af))]=0
    return maximum(Af, 0)


def Bf1(t, r, T):
    return ((1 + r)**T - (1 + r)**(t - 1)) / ((1 + r)**T - 1)


def Bfactor1(r, T, Tmax=60):
    t = arange(1, Tmax + 1).reshape(-1, 1)  # shape (T,1)
    Bf = maximum(array([Bf1(time, rate, Tm)
                              for time in t for rate in r for Tm in T]), 0)
    return Bf


def shift(arr, num, fill_value=0):
    """
    Shifts a numpy array of shape (T,m) num times filling fill_values to the missing slots

    Parameters
    ----------
    arr : array_like of shape = (T,m)
        a numpy array containing T observations for m samples
    num : scalar indicating the number of lags (if positive) or leads (if negative) to shift the numpy array verticaly

    fill_value: scalar indicating shift numpy array {1}

    Returns
    -------
    arr : array_like of shape = (T,m)
        a numpy array containing shifted T observations for m samples

    Examples
    -------
    random.seed(42)
    test_array = random.randn(3,5)
    test_array
    shift(test_array,2)

    Returns

    array( [[ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ],
            [ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ],
            [ 0.49671415, -0.1382643 ,  0.64768854,  1.52302986, -0.23415337]])


    shift(test_array,1)

    Returns
    array([[ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ],
       [ 0.49671415, -0.1382643 ,  0.64768854,  1.52302986, -0.23415337],
       [-0.23413696,  1.57921282,  0.76743473, -0.46947439,  0.54256004]])

    shift(test_array,-1)

    Returns
    array([[-0.23413696,  1.57921282,  0.76743473, -0.46947439,  0.54256004],
       [-0.46341769, -0.46572975,  0.24196227, -1.91328024, -1.72491783],
       [ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ]])

    """
    result = empty_like(arr)
    if num > 0:
        result[:num] = fill_value
        result[num:] = arr[:-num]
    elif num < 0:
        result[num:] = fill_value
        result[:num] = arr[-num:]
    else:
        result[:] = arr
    return result


def cif_to_cond_prob(cif1, cif2, s1=1, s2=1):
    """
    Converts two CIFs (Cumulative Incidence Functions) to conditional probabilities of death.
    T is the number of periods, m is the number of samples.

    Parameters
    ----------
    cif1 : array_like of shape = (T,m)
        a numpy array containing event 1 CIF curve in each column.
    cif2 : array_like of shape = (T,m)
        a numpy array containing event 1 CIF curve in each column.
    s1: scalar indicating shift of cif1 curves {1}
    s2: scalar indicating shift of cif1 curves {1}

    Returns
    -------
    (conditional_prob_1, conditional_prob_2)
        2-tuple containing one numpy array in each element.
        conditional_prob_1 contains pd curves for the first CIF
        conditional_prob_2 contains pd curves for the first CIF

    Example
    -------
    cif_PD = cumsum(random.uniform(0,high=1,size=(10,5)),axis=0)/10
    cif_CAN = cumsum(random.uniform(0,high=1,size=(10,5)),axis=0)/10
    PD , CAN = cif_to_cond_prob(cif_PD,cif_CAN,s1=1,s2=3)
    """
    cif1_shifted = shift(cif1, s1)
    den = (1 - cif1_shifted - cif2)
    cond_prob1 = clip((cif1 - cif1_shifted) / den, 0, 1)

    return (cond_prob1, 0)


def compute_S(PD, CAN, PRE, Bf):
    """
    Computes Survival curve and laggs it one period S(t-1)

    Parameters
    ----------
    PD : array_like of shape = (T,m)
        a numpy array containing probability of default (conditional to survival in t-1). T periods in each rows (1...T) and m samples in each column (1 ...m).
    CAN : array_like of shape = (T,m)
        a numpy array containing probability of full prepayment (conditional to survival in t-1). T periods in each rows (1...T) and m samples in each column (1 ...m).
    PRE : array_like of shape = (T,m)
        a numpy array containing probability of prepayment (conditional to survival in t-1). T periods in each rows (1...T) and m samples in each column (1 ...m).
    Bf: array_like of shape = (T,m)
        a numpy array containing Bf factors. T periods in each rows (1...T) and m samples in each column (1 ...m). Row 1 contains only 1"s


    Returns
    -------
    S_(t-1)
       numpy array in each element (T rows and m columns)

    Example
    -------


    """
    # Pseudo survival function
    Stilde = cumprod((1 - PD) * (1 - CAN), axis=0)
    Stilde_m1 = shift(Stilde, 1, 1)

    # Prepayment survival function
    PRE_m1 = shift(PRE, 1, 0)
    Den = Stilde_m1 * Bf
    C = divide(PRE_m1 , Den,out=zeros_like(Den),where=(Den!=0))

    Cstar = cumsum(C, axis=0)
    PRE_bar = maximum(minimum(1 - Cstar, 1), 0)
    # Survival Function
    S = Stilde_m1 * PRE_bar
    return S


def pbroyden(
        func,
        x0=0.01,
        eps=0.00001,
        tol=0.0001,
        max_iter=30,
        verbose=True):
    """
    Pseudo Broyden Method: Algorithm to find roots for a multivariate function with multivariate outputs.

    Parameters
    ----------
    func : function (Rn to Rn) (If used to compute Economic Profit (at present value) usually inputs a vector of m samples of rates for initial values and outputs a m-vector of Economic profits)

    x0 : array_like of shape (m,) that inputs initial guess for rates
    eps : step to vary arguments to optimize func
    tol : tolerance number for diference between 0 and the actual solution value output
    max_iter: maximun of iterations to use
    verbose: If set to true prints # of iterations

    Returns
    -------
    arr : array_like of shape = (m,) containing optimun solution (IRR if used to compute roots of Economic Profit)

    Examples
    -------

    1) Simulation of data
    random.seed(1)
    # Datos del producto
    m = 1_000 # Number of samples
    desembolsos = random.randint(10000,11000,(1,m))  # shape (1,m)
    T = random.choice([12, 24, 36, 48, 60 ],m).reshape(1,-1) # shape (1,m)
    Tmax = max(T)
    descuentos = 0.19/12*ones((1,m)).reshape(1,-1)
    # Curvas del CLENTE para este producto
    cif_PD = cumsum(random.uniform(
        0,high=1,size=(Tmax,m)),axis=0)/Tmax/3  # shape (T, m)
    cif_CAN = cumsum(random.uniform(
        0,high=1,size=(Tmax,m)),axis=0)/Tmax/3 # shape (T, m)
    PRE = cumsum(random.uniform(0,high=1,size=(Tmax,m)),
                    axis=0)/Tmax/30 # shape (T, m)
    PD , CAN = cif_to_cond_prob(cif_PD,cif_CAN,s1=1,s2=1)

    2) defining function to optimize

    3) Solving for roots with Pseudo Broyden"s Algorithm
    r0 = random.uniform(0.2/12,.30/12,(1,m)).reshape(1,-1)   # shape (1,m)
    param = {"PD":PD,"CAN":CAN,"PRE":PRE}
    funct = lambda x: van(descuentos,desembolsos,x,T,param).reshape(m,)
    def test2():
        tmin = pbroyden(funct, r0.reshape(m,))
        return tmin.reshape(m,)

    """
    iter_counter = 0
    error = 10
    xm = x0
    xp = xm + eps
    fem = func(xm)
    fep = func(xp)
    m = fem.shape[0]
    delta_error = 10
    solved = False
    solved_operations = 0
    counter_solved = 0
    mask_solved = array([False]*m).reshape(m,)
    mask_reshape_solved = array([False]*m).reshape(1, m)
    while ~( (error < tol) | (iter_counter > max_iter)| (delta_error<0.0001)|((counter_solved==3)&(solved_operations>0.5*m))):

        swap = abs(fem)>abs(fep)
        xmtemp = xm[0,swap]
        xm[0,swap] = xp[0,swap]
        xp[0,swap] = xmtemp

        femtemp = fem[swap]
        fem[swap] = fep[swap]
        fep[swap] = femtemp

        iter_counter += 1
        Den = (xp[~mask_reshape_solved]-xm[~mask_reshape_solved])
        fprime = divide((fep[~mask_solved] - fem[~mask_solved]), Den, out=ones_like(Den), where=(Den!=0))
        xp[~mask_reshape_solved] = xm[~mask_reshape_solved]
        fep[~mask_solved] = fem[~mask_solved]

        xm[~mask_reshape_solved] = xm[~mask_reshape_solved] - fem[~mask_solved] / fprime
        fem = func(xm) # xm[~mask_reshape_solved] + mask output function

        solved = (abs(fem)<tol)
        mask_solved[solved] = True
        mask_reshape_solved = mask_solved.reshape(1, m)

        error_prev = error
        error = nansum(abs(fem[~mask_solved]))
        delta_error = abs(error - error_prev)

        solved_operations_prev = solved_operations
        solved_operations = count_nonzero(solved)
        if solved_operations == solved_operations_prev:
            counter_solved += 1
        else:
            counter_solved = 0

    return xm


def van_rmin(descuentos, desembolsos, r, T, param, flag_monitoreo=False):
    """
    Parameters:
    >>> r: tasa de la iteración previa
    >>> descuentos: TIR Objetivo
    >>> desembolsos: Desembolsos efectivos
    >>> T: Plazos
    >>> param: Diccionario de parametros del clv.get_parameters_pv()

    Returns:

    """
    # start = time.time()
    cif_PD = param["cif_PD"]
    can = param["can"]
    pre = param["pre"]
    XC = param["XC"]
    XP = param["XP"]
    LGD = param["LGD"]
    ECf = param["ECf"]
    RemCap = param["RemCap"]
    rc=param['rc']
    IR = param["IR"]

    r = r.reshape(1, -1)
    r_year = power(1 + r.reshape(-1, 1), 12) - 1

    # print(f"seccion 1: {time.time()-start}")

    # Update r --> Dependencia de Cancelaciones y Prepagos con la TEA
    cif_CAN = can.update_r(XC, r_year)
    cum_PRE = pre.update_r(XP, r_year)


    # Comentar si CLV es estándar
    PD, _ = cif_to_cond_prob(shift(cif_PD, -2), shift(cif_CAN, 1), 1, 1)
    CAN, _ = cif_to_cond_prob(shift(cif_CAN, 0), shift(cif_PD, -2), 1, 1)  # Comentar si CLV es estándar
    PRE = maximum(cum_PRE - shift(cum_PRE, 1), 0)

    descuentos = descuentos.reshape(1, -1)

    # Bbar: Contractual Balance
    Bf = Bfactor2(r, T, Tmax=60)
    Bbar = multiply(Bf, desembolsos)

    # Survival Curves
    Sm1 = compute_S(PD, CAN, PRE, Bf)

    # B: Behavioral Balance
    B = maximum(Sm1*Bbar, 0)

    if not flag_monitoreo:

        ###########################################
        #### Actualizacion de la TT Zero Cupon ####
        ###########################################   

        PrepagoRDM = param["PrepagoRDM"]
        PrepagoRDM = stack(PrepagoRDM)
        tt_fact = param["tt_fact"]
        tt_fact = stack(tt_fact)

        # Survival Curve TT Zero Cupon
        Sm1_tt = cumprod(1-PrepagoRDM, axis=1)
        Sm1_tt = Sm1_tt.T # TT calc.

        # Behavioral Balance TT Zero Cupon
        B_tt = maximum(Sm1_tt*Bbar, 0)

        # # Factor de Descuento (TT)
        exponente = arange(0, 1801, 30).reshape(1, -1)
        fact_dscto = power(divide(1, 1 + divide(tt_fact, 360)), exponente).T # (61,m)

        saldo_t_por_factor = B_tt*fact_dscto[:60,:]
        saldo_t_1_por_factor = B_tt*fact_dscto[1:,:]
        saldo_t_1_por_factor_360 = saldo_t_1_por_factor*(30/360)

        rc = divide(sum(saldo_t_por_factor, axis=0) - sum(saldo_t_1_por_factor, axis=0), sum(saldo_t_1_por_factor_360, axis=0))
        rc = rc/12
    # print(f"seccion 3: {time.time()-start}")

    ###########################################
    # I: Interest Income from Lending
    # start = time.time()
    B_m_D = B*(1 - PD)
    I = B_m_D*r  # <-- Interest Income

    P = minimum(multiply(PRE, B[0,:]), B_m_D)
    D = PD*B  # <-- Default
    A = multiply(Afactor1(r, T, Tmax=60), B_m_D) # <-- Amortizations
    C = CAN*(B_m_D - A) # <-- Cancelations

    # EF: Interest Outcome from Cost of Funds
    D_ef = shift(D, 2)
    B_ef_aux = B[0,:] - cumsum(D_ef + A + C + P, axis=0)
    B_ef = maximum(concatenate([B[0,:].reshape(1, -1), B_ef_aux[0:-1,:]], axis=0), 0)
    
    COF = -B_ef*rc  # <-- Cost Of Funds (Interest Outcome)
    EL = -LGD*D_ef  # <-- Expected Loss
    EC = B_ef*ECf  # <-- Economic Capital
    RemEC = EC*RemCap  # <-- Remuneration to Economic Capital
    EC_flow = -diff(EC, axis=0, append=0) # Economic Capital Flow
    EC_0 = -EC[0,:].reshape(1, -1)

    # C: Costs
    costos = param["COSTOS_VIDA"]
    CH = maximum((1 - cif_PD - cif_CAN), 0)  # Cuentas Hábiles
    rr1 = param["RR1"]  # Curva Roll Rate (1-30)
    rr2 = param["RR2"]  # Curva Roll Rate (31-60)

    costos_rr1 = CH*costos[0]*rr1  # Costos cobranzas 1-30
    costos_rr2 = CH*costos[1]*rr2  # Costos cobranzas 31-60
    costos_BmD = B_m_D*costos[2]  # Costos Mantenimiento SBS
    # Costos: adminitrativos, procesos de operaciones, transaccionales, publicidad, otros
    costos_CH = CH*costos[3]

    costos_total = -(costos_rr1 + costos_rr2 + costos_BmD + costos_CH)*(B_m_D>0)
    costos_T0 = -param["COSTOS_T0"]  # Costos en el periodo t=0

    # Ingresos No Financieros (INOF)
    inof_tr = param["INOF_TR"]

    portes = CH*inof_tr[0]
    seguro = B_m_D*inof_tr[1]

    # Descomentar para activar la penalidad por pago atrasado
    # pa = param["PA"]
    # pago_atrasado = clip(inof_tr[2]*Cuota, inof_min, inof_max)*CH*pa
    # inof = (portes + seguro + pago_atrasado)*(B_m_D>0)

    inof = (portes + seguro)*(B_m_D>0)

    # Taxes (Impuesto a la Renta)
    tax_0 = -(costos_T0)*IR
    taxes = -(I + COF + EL + RemEC + inof + costos_total)*IR

    # Computing Cash Flow
    CF = (I + COF + EL + RemEC + EC_flow + inof + costos_total + taxes)*(B_m_D>0)

    # Computing Net Present Value
    Tmax = CF.shape[0]
    descuento_matrix = array([power(1/(1+descuento), t)
                                 for descuento in descuentos for t in arange(1, Tmax+1).reshape(-1, 1)])
    # Discounted Cash Flows for simple sum
    CF_discounted = multiply(descuento_matrix, CF)
    CF_0 = tax_0 + EC_0 + costos_T0  # Cash Flow in t=0
    pv = sum(CF_discounted, axis=0).reshape(1, -1) + CF_0  # Net Present Value
    # print(f"seccion 4: {time.time()-start}")
    return pv


def van_irr(descuentos, desembolsos, r, T, param,flag_monitoreo=False):
    """
    Parameters:
    >>> r: TEA de desembolso
    >>> descuentos: TIR Objetivo
    >>> desembolsos: Desembolsos efectivos
    >>> T: Plazos
    >>> param: Diccionario de parámetros del clv.get_parameters_pv()

    Returns: pv 

    """
    PD = param["PD"]
    cif_PD = param["cif_PD"]
    CAN = param["CAN"]
    cif_CAN = param["cif_CAN"]
    PRE = param["PRE"]
    LGD = param["LGD"]
    rc = param["rc"]
    ECf = param["ECf"]
    RemCap = param["RemCap"]
    IR = param["IR"]

    r = r.reshape(1, -1)
    descuentos = descuentos.reshape(1, -1)

    # Bbar: Contractual Balance
    Bf = Bfactor2(r, T, Tmax=60)
    Bbar = multiply(Bf, desembolsos)

    # Survival Curves
    Sm1 = compute_S(PD, CAN, PRE, Bf)

    # B: Behavioral Balance
    B = maximum(Sm1*Bbar, 0)

    if not flag_monitoreo:

        ###########################################
        #### Actualizacion de la TT Zero Cupon ####
        ###########################################

        PrepagoRDM = param["PrepagoRDM"]
        PrepagoRDM = stack(PrepagoRDM)
        tt_fact = param["tt_fact"]
        tt_fact = stack(tt_fact)

        # Survival Curve TT Zero Cupon
        Sm1_tt = cumprod(1-PrepagoRDM, axis=1)
        Sm1_tt = Sm1_tt.T # TT calc.

        # Behavioral Balance TT Zero Cupon
        B_tt = maximum(Sm1_tt*Bbar, 0)

        # Factor de Descuento (TT)
        exponente = arange(0, 1801, 30).reshape(1, -1)
        fact_dscto = power(divide(1, 1 + divide(tt_fact, 360)), exponente).T # (61,m)

        saldo_t_por_factor = B_tt*fact_dscto[:60,:]
        saldo_t_1_por_factor = B_tt*fact_dscto[1:,:]
        saldo_t_1_por_factor_360 = saldo_t_1_por_factor*(30/360)

        rc = divide(sum(saldo_t_por_factor, axis=0) - sum(saldo_t_1_por_factor, axis=0), sum(saldo_t_1_por_factor_360, axis=0))
        rc = rc/12

        ###########################################

    # I: Interest Income from Lending
    B_m_D = B*(1 - PD)
    I = B_m_D*r  # <-- Interest Income

    P = minimum(multiply(PRE, B[0,:]), B_m_D)
    D = PD*B  # <-- Default
    A = multiply(Afactor1(r, T, Tmax=60), B_m_D) # <-- Amortizations
    C = CAN*(B_m_D - A) # <-- Cancelations

    # EF: Interest Outcome from Cost of Funds
    D_ef = shift(D, 2)
    B_ef_aux = B[0,:] - cumsum(D_ef + A + C + P, axis=0)
    B_ef = maximum(concatenate([B[0,:].reshape(1, -1), B_ef_aux[0:-1,:]], axis=0), 0)
    
    COF = -B_ef*rc  # <-- Cost Of Funds (Interest Outcome)
    EL = -LGD*D_ef  # <-- Expected Loss
    EC = B_ef*ECf  # <-- Economic Capital
    RemEC = EC*RemCap  # <-- Remuneration to Economic Capital
    EC_flow = -diff(EC, axis=0, append=0)     # Economic Capital Flow
    EC_0 = -EC[0,:].reshape(1, -1)

    # C: Costs
    costos = param["COSTOS_VIDA"]
    CH = maximum((1 - cif_PD - cif_CAN), 0)  # Cuentas Hábiles
    rr1 = param["RR1"]  # Curva Roll Rate (1-30)
    rr2 = param["RR2"]  # Curva Roll Rate (31-60)

    costos_rr1 = CH*costos[0]*rr1  # Costos cobranzas 1-30
    costos_rr2 = CH*costos[1]*rr2  # Costos cobranzas 31-60
    costos_BmD = B_m_D*costos[2]  # Costos Mantenimiento SBS
    # Costos: adminitrativos, procesos de operaciones, transaccionales, publicidad, otros
    costos_CH = CH * costos[3]

    costos_total = -(costos_rr1 + costos_rr2 + costos_BmD + costos_CH)*(B_m_D>0)
    costos_T0 = -param["COSTOS_T0"]  # Costos en el periodo t=0

    # Ingresos No Financieros (INOF)
    inof_tr = param["INOF_TR"]
    
    portes = CH*inof_tr[0]
    seguro = B_m_D*inof_tr[1]

    inof = (portes + seguro)*(B_m_D>0)

    # Taxes (Impuesto a la Renta)
    tax_0 = -(costos_T0)*IR
    taxes = -(I+COF+EL+RemEC+inof+costos_total)*IR

    # Computing Cash Flow
    CF = (I + COF + EL + RemEC + EC_flow + inof + costos_total + taxes)*(B_m_D>0)

    # Computing Net Present Value
    Tmax = CF.shape[0]
    descuento_matrix = array([power(1/(1+descuento), t)
                                 for descuento in descuentos for t in arange(1, Tmax+1).reshape(-1, 1)])
    # Discounted Cash Flows for simple sum
    CF_discounted = multiply(descuento_matrix, CF)
    CF_0 = tax_0 + EC_0 + costos_T0  # Cash Flow in t=0
    pv = sum(CF_discounted, axis=0).reshape(1, -1) + CF_0  # Net Present Value

    return pv


def get_parameters_transform(X, tt_dscto):

    m = X.shape[0]
    dscto_anual = tt_dscto["Tasa_dscto"].values
    descuentos = ((1 + dscto_anual)**(1/12) - 1)*ones((1, m)).reshape(1, -1)
    dscto_anual_leads = tt_dscto["Tasa_dscto_leads"].values
    descuentos_leads = ((1 + dscto_anual_leads)**(1/12) - 1)*ones((1, m)).reshape(1, -1)
    desembolsos = X["DESEMBOLSO"].values
    r = X["TEA"].values
    r = power(1 + r, 1/12)-1
    r = r.reshape(1, -1)
    T = X["PLAZO"].values
    T = T.reshape(1, -1)

    return descuentos, descuentos_leads, desembolsos, r, T


def get_param(X_transformed, X_curves, X_instance):

    RemCap_year = X_transformed["TT_DSCTO"]["RemCap"].values[0]
    RemCap = (1+RemCap_year)**(1/12)-1

    rc = X_transformed["TT_DSCTO"]["TT"].values
    rc = power(1+rc,1/12)-1
    rc = rc.reshape(1, -1)

    ## TT Zero Cupon
    PrepagoRDM = X_transformed["TT_DSCTO"]["prepagoRDM"].values
    tt_fact = X_transformed["TT_DSCTO"]["tt_fact"].values
    cif_PD = X_curves["PD"] # Matrix of cumulative Pds (shape T,m)
    cif_PD = concatenate(cif_PD.values.tolist()).T
    cif_CAN = X_curves["CAN"] # Matrix of cumulative CANs (shape T,m)
    cif_CAN = concatenate(cif_CAN.values.tolist()).T
    factores_can = X_transformed['CAN']['factores']
    cum_PRE = X_curves["PRE"] # Matrix of cumulative PREs (shape T,m)
    cum_PRE = concatenate(cum_PRE.values.tolist()).T
    factores_pre = X_transformed['PRE']['factores']

    LGD = X_curves["LGD"]
    LGD = concatenate(LGD.values.tolist()).T
    ECf = X_curves["CAP"]
    ECf = concatenate(ECf.values.tolist()).T
    RR1 = X_curves["RR1"]
    RR1 = concatenate(RR1.values.tolist()).T
    RR2 = X_curves["RR2"]
    RR2 = concatenate(RR2.values.tolist()).T
    PD , _ = cif_to_cond_prob(shift(cif_PD, -2), shift(cif_CAN, 1), 1, 1) # comentar si clv se corrige a modelo estandar
    CAN , _ = cif_to_cond_prob(shift(cif_CAN, 0), shift(cif_PD, -2), 1, 1) # comentar si clv se corrige a modelo estandar
    PRE = cum_PRE - shift(cum_PRE, 1)
    PRE_TR = X_transformed["PRE"]
    CAN_TR = X_transformed["CAN"]
    can = X_instance["CAN"]
    pre = X_instance["PRE"]
    COSTOS_VIDA, COSTOS_T0 = X_transformed["COST"]
    COSTOS_T0 = array(sum(COSTOS_T0, axis=1)).reshape(1, -1)
    COSTOS_VIDA = array(COSTOS_VIDA).T
    INOF_TR = X_transformed["INOF"]
    INOF_TR = array(INOF_TR).T

    param = {
        "PD": PD, "cif_PD": cif_PD, "CAN": CAN, "cif_CAN": cif_CAN, "PRE": PRE,"factores_can": factores_can, 
        "factores_pre": factores_pre, "cum_PRE": cum_PRE, "can": can, "pre": pre, 
        "XP": PRE_TR, "XC": CAN_TR, "RR1": RR1, "RR2": RR2, "COSTOS_VIDA": COSTOS_VIDA, "COSTOS_T0": COSTOS_T0, "INOF_TR": INOF_TR, 
        "PrepagoRDM": PrepagoRDM, "tt_fact": tt_fact, "rc": rc, "LGD": LGD,"ECf": ECf, "RemCap": RemCap, "IR": 0.295
    }

    return param

def get_components(discounts, loan_amount, r, T, param, dict_comp, r_report="Base", flag_monitoreo=False):

    cif_PD = param["cif_PD"]
    can = param["can"]
    pre = param["pre"]
    XC = param["XC"]
    XP = param["XP"]
    LGD = param["LGD"]
    rc = param["rc"]
    ECf = param["ECf"]
    RemCap = param["RemCap"]
    IR = param["IR"]

    r = r.reshape(1, -1)
    r_year = power(1 + r.reshape(-1, 1), 12) - 1

    # Update r --> Dependencia de Cancelaciones y Prepagos con la TEA
    #cif_CAN = can.update_r(XC, r_year)
    #cum_PRE = pre.update_r(XP, r_year)

    # Update r --> Dependencia de Cancelaciones y Prepagos con la TEA
    cif_CAN_pre = can.update_r(XC, r_year)
    factores_can = array(param['factores_can'])
    cif_CAN = cif_CAN_pre*factores_can
    cif_CAN[cif_CAN>=1] = 0.999999
    
    cum_PRE_pre = pre.update_r(XP, r_year)
    factores_pre = array(param['factores_pre'])
    cum_PRE = cum_PRE_pre*factores_pre
    cum_PRE[cum_PRE>=1] = 0.999999

    # Comentar si CLV es estándar
    PD, _ = cif_to_cond_prob(shift(cif_PD, -2), shift(cif_CAN, 1), 1, 1)
    CAN, _ = cif_to_cond_prob(shift(cif_CAN, 0), shift(cif_PD, -2), 1, 1)  # Comentar si CLV es estándar
    PRE = maximum(cum_PRE - shift(cum_PRE, 1),0)

    discounts = discounts.reshape(1, -1)

    # Bbar: Contractual Balance
    Bf = Bfactor2(r, T, Tmax=60)
    Bbar = multiply(Bf, loan_amount)

    # Plotting the number of people who survived and died due to their age.
    # Survival Curves
    Sm1 = compute_S(PD, CAN, PRE, Bf)

    # B: Behavioral Balance
    B = maximum(Sm1*Bbar, 0)

    if not flag_monitoreo:

        ###########################################
        #### Actualizacion de la TT Zero Cupon ####
        ###########################################

        PrepagoRDM = param["PrepagoRDM"]
        PrepagoRDM = stack(PrepagoRDM)
        tt_fact = param["tt_fact"]
        tt_fact = stack(tt_fact)

        # Survival Curve TT Zero Cupon
        Sm1_tt = cumprod(1-PrepagoRDM, axis=1)
        Sm1_tt = Sm1_tt.T # TT calc.

        # Behavioral Balance TT Zero Cupon
        B_tt = maximum(Sm1_tt*Bbar, 0)

        # Factor de Descuento (TT)
        exponente = arange(0, 1801, 30).reshape(1, -1)
        fact_dscto = power(divide(1, 1 + divide(tt_fact, 360)), exponente).T # (61,m)

        saldo_t_por_factor = B_tt*fact_dscto[:60,:]
        saldo_t_1_por_factor = B_tt*fact_dscto[1:,:]
        saldo_t_1_por_factor_360 = saldo_t_1_por_factor*(30/360)

        rc = divide(sum(saldo_t_por_factor, axis=0) - sum(saldo_t_1_por_factor, axis=0), sum(saldo_t_1_por_factor_360, axis=0))
        rc = rc/12

        ###########################################
    
    # I: Interest Income from Lending
    B_m_D = B*(1-PD)
    I = B_m_D*r  # <-- Interest Income

    P = minimum(multiply(PRE, B[0, :]),B_m_D)
    D = PD*B  # <-- Default
    A = multiply(Afactor1(r, T, Tmax=60), B_m_D)
    C = CAN*(B_m_D -A) # <-- Cancelations

    # EF: Interest Outcome from Cost of Funds
    D_ef = shift(D, 2)
    B_ef_aux = B[0, :]-cumsum(D_ef+A+C+P, axis=0)
    B_ef = maximum(concatenate([B[0, :].reshape(1, -1), B_ef_aux[0:-1, :]], axis=0), 0)
    
    COF = -B_ef*rc  # <-- Cost Of Funds (Interest Outcome)
    EL = -LGD*D_ef  # <-- Expected Loss
    EC = B_ef*ECf  # <-- Economic Capital
    RemEC = EC*RemCap  # <-- Remuneration to Economic Capital
    # Economic Capital Flow (Variation)
    EC_flow = -diff(EC, axis=0, append=0)
    EC_0 = -EC[0, :].reshape(1, -1)

    # C: Costs
    costos = param["COSTOS_VIDA"]
    CH = maximum((1-cif_PD-cif_CAN), 0)  # Cuentas Hábiles
    rr1 = param["RR1"]  # Curva Roll Rate (1-30)
    rr2 = param["RR2"]  # Curva Roll Rate (31-60)

    costos_rr1 = CH*costos[0]*rr1  # Costos cobranzas 1-30
    costos_rr2 = CH*costos[1]*rr2  # Costos cobranzas 31-60
    costos_BmD = B_m_D*costos[2]  # Costos Mantenimiento SBS
    # Costos: adminitrativos, procesos de operaciones, transaccionales, publicidad, otros
    costos_CH = CH * costos[3]
    costos_total = -(costos_rr1 + costos_rr2 + costos_BmD + costos_CH)*(B_m_D>0)
    costos_T0 = -param["COSTOS_T0"]  # Costos en el periodo t=0

    # Ingresos No Financieros (INOF)
    inof_tr = param["INOF_TR"]
    portes = CH*inof_tr[0]
    seguro = B_m_D*inof_tr[1]

    # Descomentar para activar la penalidad por pago atrasado
    # pa = param["PA"]
    # pago_atrasado = clip(inof_tr[2]*Cuota, inof_min, inof_max)*CH*pa
    # inof = (portes + seguro + pago_atrasado)*(B_m_D>0)

    inof = (portes + seguro)*(B_m_D>0)

    # Taxes (Impuesto a la Renta)
    tax_0 = -(costos_T0)*IR
    taxes = -(I + COF + EL + RemEC + inof + costos_total)*IR

    # Computing Cash Flow
    CF = (I + COF + EL + RemEC + EC_flow + inof + costos_total + taxes)*(B_m_D>0)
    CF_t_0 = tax_0 + EC_0 + costos_T0  # Cash Flow in t=0

    Tmax = CF.shape[0]
    descuento_matrix = array([power(1/(1+descuento), t)
                                for descuento in discounts for t in arange(1, Tmax+1).reshape(-1, 1)])
        
    #################
    #### Reporte ####
    #################

    df = DataFrame(index=range(CF.shape[1]))
    if "NPV" in dict_comp:
        CF_discounted = multiply(descuento_matrix, CF)
        pv = sum(CF_discounted, axis=0).reshape(1, -1) + CF_t_0
        df["NPV"] = pv.reshape(-1,)
    if "Net Profit" in dict_comp:
        cf_aritmetico_aux = sum(CF, axis=0).reshape(1, -1) + CF_t_0
        cf_aritmetico = divide(cf_aritmetico_aux, divide(T, 12))
        df["Net_Profit"] = cf_aritmetico.reshape(-1,)
    if "ROE" in dict_comp:
        num = sum(CF, axis=0).reshape(1, -1) + CF_t_0 
        den = sum(EC, axis=0).reshape(1, -1) 
        roe = divide(num, den)*12
        df["ROE"] = roe.reshape(-1,)
    if "ECAP" in dict_comp:
        df["Capital_Promedio"] = divide(sum(EC, axis=0), T).reshape(-1,)
    if "ROA" in dict_comp:
        cf_final = sum(CF, axis=0).reshape(1, -1) + CF_t_0 
        saldo = sum(B, axis=0).reshape(1, -1)   
        df["ROA"] = (divide(cf_final, saldo)*12).reshape(-1,)
    if "Avg Balance" in dict_comp:
        df["Avg_Balance"] = divide(sum(B, axis=0), T).reshape(-1,)
    if "Target IRR" in dict_comp:
        df["Target IRR"] = (power(1 + discounts, 12) - 1).reshape(-1,)
    if "Interest Income" in dict_comp:
        df["Interest_Income"] = sum(I, axis=0).reshape(-1,)
    if "Cost of Funds" in dict_comp:
        df["Cost_of_Funds"] = sum(COF, axis=0).reshape(-1,)
    if "Loss Rate" in dict_comp:
        df["Loss_Rate"] = sum(EL, axis=0).reshape(-1,)
    if "Avg Balance - Y" in dict_comp:
        df["Avg_Balance_Yr1"] = divide(sum(B[:12,:], axis=0), 12).reshape(-1,)
        df["Avg_Balance_Yr2"] = divide(sum(B[12:24,:], axis=0), 12).reshape(-1,)
        df["Avg_Balance_Yr3"] = divide(sum(B[24:36,:], axis=0), 12).reshape(-1,)
        df["Avg_Balance_Yr4"] = divide(sum(B[36:48,:], axis=0), 12).reshape(-1,)
        df["Avg_Balance_Yr5"] = divide(sum(B[48:60,:], axis=0), 12).reshape(-1,)
    if "Capital Flow - Y" in dict_comp:
        df["Capital_Flow_Yr1"] = sum(EC_flow[:12,:], axis=0).reshape(-1,)
        df["Capital_Flow_Yr2"] = sum(EC_flow[12:24,:], axis=0).reshape(-1,)
        df["Capital_Flow_Yr3"] = sum(EC_flow[24:36,:], axis=0).reshape(-1,)
        df["Capital_Flow_Yr4"] = sum(EC_flow[36:48,:], axis=0).reshape(-1,)
        df["Capital_Flow_Yr5"] = sum(EC_flow[48:60,:], axis=0).reshape(-1,)
    if "Capital Flow NPV - Y" in dict_comp:
        EC_flow_discounted = multiply(descuento_matrix, EC_flow)
        df["Capital_Flow_NPV_Yr1"] = sum(EC_flow_discounted[:12,:], axis=0).reshape(-1,)
        df["Capital_Flow_NPV_Yr2"] = sum(EC_flow_discounted[12:24,:], axis=0).reshape(-1,)
        df["Capital_Flow_NPV_Yr3"] = sum(EC_flow_discounted[24:36,:], axis=0).reshape(-1,)
        df["Capital_Flow_NPV_Yr4"] = sum(EC_flow_discounted[36:48,:], axis=0).reshape(-1,)
        df["Capital_Flow_NPV_Yr5"] = sum(EC_flow_discounted[48:60,:], axis=0).reshape(-1,)
    if "Capital Remuneration - Y" in dict_comp:
        df["Capital_Remuneration_Yr1"] = sum(RemEC[:12,:], axis=0).reshape(-1,)
        df["Capital_Remuneration_Yr2"] = sum(RemEC[12:24,:], axis=0).reshape(-1,)
        df["Capital_Remuneration_Yr3"] = sum(RemEC[24:36,:], axis=0).reshape(-1,)
        df["Capital_Remuneration_Yr4"] = sum(RemEC[36:48,:], axis=0).reshape(-1,)
        df["Capital_Remuneration_Yr5"] = sum(RemEC[48:60,:], axis=0).reshape(-1,)
    if "Capital Remuneration NPV - Y" in dict_comp:
        RemEC_discounted = multiply(descuento_matrix, RemEC)
        df["Capital_Remuneration_NPV_Yr1"] = sum(RemEC_discounted[:12,:], axis=0).reshape(-1,)
        df["Capital_Remuneration_NPV_Yr2"] = sum(RemEC_discounted[12:24,:], axis=0).reshape(-1,)
        df["Capital_Remuneration_NPV_Yr3"] = sum(RemEC_discounted[24:36,:], axis=0).reshape(-1,)
        df["Capital_Remuneration_NPV_Yr4"] = sum(RemEC_discounted[36:48,:], axis=0).reshape(-1,)
        df["Capital_Remuneration_NPV_Yr5"] = sum(RemEC_discounted[48:60,:], axis=0).reshape(-1,)
    if "Interest Income - Y" in dict_comp:
        df["Interest_Income_Yr1"] = sum(I[:12,:], axis=0).reshape(-1,)
        df["Interest_Income_Yr2"] = sum(I[12:24,:], axis=0).reshape(-1,)
        df["Interest_Income_Yr3"] = sum(I[24:36,:], axis=0).reshape(-1,)
        df["Interest_Income_Yr4"] = sum(I[36:48,:], axis=0).reshape(-1,)
        df["Interest_Income_Yr5"] = sum(I[48:60,:], axis=0).reshape(-1,)
    if "Interest Income NPV - Y" in dict_comp:
        I_discounted = multiply(descuento_matrix, I)
        df["Interest_Income_NPV_Yr1"] = sum(I_discounted[:12,:], axis=0).reshape(-1,)
        df["Interest_Income_NPV_Yr2"] = sum(I_discounted[12:24,:], axis=0).reshape(-1,)
        df["Interest_Income_NPV_Yr3"] = sum(I_discounted[24:36,:], axis=0).reshape(-1,)
        df["Interest_Income_NPV_Yr4"] = sum(I_discounted[36:48,:], axis=0).reshape(-1,)
        df["Interest_Income_NPV_Yr5"] = sum(I_discounted[48:60,:], axis=0).reshape(-1,)
    if "Non Financial Income - Y" in dict_comp:
        df["Non_Financial_Income_Yr1"] = sum(inof[:12,:], axis=0).reshape(-1,)
        df["Non_Financial_Income_Yr2"] = sum(inof[12:24,:], axis=0).reshape(-1,)
        df["Non_Financial_Income_Yr3"] = sum(inof[24:36,:], axis=0).reshape(-1,)
        df["Non_Financial_Income_Yr4"] = sum(inof[36:48,:], axis=0).reshape(-1,)
        df["Non_Financial_Income_Yr5"] = sum(inof[48:60,:], axis=0).reshape(-1,)
    if "Non Financial Income NPV - Y" in dict_comp:
        inof_discounted = multiply(descuento_matrix, inof)
        df["Non_Financial_Income_NPV_Yr1"] = sum(inof_discounted[:12,:], axis=0).reshape(-1,)
        df["Non_Financial_Income_NPV_Yr2"] = sum(inof_discounted[12:24,:], axis=0).reshape(-1,)
        df["Non_Financial_Income_NPV_Yr3"] = sum(inof_discounted[24:36,:], axis=0).reshape(-1,)
        df["Non_Financial_Income_NPV_Yr4"] = sum(inof_discounted[36:48,:], axis=0).reshape(-1,)
        df["Non_Financial_Income_NPV_Yr5"] = sum(inof_discounted[48:60,:], axis=0).reshape(-1,)
    if "Cost of Funds - Y" in dict_comp:
        df["Cost_of_Funds_Yr1"] = sum(COF[:12,:], axis=0).reshape(-1,)
        df["Cost_of_Funds_Yr2"] = sum(COF[12:24,:], axis=0).reshape(-1,)
        df["Cost_of_Funds_Yr3"] = sum(COF[24:36,:], axis=0).reshape(-1,)
        df["Cost_of_Funds_Yr4"] = sum(COF[36:48,:], axis=0).reshape(-1,)
        df["Cost_of_Funds_Yr5"] = sum(COF[48:60,:], axis=0).reshape(-1,)
    if "Cost of Funds NPV - Y" in dict_comp:
        COF_discounted = multiply(descuento_matrix, COF)
        df["Cost_of_Funds_NPV_Yr1"] = sum(COF_discounted[:12,:], axis=0).reshape(-1,)
        df["Cost_of_Funds_NPV_Yr2"] = sum(COF_discounted[12:24,:], axis=0).reshape(-1,)
        df["Cost_of_Funds_NPV_Yr3"] = sum(COF_discounted[24:36,:], axis=0).reshape(-1,)
        df["Cost_of_Funds_NPV_Yr4"] = sum(COF_discounted[36:48,:], axis=0).reshape(-1,)
        df["Cost_of_Funds_NPV_Yr5"] = sum(COF_discounted[48:60,:], axis=0).reshape(-1,)
    if "Losses - Y" in dict_comp:
        df["Losses_Yr1"] = sum(EL[:12,:], axis=0).reshape(-1,)
        df["Losses_Yr2"] = sum(EL[12:24,:], axis=0).reshape(-1,)
        df["Losses_Yr3"] = sum(EL[24:36,:], axis=0).reshape(-1,)
        df["Losses_Yr4"] = sum(EL[36:48,:], axis=0).reshape(-1,)
        df["Losses_Yr5"] = sum(EL[48:60,:], axis=0).reshape(-1,)
    if "Losses NPV - Y" in dict_comp:
        EL_discounted = multiply(descuento_matrix, EL)
        df["Losses_NPV_Yr1"] = sum(EL_discounted[:12,:], axis=0).reshape(-1,)
        df["Losses_NPV_Yr2"] = sum(EL_discounted[12:24,:], axis=0).reshape(-1,)
        df["Losses_NPV_Yr3"] = sum(EL_discounted[24:36,:], axis=0).reshape(-1,)
        df["Losses_NPV_Yr4"] = sum(EL_discounted[36:48,:], axis=0).reshape(-1,)
        df["Losses_NPV_Yr5"] = sum(EL_discounted[48:60,:], axis=0).reshape(-1,)
    if "Direct Costs - Y" in dict_comp:
        df["Direct_Costs_Yr1"] = sum(costos_total[:12,:], axis=0).reshape(-1,)
        df["Direct_Costs_Yr2"] = sum(costos_total[12:24,:], axis=0).reshape(-1,)
        df["Direct_Costs_Yr3"] = sum(costos_total[24:36,:], axis=0).reshape(-1,)
        df["Direct_Costs_Yr4"] = sum(costos_total[36:48,:], axis=0).reshape(-1,)
        df["Direct_Costs_Yr5"] = sum(costos_total[48:60,:], axis=0).reshape(-1,)
    if "Direct Costs NPV - Y" in dict_comp:
        costos_total_discounted = multiply(descuento_matrix, costos_total)
        df["Direct_Costs_NPV_Yr1"] = sum(costos_total_discounted[:12,:], axis=0).reshape(-1,)
        df["Direct_Costs_NPV_Yr2"] = sum(costos_total_discounted[12:24,:], axis=0).reshape(-1,)
        df["Direct_Costs_NPV_Yr3"] = sum(costos_total_discounted[24:36,:], axis=0).reshape(-1,)
        df["Direct_Costs_NPV_Yr4"] = sum(costos_total_discounted[36:48,:], axis=0).reshape(-1,)
        df["Direct_Costs_NPV_Yr5"] = sum(costos_total_discounted[48:60,:], axis=0).reshape(-1,)
    if "Income Tax - Y" in dict_comp:
        df["Income_Tax_Yr1"] = sum(taxes[:12,:], axis=0).reshape(-1,)
        df["Income_Tax_Yr2"] = sum(taxes[12:24,:], axis=0).reshape(-1,)
        df["Income_Tax_Yr3"] = sum(taxes[24:36,:], axis=0).reshape(-1,)
        df["Income_Tax_Yr4"] = sum(taxes[36:48,:], axis=0).reshape(-1,)
        df["Income_Tax_Yr5"] = sum(taxes[48:60,:], axis=0).reshape(-1,)
    if "Income Tax NPV - Y" in dict_comp:
        taxes_discounted = multiply(descuento_matrix, taxes)
        df["Income_Tax_NPV_Yr1"] = sum(taxes_discounted[:12,:], axis=0).reshape(-1,)
        df["Income_Tax_NPV_Yr2"] = sum(taxes_discounted[12:24,:], axis=0).reshape(-1,)
        df["Income_Tax_NPV_Yr3"] = sum(taxes_discounted[24:36,:], axis=0).reshape(-1,)
        df["Income_Tax_NPV_Yr4"] = sum(taxes_discounted[36:48,:], axis=0).reshape(-1,)
        df["Income_Tax_NPV_Yr5"] = sum(taxes_discounted[48:60,:], axis=0).reshape(-1,) 
    if "PD Curve" in dict_comp:
        PD_marg = cif_PD - shift(cif_PD, 1)
        df[["PD" + str(x) for x in list(range(1, 61))]] = PD_marg.T
    if "PRE Curve" in dict_comp:
        PRE_marg = cum_PRE - shift(cum_PRE, 1)
        df[["PRE" + str(x) for x in list(range(1, 61))]] = PRE_marg.T 
    if "CAN Curve" in dict_comp:
        CAN_marg = cif_CAN - shift(cif_CAN, 1)
        df[["CAN" + str(x) for x in list(range(1, 61))]] = CAN_marg.T
    if "Saldo Curve" in dict_comp:
        df[["SALDOPROM" + str(x) for x in list(range(1, 60))]] = B[1:].T
    if "IF Curve" in dict_comp:
        df[["IF" + str(x) for x in list(range(1, 61))]] = I.T
    if "EF Curve" in dict_comp:
        df[["EF" + str(x) for x in list(range(1, 61))]] = COF.T
    if "TT" in dict_comp:
        df["TT"] = (power(1 + rc, 12) - 1).reshape(-1,)
    if "Descomposicion VAN" in dict_comp: ## VAN Total debe ser cero si se ingresa una tasa mínima
        cf_discounted = multiply(descuento_matrix, CF)
        df["VAN Total"] = (sum(cf_discounted, axis=0).reshape(1,-1) + costos_T0 + tax_0 + EC_0).reshape(-1,)
        capital_discounted = multiply(descuento_matrix, EC_flow)
        df["VAN Capital"] = (sum(capital_discounted, axis=0).reshape(1,-1) + EC_0).reshape(-1,)
        tt_discounted = multiply(descuento_matrix, COF)
        df["VAN TT"] = (sum(tt_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
        loss_discounted = multiply(descuento_matrix, EL)
        df["VAN Perdida"] = (sum(loss_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
        costs_discounted = multiply(descuento_matrix, costos_total)
        df["VAN Costos"] = (sum(costs_discounted, axis=0).reshape(1,-1) + costos_T0).reshape(-1,)
        taxes_discounted = multiply(descuento_matrix, taxes)
        df["VAN IR"] = (sum(taxes_discounted, axis=0).reshape(1,-1) + tax_0).reshape(-1,)
    if "VAN Intereses" in dict_comp:
        interests_discounted = multiply(descuento_matrix, I)
        df["VAN Intereses"] = (sum(interests_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
    if "VAN Inof" in dict_comp:
        inof_discounted = multiply(descuento_matrix, inof)
        df["VAN INOF"] = (sum(inof_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
    if "VAN RemCap" in dict_comp:
        rem_cap_discounted = multiply(descuento_matrix, RemEC)
        df["VAN RemCap"] = (sum(rem_cap_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
    ## Pauta
    if "Margen Neto" in dict_comp:
        margen_neto = sum(I[:12,:] + COF[:12,:] + EL[:12,:] + inof[:12,:], axis=0)
        df["Margen_Neto"] = margen_neto.reshape(-1,)        
    if "Margen Financiero" in dict_comp:
        margen_fin = I + COF
        df[["Margen_Financiero_" + r_report + "_" + str(x) for x in list(range(1, 25))]] = margen_fin[:24,:].T
    if "Saldo Remanente" in dict_comp:
        df[["Saldo_Remanente_" + r_report + "_" + str(x) for x in list(range(1, 25))]] = B[:24,:].T
    if "IxS" in dict_comp:
        df[["IxS_" + r_report + "_" + str(x) for x in list(range(1, 37))]] = inof[:36,:].T
    if "Provisiones" in dict_comp:
        df[["Provisiones_" + r_report + "_" + str(x) for x in list(range(1, 25))]] = EL[:24,:].T

    return df


def preprocessing(X, param_canal, param_segmento):
    """

    Args:


    Returns:

    """

    # Verifica si el canal está parametrizado e imputa canal ponderado si no lo está
    X["CANAL"].fillna("PONDERADO", inplace=True)
    b_canal_no_existe = ~X["CANAL"].isin(param_canal["CANAL"].unique())
    X.loc[b_canal_no_existe, "CANAL"] = "PONDERADO"

    # Imputación modal de segmento ortogonal 
   
    condition_list_scores = [(X["SCORE"] < 340), (X["SCORE"] >= 340) & (X["SCORE"] < 385), (X["SCORE"] >= 385) & (X["SCORE"]<430), (X["SCORE"]>=430)]
    choice_list_scores = [0, 340, 385, 430]
    X.loc[:, "SCORE_SEG"] = select(condition_list_scores, choice_list_scores, default= "Not Specified")

    condition_list_desembolso = [(X["DESEMBOLSO"]<10000), (X["DESEMBOLSO"]>=10000) & (X["DESEMBOLSO"]<20500), (X["DESEMBOLSO"]>=20500) & (X["DESEMBOLSO"]<43200), (X["DESEMBOLSO"]>=43200)]
    choice_list_desembolso = [0, 10000, 20500, 43200]
    X.loc[:, "DESEMBOLSO_SEG"] = select(condition_list_desembolso, choice_list_desembolso, default= "Not Specified")

    X = pd.merge(X, param_segmento, on=["SCORE_SEG","DESEMBOLSO_SEG"], how= "left")

    X.loc[:,"SEGMENTO"] =where(X["SEGMENTO"].isnull(), X["SEGMENTO_MISSING"].values, X["SEGMENTO"].values).astype(int)

    X.drop(columns=["SEGMENTO_MISSING"], inplace=True )

    return X


def pv_structure_with_stressed_curves(descuentos, desembolsos, r, T, param, impacto, flag_reporte=False, flag_monitoreo=False):
    """
    Args:
        descuentos: Tasa de descuento mensual (TIR Objetivo)
        desembolsos: Disbursement principal
        r: Monthly interest rate
        T: Disbursement maturity
        param: Diccionario de parámetros del clv.get_parameters_pv()

    Returns: 
        pv 

    """
    
    PD = minimum(param["PD"] * impacto, 1)
    cif_PD = minimum(param["cif_PD"] * impacto, 1)
    CAN = param["CAN"]
    cif_CAN = param["cif_CAN"]
    PRE = param["PRE"]
    LGD = param["LGD"]
    tt = param["tt"]
    ECf = param["ECf"]
    RemCap = param["RemCap"]
    IR = param["IR"]

    r = r.reshape(1, -1)
    descuentos = descuentos.reshape(1, -1)

    # Bbar: Contractual Balance
    Bf = Bfactor2(r, T, Tmax=60)
    Bbar = multiply(Bf, desembolsos)

    # Survival Curves
    Sm1 = compute_S(PD, CAN, PRE, Bf)

    # B: Behavioral Balance
    B = maximum(Sm1*Bbar, 0)

    if not flag_monitoreo:

        ###########################################
        #### Actualizacion de la TT Zero Cupon ####
        ###########################################

        PrepagoRDM = param["PrepagoRDM"]
        PrepagoRDM = stack(PrepagoRDM)
        tt_fact = param["tt_fact"]
        tt_fact = stack(tt_fact)

        # Survival Curve TT Zero Cupon
        Sm1_tt = cumprod(1 - PrepagoRDM, axis=1)
        Sm1_tt = Sm1_tt.T # TT calc.

        # Behavioral Balance TT Zero Cupon
        B_tt = maximum(Sm1_tt*Bbar, 0)

        # Factor de Descuento (TT)
        exponente = arange(0, 1801, 30).reshape(1, -1)
        fact_dscto = power(divide(1, 1 + divide(tt_fact, 360)), exponente).T # (61,m)

        saldo_t_por_factor = B_tt*fact_dscto[:60,:]
        saldo_t_1_por_factor = B_tt*fact_dscto[1:,:]
        saldo_t_1_por_factor_360 = saldo_t_1_por_factor*(30/360)

        tt = divide(sum(saldo_t_por_factor, axis=0) - sum(saldo_t_1_por_factor, axis=0), sum(saldo_t_1_por_factor_360, axis=0))
        tt = tt/12

        ###########################################

    # I: Interest Income from Lending
    B_m_D = B*(1 - PD)
    I = B_m_D*r  # <-- Interest Income

    P = minimum(multiply(PRE, B[0,:]), B_m_D)
    D = PD*B  # <-- Default
    A = multiply(Afactor1(r, T, Tmax=60), B_m_D) # <-- Amortizations
    C = CAN*(B_m_D - A) # <-- Cancelations

    # EF: Interest Outcome from Cost of Funds
    D_ef = shift(D, 2)
    B_ef_aux = B[0,:] - cumsum(D_ef + A + C + P, axis=0)
    B_ef = maximum(concatenate([B[0,:].reshape(1, -1), B_ef_aux[0:-1,:]], axis=0), 0)
    
    COF = -B_ef*tt  # <-- Cost Of Funds (Interest Outcome)
    EL = -LGD*D_ef  # <-- Expected Loss
    EC = B_ef*ECf  # <-- Economic Capital
    RemEC = EC*RemCap  # <-- Remuneration to Economic Capital
    EC_flow = -diff(EC, axis=0, append=0)     # Economic Capital Flow
    EC_0 = -EC[0,:].reshape(1, -1)

    # C: Costs
    costos = param["COSTOS_VIDA"]
    CH = maximum((1 - cif_PD - cif_CAN), 0)  # Cuentas Hábiles
    rr1 = param["RR1"]  # Curva Roll Rate (1-30)
    rr2 = param["RR2"]  # Curva Roll Rate (31-60)

    costos_rr1 = CH*costos[0]*rr1  # Costos cobranzas 1-30
    costos_rr2 = CH*costos[1]*rr2  # Costos cobranzas 31-60
    costos_BmD = B_m_D*costos[2]  # Costos Mantenimiento SBS
    # Costos: adminitrativos, procesos de operaciones, transaccionales, publicidad, otros
    costos_CH = CH * costos[3]

    costos_total = -(costos_rr1 + costos_rr2 + costos_BmD + costos_CH)*(B_m_D>0)
    costos_T0 = -param["COSTOS_T0"]  # Costos en el periodo t=0

    # Ingresos No Financieros (INOF)
    inof_tr = param["INOF_TR"]
    portes = CH*inof_tr[0]
    seguro = B_m_D*inof_tr[1]

    inof = (portes + seguro)*(B_m_D > 0)

    # Taxes (Impuesto a la Renta)
    tax_0 = -(costos_T0)*IR
    taxes = -(I + COF + EL + RemEC + inof + costos_total)*IR

    # Computing Cash Flow
    CF = (I + COF + EL + RemEC + EC_flow + inof + costos_total + taxes)*(B_m_D > 0)

    # Computing Net Present Value
    Tmax = CF.shape[0]
    descuento_matrix = array([power(1/(1+descuento), t)
                                 for descuento in descuentos for t in arange(1, Tmax+1).reshape(-1, 1)])
    # Discounted Cash Flows for simple sum
    CF_discounted = multiply(descuento_matrix, CF)
    CF_0 = tax_0 + EC_0 + costos_T0  # Cash Flow in t=0
    pv = sum(CF_discounted, axis=0).reshape(1, -1) + CF_0  # Net Present Value
    
    if flag_reporte:
        output = divide(sum(EC, axis=0), T).reshape(-1,)
    else:
        output = pv

    return output


def roa_rmin(target_indicator, desembolsos, r, T, param, flag_monitoreo=False):
    """
    Parameters:
    >>> r: tasa de la iteración previa
    >>> desembolsos: Desembolsos efectivos
    >>> T: Plazos
    >>> param: Diccionario de parametros del clv.get_parameters_pv()

    Returns:

    """
    cif_PD = param["cif_PD"]
    can = param["can"]
    pre = param["pre"]
    XC = param["XC"]
    XP = param["XP"]
    LGD = param["LGD"]
    tt = param["rc"]
    ECf = param["ECf"]
    RemCap = param["RemCap"]
    IR = param["IR"]

    r = r.reshape(1, -1)
    r_year = power(1 + r.reshape(-1, 1), 12) - 1

    # Update r --> Dependencia de Cancelaciones y Prepagos con la TEA
    cif_CAN_pre = can.update_r(XC, r_year)
    factores_can = array(param['factores_can'])
    cif_CAN = cif_CAN_pre*factores_can
    cif_CAN[cif_CAN>=1] = 0.999999
    
    cum_PRE_pre = pre.update_r(XP, r_year)
    factores_pre = array(param['factores_pre'])
    cum_PRE = cum_PRE_pre*factores_pre
    cum_PRE[cum_PRE>=1] = 0.999999

    # Comentar si CLV es estándar
    PD, _ = cif_to_cond_prob(shift(cif_PD, -2), shift(cif_CAN, 1), 1, 1)
    CAN, _ = cif_to_cond_prob(shift(cif_CAN, 0), shift(cif_PD, -2), 1, 1)  # Comentar si CLV es estándar
    # PD, CAN = cif_to_cond_prob(cif_CAN,cif_PD,1,1) # Descomentar si CLV es estándar
    PRE = maximum(cum_PRE - shift(cum_PRE, 1), 0)

    # Bbar: Contractual Balance
    Bf = Bfactor2(r, T, Tmax=60)
    Bbar = multiply(Bf, desembolsos)

    # Survival Curves
    Sm1 = compute_S(PD, CAN, PRE, Bf)

    # B: Behavioral Balance
    B = maximum(Sm1 * Bbar, 0)

    if not flag_monitoreo:

        ###########################################
        #### Actualizacion de la TT Zero Cupon ####
        ###########################################   

        PrepagoRDM = param["PrepagoRDM"]
        PrepagoRDM = stack(PrepagoRDM)
        tt_fact = param["tt_fact"]
        tt_fact = stack(tt_fact)

        # Survival Curve TT Zero Cupon
        Sm1_tt = cumprod(1 - PrepagoRDM, axis=1)
        Sm1_tt = Sm1_tt.T  # TT calc.

        # Behavioral Balance TT Zero Cupon
        B_tt = maximum(Sm1_tt * Bbar, 0)

        # Factor de Descuento (TT)
        exponente = arange(0, 1801, 30).reshape(1, -1)
        fact_dscto = power(divide(1, 1 + divide(tt_fact, 360)), exponente).T  # (61,m)

        saldo_t_por_factor = B_tt * fact_dscto[:60,:]
        saldo_t_1_por_factor = B_tt * fact_dscto[1:,:]
        saldo_t_1_por_factor_360 = saldo_t_1_por_factor * (30/360)

        tt = divide(sum(saldo_t_por_factor, axis=0) - sum(saldo_t_1_por_factor, axis=0), sum(saldo_t_1_por_factor_360, axis=0))
        tt = tt/12

    ###########################################

    # I: Interest Income from Lending
    B_m_D = B * (1 - PD)
    I = B_m_D * r  # <-- Interest Income

    P = minimum(multiply(PRE, B[0,:]), B_m_D)
    D = PD * B  # <-- Default
    A = multiply(Afactor1(r, T, Tmax=60), B_m_D)  # <-- Amortizations
    C = CAN * (B_m_D - A)  # <-- Cancelations

    # EF: Interest Outcome from Cost of Funds
    D_ef = shift(D, 2)
    B_ef_aux = B[0,:] - cumsum(D_ef + A + C + P, axis=0)
    B_ef = maximum(concatenate([B[0,:].reshape(1, -1), B_ef_aux[0:-1,:]], axis=0), 0)
    
    COF = -B_ef * tt  # <-- Cost Of Funds (Interest Outcome)
    EL = -LGD * D_ef  # <-- Expected Loss
    EC = B_ef * ECf  # <-- Economic Capital
    RemEC = EC * RemCap  # <-- Remuneration to Economic Capital
    #RemEC = (EC.T * RemCap).T 
    EC_flow = -diff(EC, axis=0, append=0)  # Economic Capital Flow
    EC_0 = -EC[0,:].reshape(1, -1)

    # C: Costs
    costos = param["COSTOS_VIDA"]
    CH = maximum((1 - cif_PD - cif_CAN), 0)  # Cuentas Hábiles
    rr1 = param["RR1"]  # Curva Roll Rate (1-30)
    rr2 = param["RR2"]  # Curva Roll Rate (31-60)

    costos_rr1 = CH * costos[0] * rr1  # Costos cobranzas 1-30
    costos_rr2 = CH * costos[1] * rr2  # Costos cobranzas 31-60
    costos_BmD = B_m_D * costos[2]  # Costos Mantenimiento SBS
    # Costos: adminitrativos, procesos de operaciones, transaccionales, publicidad, otros
    costos_CH = CH * costos[3]

    costos_total = -(costos_rr1 + costos_rr2 + costos_BmD + costos_CH) * (B_m_D > 0)
    costos_T0 = -param["COSTOS_T0"]  # Costos en el periodo t=0

    # Ingresos No Financieros (INOF)
    inof_tr = param["INOF_TR"]
    portes = CH * inof_tr[0]
    seguro = B_m_D * inof_tr[1]

    inof = (portes + seguro) * (B_m_D > 0)

    # Taxes (Impuesto a la Renta)
    tax_0 = -(costos_T0) * IR
    taxes = -(I + COF + EL + RemEC + inof + costos_total) * IR

    # Computing Cash Flow
    CF = (I + COF + EL + RemEC + EC_flow + inof + costos_total + taxes) * (B_m_D > 0)
    CF_0 = tax_0 + EC_0 + costos_T0  # Cash Flow in t=0

    cf_final = sum(CF, axis=0).reshape(1, -1) + CF_0 
    saldo = sum(B, axis=0).reshape(1, -1)   
    roa_target = (divide(cf_final, saldo) * 12)- array(target_indicator).reshape(1, -1)

    return roa_target