# Script Curvas CLV
import source.clv_cef.cef_engine.utils as ut
class CurveCan():
    """ Creating Cancelation Probability Curves """

    def __init__(self, hyperparams, impacto=1):
        self.impacto = impacto
        [setattr(self, key, hyperparams[key]) for key in hyperparams]
        df_paramTt = self.param_Tt[["T"]].copy()
        df_paramTt["sh_t"] = self.param_Tt.loc[:,"1":].apply(lambda x: x.values, axis=1)
        self.param_Tt = df_paramTt.copy() 

    def transform(self, X):
        X_transformed = ut.can_transform(
            X, self.param_PDCal, self.param_GroupPD, self.param_Enalta, self.param_factor)
        return X_transformed

    def predict(self, X):
        X_predict, self.factores = ut.can_predict(X, self.param_T, self.param_Tt, impacto=self.impacto)
        return X_predict

    def update_r(self, X, r):
        curve = self.predict(ut.can_update_r(X, r))  # Predict con nueva TEA
        return ut.np_stack(curve["curve"].values, axis=0).T

# 2. PD Curve
class CurvePD():
    """ Creating Default Probability Temporal Curves """

    def __init__(self, hyperparams, flag_portafolio):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]
        self.flag_portafolio = flag_portafolio
        
    def transform(self, X):
        X_transformed = ut.pd_transform(X)
        return X_transformed

    def predict(self, X):
        X_predict, self.pd_12_temporal = ut.pd_predict(
            X, self.param_scalar, self.param_T, self.param_Tt, self.flag_portafolio)
        return X_predict

# 3. Prepayment Curve

# Prepayment Curve
class CurvePre():
    """ Creating the Prepayment Curve """

    def __init__(self, hyperparams, impacto=1):
        self.impacto = impacto
        self.pre_cache_values={}
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        X_transformed = ut.pre_transform(
            X, self.param_PDCal, self.param_GroupPD, self.param_Enalta, self.param_factor)
        return X_transformed

    def predict(self, X):
        X_predict, self.factores = ut.pre_predict(
            X, self.param_Primera, self.param_Logit, self.param_MCO, 
            #CORRIGIENDO
            self.param_PDCal,
            impacto=self.impacto, pre_cache_values=self.pre_cache_values)
        return X_predict
    
    def update_r(self, X, r):
        
        X_transformed = X.copy()
        X_update = ut.pre_update_r(X_transformed, r, self.param_PDCal)
        curve = self.predict(X_update)  # Predict con nueva TEA
        result = ut.np_stack(curve["curve"].values, axis=0).T
        return result

# 4. LGD Curve 
# LGD Curve
class CurveLGD():
    """ Creating LGD Curves """

    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]
            

    def transform(self, X):
        X_transformed = ut.lgd_transform(X, self.lgd_Enalta, self.limit_T)
        return X_transformed

    def predict(self, X):
        X_predict, self.lgd21 = ut.lgd_predict(X, self.param_T)
        return X_predict


# 5. Roll Rates Curves
class CurveRR1():
    """ Class for creating Roll Rate Temporal Curve 1 - 30 """

    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]
            

    def transform(self, X):
        X_transformed = ut.rr1_transform(X, self.param_GroupPD)
        return X_transformed

    def predict(self, X):
        X_predict = ut.rr1_predict(X, self.param_T1)
        return X_predict


class CurveRR2():
    """ Class for creating Roll Rate Temporal Curve 31 - 60 """

    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]
            

    def transform(self, X):
        X_transformed = ut.rr2_transform(X, self.param_GroupPD)
        return X_transformed

    def predict(self, X):
        X_predict = ut.rr2_predict(X, self.param_T2)
        return X_predict

# 7. CAP Curve
class CurveCAP():
    """ Class for creating CAP Curve """

    def __init__(self, hyperparams, flag_portafolio):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]
        self.flag_portafolio = flag_portafolio

    def transform(self, X):
        X_transformed = ut.cap_transform(X, self.param_PDTTC, self.flag_portafolio)
        return X_transformed

    def predict(self, X):
        X_predict = ut.cap_predict(X, self.param_scalar)
        return X_predict


# Curve Costos
class CurveCostos():
    def __init__(self, hyperparams, flag_portafolio):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]
        self.flag_portafolio = flag_portafolio

    def transform(self, X):
        costos_t_1_T, costos_t_0 = ut.costos_transform(
            X, self.param_canalT0, self.param_montoT0, self.param_otrosT0, self.param_costost, self.flag_portafolio)
        return costos_t_1_T, costos_t_0

# Curve Inof
class CurvesInoF():
    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        inof_tr = ut.inof_transform(
            X, self.param_pmoneda, self.param_psegmento, self.param_seguros)
        return inof_tr

# Curve TT&Descuentos
class CurvesTT_Desc():
    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        df_tt_desc = ut.tt_desc_transform(
            X, self.param_tasadescuento_tmin, self.param_tasadescuento_leads, 
            self.param_tt_prepago, self.param_tt_factor, self.param_remcap,
            self.param_indicator_target,
            self.param_educated_guess
            )
        return df_tt_desc