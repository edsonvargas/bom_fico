@Library('jenkins-sharedlib@atla-new-features')
import sharedlib.JenkinsfileUtil

def utils = new JenkinsfileUtil(steps, this)
/* Project settings */
def project = "PRCG"
/* Namespace settings */
def namespace = "PRCG"
/* Mail configuration*/
// If recipients is null the mail is sent to the person who start the job
// The mails should be separated by commas(',')
def recipients = ""
def deploymentEnvironment = "dev"
// ocp | aks
def hosted = "aks"
// ocp311 | ocpa4
def ocpVersion = "ocpa4"
// MAVEN339_JDK11_OPENJ9 | MAVEN339_JAVA8
def javaVersion = "MAVEN339_JDK11_OPENJ9"
// OPTIONAL: Subscription Id for AKS Cluster
def aksSubscriptionId = ""
// for AKS Resource Group, for anything else: def aksRG = ""
def aksRG = "RSGREU2PRCGD01"
// for AKS Cluster Name, for anything else: def aksCluster = ""
def aksCluster = "aksveu2prcgd01"
// Ingress information for AKS
def ingressFQDN = "azingressprcgdesa.credito.bcp.com.pe"
def ingressCertificateSecret = "azingressdesa-cert"
// registry for AKS
def azureRegistry = "acrgeu2inctd01.azurecr.io"
try {
  node {
    stage('Preparation') {
      env.TIME_DELTA_INIT = steps.sh(script: "date +%s", returnStdout: true).toString().trim()
      cleanWs()
      utils.notifyByMail('START', recipients)
      checkout scm
      utils.prepare()
      //Setup parameters
      env.project = "${project}"
      utils.getDelta("prepare")
    }
    // values for k8s annotations
    def gitrepo = "${utils.currentGitURL}"
    def repobranch = "${utils.branchName}"
    def gitcommit = "${utils.currentGitCommit}"

    stage('Build & U.Test') {
      utils.setDeltaInit()
      utils.setMavenJavaVersion(javaVersion)
      utils.buildMaven("-U", false)
      utils.getDelta("build")
    }
    stage('QA Analisys') {
      utils.setDeltaInit()
      utils.executeSonar()
      utils.getDelta("qa")
    }
    stage('SAST Analisys'){
      utils.setDeltaInit()
      utils.executeFortifyMavenSast()
      utils.getDelta("sast")
    }
    stage('Upload Artifact') {
      utils.setDeltaInit()
      utils.deployArtifactoryMaven()
      utils.getDelta("upload_artifactory")
    }
    stage('Save Results') {
      utils.setDeltaInit()
      utils.saveResultMaven('jar')
      utils.getDelta("save_result")
    }
    stage('Application Delivery') {
      utils.setDeltaInit()
      utils.downloadSingleFilefromRepo("ATLA", "maintenance-tasks", "develop", "atla-token-bitbucket-${deploymentEnvironment}",
              "jenkins/internal-compact/eq_gt_1.9.0/jenkinsvault/internal-delivery-single-pipeline.groovy",
              "${WORKSPACE}/devops/jenkins/internal-delivery-pipeline.groovy")
      def deliverybranchname = "1.9.1"
      def mapVars = [:]
      mapVars << ["utils": utils]
      mapVars << ["project": project]
      mapVars << ["namespace": namespace]
      mapVars << ["deploymentEnvironment": deploymentEnvironment]
      mapVars << ["hosted": hosted]
      mapVars << ["ocpVersion": ocpVersion]
      mapVars << ["javaVersion": javaVersion]
      mapVars << ["aksSubscriptionId": aksSubscriptionId]
      mapVars << ["aksRG": aksRG]
      mapVars << ["aksCluster": aksCluster]
      mapVars << ["ingressFQDN": ingressFQDN]
      mapVars << ["ingressCertificateSecret": ingressCertificateSecret]
      mapVars << ["azureRegistry": azureRegistry]
      mapVars << ["gitrepo": gitrepo]
      mapVars << ["repobranch": repobranch]
      mapVars << ["gitcommit": gitcommit]
      mapVars << ["deliverybranchname": deliverybranchname]
      mapVars << ["deliveryref": "tag"]
      load("devops/jenkins/internal-delivery-pipeline.groovy").deliveryApplication(mapVars)
      utils.getDelta("application_delivery")
    }
    stage('Application Deployment') {
      utils.setDeltaInit()
      utils.downloadSingleFilefromRepo("ATLA", "maintenance-tasks", "develop", "atla-token-bitbucket-${deploymentEnvironment}",
              "jenkins/internal-compact/eq_gt_1.9.0/jenkinsvault/internal-delivery-single-pipeline.groovy",
              "${WORKSPACE}/devops/jenkins/internal-delivery-pipeline.groovy")
      def deliverybranchname = "1.9.1"
      def mapVars = [:]
      mapVars << ["utils": utils]
      mapVars << ["project": project]
      mapVars << ["namespace": namespace]
      mapVars << ["deploymentEnvironment": deploymentEnvironment]
      mapVars << ["hosted": hosted]
      mapVars << ["ocpVersion": ocpVersion]
      mapVars << ["javaVersion": javaVersion]
      mapVars << ["aksSubscriptionId": aksSubscriptionId]
      mapVars << ["aksRG": aksRG]
      mapVars << ["aksCluster": aksCluster]
      mapVars << ["ingressFQDN": ingressFQDN]
      mapVars << ["ingressCertificateSecret": ingressCertificateSecret]
      mapVars << ["azureRegistry": azureRegistry]
      mapVars << ["gitrepo": gitrepo]
      mapVars << ["repobranch": repobranch]
      mapVars << ["gitcommit": gitcommit]
      mapVars << ["deliverybranchname": deliverybranchname]
      mapVars << ["deliveryref": "tag"]
      load("devops/jenkins/internal-delivery-pipeline.groovy").deploymentApplication(mapVars)
      utils.getDelta("application_deployment")
    }
    stage('Post Execution') {
      utils.printLogstashInfo('SUCCESS',"${project}","${deploymentEnvironment}","${hosted}","JOB-TYPE: JAVA-MS")
      utils.executePostExecutionTasks()
      utils.notifyByMail('SUCCESS', recipients)
    }
  }
} catch (Exception e) {
  node {
    utils.printLogstashInfo('FAILED',"${project}","${deploymentEnvironment}","${hosted}","JOB-TYPE: JAVA-MS")
    utils.executeOnErrorExecutionTasks()
    utils.notifyByMail('FAIL', recipients)
    throw e
  }
}