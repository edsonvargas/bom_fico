package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.impl;


import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesalePostHeaders;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.WholesaleCreditEvaluationsService;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.WholesaleCreditEvaluationsDao;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.ExchangeRateRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.GetCommercialSpreadAndBlackListRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.GetTransferRateRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.dto.TokenAppcodeDto;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CommonTransferRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExchangeRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.SpreadComercialAndBlackList;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.token.TokenRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy.AlexandriaApi;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy.GeneratorApi;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.Util;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.AlexandriaBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.ErrorHandlerBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import com.github.benmanes.caffeine.cache.Cache;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.reactivex.Observable;
import io.reactivex.schedulers.Schedulers;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


/**
 * <br/>
 * Clase service que contiene los metodos necesarios para tramitar la data y logica de negocio que
 * consumira la clase REST LoanRateController<br/>
 * <b>Class</b>: LoanRateServiceImpl<br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: BCP <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>Christian Garcia</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Dec 13, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */


@Service
@Slf4j
public class WholesaleCreditEvaluationsServiceImpl implements WholesaleCreditEvaluationsService {

  @Autowired
  private WholesaleCreditEvaluationsDao wholesaleCreditEvaluationsDao;

  @Autowired
  private AlexandriaApi alexandriaApi;

  @Autowired
  private GetTransferRateRepository getTransferRateRepository;

  @Autowired
  private AlexandriaBuilder alexandriaBuilder;

  @Autowired
  private GetCommercialSpreadAndBlackListRepository getCommercialSpreadAndBlackListRepository;

  @Autowired
  private ExchangeRateRepository exchangeRateRepository;
  @Value("${fico.token.clientId}")
  private String clientId;
  @Value("${fico.token.clientSecret}")
  private String clientSecret;

  @Autowired
  private GeneratorApi generatorApi;

  @Autowired
  private Cache<Integer, String> globalCache;

  @Autowired
  private ErrorHandlerBuilder errorHandlerBuilder;

  @Override
  public Observable<PricingWholesaleResponse> response(
          PricingWholesalePostHeaders headers, Request request) {

    Util.validateTermMaxValue(request);

    TokenRequest tk = new TokenRequest();
    tk.setClientId(clientId);
    tk.setSecret(clientSecret);

    Observable<String> tokenObservable = generatorApi
        .executeProcessTokenUsingPost(tk).toObservable()
        .doOnNext(s ->
                      globalCache.put(1,s))
        .doOnError(ex -> log.error(ex.getMessage()));

    Observable<String> tokenCacheObservable =
        Maybe.fromCallable(() ->
                               globalCache.getIfPresent(1))
            .toObservable()
            .switchIfEmpty(tokenObservable)
            .doOnError(ex -> log.error(ex.getMessage()))
            .subscribeOn(Schedulers.io());

    Observable<CustomerGetResponse> customerGetObservable =
        alexandriaApi
            .search(headers.getOcpApimSubscriptionKey(), request.getCustomerInfo().getIdc())
            .flatMap(
                response ->
                    Observable.just(
                        alexandriaBuilder.getAlexandria(
                            errorHandlerBuilder.validateAlexandriaException(
                                response.body(), response.code()),
                            true)))
            .doOnError(error -> log.error(
                "Error MS Alexandria : " + error.getLocalizedMessage()))
            .subscribeOn(Schedulers.io());

    Observable<CustomerGetResponse> guarantorGetObservable =
        Objects.isNull(request.getGuarantorInfo())
            ? Observable.just(alexandriaBuilder.getAlexandria(null, false))
            : alexandriaApi
                .search(headers.getOcpApimSubscriptionKey(), request.getGuarantorInfo().getIdc())
                .distinct()
                .map(cus -> alexandriaBuilder.getAlexandria(cus.body(), false))
                .doOnError(error -> log.error(
                    "Error MS Alexandria : " + error.getLocalizedMessage()))
                .onErrorResumeNext(Observable.just(
                    alexandriaBuilder.getAlexandria(null, false)))
                .switchIfEmpty(Observable.just(
                    alexandriaBuilder.getAlexandria(null, false)))
                .subscribeOn(Schedulers.io());

    //req. contingentes inicio
    if (request.getQuotationType() == null) { //Valor por defecto en caso de null
      request.setQuotationType(Request.QuotationTypeEnum.fromValue(Constantes.CORTO_PLAZO));
    }
    //fin

    Observable<CommonTransferRate> commonTransferRatesObservable =
        Flowable.fromCallable(() -> getTransferRateRepository
            .getTransferRate(
                request.getCreditInfo()
                    .getCreditInfoBase().getCurrency().getCode().getValue(),
                request.getCreditInfo().getCreditInfoBase().getTerm(), //req contingetes
                "D",
                request.getQuotationType().getValue()))//req contingetes
                .toObservable()
                .distinct()
                .subscribeOn(Schedulers.io());

    Observable<SpreadComercialAndBlackList> spreadComercialAndBlackList =
        validateAppCodeForBlackList(headers.getAppCode(), request)
            .distinct()
            .subscribeOn(Schedulers.io())
            .doOnError(Throwable::printStackTrace)
            .onErrorResumeNext(defaultSpreadComercialAndBlackList())
            .switchIfEmpty(defaultSpreadComercialAndBlackList());

    Observable<ExchangeRate> exchangeRateObservable =
        Observable.fromCallable(() -> exchangeRateRepository.getExchangeType())
                .distinct()
                .subscribeOn(Schedulers.io())
                .onErrorResumeNext(Observable.just(new ExchangeRate()))
                .switchIfEmpty(Observable.just(new ExchangeRate()));

    return Observable.combineLatest(
            tokenCacheObservable,
            guarantorGetObservable,
            spreadComercialAndBlackList,
            exchangeRateObservable, (token,
                guarantorGetResponse,
                spreadComercialAndBlackListResponse,
                exchangeRateResponse) ->
                validateSpreadAndCustomer(
                    headers,
                    request,
                    token,
                    exchangeRateResponse,
                    guarantorGetResponse,
                    customerGetObservable,
                    spreadComercialAndBlackListResponse,
                    commonTransferRatesObservable))
        .distinct()
        .flatMap(responseObservable -> responseObservable.firstElement().toObservable());
  }

  /**
   * Method validateAppCodeForBlackList
   *
   * @version 1.0
   */
  public Observable<SpreadComercialAndBlackList> validateAppCodeForBlackList(
      String appCode, Request request) {

    if (Constantes.SALESFORCE_APPCODE.equalsIgnoreCase(appCode)) {
      return defaultSpreadComercialAndBlackList();
    } else {

      return Observable.just(getCommercialSpreadAndBlackListRepository
          .getSpreadComercialAndBlackList(
              request.getCustomerInfo().getIdc(),
              request.getCreditInfo().getCreditInfoBase()
                  .getCurrency().getCode().getValue()));
    }
  }

  /**
   * Method validateSpreadAndCustomer
   *
   * @version 1.0
   */
  @Override
  public Observable<PricingWholesaleResponse> validateSpreadAndCustomer(
      PricingWholesalePostHeaders headers,
      Request request,
      String token,
      ExchangeRate exchangeRateResponse,
      CustomerGetResponse guarantorGetResponse,
      Observable<CustomerGetResponse> customerGetObservable,
      SpreadComercialAndBlackList spreadComercialAndBlackListResponse,
      Observable<CommonTransferRate> commonTransferRatesObservable) {


    TokenAppcodeDto tokenAppCode = new TokenAppcodeDto();
    tokenAppCode.setToken(Constantes.BEARER + token);
    tokenAppCode.setAppCode(headers.getAppCode());

    if (spreadComercialAndBlackListResponse.getBlacklistRate().intValue() == -1
        && spreadComercialAndBlackListResponse.getSpreadComercial().intValue() == -1) {

      return customerGetObservable.flatMap(
          customerGetResponse -> wholesaleCreditEvaluationsDao.wholeInfo(
              request,
              tokenAppCode,
              customerGetResponse,
              guarantorGetResponse,
              commonTransferRatesObservable,
              spreadComercialAndBlackListResponse,
              exchangeRateResponse));
    } else {

      return wholesaleCreditEvaluationsDao.wholeInfo(
          request,
          tokenAppCode,
          new CustomerGetResponse(),
          guarantorGetResponse,
          commonTransferRatesObservable, spreadComercialAndBlackListResponse,
          exchangeRateResponse);
    }
  }

  /**
   * Method defaultSpreadComercialAndBlackList
   *
   * @version 1.0
   */
  public Observable<SpreadComercialAndBlackList> defaultSpreadComercialAndBlackList() {

    SpreadComercialAndBlackList spreadComercialAndBlackList = new SpreadComercialAndBlackList();
    spreadComercialAndBlackList.setSpreadComercial(BigDecimal.ONE.negate());
    spreadComercialAndBlackList.setBlacklistRate(BigDecimal.ONE.negate());
    return Observable.just(spreadComercialAndBlackList);
  }

}
