package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.impl;

import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.WholesaleCreditEvaluationsDao;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.CreditInfoCpRequestRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.CreditInfoCpResponseRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.ExceptionRoleRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.GuaranteeAlexandriaRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.SpecificClWarrantiesReqRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.WarrantiesReqRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.dto.TokenAppcodeDto;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CommonTransferRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CreditInfoCpResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExchangeRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.SpreadComercialAndBlackList;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.DmResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.mlx.MlxResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy.FicoClvMlxApi;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.proxy.FicoDmApi;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.ErrorHandlerBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.FicoClvMlxBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.FicoDmBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.RequestBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.ResponseBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.SpecificBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.WarrantyBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.WholsaleBuilder;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import io.reactivex.Observable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import retrofit2.Response;


/**
 * <br/>
 * Clase service que contiene los metodos necesarios para tramitar la data y logica de negocio que
 * consumira la clase REST LoanRateController<br/>
 * <b>Class</b>: LoanRateServiceImpl<br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 * <u>Service Provider</u>: BCP <br/>
 * <u>Developed by</u>: <br/>
 * <ul>
 * <li>Christian Garcia</li>
 * </ul>
 * <u>Changes</u>:<br/>
 * <ul>
 * <li>Dec 13, 2021 Creaci&oacute;n de Clase.</li>
 * </ul>
 * @version 1.0
 */

@Component
@Slf4j
@AllArgsConstructor
public class WholesaleCreditEvaluationsDaoImpl implements WholesaleCreditEvaluationsDao {

  @Autowired
  private FicoDmApi ficoDmApi;

  @Autowired
  private FicoClvMlxApi ficoClvMlxApi;

  @Autowired
  private FicoClvMlxBuilder ficoClvMlxBuilder;

  @Autowired
  private FicoDmBuilder ficoDmBuilder;

  @Autowired
  private WholsaleBuilder wholsaleBuilder;

  @Autowired
  private WarrantyBuilder warrantyBuilder;

  @Autowired
  private SpecificBuilder specificBuilder;

  @Autowired
  private CreditInfoCpRequestRepository creditInfoCpRequestRepository;

  @Autowired
  private CreditInfoCpResponseRepository creditInfoCpResponseRepository;

  @Autowired
  private ExceptionRoleRepository exceptionRoleRepository;

  @Autowired
  private SpecificClWarrantiesReqRepository specificClWarrantiesReqRepository;

  @Autowired
  private WarrantiesReqRepository warrantiesReqRepository;

  @Autowired
  private GuaranteeAlexandriaRepository guaranteeAlexandriaRepository;

  @Autowired
  private ErrorHandlerBuilder errorHandlerBuilder;

  /**
   * Method wholeInfo
   *
   * @version 1.0
   */
  @Override
  public Observable<PricingWholesaleResponse> wholeInfo(
      Request request,
      TokenAppcodeDto tokenAppCode,
      CustomerGetResponse customerGetResponse,
      CustomerGetResponse  guarantorGetResponse,
      Observable<CommonTransferRate> commonTransferRatesObservable,
      SpreadComercialAndBlackList spreadComercialAndBlackList,
      ExchangeRate exchangeRate) {
    return mlxFirst(
        request,
        customerGetResponse,
        guarantorGetResponse,
        tokenAppCode, commonTransferRatesObservable,
        spreadComercialAndBlackList, exchangeRate);
  }

  /**
   * Method mlxFirst
   *
   * @version 1.0
   */
  @Override
  public Observable<PricingWholesaleResponse> mlxFirst(
      Request request,
      CustomerGetResponse customerGetResponse,
      CustomerGetResponse  guarantorGetResponse,
      TokenAppcodeDto tokenAppCode,
      Observable<CommonTransferRate> commonTransferRatesObservable,
      SpreadComercialAndBlackList spreadComercialAndBlackList,
      ExchangeRate exchangeRate) {

    //No existe en lista negra
    if (spreadComercialAndBlackList.getBlacklistRate().intValue() < 0  || request.getQuotationType().getValue() == "CONT") {
      return commonTransferRatesObservable
          .flatMap(commonResponse -> ficoClvMlxApi
              .executeProcessFicoClvMlxUsingPost(
                  tokenAppCode.getToken(),
                  ficoClvMlxBuilder.getRequestMlx(
                      request,customerGetResponse,
                      guarantorGetResponse, commonResponse, exchangeRate))
              .doOnError(error -> log.error("Error MLX : " + error.getLocalizedMessage()))
              .toObservable()
              .distinct()
              .flatMap(mlx -> dmResponse(
                    errorHandlerBuilder.validateStatusCode(
                        mlx.body(),
                        mlx.code(),
                        Constantes.ERROR_TYPE_FICO_MLX,
                        String.valueOf(mlx.errorBody())), request,
                           customerGetResponse,
                           tokenAppCode, spreadComercialAndBlackList)));

    } else {
      //existe lista negra
      return commonTransferRatesObservable
          .flatMap(commonResponse1 ->
                       dmResponse(null, request,
                                   customerGetResponse,
                                  tokenAppCode, spreadComercialAndBlackList));
    }

  }

  /**
   * Method dmResponse
   *
   * @version 1.0
   */
  @Override
  public Observable<PricingWholesaleResponse> dmResponse(
      MlxResponse mlx,
      Request request,

      CustomerGetResponse alexandriaResponse1,
      TokenAppcodeDto tokenAppCode,
      SpreadComercialAndBlackList spreadComercialAndBlackList) {

    return ficoDmApi
        .executeProcessFicoDmUsingPost(
            tokenAppCode.getToken(),
            ficoDmBuilder.getRequestInput(
                request,
                alexandriaResponse1,
                mlx,
                tokenAppCode.getAppCode(),
                spreadComercialAndBlackList))
        .toObservable()
        .distinct()
        .doOnError(error -> log.error("Error DM : "  + error.getLocalizedMessage()))
        .flatMap(dmResponse -> saveData(request,dmResponse,alexandriaResponse1));

  }

  /**
   * Method getResponseFinal
   *
   * @version 1.0
   */
  @Override
  public Observable<PricingWholesaleResponse> getResponseFinal(
      PricingWholesaleResponse response,
      CreditInfoCpResponse infoCpResponse) {
    response.setQuotationId(infoCpResponse.getCreditInfoCpResId());
    return Observable.just(response);
  }

  /**
   * Method saveData
   *
   * @version 1.0
   */
  @Override
  public Observable<PricingWholesaleResponse> saveData(
      Request request,
      Response<DmResponse>  dmResponse,
      CustomerGetResponse alexandriaResponse1) {
    PricingWholesaleResponse finalResponse =
        wholsaleBuilder.getResponse(
            request,
            errorHandlerBuilder
                .validateStatusCode(
                    dmResponse.body(), dmResponse.code(),
                    Constantes.ERROR_TYPE_FICO_DM,
                    String.valueOf(dmResponse.errorBody())));

    return Observable.fromCallable(() -> creditInfoCpRequestRepository
            .save(RequestBuilder.generateDbObjectRequest(request)))
            .flatMap(creditInfoCpRequest -> {
              Integer reqId = creditInfoCpRequest.getCreditInfoCpReqId();

              if (CollectionUtils.isNotEmpty(
                  request.getCreditInfo().getSpecificCreditLinesWarranties())) {
                specificClWarrantiesReqRepository.saveAll(
                    specificBuilder.generateDbObjectSpecific(reqId, request));
              }
              if (CollectionUtils.isNotEmpty(request.getCreditInfo().getWarranties())) {
                warrantiesReqRepository.saveAll(
                    warrantyBuilder.generateDbObjectWarranty(reqId,request));
              }

              if (CollectionUtils.isNotEmpty(
                  dmResponse.body().getNoRevPayload().getPayloadOutput().getExcepciones())) {
                exceptionRoleRepository.saveAll(
                    ResponseBuilder.generateDbObjectExceptionRole(reqId, finalResponse));
              }

              if (CollectionUtils.isNotEmpty(alexandriaResponse1.getGuarantees())) {

                guaranteeAlexandriaRepository.saveAll(
                    ResponseBuilder.generateDbObjectGuarantee(
                        reqId, alexandriaResponse1.getGuarantees()));
              }

              CreditInfoCpResponse creditInfoCpResponse = creditInfoCpResponseRepository
                  .save(ResponseBuilder.generateDbObjectResponse(
                      reqId, finalResponse, alexandriaResponse1));

              return getResponseFinal(finalResponse, creditInfoCpResponse);


            });

  }

}