from pathlib import Path
from numpy import clip, power, sqrt
from pandas import read_csv
# import modin.pandas as pd
import pyme_engine.wtp_pyme.wtp_engine.utils_wtp as wtp
from threading import Thread

# import warnings
# warnings.simplefilter("ignore")
class SetPath:
    def __init__(self, path='wtp_pyme\pyme_engine'):
        self.data_frame_loaded={}
        self.path = path
        self.hyperparams = None
        self.set_path_wtp()

    def set_path_wtp(self):
        files = ["num_imputing","num_transform","num_transform","num_capping",
                "num_standarization","dem_betas","efect_betas","pct_betas"]
        parent_path =  f"{Path(__file__).resolve().parent}/data/"
        
        def read_data(file):
            data = None
            final_path = f"{parent_path}{file}.csv"
            if Path(final_path).exists():
                data = read_csv(final_path)

            self.data_frame_loaded[file] = data
        
        # threads = []
        # def start_threads(file_name):
        #     th = Thread(target=read_data, args=(file_name,))
        #     threads.append(th)
        #     th.start()
        [read_data(file) for file in files]
        # [t.join() for t in threads]
        
        # param_model_dt = wtp.read_pickle(f"{Path(__file__).resolve().parent}/data/decision_tree.pkl")
        
        self.hyperparams = {
            # 'param_model_dt': param_model_dt,
            'param_num_imp': self.data_frame_loaded['num_imputing'],
            'param_num_transform':self.data_frame_loaded['num_transform'],
            'param_num_capping':self.data_frame_loaded['num_capping'],
            'param_num_standarization':self.data_frame_loaded['num_standarization'],
            'param_dem_betas':self.data_frame_loaded['dem_betas'],
            'param_efect_betas':self.data_frame_loaded['efect_betas'],
            'param_pct_betas':self.data_frame_loaded['pct_betas']
        }

class WTPEngine():

    def __init__(self, hyperparams=SetPath().hyperparams):
        for key in hyperparams:
            setattr(self, key, hyperparams[key])

    def get_cluster(self, X):
        """ Reducción de dimensionalidad para el cálculo (best practices)
        """

        X_tr = wtp.cluster_transform(X)
        clusters = wtp.cluster_predict(X_tr)

        return clusters

    def transform(self, X):
        """ Return: X_tr en formato largo (escenarios como tabla plana --> hacia abajo)
        >>> X input es del clv
        """

        X.loc[:,'cluster'] = self.get_cluster(X)   

        self.rates = X['tea']
        self.montos = X['montodesembolsadosol']
        self.pd_riesgo = X['pdapplicant_pre']
        self.ing_12 = X.groupby(['cluster'])['ing_ult12m'].transform(lambda x: x.fillna(x.median()))
        self.rcc_sow_pym = X.groupby(['cluster'])['rcc_sow_pym_bcp_prm_u12'].transform(lambda x: x.fillna(x.median()))

        self.X_tr = wtp.preprocessing(X, self.param_num_imp, self.param_num_transform, self.param_num_capping, self.param_num_standarization)

        return self.X_tr

    def get_takeup_rate(self):
        """ Modelo de Demanda
        """
        self.takeup_rate = wtp.tkr_predict(self.X_tr, self.param_dem_betas)

        return self.takeup_rate

    def get_efectividad(self):
        """ Efectividad a nivel de cuentas para cada escenario
        """
        alpha, beta1, beta2  = list(self.param_efect_betas['value'])
        # self.efectividad = clip(alpha + beta1 * (self.rates * self.montos) + beta2 * self.montos, 0, 1) 
        self.efectividad = clip(alpha + beta1 * self.rates + beta2 * self.montos, 0, 1) 

        return self.efectividad

    def get_porcentaje_oferta(self):
        """ Cuánto se toma del crédito para cada escenario
        >>> riesgo: pd pre-covid
        """
        # alpha, beta1, beta2 = list(self.param_pct_betas['value'])
        # self.porc_oferta = clip(alpha + beta2 * power(self.pd_riesgo, 1/4) + beta1 * sqrt(self.montos), 0, 1)

        alpha, beta1, beta2, beta3, beta4 = list(self.param_pct_betas['value'])
        self.porc_oferta = clip(alpha + beta2 * power(self.pd_riesgo, 1/4) + beta1 * sqrt(self.montos) + beta3 * self.ing_12 + beta4 * self.rcc_sow_pym, 0, 1)
        
        
        return self.porc_oferta

    def get_final_rate(self):
        """ Optimizador 1:1 para cada CLIENTE (Reducción de dimensiones)
        """
        self.X_vo, self.X_esc_base, self.X_ind_opt, self.min_value = wtp.van_optimization(self.X_tr, self.takeup_rate, self.efectividad, self.porc_oferta)

        return self.X_vo, self.X_esc_base, self.X_ind_opt, self.min_value


    def get_portfolio_optimization(self):
        """ Returns: Tasa optimizada cumpliendo objetivo de portafolio
        >>> escenarios: Cliente, rates, monto_esperado, van_esperado, tir_esperada
        """
        optimized_rates_portfolio = wtp.port_optimization(self.X_vo, self.min_value)

        return optimized_rates_portfolio

    



