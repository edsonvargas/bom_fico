from numpy import (arange, array, concatenate, copy, divide, exp, indices,
                   isinf, isnan, log, maximum, mean, minimum, multiply, power,
                   repeat, stack, sum, zeros, where)
from pandas import DataFrame, merge, pivot_table, concat

from math import erf,sqrt

def get_np_coefs(df_coefs, df):
    """Completes variable names in a pandas dataframe. Returns a dataframe with coefficients

    Arguments:
    df_coefs -- a pandas dataframe containing only one row with model coefficients. (df_coefs.columns is a subset of df.columns)
    df -- a pandas dataframe from which we take the df.columns values as template to complete coefficients

    Example:
    data = array([[12, 411, 3, 4.4, 5, 10,27 ],
            [14, 430, 4, 6, 5, 10,20 ]])
    columns = [ "x","y", "var1", "var2","var3", "var4","var5"]
    df = DataFrame(data=data, columns=columns)

    data = array([[ 0.1, 0.2,  0.3 ]])
    columns = [ "var1", "var3","var5"]
    df_coefs = DataFrame(data=data, columns=columns)

    completed_coefs = get_np_coefs(df_coefs14, df)

    Which returns:
        x	y	var1	var2	var3	var4	var5	all_coefs
    0	0.0	0.0	0.0	    0.4	    0.0	    0.8	    1.0	    [[0.0, 0.0, 0.0, 0.4, 0.0, 0.8, 1.0]]

    """

    import pandas as pd

    if df.shape[0]>1:
        df2 = DataFrame(data=df_coefs,columns=df.columns)
        df2 = df2.fillna(0)
        if len(df2)==1:
            df2["all_coefs"]=[df2.values]
        else:
            df2["all_coefs"]=[[value] for value in df2.values]
        return df2
    else:        
        coef_list = [df_coefs[var_name].values[0] if (var_name in df_coefs.columns ) else 0 for var_name in df.columns]
        coef_list = array(coef_list).reshape(1, -1)
        
        return coef_list


def transf_3esc(X, limite):
    """ Transforma los NaN en 0 y le aplica una cota a "x", la cota superior está determinada por límite
        Arguments:
        x -- x es un escalar
        limite -- limite es un escalar
    """
    X = X.copy()
    X = X.fillna(0)
    value = minimum(X, limite)
    return value


def transf_mtoingr(X):
    """ Calcula el ratio de desembolso vs Ingreso con las variables de x

        Arguments:
        x -- x es un DataFrame
    """
    ingreso, desembolso = X["MTOMEJORINGRESOAJUSTADOSOL"].values, X["DESEMBOLSO"].values
    moneda, tc = X["CODMONEDA"].values, X["TIPOCAMBIO"].values

    mtoTransformado = where(moneda == "SOLES", desembolso, desembolso*tc)
    ratio = divide(mtoTransformado, ingreso)
    ratio[isnan(ratio)] = 6.9

    return ratio


def costo_montoT0(X, param_montoT0):
    X = X.copy()
    df_monto = pivot_table(param_montoT0, index="CANAL", columns=["Bucket Desembolso"], values=["max", "comision"])
    df_monto.columns = df_monto.columns.droplevel()
    df_monto = df_monto.reset_index()
    df_monto.columns = ["CANAL", "val1", "val2", "val3", "val4", "max1", "max2", "max3", "max4"]
    X = merge(X, df_monto, on=["CANAL"], how="left")

    max1 = X["max1"].values
    max2 = X["max2"].values
    max3 = X["max3"].values
    val1 = X["val1"].values
    val2 = X["val2"].values
    val3 = X["val3"].values
    val4 = X["val4"].values
    desembolso = X["Desembolso"].values

    b1 = desembolso < max1
    b2 = (desembolso >= max1) & (desembolso < max2)
    b3 = (desembolso >= max2) & (desembolso < max3)
    b4 = desembolso >= max3

    comisiones = b1 * val1 + b2 * val2 + b3 * val3 + b4 * val4

    return comisiones


def transf_subsegmento(X):
    """ Dummy Transformer if x equals "BEX" or "ENALTA"
    """
    subsegmento = (X.isin(["BEX", "ENALTA"])).astype(int)
    return subsegmento


def transf_niveleducacional1(X):
    niveduc1 = (~X.isin(["TÉCNICO", "TECNICO", "SECUNDARIA", "PRIMARIA"])).astype(int)
    return niveduc1


def transf_enalta_demas(X):
    """ Puts labels ("Enalta" & "Normal")
    """
    segmento = X.reshape(-1, 1)
    segmento[segmento != "ENALTA"] = "Normal"
    segmento[segmento == "ENALTA"] = "Enalta"
    return segmento


def ratio_apalancamiento(X):
    """ Calculates leverage ratio given a pandas dataframe

    Arguments:
    x -- Pandas DataFrame cointaining
            -MTOMEJORINGRESOAJUSTADOSOL, DESEMBOLSO, CODMONEDA, TIPOCAMBIO, MTODEUDATOTAL

    Example:
    data = array([[7500, 10000, "SOLES", 3.48, 500], [2500, 8000, "SOLES", 3.54, 600]])
    columns = ["MTOMEJORINGRESOAJUSTADOSOL", "DESEMBOLSO", "CODMONEDA, "TIPOCAMBIO","MTODEUDATOTAL"]
    df = DataFrame(data=data, columns=columns)

    df.loc[:, "LeverageRatio"] = ratio_apalancamiento(X)

    Which returns:
        MTOMEJORINGRESOAJUSTADOSOL DESEMBOLSO CODMONEDA TIPOCAMBIO MTODEUDATOTAL LeverageRatio
    0                         7500      10000     SOLES       3.48           500        0.7143
    1                         2500       8000     SOLES       3.54           300        0.3012

    """
    X = X.copy()
    ingreso = X["MTOMEJORINGRESOAJUSTADOSOL"].values
    desembolso = X["DESEMBOLSO"].values
    moneda = X["CODMONEDA"].values
    tc = X["TIPOCAMBIO"].values
    deuda_sf = X["MTODEUDA_TOTAL"].values

    mto_transformado = where(moneda == "SOLES", desembolso, desembolso*tc)
    ratio_apalancamiento = divide(ingreso, mto_transformado + deuda_sf)

    return ratio_apalancamiento

def ajuste_pdcalibrada(X, param_PDCal):
    """ Ajuste pdcalibrada a usarse en el Suma Producto Primera de la curva de Prepagos """

    X["pdcalibradaAJUSTE"] = X["pd_12_temporal"]  # Por default la pd ajustada es la misma pd calibrada

    if any((X["T"] == 48) & (X["Score"] < 360)):  # Ajuste plazo 48
        valor_ajuste_48 = param_PDCal[(param_PDCal["T"] == 48) & (param_PDCal["Score"] == 360)]["pd_12_temporal"].values[0]
        X.loc[(X["T"] == 48) & (X["Score"] < 360), "pdcalibradaAJUSTE"] = valor_ajuste_48
    if any((X["T"] == 60) & (X["Score"] < 460)):  # Ajuste plazo 60
        valor_ajuste_60 = param_PDCal[(param_PDCal["T"] == 60) & (param_PDCal["Score"] == 460)]["pd_12_temporal"].values[0]
        X.loc[(X["T"] == 60) & (X["Score"] < 460), "pdcalibradaAJUSTE"] = valor_ajuste_60

    return X["pdcalibradaAJUSTE"]

def ajuste_pdcalibrada_old(X, param_PD):
    """ Ajuste pdcalibrada a usarse en el Suma Producto Primera de la curva de Prepagos

    Arguments:
    - x: dataframe with at least T and sc_nue_app_cef as columns
    - param_PD: dataframe with at least T, Score and pdcalibrada as columns

    Example:
    >> df.loc[; "pdcalibradaAJUSTE"] = ajuste_pdcalibrada(x, para_PD)
    """
    d1 = (X["T"] == 60) & (X["Score"] < 460)
    d2 = (X["T"] == 48) & (X["Score"] < 360)
    Y = merge(X[["Score", "T"]], param_PD[["T", "Score", "pdcalibrada"]], left_on=[
                 "T", "Score"], right_on=["T", "Score"], how="left")["pdcalibrada"]
    
    d1_ = param_PD[(param_PD["T"] == 60) & (param_PD["Score"] == 460)]["pdcalibrada"]
    d2_ = param_PD[(param_PD["T"] == 48) & (param_PD["Score"] == 360)]["pdcalibrada"]

    # Y[d1],Y[d2] =0,0
    if len(d1_)>0:
        Y[d1] = d1_.values[0]
    if len(d2_)>0:
        Y[d2] = d2_.values[0]

    return Y


def transf_flag_pdh(X):
    b1 = X == "NO"
    X[b1] = 0
    X[~b1] = 1
    return X


def can_transform(X, param_PDCal, param_GroupPD, param_Enalta, param_factor):
    """
    Returns a pandas dataframe with transformed variables

    Arguments:
    X -- A pandas dataframe containing the variables used to build the cancelation curve

    Example:
    >> curve = CurveCan()
    >> df_transformed = curve.transform(X)

    Which returns: a pandas dataframe
    """

    X = X[["MTODEUDA_TOTAL", "NIVELEDUCACIONAL", "FLG_PDH", "PLAZO", "SUBSEGMENTO", "MTOMEJORINGRESOAJUSTADOSOL", "DESEMBOLSO",
    "CODMONEDA", "TIPOCAMBIO", "SCORE", "TCAMBIO", "TEA"]].copy()

    X["MTODEUDA_TOTAL"].fillna(0, inplace=True)

    X["niveleducacional3"] = where(X["NIVELEDUCACIONAL"].isin(["TECNICO", "TÉCNICO"]), 1, 0)
    X["flgpdh1"] = (X["FLG_PDH"].values == "SI").astype(int)
    X["plazo2"] = (X["PLAZO"].values == 24).astype(int)
    X["plazo5"] = (X["PLAZO"].values == 60).astype(int)

    log_val = log(X["DESEMBOLSO"].values)
    log_val[isinf(log_val)] = 0
    X["log_mtodesembolso"] = log_val

    X["niveleducacional1"] = where(~X["NIVELEDUCACIONAL"].isin(["TÉCNICO", "TECNICO", "SECUNDARIA", "PRIMARIA"]), 1, 0)
    X["subsegmentonew1"] = where(X["SUBSEGMENTO"].isin(["BEX", "ENALTA"]), 1, 0)
    X["ratioapalancamiento"] = ratio_apalancamiento(X[["MTOMEJORINGRESOAJUSTADOSOL", "DESEMBOLSO", "CODMONEDA", "TIPOCAMBIO", "MTODEUDA_TOTAL"]])

    X.rename(
        columns={
            "SCORE": "Score",
            "TCAMBIO": "tcambio",
            "MTOMEJORINGRESOAJUSTADOSOL": "mtoingreso",
            # "PLAZO": "T",
            "SUBSEGMENTO": "SegFactor"
        },
        inplace=True
    )

 # Plazo mask para los cruces de params
    X.loc[:, "T"] = where(
        X["PLAZO"] <= 12, 12, where(X["PLAZO"] <= 24, 24, where(X["PLAZO"] <= 36, 36, where(X["PLAZO"] <= 48, 48, 60))))

    param_PDCal = param_PDCal.set_index(["T", "Score"])
    X = X.merge(param_PDCal, left_on=["T", "Score"], right_on=["T", "Score"], how="left")  # pdcalibrada
	
    X["spread"] = X["TEA"] - X["pd_12_temporal"]

    df_temp = param_GroupPD[["T", "min", "group_PD"]][param_GroupPD["group_PD"] == "PD1"][["T", "min"]]
    df_temp = df_temp.set_index("T")
    X = X.merge(df_temp, on="T", how="left")  # GroupPD

    X["mtoingresox2"] = ((X["mtoingreso"] >= 2600) & (X["mtoingreso"] < 3800)).astype(int)
    X["mtoingresox3"] = ((X["mtoingreso"] >= 3800) & (X["mtoingreso"] < 5000)).astype(int)
    X["mtoingresox6"] = (X["mtoingreso"] >= 5000).astype(int)

    df_temp = param_Enalta[["SegFactor", "T", "Cancelaciones"]]
    df_temp = df_temp.set_index(["SegFactor", "T"])
    X = X.merge(df_temp, left_on=["SegFactor", "T"], right_on=["SegFactor", "T"], how="left", right_index=True)  # Factor Enalta para Cancelaciones

    X["Cancelaciones"] = X["Cancelaciones"].fillna(1)  # Factor Enalta para Cancelaciones
    X = merge(X.set_index(["SegFactor", "T"]),
        param_factor[["SegFactor", "T", "f_can"]].set_index(["SegFactor", "T"]), 
        on=["SegFactor", "T"], how="left").reset_index()
    
    X = X[["niveleducacional3", "flgpdh1", "plazo2", "plazo5", "log_mtodesembolso",
           "tcambio", "T", "Score", "niveleducacional1", "subsegmentonew1",
           "ratioapalancamiento", "pd_12_temporal", "spread",
           "mtoingresox2", "mtoingresox3", "mtoingresox6", "Cancelaciones",'f_can','TEA']]

    return X


def can_predict(X, param_T, param_Tt, impacto=1):
    """
    Returns a pandas dataframe with one additional column called "curve" (Cancelation Curve)

    Arguments:
    X -- a pandas dataframe cointaining transformed variables used to build the cancelation curve

    Example:
    >> curve = CurveCan()
    >> df_transformed = curve.predict(X)
    >> df_curves = curve.predict(df_transformed)

    Which returns:
            curve
    0    [[0.0, 0.0, 0.03, 0.07, 0.09, 0.2, 0.4]]
    1    [[0.0, 0.0, 0.03, 0.04, 0.09, 0.1, 0.2]]
    2    [[0.0, 0.0, 0.05, 0.6, 0.08, 0.09, 0.1]]
    """
    X = X.copy()
    #CORRIGIENDO
    X['spread'] = X['TEA'] - X['pd_12_temporal']
    X.drop(columns=["TEA"], inplace=True)

    factores_can = array(X['f_can'])
    # Paso1: Crear lista de los diferentes plazos en el input de coeficientes
    df_param_T = DataFrame(param_T)
    plazo_list = df_param_T["T"].values.tolist()
    # Paso2: Crear diccionario de los coeficientes por plazo
    # dict_coefs = dict()
    if X.shape[0] > 1:
        
        # PROCESS FOR SEVERAL RECORDS
        # for plazo in plazo_list:
        #     dict_coefs["coefs" + str(plazo)] = df_param_T[df_param_T["T"]
        #                                                   == plazo].drop(columns=["T"])
        # # Paso3: Consolidar en una lista los coeficientes por cada plazo
        # df_list = []
        # for plazo in plazo_list:
        #     df_param_T = get_np_coefs(dict_coefs["coefs" + str(plazo)], X)
        #     df_param_T["joinvar"] = plazo
        #     df_list.append(df_param_T)

        modelos = df_param_T.drop(columns=["T"])
        df_list = get_np_coefs(modelos, X)
        df_list["joinvar"] = plazo_list


        

        df_Param_T_all = df_list# concat(df_list, ignore_index=True)
        # Paso4: Agregando la lista consolidada de coeficientes a la matriz de
        # variables X
        X_2 = merge(X,
                    df_Param_T_all[["all_coefs",
                                    "joinvar"]],
                    left_on="T",
                    right_on="joinvar",
                    how="left")
        # Paso5: Creando una lista con los nombres de las variables X
        total_columns = X.columns.tolist()
        # Paso6: Calculando la suma del producto de coeficientes y variables
        B = concatenate(X_2["all_coefs"].values)
        Xdata = X_2[total_columns].values
        X_2["suma_producto"] = sum(B * Xdata, axis=1)
        # END OF PROCESS FOR SEVERAL RECORDS, RETURNS X_2
    else:

        # PROCESS FOR 1 RECORD
        dict_coefs = df_param_T[df_param_T['T'] == X['T'][0]].drop(columns=['T'])
        # Paso3: Consolidar en una lista los coeficientes por cada plazo
        B = get_np_coefs(dict_coefs, X)

        # Paso4: Creando una lista con los nombres de las variables X
        total_columns = X.columns.tolist()
        # Paso6: Calculando la suma del producto de coeficientes y variables
        Xdata = X[total_columns].values
        X["suma_producto"] = sum(B * Xdata, axis=1)
        X_2 = X.copy()
        # END OF PROCESS FOR 1 RECORD, RETURNS X_2

    # Paso7 calculando la curva de cancelaciones
    merged = merge(X[["T"]], param_Tt, left_on="T", right_on="T", how="left")
    X_2["sh_t"] = merged["sh_t"]

    # Creando la curva
    T_ajustado = X["T"].values.reshape(-1, 1) - 2
    fact1 = array(X_2["sh_t"].values.tolist())  # shape (m,60)
    fact2 = X_2["suma_producto"].values.reshape(-1, 1)  # shape (m,1)
    fact3 = X_2["Cancelaciones"].values.reshape(-1, 1)
    curve = (1 - exp(-fact1 * exp(fact2))) * fact3
    rows, columns = indices((curve.shape[0], curve.shape[1]))
    mask_value = sum((columns == T_ajustado) * curve, axis=1).reshape(-1, 1)
    curve = (columns < T_ajustado) * curve + (columns >= T_ajustado) * mask_value

    curve = curve * impacto
    X["curve"] = curve.tolist()

    return X["curve"].to_frame(), factores_can


def can_update_r(X, r):
    """
    Update values (according to a new TEA) for new CAN curve. CAN Curve"s dependency on TEA

    Arguments:
    - X --> X transformado (para que encuentre pd calibrada)
    - r --> array of TEA como variable de control

    Example:
    >> curve = CurveCan()
    >> df_transformed = curve.predict(X)
    >> df_curves_update_r = curve.update_r(df_transformed)

    Which returns: A pandas dataframe with the updated values
    """
    X = X.copy()
    X["TEA"] = r.reshape(-1, 1)
    X["spread"] = X["TEA"].values - X["pd_12_temporal"].values
    return X


def pd_transform(X):
    """
    Returns a pandas dataframe with transformed columns added to the dataframe

    Arguments:
    X -- a pandas dataframe containing the variables used to build the pd curve.

    Example:
    >> curve = CurvePD()
    >> X = curve.transform(X)

    Which returns: a pandas dataframe
    """

    X = X[["SCORE", "PLAZO", "SUBSEGMENTO"]].copy()

    X.rename(columns={"SCORE": "score"}, inplace=True)
    X.loc[:, "Segmento"] = where(X["SUBSEGMENTO"].values == "ENALTA", "Enalta", "Normal")
    X.drop(columns=["SUBSEGMENTO"], inplace=True)

    return X

def pd_predict(X, param_scalar, param_T, param_Tt, flag_portafolio):
    """
    Returns a pandas dataframe with one column of name "curve"

    Arguments:
    X -- a pandas dataframe containing the variables used to build the pd curve.

    Example:
    >> curve = CurvePD()
    >> df = curve.predict(X)

    Which returns:

            curve
    0    [[0.0, 0.0, 0.03, 0.07, 0.09, 0.2, 0.4]]
    1    [[0.0, 0.0, 0.03, 0.04, 0.09, 0.1, 0.2]]
    2    [[0.0, 0.0, 0.05, 0.6, 0.08, 0.09, 0.1]]

    """
    X = X.copy()

    # Plazo mask para los cruces de params
    X.loc[:, "T"] = where(
        X["PLAZO"] <= 12, 12, where(X["PLAZO"] <= 18, 18, 
                                    where(X["PLAZO"] <= 24, 24, 
                                    where(X["PLAZO"] <= 36, 36, 
                                          where(X["PLAZO"] <= 48, 48, 60)))))

    # Proceso
    offset = param_scalar[param_scalar["param"] == "offset"]["value"].values[0]
    factor = param_scalar[param_scalar["param"] == "factor"]["value"].values[0]
    score = X["score"].values
    
    xBeta = - (score - offset) / factor

    X = X.merge(param_T, how="left", on=["T", "Segmento"])
    alpha = X[ "alpha"].values
    beta = X[ "beta"].values
    xBetaCalibrado = alpha + beta * xBeta

    param_Tt_piv_a = param_Tt.pivot(index=["Segmento", "T"], columns="t", values="alpha")
    param_Tt_piv_b = param_Tt.pivot(index=["Segmento", "T"], columns="t", values="beta")

    col_a = param_Tt_piv_a.apply(lambda x: x.values, axis=1)
    col_b = param_Tt_piv_b.apply(lambda x: x.values, axis=1)

    col_a.name, col_b.name = "alpha", "beta"
    col_a, col_b = col_a.reset_index(), col_b.reset_index()

    alpha_t = merge(X[["Segmento","T"]], col_a, on=["Segmento","T"], how="left")["alpha"].values.reshape(1,-1)
    beta_t = merge(X[["Segmento","T"]], col_b, on=["Segmento","T"], how="left")["beta"].values.reshape(1,-1)
    alpha_t = concatenate(alpha_t.tolist(), axis=0)
    beta_t = concatenate(beta_t.tolist(), axis=0)

    valueT = -1 * (alpha_t + beta_t * xBetaCalibrado.reshape(-1, 1))
    
    pdTemporal = 1 / (1 + exp(valueT))
 
    columns = indices((pdTemporal.shape[0], pdTemporal.shape[1]))[1]
    zeros1 = zeros((columns.shape[0], columns.shape[1]))

    # ## Quitando efecto covid
    curve = pdTemporal.copy()

    # Plazo real del desembolso
    T = X["PLAZO"].values.reshape(-1, 1)

    # Valor que se repite desde el plazo del desembolso hasta 60
    mask_value = sum((columns == T)*curve, axis=1).reshape(-1, 1)

    if flag_portafolio == False:
        # En originacion el default solo puede existir a partir del segundo periodo (por definición)
        curve = (columns < 3)*zeros1 + ((columns < T + 1) & (columns >= 3))*curve + (columns >= T + 1)*mask_value
        curve = curve[:, 1:]
    else:
        # Flag portafolio = True
        # En portafolio se permite que el default pueda existir desde el primer periodo
        curve =  (columns < T + 1)*curve + (columns >= T + 1)*mask_value
        curve = curve[:, 1:]

    X["curve"] = curve.tolist()

    pd_12_temporal = curve[:,11]


    return X["curve"].to_frame(), pd_12_temporal


def pre_transform(X, param_PDCal, param_GroupPD, param_Enalta, param_factor):
    """
    Returns a pandas dataframe with transformed variables

    Arguments:
    X -- A pandas dataframe containing the variables used to build the prepayment curve

    Example:
    >> curve = CurvePre()
    >> df_transformed = curve.transform(X)

    Which returns: a pandas dataframe
    """
    X = X[["MTODEUDA_TOTAL", "FLG_PDH", "DESEMBOLSO", "SUBSEGMENTO", "MTOMEJORINGRESOAJUSTADOSOL", "CODMONEDA",
           "TIPOCAMBIO", "SCORE", "PLAZO", "TEA"]].copy()

    X["MTODEUDA_TOTAL"].fillna(0, inplace=True)

    X["flgpdh1cate"] = (X["FLG_PDH"].values == "SI").astype(int)
    X["cosecha4"] = 1
    X["4cumaratioprepago4"] = 1

    LogTransformationList = [
        ("log_mtodesembolsadosol", "DESEMBOLSO"), ("log_mtodeuda_total", "MTODEUDA_TOTAL")]

    for coef, variable in LogTransformationList:
        log_value = log(X[variable])
        log_value[isinf(log_value)] = 0
        X[coef] = log_value

    X["subsegmento"] = where(X["SUBSEGMENTO"].isin(["BEX", "ENALTA"]), 1, 0)
    X["ratioapalancamiento"] = ratio_apalancamiento(
        X[["MTOMEJORINGRESOAJUSTADOSOL", "DESEMBOLSO", "CODMONEDA", "TIPOCAMBIO", "MTODEUDA_TOTAL"]])

    X.rename(
        columns={
            "SCORE": "sc_nue_app_cef",
            # "PLAZO": "T",
            "SUBSEGMENTO": "SegFactor"
        },
        inplace=True
    )
    X["Score"] = X["sc_nue_app_cef"].values
    
    # Plazo mask para los cruces de params
    X.loc[:, "T"] = where(
        X["PLAZO"] <=12, 12, where(X["PLAZO"] <= 24, 24, where(X["PLAZO"] <= 36, 36, where(X["PLAZO"] <= 48, 48, 60))))
    # Otros tipos de transformación    
    X = X.merge(param_PDCal, on=["T", "Score"], how="left")  # PD Calibrada
    X = X.merge(param_GroupPD[["T", "min", "group_PD"]][param_GroupPD["group_PD"] == "PD1"][["T", "min"]], on="T", how="left")  # Group PD    
    X = X.merge(param_Enalta[["SegFactor", "T", "Prepagos"]], on=["SegFactor", "T"],how="left")  # Factor Enalta para Prepagos

    X["spread"] = X["TEA"] - X["pd_12_temporal"]
    X["PD1"] = (X["min"] <= X["Score"]).astype(int)  # PD 1
    X["PD2"] = (X["min"] > X["Score"]).astype(int)  # PD2 - Ratio Apalancamiento --v
    X["Prepagos"] = X["Prepagos"].fillna(1)  # Factor Enalta para Prepagos
    
    X["pdcalibradaAJUSTE"] = ajuste_pdcalibrada(X, param_PDCal)
    ind = (X["T"] == 60) | (X["T"] == 48)
    X["spreadAJUSTE"] = ind * (X["TEA"] - X["pdcalibradaAJUSTE"]) + (1 - ind) * X["spread"]
    X["_cons"] = 1  # Constante
    X = X.merge(param_factor[["SegFactor", "T", "f_pre"]], on=["SegFactor", "T"], how="left")

    X = X[['flgpdh1cate', 'cosecha4', '4cumaratioprepago4',
           'log_mtodesembolsadosol', 'log_mtodeuda_total',
            'T', 'Score',
           'subsegmento', 'pd_12_temporal', 'spread', 'PD1',
           'PD2', 'ratioapalancamiento', 'Prepagos', 'pdcalibradaAJUSTE',
           'spreadAJUSTE', '_cons', "f_pre", "TEA"]]

    return X


def pre_predict(X, param_Primera, param_Logit, param_MCO, param_PDCal, impacto=1, pre_cache_values={}):
    """
    Returns a pandas dataframe with one additional column called "curve" (Prepayment Curve)

    Arguments:
    X -- a pandas dataframe cointaining transformed variables used to build the prepayment curve

    Example:
    >> curve = CurvePre()    >> df_transformed = curve.predict(X)
    >> df_curves = curve.predict(df_transformed)

    Which returns:
            curve
    0    [[0.0, 0.0, 0.03, 0.07, 0.09, 0.2, 0.4]]
    1    [[0.0, 0.0, 0.03, 0.04, 0.09, 0.1, 0.2]]
    2    [[0.0, 0.0, 0.05, 0.6, 0.08, 0.09, 0.1]]
    """
    X = X.copy()
    factores_pre = array(X['f_pre'])
    #CORRIGIENDO
    X["spread"] = X["TEA"] - X["pd_12_temporal"]
    X["pdcalibradaAJUSTE"] = ajuste_pdcalibrada(X[["T", "Score", "pd_12_temporal"]], param_PDCal)  # Ajuste PD Calibrada
    X["spreadAJUSTE"]  = where(X["T"].isin([48, 60]), X["TEA"] - X["pdcalibradaAJUSTE"], X["spread"])  # Ajuste Spread
    X.drop(columns=["TEA"], inplace=True)
    #CORRIGIENDO_FIN

    X_2 = X.copy()
    # Getting coefficients in the same order as the df of transformed variables
    if len(pre_cache_values)==0:
        param_cumaratio = param_Primera[["4cumaratioprepago4"]].copy()
        param_demas = param_Primera[['cosecha4',
                                    'log_mtodesembolsadosol', 'spreadAJUSTE', 'flgpdh1cate',
                                    'pdcalibradaAJUSTE', 'ratioapalancamiento', '_cons', 'T']].copy()

        param_cumaratio["T"],param_demas["T"]=param_Primera["T"].values, param_Primera["T"].values
        dictionary_list = [(param_Logit, "Logit")
                            , (param_MCO, "MCO")
                            , (param_cumaratio, "CumaRatio")
                            , (param_demas, "Demas")]

        pre_cache_values["dictionary_list"]=dictionary_list
        pre_cache_values['total_columns']=X.columns.tolist()
        
        if X.shape[0] > 1:
            for tipo_modelo, nombre in dictionary_list:
                dict_coef_ = tipo_modelo.drop(columns="T")
                df_param_Logit_all = get_np_coefs(dict_coef_,X)            
                df_param_Logit_all['T']=tipo_modelo['T']
                df_param_Logit_all.set_index('T',inplace=True)
                
                pre_cache_values[f'SP_{nombre}']=df_param_Logit_all
    
    total_columns = pre_cache_values['total_columns']
    
    if X.shape[0] > 1:
        # PROCESS FOR SEVERAL RECORDS        
        def sub_for_pre_predict_more( nombre):
                 
            
            # B = concat_arrays(X_complete["all_coefs"].values)
            if f'B_{nombre}' not in pre_cache_values:
                df_param_Logit_all = pre_cache_values[f'SP_{nombre}']            
                X_complete = merge(X,df_param_Logit_all["all_coefs"], on='T', how='left')
                B = concatenate(X_complete["all_coefs"].values)
                pre_cache_values[f'B_{nombre}']=B
                
            B =  pre_cache_values[f'B_{nombre}']                
            
            Xdata = X[total_columns].values
            X_2["SP_" + nombre] = sum(B * Xdata, axis=1)
        
        [sub_for_pre_predict_more(nombre) for _, nombre in pre_cache_values["dictionary_list"]]
        X_2 = X_2.merge(param_Primera[["L1", "L2", "T"]], on="T", how="left")
        # END OF PROCESS FOR SEVERAL RECORDS, RETURNS X_2
    else:
        # PROCESS FOR 1 RECORD
        def sub_for_pre_predict(tipo_modelo, nombre):
            dict_coefs = tipo_modelo[tipo_modelo['T'] == X['T'][0]].drop(columns=['T'])
            B = get_np_coefs(dict_coefs, X)
            Xdata = X_2[X.columns.tolist()].values
            X_2["SP_" + nombre] = sum(B * Xdata, axis=1)
            
        [sub_for_pre_predict(tipo_modelo, nombre) for tipo_modelo, nombre in pre_cache_values["dictionary_list"]]

        df_temp = param_Primera[["L1", "L2", "T"]]
        X_2 = X_2.merge(df_temp, on="T", how="left")
        # END OF PROCESS FOR 1 RECORD, RETURNS X

    Logit = X_2["SP_Logit"].values
    MCO = X_2["SP_MCO"].values
    FEnalta = X_2["Prepagos"].values

    
    value = 1 / (1 + exp(-Logit)) * MCO * FEnalta
    X_2["ValorInicial"] = value
    X_2["Factor1"] = X_2["L1"] + X_2["SP_CumaRatio"]
    X_2["Factor2"] = X_2["L2"]
    X_2["Constante"] = X_2["SP_Demas"]

    
    curves = zeros((X_2.shape[0], 61))
    curves[:, 1] = X_2["ValorInicial"].values

    
    c = X_2["Constante"].values
    b1 = X_2["Factor1"].values
    b2 = X_2["Factor2"].values
    
    
    for ii in range(2, 61):
        curves[:, ii] = c + b1 * curves[:, ii - 1] + b2 * curves[:, ii - 2]
    curves = maximum(curves, 0)
    curves = curves[:, 1:]
    # print(f'bloque 3  {time.time()-start}')

    # Creando la curva
    # start=time.time()
    T = X["T"].values.reshape(-1, 1)
    columns = indices((curves.shape[0], curves.shape[1]))[1]
    mask_value = sum((columns == T - 2) * curves, axis=1).reshape(-1, 1)
    curve = (columns < T - 1) * curves + (columns >= T - 1) * mask_value

    curve = curve * impacto

    X["curve"] = curve.tolist()
    result = X["curve"].to_frame()
    # print(f'bloque 4 {time.time()-start}')

    return result, factores_pre


def pre_update_r(X, r, param_PDCal):
    """
    Prepayment curve with new TEA value. PRE Curve"s dependency on TEA

    Arguments:
    - X --> X transformado (para que encuentre pd calibrada)
    - r --> array of TEA como variable de control

    Example:
    >> curve = CurvePre()
    >> df_transformed = curve.predict(X)
    >> df_curves_update_r = curve.update_r(df_transformed)

    Which returns: A pandas dataframe with the updated values
    """
    
    X = X.copy()
    X["TEA"] = r.reshape(-1, 1)
    X["spread"] = X["TEA"] - X["pd_12_temporal"]
    X["pdcalibradaAJUSTE"] = ajuste_pdcalibrada(X, param_PDCal)
    ind = (X["T"] == 60) | (X["T"] == 48)
    X["spreadAJUSTE"] = ind * (X["TEA"] - X["pdcalibradaAJUSTE"]) + (1 - ind) * X["spread"]
    

    return X


def lgd_transform(X, lgd_Enalta, limit_T):
    """
    Returns a pandas dataframe with transformed variables

    Arguments:
    X -- A pandas dataframe containing the variables used to build the LGD curve

    Example:
    >> curve = CurvePre()
    >> df_transformed = curve.transform(X)

    Which returns: a pandas dataframe
    """
    # Aplicando las transformaciones de utils a las variables de la Curva
    X = X.copy()
    X["pasivos12m"] = transf_3esc(X["FMPASIVO_SUM_12"], limit_T["pasivos12m"][0])
    X["pasivos24m"] = transf_3esc(X["PMPASIVO_MIN_24"], limit_T["pasivos24m"][0])
    X["T_RAT_DESEMB_INGR"] = transf_mtoingr(X)
    X["rat_mto_aprob"] = transf_3esc(X["T_RAT_DESEMB_INGR"], limit_T["rat_mto_aprob"][0])
    X["flg_normal"] = transf_3esc(X["FLG_NORMAL"], limit_T["flg_Normal"][0])
    X["ant_laboral"] = transf_3esc(X["ANT_LABORAL_MESES"], limit_T["ant_laboral"][0])
    X["SegFactor"] = X["SUBSEGMENTO"]
    X = X.merge(lgd_Enalta, on=["SegFactor"], how="left")
    X["alpha"] = X["alpha"].fillna(0)
    X["beta"] = X["beta"].fillna(1)

    # Plazo mask para los cruces de params
    X["PLAZO"] = where(
        X["PLAZO"] <= 12, 12, where(X["PLAZO"] <= 18, 18, where(X["PLAZO"] <= 24, 24, where(X["PLAZO"] <= 36, 36, where(X["PLAZO"] <= 48, 48, 60)))))

    # Seleccionando las variables de interés del set de inputs
    X = X[["PLAZO", "pasivos12m", "flg_normal", "pasivos24m",
           "rat_mto_aprob", "ant_laboral", "alpha", "beta"]]
    X["intercept"] = 1
    X["maturity"] = 1

    return X


def lgd_predict(X, param_T):
    """
    Returns a pandas dataframe with one additional column called "curve" (LGD Curve)

    Arguments:
    X -- a pandas dataframe cointaining transformed variables used to build the LGD curve

    Example:
    >> curve = CurveLGD()
    >> df_transformed = curve.predict(X)
    >> df_curves = curve.predict(df_transformed)

    Which returns:
            curve
    0    [[0.0, 0.0, 0.03, 0.07, 0.09, 0.2, 0.4]]
    1    [[0.0, 0.0, 0.03, 0.04, 0.09, 0.1, 0.2]]
    2    [[0.0, 0.0, 0.05, 0.6, 0.08, 0.09, 0.1]]
    """
    X = X.copy()
    # Paso1: Crear lista de los diferentes plazos en el input de coeficientes
    df_Param_LGD = DataFrame(param_T)

    if X.shape[0] > 1:
        
        plazo_list = df_Param_LGD["PLAZO"].values.tolist()
        # # Paso2: Crear diccionario de los coeficientes por plazo
        # dict_coefs = dict()
        # for plazo in plazo_list:
        #     dict_coefs["coefs" + str(plazo)] = df_Param_LGD[df_Param_LGD["PLAZO"]
        #                                                     == plazo].drop(columns=["PLAZO"])
        # # Paso3: Consolidar en una lista los coeficientes por cada plazo
        # df_list = []
        # for plazo in plazo_list:
        #     df_Param_LGD = get_np_coefs(dict_coefs["coefs" + str(plazo)], X)
        #     df_Param_LGD["joinvar"] = plazo
        #     df_list.append(df_Param_LGD)
        # df_Param_LGD_all = concat(df_list, ignore_index=True)
        modelos = df_Param_LGD.drop(columns=["PLAZO"])
        df_Param_LGD = get_np_coefs(modelos, X)
        df_Param_LGD["joinvar"] = plazo_list
        
        df_Param_LGD_all =df_Param_LGD

        # Paso4: Agregando la lista consolidada de coeficientes a la matriz de
        # variables X
        X_complete = merge(X,
                           df_Param_LGD_all[["all_coefs",
                                             "joinvar",
                                             "maturity"]],
                           left_on="PLAZO",
                           right_on="joinvar",
                           how="left")
        X_complete = X_complete.rename(
            columns={
                "maturity_x": "maturity",
                "maturity_y": "maturity_coef"})
        # Paso5: Creando una lista con los nombres de las variables X
        total_columns = X.columns.tolist()
        # Paso5: Calculando la suma del producto de coeficientes y variables
        B = concatenate(X_complete["all_coefs"].values)
        Xdata = X_complete[total_columns].values
        X_complete["suma_producto"] = sum(B * Xdata, axis=1)

    else:

        # PROCESS FOR 1 RECORD
        # Paso1: Crear array de los coeficientes
        dict_coefs = df_Param_LGD[df_Param_LGD['PLAZO'] == X['PLAZO'][0]].drop(columns=['PLAZO'])

        # Paso3: Consolidar en una lista los coeficientes con ceros donde en las X's que no entran en la ecuacion
        B = get_np_coefs(dict_coefs, X)

        # Paso5: Calculando la suma del producto de coeficientes y variables
        X["suma_producto"] = sum(B * X, axis=1)
        X["maturity_coef"] = dict_coefs['maturity'].values[0]
        X_complete = X.copy()
        # END OF PROCESS FOR 1 RECORD, RETURNS X_complete

    # Paso6: Calculando la curva LGD (intercepto + maturity*t
    # +coeficientes*beta)
    suma_producto = X_complete["suma_producto"].values.reshape(-1, 1)
    maturity_coef = X_complete["maturity_coef"].values.reshape(-1, 1)
    alpha, beta = X_complete["alpha"].values.reshape(-1, 1), X_complete["beta"].values.reshape(-1, 1)
    t = arange(1, 61).reshape(1, -1)
    suma_prod_sm = suma_producto - maturity_coef

    curve = (alpha + multiply((multiply(maturity_coef, t) + suma_prod_sm), beta))
    ## Se descomenta para COVID
    # curve[:,12:24] = curve[:,3:15]
    # curve[:,3:12] = curve[:,2].reshape(-1,1)
    # curve[:,:2] = 0

    lgd21 = curve[:,20]

    X_complete["curve"] = curve.tolist()

    return X_complete["curve"].to_frame(), lgd21.reshape(-1, 1)


def rr1_transform(X, param_GroupPD):
    """
    Returns a pandas dataframe with transformed variables

    Arguments:
    X -- A pandas dataframe containing the variables used to build the RR1 curve

    Example:
    >> curve = CurveRR1()
    >> df_transformed = curve.transform(X)

    Which returns: a pandas dataframe
    """
    X = X[["PLAZO", "SCORE"]].copy()
    X.rename(columns={"SCORE": "Score"}, inplace=True)

    # Plazo mask para los cruces de params
    X.loc[:, "T"] = where(
        X["PLAZO"] <= 12, 12, where(X["PLAZO"] <= 24, 24, where(X["PLAZO"] <= 36, 36, where(X["PLAZO"] <= 48, 48, 60))))

    X = X.merge(param_GroupPD[["T",
                            "min",
                            "group_PD"]][param_GroupPD["group_PD"] == "PD1"][["T",
                                                                                "min"]],
                on="T",
                how="left")
    X["PD1"] = (X["min"] <= X["Score"]).astype(int)
    X["PD2"] = (X["min"] > X["Score"]).astype(int)
    X = X[["T", "Score", "PD1", "PD2"]]

    return X


def rr1_predict(X, param_T1):
    """
    Returns a pandas dataframe with one additional column called "curve" (RR1 Curve)

    Arguments:
    X -- a pandas dataframe cointaining transformed variables used to build the RR1 curve

    Example:
    >> curve = CurveRR1()
    >> df_transformed = curve.predict(X)
    >> df_curves = curve.predict(df_transformed)

    Which returns:
            curve
    0    [[0.0, 0.0, 0.03, 0.07, 0.09, 0.2, 0.4]]
    1    [[0.0, 0.0, 0.03, 0.04, 0.09, 0.1, 0.2]]
    2    [[0.0, 0.0, 0.05, 0.6, 0.08, 0.09, 0.1]]
    """
    X = X.copy()
    X = X[["T", "PD1", "PD2"]].merge(param_T1[["T", "PD1", "PD2", "alpha", "beta"]], on=[
        "T", "PD1", "PD2"], how="left")
    alpha, beta = X["alpha"].values.reshape(-1, 1), X["beta"].values.reshape(-1, 1)
    T = X["T"].values.reshape(-1, 1)
    t = arange(1, 61).reshape(1, -1)
    curve = multiply(alpha, log(t)) + beta

    columns = indices((curve.shape[0], curve.shape[1]))[1]
    mask_valueT = sum((columns == T - 1) * curve, axis=1).reshape(-1, 1)  # Cap en base al T
    curve = (columns < T) * curve + (columns >= T) * mask_valueT
    mask_value = sum((columns == 28) * curve, axis=1).reshape(-1, 1)  # Cap del 29 en adelante
    curve = (columns < 29) * curve + (columns >= 29) * mask_value

    X["curve"] = curve.tolist()

    return X["curve"].to_frame()


def rr2_transform(X, param_GroupPD):
    """
    Returns a pandas dataframe with transformed variables

    Arguments:
    X -- A pandas dataframe containing the variables used to build the RR2 curve

    Example:
    >> curve = CurveRR2()
    >> df_transformed = curve.transform(X)

    Which returns: a pandas dataframe
    """
    X = X[["PLAZO", "SCORE"]].copy()
    X.rename(columns={"SCORE": "Score"}, inplace=True)

    # Plazo mask para los cruces de params
    X.loc[:, "T"] = where(
        X["PLAZO"] <= 12, 12, where(X["PLAZO"] <= 24, 24, where(X["PLAZO"] <= 36, 36, where(X["PLAZO"] <= 48, 48, 60))))

    X = X.merge(param_GroupPD[["T",
                               "min",
                               "group_PD"]][param_GroupPD["group_PD"] == "PD1"][["T",
                                                                                 "min"]],
                on="T",
                how="left")
    X["PD1"] = (X["min"] <= X["Score"]).astype(int)
    X["PD2"] = (X["min"] > X["Score"]).astype(int)

    X = X[["T", "Score", "PD1", "PD2"]]

    return X


def rr2_predict(X, param_T2):
    """
    Returns a pandas dataframe with one additional column called "curve" (RR2 Curve)

    Arguments:
    X -- a pandas dataframe cointaining transformed variables used to build the RR2 curve

    Example:
    >> curve = CurveRR2()
    >> df_transformed = curve.predict(X)
    >> df_curves = curve.predict(df_transformed)

    Which returns:
            curve
    0    [[0.0, 0.0, 0.03, 0.07, 0.09, 0.2, 0.4]]
    1    [[0.0, 0.0, 0.03, 0.04, 0.09, 0.1, 0.2]]
    2    [[0.0, 0.0, 0.05, 0.6, 0.08, 0.09, 0.1]]
    """
    X = X.copy()
    X = X[["T", "PD1", "PD2"]].merge(
        param_T2[["PD1", "PD2", "alpha", "beta"]], on=["PD1", "PD2"], how="left")

    alpha, beta = X["alpha"].values.reshape(-1, 1), X["beta"].values.reshape(-1, 1)
    T = X["T"].values.reshape(-1, 1)
    t = arange(1, 61).reshape(1, -1)
    curve = multiply(alpha, log(t)) + beta

    columns = indices((curve.shape[0], curve.shape[1]))[1]
    mask_value = sum((columns == T - 1) * curve, axis=1).reshape(-1, 1)  # Cap en base al T
    curve = (columns < T) * curve + (columns >= T) * mask_value
    curve = maximum(curve, 0)

    X["curve"] = curve.tolist()

    return X["curve"].to_frame()


def cap_transform(X, param_PDTTC, flag_portafolio=False):
    """
    Returns a pandas dataframe with transformed variables

    Arguments:
    X -- A pandas dataframe containing the variables used to build the CAP curve

    Example:
    >> curve = CurveCAP()
    >> df_transformed = curve.transform(X)

    Which returns: a pandas dataframe
    """
    if flag_portafolio == False:
        X = X[["SEGMENTO", "SCORE"]].copy()
        X.rename(columns={"SEGMENTO": "SegmentoOrtogonal", "SCORE": "Score"}, inplace=True)

        df_pdttc = param_PDTTC.pivot(index="SegmentoOrtogonal", columns=["bucket_PD"], values=["max", "PD_TTC"])
        df_pdttc.columns = df_pdttc.columns.droplevel()
        df_pdttc = df_pdttc.reset_index()
        df_pdttc.columns = ["SegmentoOrtogonal", "max1", "max2", "max3", "max4", "max5", "max6", "val1", "val2", "val3",
                            "val4",
                            "val5", "val6"]
        X = merge(X, df_pdttc, on=["SegmentoOrtogonal"], how="left")

        X.loc[:, "max1":"val6"] = X.loc[:, "max1":"val6"].fillna(0)
        max1 = X["max1"].values
        max2 = X["max2"].values
        max3 = X["max3"].values
        max4 = X["max4"].values
        max5 = X["max5"].values
        val1 = X["val1"].values
        val2 = X["val2"].values
        val3 = X["val3"].values
        val4 = X["val4"].values
        val5 = X["val5"].values
        val6 = X["val6"].values
        score = X["Score"].values

        b1 = score <= max1
        b2 = (score > max1) & (score <= max2)
        b3 = (score > max2) & (score <= max3)
        b4 = (score > max3) & (score <= max4)
        b5 = (score > max4) & (score <= max5)
        b6 = score > max5

        X["PD_TTC"] = b1 * val1 + b2 * val2 + b3 * val3 + b4 * val4 + b5 * val5 + b6 * val6

    else:  
    # Flag portafolio = True
    # Se usa la PD TTC dato y LGD TTC dato para el calculo del capital
        X = X[["PD_TTC", "LGD_TTC"]]    
    
    return X


def cap_predict(X, param_scalar):
    """
    Returns a pandas dataframe with one additional column called "curve" (CAP Curve)

    Arguments:
    X -- a pandas dataframe cointaining transformed variables used to build the CAP curve

    Example:
    >> curve = CurveCAP()
    >> df_transformed = curve.predict(X)
    >> df_curves = curve.predict(df_transformed)

    Which returns:
            curve
    0    [[0.0, 0.0, 0.03, 0.07, 0.09, 0.2, 0.4]]
    1    [[0.0, 0.0, 0.03, 0.04, 0.09, 0.1, 0.2]]
    2    [[0.0, 0.0, 0.05, 0.6, 0.08, 0.09, 0.1]]
    """

    X = X.copy()
    intercept = param_scalar[param_scalar["param"]
                             == "intercept"]["value"].values[0]
    beta_pd = param_scalar[param_scalar["param"] == "pd"]["value"].values[0]
    beta_lgd = param_scalar[param_scalar["param"] == "lgd"]["value"].values[0]
    beta_pd2 = param_scalar[param_scalar["param"] == "pd2"]["value"].values[0]
    beta_lgd2 = param_scalar[param_scalar["param"] == "lgd2"]["value"].values[0]

    factor_pn = param_scalar[param_scalar["param"]
                             == "factor_pn"]["value"].values[0]
    factor_pyg = param_scalar[param_scalar["param"]
                              == "factor_pyg"]["value"].values[0]
    pd_ttc = X["PD_TTC"].values.reshape(-1,1)
    lgd_ttc = X["LGD_TTC"].values.reshape(-1,1)

    curve = repeat(norm_cdf((intercept + beta_pd * pd_ttc + beta_lgd * lgd_ttc + beta_pd2 * power(pd_ttc, 2) + beta_lgd2*power(lgd_ttc, 2)))*factor_pn *factor_pyg, 60).reshape(X.shape[0],60)
    # curve = repeat(norm.cdf((intercept + beta_pd * pd_ttc + beta_lgd * lgd_ttc + beta_pd2 * power(pd_ttc, 2)))*factor_pn *factor_pyg, 60).reshape(X.shape[0],60)
    X["curve"] = curve.tolist()

    return X["curve"].to_frame()


def costos_transform(X, param_canalT0, param_montoT0, param_otrosT0, param_costost, flag_portafolio):

    X = X.copy() 
    
    # 1. Costos T0
    X = X.merge(param_canalT0, on=["CANAL"], how="left")  # Costos FFVV (por canal)
    	
    #CORRIGIENDO
    cost_ponderado = param_canalT0[param_canalT0.CANAL=='PONDERADO']['costos_FFVV']
    X['costos_FFVV'] = where(X.costos_FFVV.isna(), cost_ponderado ,X.costos_FFVV)
    #CORRIGIENDO_FIN

    X.rename(columns={"DESEMBOLSO": "Desembolso"}, inplace=True)
    X["costos_ventas"] = costo_montoT0(X, param_montoT0) * X["Desembolso"]  # Costos de Ventas
    X[param_otrosT0.columns] = param_otrosT0.values[0]  # Costos Credito Bca Minorista

    # 2. Costos para todo t != 0
    X[param_costost.columns] = param_costost.values[0]

    # Creando una única curva según lo que vaya a multiplicar
    #CORRIGIENDO
    X["costos_B_m_D"] = X["costos_adm_saldo"] + X["costos_mantSBS_saldo"] + \
        X["costos_indirectos_saldo"] + X["costos_twow_saldo"]
    X["costos_CH"] = X["costos_adm_unidades"] + X["costos_transaccionales_unidades"]
    #CORRIGIENDO_FIN
    
    # X["costos_B_m_D"] = X["costos_mantSBS"]
    # X["costos_CH"] = X["costos_adm"] + X["costos_procesos_op"] + \
    #                  X["costos_transaccionales"] + X["costos_publicidad"] + \
    #                  X["costos_otros"] + X["costos_indirectos"]

    # Reporte
    fact_costos_lifetime = X[["costos_cob_1_30", "costos_cob_31_60", "costos_B_m_D", "costos_CH"]]
    fact_costos_t_0 = X[["costos_FFVV", "costos_ventas", "costos_bca_min", "publicidad_T0"]]

    # Ajuste al costo en t=0 si se ejecuta en modo portafolio
    if flag_portafolio == True:
        # Se asume que el costo en t=0 se reparte entre los periodos de vida del credito,
        # por lo tanto, se ajusta (reduciendo el costo) con la proporcion de periodos restantes
        factor_de_ajuste = X["PLAZO"] / X["PLAZO_ORIGINAL"]
        fact_costos_t_0 = fact_costos_t_0 * factor_de_ajuste

    return fact_costos_lifetime, fact_costos_t_0


def inof_transform(X, param_pmoneda, param_psegmento, param_seguros):
    X = X.copy()

    # 1. Portes --> Se aplica a las cuentas hábiles (1-PD-Can)
    X = X.merge(param_pmoneda, on=["CODMONEDA"], how="left")  # Porte moneda
    X = X.merge(param_psegmento, on=["SUBSEGMENTO"], how="left")  # Porte segmento
    X["portes"] = X["porte_moneda"] * X["porte_segmento"]
    X = X.drop(columns=["porte_moneda", "porte_segmento"])

    # 2. Seguros --> Se aplica a B_m_D
    X["seguros"] = param_seguros.values[0][0]

    inof_tr = X.loc[:, "portes":"seguros"]

    return inof_tr


def tt_desc_transform(X, param_tasadescuento_tmin, param_tasadescuento_leads, 
                      param_tt_prepago, param_tt_factor, param_remcap, param_indicator_target,
                      param_educated_guess=None):

    X = X.copy()    

    ## Calculo TT Zero Cupon
    # Plazo mask para los cruces de params
    X.loc[:, "PLAZO"] = where(
        X["PLAZO"] <= 12, 12, where(X["PLAZO"] <= 18, 18, where(X["PLAZO"] <= 24, 24, where(X["PLAZO"] <= 36, 36, where(X["PLAZO"] <= 48, 48, 60)))))

    # >> Prepago RDM
    # param_tt_prepagos_piv = pivot_table(param_tt_prepago, index=["SUBSEGMENTO", "PLAZO"], columns="t", values="prepagoRDM")
    param_tt_prepagos_piv = pivot_table(param_tt_prepago, index=["MESAPERTURA","SUBSEGMENTO", "PLAZO"], columns="t", values="prepagoRDM")
    col = param_tt_prepagos_piv.apply(lambda x: x.values, axis=1)
    col.name = "prepagoRDM"
    col = col.reset_index()
    # X = merge(X, col, on=["SUBSEGMENTO", "PLAZO"], how="left")
    X = merge(X, col, on=["MESAPERTURA","SUBSEGMENTO", "PLAZO"], how="left")
    
    # >> Factor TT
    # X["tt_fact"] = [param_tt_factor["tt_fact"].values] * X.shape[0]
    param_tt_fact_piv = param_tt_factor.pivot(index=["MESAPERTURA"], columns="t", values="tt_fact")
    col2 = param_tt_fact_piv.apply(lambda x: x.values, axis=1)
    col2.name = "tt_fact"
    
    X = merge(X, col2, on=["MESAPERTURA"], how="left")
    
    # Nominalizando la curva de TT's
    X["tt_fact"] = (power(1 + X['tt_fact'], 1/12) - 1)*12 # OFSAA

    ## Calculo TT Duration desde csv
    X["TT"] = 0.06 if "TT" not in X.columns else X["TT"].values
    X["RemCap"] = array(param_remcap["Anual"])[0]
    

    # Tasas de descuento para Tasa Minima y TEA
    X = merge(X, param_tasadescuento_tmin, on=["SUBSEGMENTO"], how="left")
    X = merge(X, param_tasadescuento_leads, on=["SUBSEGMENTO"], how="left")

    ## Semilla personalizada para la optimizacion
    X = merge(X, param_educated_guess, on=["SUBSEGMENTO"], how="left")

    # Uniendo el Indicator Target
    aux = X.merge(param_indicator_target, how='left', on='SUBSEGMENTO')
    aux['SCORE'] = where(aux.SCORE.isna(),3,aux.SCORE)
    condition = (aux['SCORE'] > aux['min_score']) & (aux['SCORE'] <= aux['max_score']) \
                    & (aux['DESEMBOLSO'] > aux['min_ticket']) & (aux['DESEMBOLSO'] <= aux['max_ticket'])
    X['INDICATOR_TARGET'] = aux.loc[condition, 'INDICATOR_TARGET'].reset_index(drop=True)

    df_tt_desc = X[["prepagoRDM", "tt_fact", "TT", "RemCap", "Tasa_dscto", "Tasa_dscto_leads", "eg_rmin", "eg_tea", "eg_irr","INDICATOR_TARGET"]]
    

    return df_tt_desc



def reglas_de_negocio(r_min, flag_pdh):
    # 1* Piso y tope:
    rmin = copy(r_min)

    rmin[(rmin < 0.099) & (flag_pdh == 1)] = 0.099 # 9.90% si es pdh
    rmin[(rmin < 0.109) & (flag_pdh == 0)] = 0.109 # 10.90% si no es pdh
    rmin[(rmin > 0.459) | (isnan(rmin))] = 0.459 # 34.90% es el límite a cobrar  
    
    # 2* Redondeo1: Obteniendo valores que terminen o en .50 o .90
    int_input = round(rmin, 2)
    dec_input = rmin - int_input         
    b1 = (dec_input>0.001) & (dec_input<=0.007)
    b2 = (dec_input>0.007) & (dec_input<=0.01) 
    dec_input[b1] = int_input[b1] + 0.005
    dec_input[b2] = int_input[b2] + 0.009  
    dec_input[(~b1)&(~b2)] = (int_input[(~b1)&(~b2)] - 0.01) + 0.009
    rmin = round(dec_input, 4) 

    return rmin

def tratamiento_data_leads(X):

    X = X.copy()
    teas = X["TEA"].values
    teas_mean = mean(teas[~isnan(teas)])
    X["TEA"] = X["TEA"].fillna(teas_mean)
    scores = X["SCORE"].values
    scores[scores<288] = 288
    scores = round(scores, 0)
    X["SCORE"] = scores

    return X

def redondeo_buckets_plazo_tasa(df, tolerance=500):
    """ Cuenta la cantidad de observaciones para cada combinación posible de rango y tasa y a los grupos con menos de 500 observaciones les aumenta la tasa a la
    inmediata superior (Logic: .9 and .5).
    El df debe tener CODCLAVECIC, PLAZO, TasaPropuesta
    """

    df = df.copy()
    df["TasaPropuesta"] = round(df["TasaPropuesta"].values, 3)
    df["Plazo_Tasa"] = df["PLAZO"].astype(str) + " - " + df["TasaPropuesta"].astype(str)
    df_pivot = pivot_table(df, index=["Plazo_Tasa"], values=["CODCLAVECIC"], aggfunc="count", fill_value=0)
    df_pivot["Flag_Redondeo"] = (df_pivot.values > tolerance) * 0 + (df_pivot.values <= tolerance) * 1
    df_pivot.reset_index(inplace=True)
    df = merge(df, df_pivot[["Plazo_Tasa", "Flag_Redondeo"]], on=["Plazo_Tasa"], how="left")
    comparable_array_rounded = round(df["TasaPropuesta"].values - 0.001, 2)
    array_rounded = round(df["TasaPropuesta"].values + 0.001, 2)
    suma_array = (array_rounded == comparable_array_rounded) * 0.006 + (
            array_rounded != comparable_array_rounded) * 0.004
    suma_redondeo = suma_array * df["Flag_Redondeo"].values
    df["TasaPropuesta"] = df["TasaPropuesta"].values + suma_redondeo
    df = df.drop(columns=["Plazo_Tasa", "Flag_Redondeo"])

    return df


def np_stack(array, axis):
    return stack(array, axis)

def np_clip(a_values, a_min, a_max):
    
    def _np_clip(i):
        va = a_values[i]
        if(va<a_min):
            a_values[i]=a_min
        if(va>a_max):
            a_values[i]=a_max
    [_np_clip(i) for i in range(len(a_values))]
    return array(a_values)

def np_isnan(num):
    return (num!=num)

def norm_cdf(x):
    def cdf1(value):
        return (1.0 + erf(value / 1.4142135623730951)) / 2.0 # (1.0 + erf(value / sqrt(2.0))) / 2.0

    if len(x)==1:
        #'Cumulative distribution function for the standard normal distribution'
        return cdf1(x)
    else:
        return array([[cdf1(item)] for item in x])