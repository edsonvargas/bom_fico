import pandas as pd
import numpy as np
import pickle
import pulp
import copy
from sklearn.model_selection import train_test_split
from IPython.display import display
import matplotlib.pyplot as plt

def cat_missing_imp(X):
    """
    #TODO: Docstring
    """
    X = X.copy()

    CatListName = (
        [ # Dummy Transformation [OriginalColumnName, Value]
        ('cat_zona_app_agp_f','NORTE'),
        ('act_eco_fin','COMERCIO')
    ])
    for variable, valor in CatListName:
        X.loc[:,variable] = X[variable].fillna(value=valor)
    
    return X

def num_missing_imp(X, param_num_imp):
    """
    #TODO: Docstring
    """
    X = X.copy()
    
    list_act_eco = list(param_num_imp['act_eco_fin'])
    list_columns = param_num_imp.iloc[:,1:].columns

    for act_eco in list_act_eco:
        list_values = list(param_num_imp.iloc[:,1:][param_num_imp['act_eco_fin']==act_eco].to_numpy().flatten())
        list_consol = zip(list_columns,list_values)
        for col, val in list_consol:
            X.loc[:,col][(X['act_eco_fin']==act_eco) & (X[col].isna())] = val
    
    return X

def df_to_records(X, col_value, value, first=0, last=2):
    """
    #TODO: Docstring
    """
    X = X.copy()
    records = X.iloc[:,first:last][X[col_value]==value].to_records(index=False)

    return list(records)

def read_pickle(param_model_pickle):
    """"
    #TODO: Docstring
    """ 
    with open(param_model_pickle, 'rb') as input:
        obj = pickle.load(input)
    return obj

def max_van(X):
    """
    #TODO: Docstring
    """

    X = X.copy()
    cond = (X.groupby('codclavecic')['van_e'].transform(max)==X['van_e'])

    return cond.astype(int)


def cluster_transform(X):
    """"
    #TODO: Docstring
    """   
    X = X.copy()

    ContlistNum = (
    [  # Dummy Transformation [FinalColumnName, OriginalColumnName, Condition]
        ("root_root_pdapplicant_pre", "pdapplicant_covid", 4, 0.214641, 0.512231),   ### actualización de pd fwl 
        ("root_montodesembolsadosol", "montodesembolsadosol", 2, 100, 591.607978)
        ])
    for var_name, variable, power, min_v, max_v in ContlistNum:
        X.loc[:, var_name] = np.clip(np.power(X[variable], 1/power), min_v, max_v)
    
    vars_cluster = ['root_root_pdapplicant_pre', 'root_montodesembolsadosol']

    X_tr = X[vars_cluster]

    return X_tr

def cluster_predict2(X, param_model_dt):
    """"
    #TODO: Docstring
    """  
    X = X.copy()

    to_replace = {0.13660425334324258: 1,
                  0.16200352697095521: 2,
                  0.2050057418111723: 3,
                  0.21485616330391313: 4,
                  0.291865836949076: 5}

    clusters = param_model_dt(X)

    for value, label in to_replace.items():
        clusters[clusters==value] = label

    return clusters

def cluster_predict(X):
    
    X = X.copy()

    X.loc[(X.root_root_pdapplicant_pre<=0.376) & (X.root_montodesembolsadosol> 396.674),'cluster']=1
    X.loc[(X.root_root_pdapplicant_pre<=0.376) & (X.root_montodesembolsadosol>302.655) & (X.root_montodesembolsadosol<= 396.674),'cluster']=2
    X.loc[(X.root_root_pdapplicant_pre<=0.376) & (X.root_montodesembolsadosol<=302.655),'cluster']=3
    X.loc[(X.root_root_pdapplicant_pre>0.376) & (X.root_montodesembolsadosol>300.915),'cluster']=4
    X.loc[(X.root_root_pdapplicant_pre>0.376) & (X.root_montodesembolsadosol<=300.915),'cluster']=5

    clusters = X['cluster'].values
    return clusters

def dummy_transform(X):
    """
    #TODO: Docstring
    """
    X = X.copy()

    X_tr = cat_missing_imp(X)

    DummylistNum = (
    [  # Dummy Transformation [FinalColumnName, OriginalColumnName, Condition]
        ("d_rcc_pct_utl_lin_pym_tcr_bcp_prm_u3m_1", "rcc_pct_utl_lin_pym_tcr_bcp_prm_u3m", 0),
        ("d_prod_flg_cct_x3m_u3m_1", "prod_flg_cct_x3m_u3m", 0)
        ])
    for var_name, variable, valor in DummylistNum:
        X_tr.loc[:, var_name] = (X_tr.loc[:, variable] > valor).astype(int)

    DummylistCat = (
    [  # Dummy Transformation [FinalColumnName, OriginalColumnName, Condition]
        ("cat_zona_app_agp_f_LIMA_MODERNA", "cat_zona_app_agp_f", "LIMA_MODERNA"),
        ("cat_zona_app_agp_f_SELVA", "cat_zona_app_agp_f", "SELVA"),
        ("cat_zona_app_agp_f_LIMA_SUR", "cat_zona_app_agp_f", "LIMA_SUR"),
        ("act_eco_fin_COMERCIO", "act_eco_fin", "COMERCIO")
        ])

    for var_name, variable, valor in DummylistCat:
        X_tr.loc[:, var_name] = (X_tr.loc[:, variable] == valor).astype(int)

    return X_tr

def numeric_transform(X, param_num_imp, param_num_transform):
    """
    #TODO: Docstring
    """
    X = X.copy()

    X_tr = num_missing_imp(X, param_num_imp)

    list_num_vars = list(param_num_imp.iloc[:,1:].columns)
    list_vars_1 = df_to_records(param_num_transform, 'root_sq', 1)
    list_vars_2 = df_to_records(param_num_transform, 'root_sq', 2)

    # Asegurar mínimo de cero en cada variable original
     
    for col in list_num_vars:
        X_tr.loc[:,col] = np.where(X_tr[col]<0, 0, X_tr[col])

    # Variables convolucionadas

    # Interacción con la tasa
    InterlistNum = (
    [  # Transformation [FinalColumnName, OriginalColumnName]
        ("tea_ing_ult12m", "ing_ult12m"),
        ("tea_ind_shopper", "ind_shopper_bank"),
        ("tea_montodesemsol", "montodesembolsadosol"),
        ("tea_rcc_mto_sld_nbcp", "rcc_mto_sld_nbcp")
        ])
    for colname, varname in InterlistNum:
        X_tr.loc[:,colname] = X_tr['tea']*X_tr[varname]
    
    # Dummies Multiplicativas
    DMlistNum = (
    [  # Transformation [FinalColumnName, OriginalColumnName, Condition]
        ("dm_tea_montodesemsol_200k", "montodesembolsadosol", 200000),
        ("dm_tea_rcc_mto_sld_nbcp_40k", "rcc_mto_sld_nbcp", 40000)
        ])
    for colname, varname, value in DMlistNum:
        X_tr.loc[:,colname] = np.where(X_tr[varname]>=value, X_tr['tea'], 0)
    
    # Convolución Tripartita
    TrilistNum = (
    [  # Transformation [FinalColumnName, OriginalColumnName, Condition]
        ("dm_tea_ing_ind_shopper_015", "ind_shopper", 0.15)
        ])
    for colname, varname, value in TrilistNum:    
        X_tr.loc[:,colname] = np.where(X_tr[varname]>value, X_tr['tea_ing_ult12m'],0) #TODO: >=
    
    # Transformation by var: 1 root
    for colname, varname in list_vars_1:
        X_tr.loc[:,colname] = np.sqrt(X_tr[varname])
    
    # Transformation by var: 2 root
    for colname, varname in list_vars_2:
        X_tr.loc[:,colname] = np.sqrt(np.sqrt(X_tr[varname]))

    return X_tr

def numeric_capping(X, param_capping):
    """"
    #TODO: Docstring
    """
    X = X.copy()

    n_clusters = np.arange(1,6)

    for cluster in n_clusters:
        list_vars_clust = df_to_records(param_capping, 'cluster', cluster, 1, 4)
        for varname, min_v, max_v in list_vars_clust:
            X.loc[:,varname][X['cluster']==cluster] = np.clip(X[varname], min_v, max_v)

    return X

def numeric_standarization(X, param_standarization):
    """"
    #TODO: Docstring
    """
    X = X.copy()

    n_clusters = np.arange(1,6)

    for cluster in n_clusters:
        list_vars_clust = df_to_records(param_standarization, 'cluster', cluster, 1, 4)
        for varname, mean_v, desv_v in list_vars_clust:
            X.loc[:,varname][X['cluster']==cluster] = np.divide(X[varname] - mean_v, desv_v)

    return X

def preprocessing(X, param_num_imp, param_num_transform, param_num_capping, param_num_standarization):
    """
    #TODO: Docstring
    """

    X_cat = dummy_transform(X)
    X_imp = numeric_transform(X_cat, param_num_imp, param_num_transform)
    X_cap = numeric_capping(X_imp, param_num_capping)
    X_std = numeric_standarization(X_cap, param_num_standarization)

    return X_std

def tkr_predict(X, param_dem_betas):
    """"
    #TODO: Docstring
    """
    X = X.copy()
    X.loc[:,'intercepto'] = 1

    list_vars_tkr = param_dem_betas.iloc[:,1:].columns

    X.loc[:, "XB"] = 0
    Xdata = X[list_vars_tkr]
    clusters = np.arange(1,6)    

    for cluster in clusters:
        B = param_dem_betas[list_vars_tkr][
            (param_dem_betas["cluster"] == cluster)]
        X.loc[:, "XB"] = np.where(
            (X["cluster"] == cluster),
            np.sum(np.multiply(Xdata, B), axis=1),
            X["XB"],
        )
    tkr = 1/(1+np.exp(-X['XB']))

    return tkr

def van_optimization(X, takeup_rate, efectividad, porc_oferta):
    """
    #TODO: Docstring
    """

    X = X.copy()
    # X.loc[:,'van_e'] = X['npv']*takeup_rate*efectividad*porc_oferta
    X.loc[:,'tkr'] = takeup_rate
    X.loc[:,'efec'] = efectividad
    # X.loc[:,'van_tkr'] = X['npv']*takeup_rate
    X.loc[:,'van_e'] = X['npv']*takeup_rate*efectividad
    X.loc[:,'van_p'] = X['npv']*efectividad
    # X.loc[:,'mto_e'] = X['montodesembolsadosol']*takeup_rate*efectividad*porc_oferta
    X.loc[:,'mto_e'] = X['montodesembolsadosol']*efectividad*porc_oferta
    # X.loc[:,'tkr'] = takeup_rate #Añadir probabilidad para ejercicio de betas

    vars_finales = ["codclavecic", "escenario", "tea", "van_e","mto_e", "cluster", "tir", 'tkr', 'efec']
    # vars_finales = ["codclavecic", "escenario", "tea", "van_e","mto_e", "cluster", "tir", "tkr"]

    X_tr = X[vars_finales]
    X_tr.loc[:,'flg_max_vane'] = max_van(X_tr)
    X_esc_base = X_tr[X_tr["escenario"]==0]
    X_ind_opt = X_tr[X_tr['flg_max_vane']==1]
    mto_esperado_total = X_tr['mto_e'][X_tr['flg_max_vane']==1].sum()

    return X_tr, X_esc_base, X_ind_opt, mto_esperado_total

def port_optimization(X, min_value):
    """
    #TODO: Docstring
    """
    X = X.copy()
    X_tr = X.copy()

    # values_mto = [(min_value, min_value*1.075),(min_value*1.075, min_value*1.15), 
    #               (min_value*1.15, min_value*1.225), (min_value*1.225, min_value*1.3),
    #               (min_value*1.375, min_value*1.45), (min_value*1.525, min_value*1.6)]
    values_mto = [min_value*1.2]
    
    X.set_index(keys=['codclavecic','escenario'], inplace=True)
    idcs = list(X_tr['codclavecic'])

    for min_v in values_mto:
        esc_opt = pulp.LpVariable.dicts("esc_opt",
                                        ((idc, escenario) for idc, escenario in X.index),
                                        cat='Binary')
    # Definición del Modelo
        model_opt = pulp.LpProblem("Optimización del Van Esperado", pulp.LpMaximize)

        # Función Objetivo
        model_opt += pulp.lpSum([esc_opt[idc, escenario] * X.loc[(idc, escenario), 'van_e'] for idc, escenario in X.index])  
        
        # Restricciones
        
        for idc in idcs:
            escenarios = X_tr['escenario'][X_tr['codclavecic']==idc]
            model_opt += pulp.lpSum(esc_opt[(idc, esc)] for esc in escenarios) == 1
        
        # model_opt += pulp.lpSum([esc_opt[idc, escenario] * X.loc[(idc, escenario), 'mto_e'] for idc, escenario in X.index]) <= max_v
        model_opt += pulp.lpSum([esc_opt[idc, escenario] * X.loc[(idc, escenario), 'mto_e'] for idc, escenario in X.index]) >= min_v

        model_opt.solve()
        print(pulp.LpStatus[model_opt.status])
        print(model_opt.objective.value())

def randomization(df_1, df_2, seed=42, test_size=0.15):
    """TODO:"""

    df_2.rename(columns={"flg_piloto":"flg_piloto_prev"}, inplace=True)
    df_2["flg_piloto"] = (df_2["flg_piloto_prev"]>0)*1

    df_1.columns = df_1.columns.str.lower()

    piloto_control = df_1.merge(df_2, on="codclavecic", how="left")
    piloto_control.loc[:,"flg_tsn"] = np.where(piloto_control["flg_tsn"].isna(), "Nulo", piloto_control["flg_tsn"])
    piloto_control_prev = piloto_control[piloto_control["flg_piloto"].isin([1,0])]
    piloto_control_samp = piloto_control[~piloto_control["flg_piloto"].isin([1,0])]

    df_piloto, df_control = train_test_split(piloto_control_samp, test_size=test_size, random_state=seed)

    df_piloto['flg_piloto'] = 1
    df_control['flg_piloto'] = 0

    df_final_piloto_p = pd.concat([df_piloto, df_control], axis=0, ignore_index=True)

    df_final_piloto_p["flg_pc_nuevo"] = 1
    piloto_control_prev["flg_pc_nuevo"] = 0

    df_final_piloto = pd.concat([df_final_piloto_p,piloto_control_prev], axis=0, ignore_index=True)

    return df_final_piloto

def psi_comb(df, cols_eval, col_piloto="flg_piloto", groups=10):
    """
    Evaluar estadísticamente la estabilidad de las poblaciones del piloto y control bajo las variables de evaluación
    
    Esta función retorna un mensaje si las poblaciones son estadísticamente estables evaluada en las columnas ´cols_eval´
    y además una tabla de doble con los resultados por los cortes de la misma variable.
    
    Parameters
    ----------
    df: pandas.DataFrame
                
    cols_eval: str
        Nombre de las columnas que se evaluarán si está homegeneamente distribuido tanto en la muestra piloto como control.
        
    col_piloto: str
        Nombre de la columna que define a cada elemento como grupo piloto o control. 
        
    Returns
    -------
    pandas.DataFrame
        Tabulación cruzada de los datos.
        
    Examples
    --------
    
    flg_piloto flg_portafolio flg_nuevo        0        1
             0              0         0 0.630353 0.632792
             1              0         1 0.122621 0.127242
             2              1         0 0.209553 0.207622
             3              1         1 0.037473 0.032344
                                  
    
    """
    df = df.copy()
    df = df[df["flg_outlier"]==0]
    count_group = df.groupby(cols_eval+[col_piloto])[col_piloto].count().unstack()
    count_tot = df[col_piloto].value_counts().sort_index().tolist()
    ct = (count_group/count_tot).reset_index()
    ct = ct[(ct[1].notna()) & (ct[0].notna())]
    
    psi = np.dot((ct[0]-ct[1]),np.log(ct[0]/ct[1]))
    
    if psi<0.1:
        print(f"Las poblaciones son estadísticamente semejantes en los cortes: {cols_eval}; Valor PSI: {psi}")
    elif psi<0.2:
        print(f"Las poblaciones son ligeramente diferentes en los cortes: {cols_eval}; Valor PSI: {psi}")
    else:
        print(f"Las poblaciones son altamente diferentes en los cortes: {cols_eval}; Valor PSI: {psi}")
    return ct  

def plotear_hist(df,variable,density=True):
    x1=df[df["flg_piloto"]==1]
    x2=df[df["flg_piloto"]==0]
    plt.hist(x1[variable],bins=20,density=density, alpha=0.5, label='Piloto', histtype='step', linewidth=2)
    plt.hist(x2[variable],bins=20,density=density, alpha=0.5, label='Control', histtype='step', linewidth=2)
    plt.legend()
    plt.xticks(rotation = -45)
    plt.title(variable.upper())
    plt.show()
    return plt.show()

def rand_validation(df):
    """TODO:"""

    lista_var = ["grupo", "flg_carterizado","flg_portafolio","flg_nuevo","flg_tsn","rango_pd","rango_monto","flg_recurrente"]
    for i in lista_var:
        display(pd.crosstab(df[i],df["flg_piloto"], normalize="columns"))

    lista_var = ["grupo", "flg_carterizado","flg_portafolio","flg_nuevo","flg_tsn","rango_pd","rango_monto","flg_recurrente"]
    df_final_piloto_2 = df.copy()
    df_final_piloto_2["flg_outlier"] = 0 
    for i in lista_var:
        aux1 = psi_comb(df_final_piloto_2,cols_eval=[i])
        print(aux1)
    lista_var_num =["mtofinalofertado","pd_aprobadocen_covid_final"]
    for i in lista_var_num:
        plotear_hist(df_final_piloto_2,i)

def get_randomization(df_1, df_2, seed=42, test_size=0.15):
    df_1 = df_1.copy()
    df_2 = df_2.copy()
    seed = seed
    test_size = test_size
    df = randomization(df_1 = df_1, df_2 = df_2, seed=seed, test_size=test_size)
    rand_validation(df)
    return df