
import pandas as pd
import line_profiler
import atexit
import cProfile
import pstats
import io
import time
from pathlib import Path

import os, sys
sys.dont_write_bytecode = True
sys.path.append(os.getcwd())

from pyme_engine.clv_pyme import clv_pyme_wrapper as clv_wrapper
from pyme_engine import pyme_wrapper as pyme_wrapper


    
profile = line_profiler.LineProfiler()
atexit.register(profile.print_stats)
path_base = Path(__file__).resolve().parent 

def profile_engine_clv():
    # Cargando datos
    path = path_base / 'input_profiler.csv'
    data = pd.read_csv(path)

    # Ejecutando el codigo
    start = time.time()
    clv_engine = clv_wrapper.ClvPymeWrapper(data)
    output = clv_engine.predict()
    # output.to_csv(path_base /  "output_profiler.csv")
    tiempo = time.time()-start
    print(output)
    print('Elapsed time:'+str(tiempo))
    return tiempo

def profile_engine_clv_wtp():
    # Cargando datos
    path = path_base / 'input_profiler.csv'
    data = pd.read_csv(path)

    # Ejecutando el codigo
    start = time.time()
    engine = pyme_wrapper.PymeWrapper()
    output = engine.predict(data.values, data.columns)    
    tiempo = time.time()-start
    
    output.to_csv(path_base /  "output_profiler.csv")
    print(output)
    print('Elapsed time:'+str(tiempo))
    return tiempo


def generate_profile(type:int=1):
    profiler = cProfile.Profile()
    profiler.enable()
    tiempo=profile_engine_clv() if type==1 else profile_engine_clv_wtp()
    profiler.disable()

    result = io.StringIO()  
    stats = pstats.Stats(profiler, stream=result).sort_stats('cumtime')
    stats.print_stats()
    data = result.getvalue()

    # chop the string into a csv-like buffer
    data = 'ncalls' + data.split('ncalls')[-1]
    if type==1:
        lines = list(filter(lambda line: 'ncalls' in line
                                        or '/utils.py' in line
                                        or '/utils_clv.py' in line
                                        or '/CLV_Engine.py' in line
                                        or '/curves_all.py' in line
                                        or '/clv_data.py' in line
                                        or '/clv_pyme_wrapper.py' in line, data.split('\n')))
    else:
        lines = list(filter(lambda line: 'ncalls' in line
                                        or '/utils.py' in line
                                        or '/utils_clv.py' in line
                                        or '/CLV_Engine.py' in line
                                        or '/curves_all.py' in line
                                        or '/clv_data.py' in line
                                        or '/clv_pyme_wrapper.py' in line
                                        
                                        or '/utils_wtp.py' in line
                                        or '/WTP_Engine.py' in line
                                        or '/wtp_pyme_wrapper.py' in line
                                        or '/pyme_wrapper.py' in line, data.split('\n')))
    data = '\n'.join([','.join([word.strip().replace('    ', ',').replace('  ', ',')
                                for word in line.split('    ')])
                      for line in lines])
    data = '\n'.join([line.replace(',,', ',').replace('ncalls', ',ncalls') for line in data.split('\n')])

    # save it to disk
    with open(path_base / 'profiler.csv', 'w+') as f:
        f.write(data)
        f.close()
    return tiempo

if __name__ == '__main__':
    generate_profile(2)

