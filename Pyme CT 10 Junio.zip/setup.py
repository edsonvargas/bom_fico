from setuptools import setup, find_packages

setup(
    name="clv_pyme",
    version="1.0",
    description="Calculadora para el CLV de Pyme CT/AF",
    author="Juan Jose Guillen",
    author_email="jguillen@bcp.com.pe",
    packages=find_packages("source"),  # include all packages under clv_cef
    package_dir={"": "source"},
    package_data={"": ["*.csv","*.pkl"]}
)
