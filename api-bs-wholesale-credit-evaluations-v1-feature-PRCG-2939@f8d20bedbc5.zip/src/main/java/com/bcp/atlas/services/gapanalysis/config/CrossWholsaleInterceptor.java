package com.bcp.atlas.services.gapanalysis.config;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Request.Builder;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * Interceptor for headers.<br/>
 * <b>Class</b>: RequestCrossInterceptor<br/>
 * <b>Copyright</b>: &copy; 2018 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 * <ul>
 * <li>Apr 1, 2019 Creaci&oacute;n de Clase.</li>
 * </ul>
 * @version 1.0
 */
@Component(CrossWholsaleInterceptor.BEAN_NAME)
@Lazy
public class CrossWholsaleInterceptor implements Interceptor {

  public static final String BEAN_NAME = "requestWholsaleInterceptor";
  @Autowired
  private CustomHeaders header;

  @Override
  public Response intercept(Chain chain) throws IOException {
    Request req = getNewRequest(chain.request());
    return chain.proceed(req);
  }

  private Request getNewRequest(Request originalRequest) {
    Builder newRequest = originalRequest.newBuilder().headers(getHeaders(originalRequest));
    return newRequest.build();
  }

  private Headers getHeaders(Request originalRequest) {
    okhttp3.Headers.Builder builder = originalRequest.headers().newBuilder();
    header.getHeader().forEach((key, value) -> {
      if (StringUtils.isEmpty(builder.get(key))) {
        builder.add(key, value);
      }
    });
    return builder.build();
  }


  /**
   * Variable store headers from cs.<br/>
   * <b>Class</b>: CustomHeaders<br/>
   * <b>Copyright</b>: &copy; 2018 Banco de Cr&eacute;dito del Per&uacute;.<br/>
   * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
   *
   * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
   * <u>Service Provider</u>: Everis Per&uacute; SAC (EVE) <br/>
   * <u>Changes</u>:<br/>
   * <ul>
   * <li>Apr 1, 2019 Creaci&oacute;n de Clase.</li>
   * </ul>
   * @version 1.0
   */
  @Getter
  @Setter
  @RefreshScope
  @ConfigurationProperties(prefix = "application.wholsale-credit-evaluation")
  @Component
  @SuppressFBWarnings(value = "USFW_UNSYNCHRONIZED_SINGLETON_FIELD_WRITES",
      justification = "This class is used for configuration purposes")
  public static class CustomHeaders {
    private Map<String, String> header = new HashMap<>();

  }
}
