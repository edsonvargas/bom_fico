package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationInfoResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.QuotationRequest;
import io.reactivex.Observable;

/**
 * <br/>
 * Clase service que contiene los metodos necesarios para tramitar la data y logica de negocio que
 * consumira la clase REST WholesaleQuotationDao<br/>
 * <b>Class</b>: LoanRateServiceImpl<br/>
 * Copyright: &copy; 2023 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: BCP <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>Marco Nolasco</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Apr 28, 2023 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
public interface WholesaleQuotationDao {

  Observable<String> generateQuotationNumber(QuotationRequest quotationRequest);

  Observable<PricingWholesaleQuotationInfoResponse> getQuotation(String quotationId);

}
