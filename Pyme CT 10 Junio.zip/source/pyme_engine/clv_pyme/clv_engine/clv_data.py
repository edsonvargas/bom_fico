
from math import ceil
from pandas import read_csv, DataFrame
from pathlib import Path
from threading import Thread

class ClvData:
    __instance = None
    data_frame_loaded = dict()

    @staticmethod
    def get_instance():
        """ Static access method. """
        if ClvData.__instance is None:
            ClvData()
        return ClvData.__instance

    def __init__(self):
        self.__load_data()
        """ Virtually private constructor. """
        if ClvData.__instance is None:
            ClvData.__instance = self

    def __load_data(self):
        files = ['can_thetaTt',
                'costos_lifetime','costos_t_0',
                'descuentos_tasadescuento_afi','descuentos_tasadescuento_alpha',
                'descuentos_tasadescuento_cen','descuentos_tasadescuento_reactivo',
                'descuentos_tasadescuento_tmin','ecap_pd_ttc','ecap_scalars','ingresos_x_servicios',
                'lgd_for_ecap_map','lgd_thetaT_T_final','lgd_thetaT','lgd_thetaT_final',
                'param_lgd_wo','param_localidad_zona','param_remcap','param_lgd_missings','param_lgd_values',
                'pd_rango_Tt','pd_scalars','pd_thetaT','pd_thetaTt',
                'pre_thetaTt','producto_code','producto_code_campaign',
                'roll1_coef','roll1_factor','roll2_coef','roll2_factor',
                'roll1','roll2',
                'tt_prepagos','tt_zdf','param_monto_pd']

        parent_path= f"{Path(__file__).resolve().parent}/data/"
        def read_data(file):
            data = None
            final_path = f"{parent_path}{file}.csv"
            if Path(final_path).exists():
                data = read_csv(final_path, encoding= 'unicode_escape')

            self.data_frame_loaded[file] = data
        
        # [read_data(file) for file in files]

        threads = []
        def start_threads(file_name):
            th = Thread(target=read_data, args=(file_name,))
            threads.append(th)
            th.start()
        [start_threads(file) for file in files]
        [t.join() for t in threads]

    def set_data_prepagos(self, input_clv):
        df = input_clv.copy()
        df = df.set_index("REQUEST_ID")

        df_final = DataFrame(columns=['product_code_final', 'Moneda', 'CantidadPlazo','t','prepagoRDM'])
        df_prepago = df.loc[:, "PRE1":"PRE144"].replace(-1,0)
        df_columns_prepago = df_prepago.columns.str.replace("PRE", "").values
        df_prepago.insert(0,"PRE0",0)
        df_prepago[["product_code_final","Moneda","CantidadPlazo"]] = df[["product_code_final", "Moneda","CantidadPlazo"]]

        for idx, row in df_prepago.iterrows():
            df_row = DataFrame({
                'product_code_final':row['product_code_final'],
                'Moneda':row['Moneda'],
                'CantidadPlazo':ceil(row['CantidadPlazo']/12)*12,
                't':df_columns_prepago,
                'prepagoRDM':row["PRE0":"PRE143"],
            })

            df_final = df_final._append(df_row)

        df_final = df_final.reset_index()
        df_final = df_final[['product_code_final', 'Moneda', 'CantidadPlazo','t','prepagoRDM']]
        df_final = df_final.astype(dtype={ 'product_code_final':int, 'Moneda':str, 'CantidadPlazo':int,'t':int,'prepagoRDM':float})
        self.data_frame_loaded["tt_prepagos"] = df_final.drop_duplicates()

        return self

    def set_data_ttzdf(self, input_clv):
        df = input_clv.copy()
        df = df.set_index("REQUEST_ID")
        
        df_final = DataFrame(columns=['t', 'Moneda', 'tt_fact'])
        df_tt = df.loc[:, "TT1":"TT145"]
        df_columns_tt = df_tt.columns.str.replace("TT", "").values
        df_tt.insert(0,"TT0",0)
        df_tt[['Moneda']] = df[['Moneda']]

        for idx, row in df_tt.iterrows():
            df_row = DataFrame({
                        "t":df_columns_tt,
                        "Moneda": row['Moneda'],
                        "tt_fact": row["TT0":"TT144"],
                    })
            
            df_final = df_final._append(df_row)

        df_final = df_final.reset_index()
        df_final = df_final[['t', 'Moneda', 'tt_fact']]
        df_final = df_final.astype(dtype={'t': int, 'tt_fact': float})
        self.data_frame_loaded["tt_zdf"] = df_final.drop_duplicates()
        return self
