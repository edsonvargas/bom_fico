package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.springframework.stereotype.Component;

/**
 * <b>Class</b>: HashBuilder<br/>
 * <b>Copyright</b>: &copy; 2018 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         2 <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Jul 26 2019 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Component
public class HashBuilder {

  /**
   * Method getIncentives()
   *
   * @version 1.0
   */
  public String sha256(String inputRaw) {
    try {
      return String.format("%064x",
            new BigInteger(1,
                    MessageDigest
                            .getInstance(Constantes.SHA_256)
                            .digest(inputRaw.getBytes(StandardCharsets.UTF_8)))
      );
    } catch (NoSuchAlgorithmException e) {
      throw new IllegalStateException(e.getMessage(), e);
    }
  }
}
