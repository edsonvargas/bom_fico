
import pandas as pd
import line_profiler
import atexit
import cProfile
import pstats
import io
import time
from pathlib import Path

import os, sys
sys.dont_write_bytecode = True
sys.path.append(os.getcwd())

#from source.clv_mayorista import clv_mayorista_wrapper as wrapper
from source.clv_mayorista import clv_mayorista_wrapper as wrapper


profile = line_profiler.LineProfiler()
atexit.register(profile.print_stats)
path_base = Path(__file__).resolve().parent 

def profile_engine_clv():
    # Cargando datos
    path = path_base / 'input_profiler.csv'
    data = pd.read_csv(path,nrows=1000)

    # Ejecutando el codigo

    output_df = pd.DataFrame()
    start = time.time()
    clv_engine = wrapper.ClvMayoristaWrapper()

    for key, value in data.iterrows():
        print(value['channelRequestId'])
        output = clv_engine.predict([value.values], data.columns)
        output['key']=value['channelRequestId']
        output_df = pd.concat([output_df, output])
    #for i in range(len(data)): 
    #    output = clv_engine.predict(data[i], data.columns)
    #    output_dict[i] = output
    #clv_engine = wrapper.ClvMayoristaWrapper(data)

    output_df.to_csv(path_base /  "output_masivo_CFZ.csv")
    tiempo = time.time()-start
    print(output)
    print('Elapsed time:'+str(tiempo))
    return tiempo


def generate_profile():
    profiler = cProfile.Profile()
    profiler.enable()
    tiempo=profile_engine_clv()
    profiler.disable()

    result = io.StringIO() 
    stats = pstats.Stats(profiler, stream=result).sort_stats('cumtime')
    stats.print_stats()
    data = result.getvalue()

    with open(path_base / 'profiler_2023.csv', 'w+') as f:
        f.write(data)
        f.close()

    # chop the string into a csv-like buffer
    data = 'ncalls' + data.split('ncalls')[-1]

    lines = list(filter(lambda line: ('ncalls' in line
                                      or '/utils.py' in line
                                      or '/utils_clv.py' in line
                                      or '/engine.py' in line
                                      or '/curves.py' in line
                                      # or '/clv_data.py' in line
                                      or '/clv_mayorista_wrapper.py' in line), data.split('\n')))
    data = '\n'.join([','.join([word.strip().replace('    ', ',').replace('  ', ',')
                                for word in line.split('    ')])
                      for line in lines])
    data = '\n'.join([line.replace(',,', ',').replace('ncalls', ',ncalls') for line in data.split('\n')])

    # save it to disk
    with open(path_base / 'profiler.csv', 'w+') as f:
        f.write(data)
        f.close()
    return tiempo

if __name__ == '__main__':
    generate_profile() 
