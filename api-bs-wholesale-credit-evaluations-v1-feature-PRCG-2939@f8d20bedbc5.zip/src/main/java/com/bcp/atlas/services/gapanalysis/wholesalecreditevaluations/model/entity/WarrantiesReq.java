package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;


/**
 * <b>Class</b>: Product.java <br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Ago 1, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Data
@Entity
@Table(name = "warranties_req",schema = "prcg_mayorista")
public class WarrantiesReq {

  @Column(name = "warranties_req_id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Id
  private Integer warrantiesReqId;

  @Column(name = "warranties_code")
  private String warrantiesCode;

  @Column(name = "warranties_currency_code")
  private String warrantiesCurrencyCode;

  @Column(name = "warranties_currency_desc")
  private String warrantiesCurrencyDesc;

  @Column(name = "commercial_value")
  private BigDecimal commercialValue;

  @Column(name = "warranties_warranty_type")
  private String warrantiesWarrantyType;

  @Column(name = "credit_info_cp_req_id")
  private Integer creditInfoCpReqId;

  @Column(name = "register_date")
  private LocalDateTime registerDate;

  @Column(name = "affected_value")
  private BigDecimal affectedValue;

  @Column(name = "realization_value")
  private BigDecimal realizationValue;
}
