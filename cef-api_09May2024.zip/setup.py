from setuptools import setup, find_packages

setup(
    name="clv_cef",
    version="1.0",
    description="Calculadora para el CLV de Credito Efectivo",
    author="J. Alonso Medina Donayre",
    author_email="edsonrvargas@bcp.com.pe",
    packages=find_packages("source"),  # include all packages under clv_cef
    package_dir={"": "source"},
    package_data={"": ["*.csv"]}
)
