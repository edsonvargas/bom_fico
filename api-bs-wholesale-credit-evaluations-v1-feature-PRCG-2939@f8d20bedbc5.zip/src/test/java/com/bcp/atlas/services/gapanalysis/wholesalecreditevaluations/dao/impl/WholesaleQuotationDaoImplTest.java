package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.QuotationRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.CreditInfoCpResponseRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc.GetQuotationInfoRepository;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.MapperUtils;
import io.reactivex.observers.TestObserver;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class WholesaleQuotationDaoImplTest {

  @InjectMocks WholesaleQuotationDaoImpl wholesaleQuotationDaoImpl;

  @Mock CreditInfoCpResponseRepository creditInfoCpResponseRepository;

  @Mock private GetQuotationInfoRepository getQuotationInfoRepository;

  @Test
  void whenGenerateQuotationNumberWithOk() {
    QuotationRequest quotationRequest =
        MapperUtils.convertToObject("RequestQuotation.json", QuotationRequest.class);
    Assert.assertNotNull(quotationRequest);
    when(creditInfoCpResponseRepository.generateQuotationNumber(any()))
        .thenReturn("abc");
    TestObserver<String> data =
        wholesaleQuotationDaoImpl.generateQuotationNumber(quotationRequest).test();
    data.awaitTerminalEvent();
  }

  @Test
  void whenGenerateQuotationNumberWithNoOk() {

    QuotationRequest quotationRequest =
        MapperUtils.convertToObject("RequestQuotation.json", QuotationRequest.class);
    Assert.assertNotNull(quotationRequest);
    when(creditInfoCpResponseRepository.generateQuotationNumber(any()))
        .thenReturn("El quotationId ingresado no es correcto.");
    TestObserver<String> data =
        wholesaleQuotationDaoImpl.generateQuotationNumber(quotationRequest).test();
    data.awaitTerminalEvent();
  }
}
