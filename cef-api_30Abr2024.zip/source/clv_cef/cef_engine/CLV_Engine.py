from pandas import DataFrame,concat
from clv_cef.cef_engine import utils_clv as clv, curves_all as curves, utils as ut, clv_data

'''
*******************************************************************************************************************************************
PROYECTO    :   CLV CREDITO EFECTIVO 
TIPO        :   PYTHON

OBJETIVO    :   CALCULAR LOS INDICADORES DE RENTABILIDAD DE LOS DESEMBOLSOS Y REALIZAR LA ASIGNACIÓN DE TASAS PARA LOS LEADS.

REPROCESABLE:   SI

LISTADO DE MODELOS:
CÓDIGO MODELO       DESCRIPCIÓN MODELO
MOD-BCP-0002938     CLV Crédito Efectivo
MOD-BCP-0000008     Cancelaciones Crédito Efectivo
MOD-BCP-0000009     Prepagos Crédito Efectivo
MOD-BCP-0000103     LGD CLV - Crédito Efectivo
MOD-BCP-0000554     Capital Económico para el Pricing Minorista
MOD-BCP-0000572     PD CLV - Crédito Efectivo

VERSION     ANALISTA            RESPONSABLE TECNICO      FECHA          ESTADO                  DESCRIPCIÓN
2.2.2       JUAN JOSE GUILLEN   GONZALO LEZMA            01/01/2021     EN PRODUCCIÓN           PUESTA EN USO DE VERSIÓN CLV VALIDADO.
2.2.1       DENNIER AGREDA      GONZALO LEZMA            01/03/2021     PENDIENTE VALIDACIÓN    SE INCLUYE FUNCIONALIDAD SHIELD.



*******************************************************************************************************************************************
'''


class SetPath:
    __terms = None

    def __init__(self, terms=None):
        self.__terms = terms.drop_duplicates().tolist() if terms is not None else None
        self.hyperparams = {}
        self.clv_data = clv_data.ClvData.get_instance()

        self.set_path_can()
        self.set_path_pd()
        self.set_path_pre()
        self.set_path_lgd()
        self.set_path_rr()
        self.set_path_ecap()
        self.set_path_cost()
        self.set_path_ing()
        self.set_path_tt()

    def set_path_can(self):
        param_Tt = self.clv_data.DataFramesLoaded["can_thetaTt"]
        param_T = self.clv_data.DataFramesLoaded["can_thetaT"]
        param_PDCal = self.clv_data.DataFramesLoaded["varios_PDcalibrada"]
        param_GroupPD = self.clv_data.DataFramesLoaded["varios_Group_PD"]
        param_Enalta = self.clv_data.DataFramesLoaded["varios_Enalta"]
        param_factor = self.clv_data.DataFramesLoaded["varios_factor_pre_can"]

        # filtering data
        if self.__terms is not None:
            terms = self.__terms
            param_PDCal = param_PDCal[param_PDCal['T'].isin(terms)]
            param_Tt = param_Tt[param_Tt['T'].isin(terms)]
            param_T = param_T[param_T['T'].isin(terms)]
            param_GroupPD = param_GroupPD[param_GroupPD['T'].isin(terms)]
            param_Enalta = param_Enalta[param_Enalta['T'].isin(terms)]

        hyperparams = {
            "param_Tt": param_Tt,
            "param_T": param_T,
            "param_PDCal": param_PDCal,
            "param_GroupPD": param_GroupPD,
            "param_Enalta": param_Enalta,
            "param_factor": param_factor

        }
        self.hyperparams["CAN"] = hyperparams

    def set_path_pd(self):
        param_Tt = self.clv_data.DataFramesLoaded["pd_thetaTt"]
        param_T = self.clv_data.DataFramesLoaded["pd_thetaT"]
        param_scalar = self.clv_data.DataFramesLoaded["pd_scalars"]

        # filtering data
        if self.__terms is not None:
            terms = self.__terms
            param_Tt = param_Tt[param_Tt['T'].isin(terms)]
            param_T = param_T[param_T['T'].isin(terms)]

        hyperparams = {
            "param_Tt": param_Tt,
            "param_T": param_T,
            "param_scalar": param_scalar
        }
        self.hyperparams["PD"] = hyperparams

    def set_path_pre(self):
        param_Logit = self.clv_data.DataFramesLoaded["pre_Logit"]
        param_MCO = self.clv_data.DataFramesLoaded["pre_MCO"]
        param_Primera = self.clv_data.DataFramesLoaded["pre_Primera"]
        param_PDCal = self.clv_data.DataFramesLoaded["varios_PDcalibrada"]
        param_GroupPD = self.clv_data.DataFramesLoaded["varios_Group_PD"]
        param_Enalta = self.clv_data.DataFramesLoaded["varios_Enalta"]
        param_factor = self.clv_data.DataFramesLoaded["varios_factor_pre_can"]

        # filtering data
        if self.__terms is not None:
            terms = self.__terms
            param_Logit = param_Logit[param_Logit['T'].isin(terms)]
            param_Primera = param_Primera[param_Primera['T'].isin(terms)]
            param_PDCal = param_PDCal[param_PDCal['T'].isin(terms)]
            param_GroupPD = param_GroupPD[param_GroupPD['T'].isin(terms)]
            param_Enalta = param_Enalta[param_Enalta['T'].isin(terms)]
            param_MCO = param_MCO[param_MCO['T'].isin(terms)]

        hyperparams = {
            "param_Logit": param_Logit,
            "param_MCO": param_MCO,
            "param_Primera": param_Primera,
            "param_PDCal": param_PDCal,
            "param_GroupPD": param_GroupPD,
            "param_Enalta": param_Enalta,     
            "param_factor": param_factor
        }
        self.hyperparams["PRE"] = hyperparams

    def set_path_lgd(self):
        param_T = self.clv_data.DataFramesLoaded["lgd_ThetaT"]
        limit_T = self.clv_data.DataFramesLoaded["lgd_Limites_Inputs"]
        lgd_Enalta = self.clv_data.DataFramesLoaded["lgd_Enalta"]

        # filtering data
        if self.__terms is not None:
            terms = self.__terms
            param_T = param_T[param_T['PLAZO'].isin(terms)]

        hyperparams = {
            "param_T": param_T,
            "limit_T": limit_T,
            "lgd_Enalta": lgd_Enalta
        }
        self.hyperparams['LGD'] = hyperparams

    def set_path_rr(self):
        param_T1 = self.clv_data.DataFramesLoaded["roll_ThetaT"]
        param_T2 = self.clv_data.DataFramesLoaded["roll_Theta"]
        param_GroupPD = self.clv_data.DataFramesLoaded["varios_Group_PD"]

        # filtering data
        if self.__terms is not None:
            terms = self.__terms
            param_T1 = param_T1[param_T1['T'].isin(terms)]
            param_GroupPD = param_GroupPD[param_GroupPD['T'].isin(terms)]

        hyperparams = {
            "param_T1": param_T1,
            "param_T2": param_T2,
            "param_GroupPD": param_GroupPD
        }
        self.hyperparams['RR'] = hyperparams

    def set_path_ecap(self):
        param_scalar = self.clv_data.DataFramesLoaded["ecap_scalars"]
        param_PDTTC = self.clv_data.DataFramesLoaded["ecap_PDTTC"]

        hyperparams = {
            "param_scalar": param_scalar,
            "param_PDTTC": param_PDTTC
        }
        self.hyperparams['CAP'] = hyperparams

    def set_path_cost(self):
        param_canalT0 = self.clv_data.DataFramesLoaded["costos_canalT0"]
        param_montoT0 = self.clv_data.DataFramesLoaded["costos_montoT0"]
        param_otrosT0 = self.clv_data.DataFramesLoaded["costos_otrosT0"]
        param_costost = self.clv_data.DataFramesLoaded["costos_t"]

        hyperparams = {
            "param_canalT0": param_canalT0,
            "param_montoT0": param_montoT0,
            "param_otrosT0": param_otrosT0,
            "param_costost": param_costost
        }
        self.hyperparams['COST'] = hyperparams

    def set_path_ing(self):
        param_pmoneda = self.clv_data.DataFramesLoaded["ingresos_portes_moneda"]
        param_psegmento = self.clv_data.DataFramesLoaded["ingresos_portes_segmento"]
        param_seguros = self.clv_data.DataFramesLoaded["ingresos_seguros"]
        # param_penalidad = self.clv_data.DataFramesLoaded["ingresos_pago_atrasado"]
        # param_penalidad_lim = self.clv_data.DataFramesLoaded["ingresos_pago_atrasado_lim"]

        hyperparams = {
            "param_pmoneda": param_pmoneda,
            "param_psegmento": param_psegmento,
            "param_seguros": param_seguros
        }
        self.hyperparams['INOF'] = hyperparams

    def set_path_tt(self):
        param_tasadescuento_tmin = self.clv_data.DataFramesLoaded["descuentos_tasadescuento_tmin"]
        param_tasadescuento_leads = self.clv_data.DataFramesLoaded["descuentos_tasadescuento_leads_subsegmento"]
        param_tt_prepago = self.clv_data.DataFramesLoaded["tt_prepagos"]
        param_tt_factor = self.clv_data.DataFramesLoaded["tt_zdf"]
        param_remcap = self.clv_data.DataFramesLoaded["param_remcap"]
        param_educated_guess = self.clv_data.DataFramesLoaded["educated_initial_guess"]
        #28112023 EVS
        param_indicator_target = self.clv_data.DataFramesLoaded["indicator_target"]

        hyperparams = {
            "param_tasadescuento_tmin": param_tasadescuento_tmin,
            "param_tasadescuento_leads": param_tasadescuento_leads,
            "param_remcap": param_remcap,
            "param_educated_guess": param_educated_guess,
            "param_indicator_target": param_indicator_target,
            "param_tt_prepago": param_tt_prepago,
            "param_tt_factor": param_tt_factor
            }
        self.hyperparams['TT_DSCTO'] = hyperparams

    def set_external_data(self, input_clv):
        param_tt_fact = self.clv_data.set_data_ttzdf(input_clv).DataFramesLoaded["tt_zdf"]
        self.hyperparams['TT_DSCTO']["param_tt_factor"] = param_tt_fact

        param_tt_prepago = self.clv_data.set_data_prepagos(input_clv).DataFramesLoaded["tt_prepagos"]
        self.hyperparams['TT_DSCTO']["param_tt_prepago"] = param_tt_prepago
        return self

class CLVEngine():

    def __init__(self, flag_portafolio=False, data=None):

        terms = data['PLAZO'] if data is not None else None
        setpath = SetPath(terms=terms)
        self.hyperparams = setpath.set_external_data(data).hyperparams if data is not None else setpath.hyperparams

        self.flag_portafolio = flag_portafolio  # True: Ejecuciones modo portafolio
        self.m, self.param, self.ingresos, self.score = None, None, None, None
        self.curves = {
            "PD": None,
            "PRE": None,
            "CAN": None,
            "LGD": None,
            "RR1": None,
            "RR2": None,
            "CAP": None}
        self.X_tr = {
            "PD": None,
            "PRE": None,
            "CAN": None,
            "LGD": None,
            "RR1": None,
            "RR2": None,
            "CAP": None,
            "COST": None,
            "INOF": None,
            "TT_DSCTO": None,
            "descuentos": None,
            "desembolsos": None,
            "INDICATOR_TARGET": None, 
            "r": None,
            "T": None}
        self.curves_instance = {
            "PD": curves.CurvePD(self.hyperparams["PD"], flag_portafolio=flag_portafolio),
            "PRE": curves.CurvePre(self.hyperparams["PRE"]),
            "CAN": curves.CurveCan(self.hyperparams["CAN"]),
            "LGD": curves.CurveLGD(self.hyperparams["LGD"]),
            "RR1": curves.CurveRR1(self.hyperparams["RR"]),
            "RR2": curves.CurveRR2(self.hyperparams["RR"]),
            "CAP": curves.CurveCAP(self.hyperparams["CAP"], flag_portafolio=flag_portafolio),
            "COST": curves.CurveCostos(self.hyperparams["COST"], flag_portafolio=flag_portafolio),
            "INOF": curves.CurvesInoF(self.hyperparams["INOF"]),
            "TT_DSCTO": curves.CurvesTT_Desc(self.hyperparams["TT_DSCTO"]),
        }

    def transform(self, X):
        """ Apply the transform methods of every curve
        """
        X["SCORE"] = ut.np_clip(X["SCORE"].values, 25, 650)

        for key in self.curves_instance:   
            self.X_tr[key] = self.curves_instance[key].transform(X)
        
        # Getting variables for NPV function
        self.X_tr["descuentos"], self.X_tr["descuentos_leads"], self.X_tr["desembolsos"], self.X_tr["r"], self.X_tr[
            "T"] = clv.get_parameters_transform(
            X, self.X_tr["TT_DSCTO"])
        
        # Getting educated guesses for rmin, tea & irr computations
        self.initial_guess_rmin = pow(1 + self.X_tr["TT_DSCTO"]["eg_rmin"].values.reshape(1, -1), 1 / 12) - 1
        self.initial_guess_tea = pow(1 + self.X_tr["TT_DSCTO"]["eg_tea"].values.reshape(1, -1), 1 / 12) - 1
        self.initial_guess_irr = pow(1 + self.X_tr["TT_DSCTO"]["eg_irr"].values.reshape(1, -1), 1 / 12) - 1
        self.m = X.shape[0]

        if 'CODCLAVECIC' in X.columns:
            self.cliente = X["CODCLAVECIC"].values
            self.codclavecic = X["CODCLAVECIC"].values

        if 'REQUEST_ID' in X.columns:
            self.cliente = X["REQUEST_ID"].values
            self.request_id = X["REQUEST_ID"].values

        return self.X_tr

    def predict(self):
        """ Apply the predict methods of every curve
        """
        for key in self.curves:
            # Para la estimacion de la curva de Cancelaciones se usa el punto 12 de la curva de PD Temporal
            if (key == "CAN") | (key == "PRE"):
                self.X_tr[key]["pd_12_temporal"] = self.curves_instance["PD"].pd_12_temporal
            # start=time.time()
            if (key == "CAP") & (self.flag_portafolio == False):  
                # Si no se ejecuta en modo portafolio entonces hay que estimar la PD TTC y LGD TTC
                self.X_tr[key]["LGD_TTC"] = self.curves_instance["LGD"].lgd21
            self.curves[key] = self.curves_instance[key].predict(self.X_tr[key])
            # print(f'++++++++++++++++++++++++++++++++++++curva {key}: {time.time()-start}')

            if (key == "CAN") | (key == "PRE"):
                self.X_tr[key]["factores"] = self.curves_instance[key].factores
      

        return self.curves

    def get_parameters_pv(self):
        """ This function is called by other functions in the class
        Returns: self.param, a parameter for any posterior VAN function
        """
        if self.param is None:
            self.param = clv.get_param(self.X_tr, self.curves, self.curves_instance)

    def get_pv(self):
        """ Returns a array containing the Net Present Value
        """
        self.get_parameters_pv()

        self.pv = clv.van_rmin(
            self.X_tr["descuentos"],
            self.X_tr["desembolsos"],
            self.X_tr["r"],
            self.X_tr["T"],
            self.param)

        return self.pv.reshape(self.m, )

    def get_rmin(self):
        """ Returns a array containing the T_min
        """
        self.get_parameters_pv()
        def funct(x): return clv.van_rmin(
            self.X_tr["descuentos"],
            self.X_tr["desembolsos"],
            x,
            self.X_tr["T"],
            self.param).reshape(
            self.m,
        )
        
        def compute():
            r0 = self.initial_guess_rmin
            tmin = clv.pbroyden(funct, r0)
            return tmin.reshape(self.m, )

        self.rmin = compute()

        return self.rmin

    def get_rmin_leads(self,flag_monitoreo=True):
        """ Returns a array containing the T_min
        """
        if self.param == None: self.get_parameters_pv()
        def funct(x): return clv.roa_rmin(
            #self.X_tr["descuentos_leads"],
            self.X_tr['TT_DSCTO']['INDICATOR_TARGET'].values, #Para ROA
            self.X_tr["desembolsos"],
            x,
            self.X_tr["T"],
            self.param,
            flag_monitoreo=flag_monitoreo).reshape(
            self.m,
        )

        def compute():
            r0 = self.initial_guess_tea
            tea = clv.pbroyden(funct, r0)
            return tea.reshape(self.m, )

        self.tea = compute()

        return self.tea

    def get_irr(self, r=[None], flg_monitoreo=False):
        """ Returns a array containing the Internal Interest Rate
        Parameters:
        >> r: Interest Rate of the loan
        """
        if self.param is None: self.get_parameters_pv()
        if r[0] == None: r = self.X_tr["r"]

        def funct(x): return clv.van_irr(
            x,
            self.X_tr["desembolsos"],
            r,
            self.X_tr["T"],
            self.param, flag_monitoreo=flg_monitoreo).reshape(
            self.m,
        )

        def compute():
            d0 = self.initial_guess_irr
            tirs = clv.pbroyden(funct, d0)
            return tirs.reshape(self.m, )

        self.irr = compute()

        return self.irr


    def get_leads_variables(self, X):
        """ This function is called by other functions in the class.
        Save attributes for a given leads exercise.
        """
        self.score_post_covid = X["SCORE_POST_COVID"].values
        flag_pdh = X["FLG_PDH"].values
        self.flag_pdh = ut.transf_flag_pdh(flag_pdh)
        self.cliente = X["CODCLAVECIC"].values
        self.campana = X["TIPCAMPANA"].values
        self.menores300 = X["SCORE"].values < 300


    def get_interestRates_leads(self):
        """ 
        Returns: 
        >>> Pandas DataFrame with one-to-one interest rates as final prices
        >>> Numpy array of final one-to-one client interest rates with business rules
        >>> Numpy array of true Rmin without business rules
        """
        rmins_mensual = self.get_rmin_leads()  # Tmin mensual sin reglas de negocio
        rmins = pow((1 + rmins_mensual), 12) - 1  # Se anualiza la Tmin
        tasas_propuestas = ut.reglas_de_negocio(rmins, self.flag_pdh)

        tasas_propuestas[self.menores300] = 0.429

        df_tasas = DataFrame()
        df_tasas["CODCLAVECIC"] = self.cliente
        df_tasas["CAMPANA"] = self.campana  # Tipo de Campana
        df_tasas["TasaPropuesta"] = tasas_propuestas

        return df_tasas, tasas_propuestas, rmins_mensual


    def get_iterations_TEA_VAN_WTP(self, head):
        """ Genera iteraciones que sirven de input al WTP de CEF
            - Itera 10 veces 100 pbs la tasa hacia arriba y hacia abajo (20 iteraciones + escenario base)

            Returns:
            A pandas dataframe with 4 columns: CODCLAVECIC, TEA, Net Present Value, Yearly CF
        """
        if self.param == None: self.get_parameters_pv()

        pv = self.get_pv()
        df = DataFrame(self.cliente.reshape(self.m, ), columns=["CODCLAVECIC"])
        tasa_anual = pow(1 + self.X_tr["r"], 12) - 1
        TEA_name = "TEA" + str(head)
        VAN_name = "VAN" + str(head)
        df[TEA_name] = tasa_anual.reshape(self.m, )
        df[VAN_name] = pv.reshape(self.m, )

        return df


    def get_profitability_indicators(self):

        if self.param == None: self.get_parameters_pv()

        self.get_rmin()
        self.get_irr(flg_monitoreo=True)

        df1 = DataFrame({
            "CODCLAVECIC": self.cliente.reshape(self.m, ),
            "TEA": (pow(1 + self.X_tr["r"], 12) - 1).reshape(self.m, ),
            "Tmin": (pow(1 + self.rmin, 12) - 1).reshape(self.m, )
        })

        dict_comp = ["NPV", "ROE", "ECAP", "Net Profit", "ROA", "Avg Balance"]
        df2 = self.get_components(self.X_tr["r"], self.X_tr["descuentos"], dict_comp, r_report="Base", flg_monitoreo=True)
        df2.rename(columns={"NPV": "VAN", "Net Profit": "UtilidadAnual"}, inplace=True)

        df = concat([df1, df2], axis=1)
        df.insert(3, "TIR", pow(1 + self.irr, 12) - 1)

        return df

    def get_components(self, r, discount, dict_comp, r_report="Base", flg_monitoreo=False):
        df = clv.get_components(discount, self.X_tr["desembolsos"], r, self.X_tr["T"], self.param, dict_comp, r_report, flg_monitoreo)
        return df

    def getMinRate(self):

        self.get_parameters_pv()
        self.get_rmin()

        df = DataFrame({
            "REQUEST_ID": self.request_id,
            "Min_Rate": pow(1 + self.rmin, 12) - 1,
            "Target_IRR": (pow(1 + self.X_tr["descuentos"], 12) - 1).reshape(-1, )
        })

        return df

    def getAggProfitability(self):
        
        self.get_parameters_pv()
        self.get_rmin_leads(flag_monitoreo=False)
        b_null = ut.np_isnan(self.tea)
        self.tea[b_null] = (1 + 0.995)**(1/12) - 1
        self.tea = ut.np_clip(self.tea, (1 + 0.01)**(1/12) - 1, (1 + 0.995)**(1/12) - 1)

        df1 = DataFrame({
            "Min_Rate": pow(1 + self.tea, 12) - 1,
            #"Target_IRR": (pow(1 + self.X_tr["descuentos_leads"], 12) - 1).reshape(-1,)
            "Target_IRR": self.X_tr['TT_DSCTO']['INDICATOR_TARGET'].values
        })

        self.get_irr(r=self.tea)

        b_null = ut.np_isnan(self.irr)
        self.irr[b_null] = (1 + 1)**(1/12) - 1
        self.irr = ut.np_clip(self.irr, (1 - 1)**(1/12) - 1, (1 + 1)**(1/12) - 1)

        dict_comp = [
            "Interest Income", "Cost of Funds", "NPV", "ROA", "ROE", "Net Profit",
            "ECAP", "Loss Rate", "Avg Balance"
        ]

        df2 = self.get_components(self.tea, self.X_tr["descuentos"], dict_comp)
        df2["IRR"] = (pow(1 + self.irr, 12) - 1).reshape(-1,)
        
        df = concat((df1, df2), axis=1)
        df["REQUEST_ID"] = self.request_id
        
        return df

    def getMinRateAggProfitability(self):
        
        self.get_parameters_pv()
        
        
        self.get_rmin()
        

        
        b_null = ut.np_isnan(self.rmin)
        self.rmin[b_null] = (1 + 0.429) ** (1 / 12) - 1
        self.rmin = ut.np_clip(self.rmin, (1 + 0.01) ** (1 / 12) - 1, (1 + 0.429) ** (1 / 12) - 1)

        df1 = DataFrame({
            "Min_Rate": pow(1 + self.rmin, 12) - 1,
            "Target_IRR": (pow(1 + self.X_tr["descuentos"], 12) - 1).reshape(-1, )
        })

        dict_comp = [
            "Interest Income", "Cost of Funds", "NPV", "ROA", "ROE", "Net Profit",
            "ECAP", "Loss Rate", "Avg Balance"
        ]

        df2 = self.get_components(self.rmin, self.X_tr["descuentos"], dict_comp)

        df = concat((df1, df2), axis=1)
        df["REQUEST_ID"] = self.request_id
        
        return df

    def getDetailProfitability(self):

        self.get_parameters_pv()

        self.get_irr()
        b_null = ut.np_isnan(self.irr)
        self.irr[b_null] = (1 + 1) ** (1 / 12) - 1
        self.irr = ut.np_clip(self.irr, (1 - 1) ** (1 / 12) - 1, (1 + 1) ** (1 / 12) - 1)
        dict_comp = [
            "Interest Income", "Cost of Funds", "NPV", "ROA", "ROE", "Net Profit",
            "ECAP", "Loss Rate", "Avg Balance", "Avg Balance - Y", "Capital Flow - Y", "Capital Remuneration - Y", "Interest Income - Y",
            "Non Financial Income - Y", "Cost of Funds - Y", "Losses - Y", "Direct Costs - Y", "Indirect Costs - Y",
            "Income Tax - Y", "Capital Flow NPV - Y", "Capital Remuneration NPV - Y",
            "Interest Income NPV - Y", "Non Financial Income NPV - Y", "Cost of Funds NPV - Y",
            "Losses NPV - Y", "Direct Costs NPV - Y", "Income Tax NPV - Y"
        ]
        df = self.get_components(self.X_tr["r"], self.X_tr["descuentos"], dict_comp)
        df["IRR"] = (pow(1 + self.irr, 12) - 1).reshape(-1, )
        df["REQUEST_ID"] = self.request_id
        return df

    def getMinRateDetailProfitability(self):

        self.get_parameters_pv()
        self.get_rmin()

        b_null = ut.np_isnan(self.rmin)
        self.rmin[b_null] = (1 + 0.429) ** (1 / 12) - 1
        self.rmin = ut.np_clip(self.rmin, (1 + 0.01) ** (1 / 12) - 1, (1 + 0.429) ** (1 / 12) - 1)

        df1 = DataFrame({
            "REQUEST_ID": self.request_id,
            "Min_Rate": pow(1 + self.rmin, 12) - 1,
            "Target_IRR": (pow(1 + self.X_tr["descuentos"], 12) - 1).reshape(-1, )
        })

        dict_comp = [
            "Interest Income", "Cost of Funds", "NPV", "ROA", "ROE", "Net Profit",
            "ECAP", "Loss Rate", "Avg Balance", "Avg Balance - Y", "Capital Flow - Y", "Capital Remuneration - Y", "Interest Income - Y",
            "Non Financial Income - Y", "Cost of Funds - Y", "Losses - Y", "Direct Costs - Y", "Indirect Costs - Y",
            "Income Tax - Y", "Capital Flow NPV - Y", "Capital Remuneration NPV - Y",
            "Interest Income NPV - Y", "Non Financial Income NPV - Y", "Cost of Funds NPV - Y",
            "Losses NPV - Y", "Direct Costs NPV - Y", "Income Tax NPV - Y"
        ]

        df2 = self.get_components(self.rmin, self.X_tr["descuentos"], dict_comp)

        df = concat((df1, df2), axis=1)

        return df

    def getCLVCurves(self):

        self.get_parameters_pv()

        dict_comp = [
            "PD Curve", "PRE Curve", "CAN Curve", "Saldo Curve", "IF Curve", "EF Curve"
        ]

        df = self.get_components(self.X_tr["r"], self.X_tr["descuentos"], dict_comp)
        df['REQUEST_ID'] = self.request_id

        return df

    def getAllOutputs(self):

        self.get_parameters_pv()
        self.get_rmin()
        # self.get_rmin_leads()

        b_null = ut.np_isnan(self.rmin)
        self.rmin[b_null] = (1 + 0.429)**(1/12) - 1
        self.rmin = ut.np_clip(self.rmin, (1 + 0.01)**(1/12) - 1, (1 + 0.429)**(1/12) - 1)

        self.get_irr(flg_monitoreo=False)
        b_null = ut.np_isnan(self.irr)
        self.irr[b_null] = (1 + 1)**(1/12) - 1
        self.irr = ut.np_clip(self.irr, (1 - 1)**(1/12) - 1, (1 + 1)**(1/12) - 1)

        df1 = DataFrame({
            "REQUEST_ID": self.request_id,
            "Min_Rate": pow(1+ self.rmin, 12) - 1,
            "Target_IRR": (pow(1 + self.X_tr["descuentos"], 12) - 1).reshape(-1,)
            })


        dict_comp = [
            "Interest Income", "Cost of Funds", "NPV", "ROA", "ROE", "Net Profit",
            "ECAP", "Loss Rate", "Avg Balance", "Avg Balance - Y", "Capital Flow - Y", "Capital Remuneration - Y", "Interest Income - Y",
            "Non Financial Income - Y", "Cost of Funds - Y", "Losses - Y", "Direct Costs - Y", "Indirect Costs - Y",
            "Income Tax - Y", "Capital Flow NPV - Y", "Capital Remuneration NPV - Y",
            "Interest Income NPV - Y", "Non Financial Income NPV - Y", "Cost of Funds NPV - Y",
            "Losses NPV - Y", "Direct Costs NPV - Y", "Income Tax NPV - Y",
            "PD Curve", "PRE Curve", "CAN Curve", "Saldo Curve", "IF Curve", "EF Curve"
        ]

        df2 = self.get_components(self.X_tr["r"], self.X_tr["descuentos"], dict_comp, flg_monitoreo=False)

        df = concat((df1, df2), axis=1)

        df["IRR"] = (pow(1 + self.irr, 12) - 1).reshape(-1,)

        # Impacto en PD
        param_pd_aux = self.param["cif_PD"]
        param_pd_aux_tir = self.param["PD"]
        self.param["cif_PD"] = self.param["cif_PD"] * 1.1
        self.param["PD"] = self.param["PD"] * 1.1
        df["PD_MinRate"] = pow(1 + self.get_rmin(), 12) - 1
        df["PD_IRR"] = pow(1 + self.get_irr(flg_monitoreo=False), 12) - 1

        self.param["cif_PD"] = param_pd_aux
        self.param["PD"] = param_pd_aux_tir

        # Impacto en PRE 
        param_pre_aux = self.param["pre"]
        param_pre_aux_tir = self.param["PRE"]
        self.param["pre"] = curves.CurvePre(self.hyperparams["PRE"], impacto=1.1)
        self.param["PRE"] = self.param["PRE"] * 1.1

        df["PRE_MinRate"] = pow(1 + self.get_rmin(), 12) - 1
        df["PRE_IRR"] = pow(1 + self.get_irr(flg_monitoreo = False), 12) - 1

        self.param["pre"] = param_pre_aux
        self.param["PRE"] = param_pre_aux_tir
        # Impacto en CAN
        self.param["can"] = curves.CurveCan(self.hyperparams["CAN"], impacto=1.1)
        self.param["cif_CAN"] = self.param["cif_CAN"] * 1.1
        self.param["CAN"] = self.param["CAN"] * 1.1

        df["CAN_MinRate"] = pow(1 + self.get_rmin(), 12) - 1
        df["CAN_IRR"]  = pow(1 + self.get_irr(flg_monitoreo = False), 12) - 1

        # Limpiando observaciones con errores
        b_drop = (df['IRR'] > 4) | (df['IRR'] < -1) | (df['Min_Rate'] > 4) | (df['PD_IRR'] > 4) | (df['PD_IRR'] < -1) | (df['PD_MinRate'] > 4) \
            | (df['PRE_IRR'] > 4) | (df['PRE_IRR'] < -1) | (df['PRE_MinRate'] > 4) | (df['CAN_IRR'] > 4) | (df['CAN_IRR'] < -1) | (df['CAN_MinRate'] > 4)

        df.drop(df[b_drop].index, inplace=True)
        df.dropna(inplace=True)

        return df

    def pauta(self):

        self.get_parameters_pv()
        self.get_rmin()
        self.get_irr()

        df = DataFrame()
        df["Tmin"] = (pow(1 + self.rmin, 12) - 1).reshape(-1, )
        df["IRR"] = (pow(1 + self.irr, 12) - 1).reshape(-1, )
        dict_comp_base = ["Net Present Value", "Saldo Remanente", "Margen Financiero", "Provisiones"]
        df_comp2 = self.get_components(self.X_tr["r"], self.X_tr["descuentos"], dict_comp_base, "Base")
        df = concat([df, df_comp2], axis=1)

        return df
    def get_profitability_datamart(self, input, flg_monitoreo):

        self.transform(input)
        self.predict()
        self.get_parameters_pv()

        #Calcular tmin
        self.get_rmin()
        
        #Calcular tir
        self.get_irr(flg_monitoreo=flg_monitoreo)

        #Calcular componentes
        dict_comp_r_base = ["NPV", "Net Profit", "ROE", "ECAP", "ROA", "Avg Balance", "Margen Neto"]
        dict_comp_r_min = ["Descomposicion VAN"]

        df_comp_r_base = self.get_components(r=self.X_tr["r"], discount=self.X_tr["descuentos"], dict_comp=dict_comp_r_base, flg_monitoreo=flg_monitoreo)
        df_comp_r_min = self.get_components(r=self.rmin, discount=self.X_tr["descuentos"], dict_comp=dict_comp_r_min, flg_monitoreo=flg_monitoreo)

        df_dict = DataFrame({
            "CODMES": input["CODMES"],
            "FECHA": input["FECHA"],
            "CODCLAVEOPECTA": input["CODCLAVEOPECTA"],
            "TEA": input["TEA"].values,
            "RMIN": (pow(1 + self.rmin, 12) - 1).reshape(-1,),
            "TARGET_IRR_TMIN": (pow(1 + self.X_tr["descuentos"], 12) - 1).reshape(-1,)
        })

        df = concat((df_dict, df_comp_r_base, df_comp_r_min), axis=1)

        return df
