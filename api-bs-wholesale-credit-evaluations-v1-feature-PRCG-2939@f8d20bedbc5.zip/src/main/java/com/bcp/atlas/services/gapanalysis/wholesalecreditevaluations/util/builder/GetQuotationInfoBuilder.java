package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.ConstitutedGuarantee;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Currency;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Exception;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.NewGuarantee;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationInfoResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Quotation;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.GetQuotationInfoEntity;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.Util;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import org.springframework.stereotype.Component;

/**
 * <b>Class</b>: GetQuotationInfoBuilder<br/>
 * <b>Copyright</b>: &copy; 2018 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         2 <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Jul 26 2019 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Component
public class GetQuotationInfoBuilder {


  /**
   * Method getQuotationInfo()
   *
   * @version 1.0
   */
  public static PricingWholesaleQuotationInfoResponse
      getQuotationInfo(List<GetQuotationInfoEntity> quotationInfoList) {

    Quotation quotation = new Quotation();
    HashSet<ConstitutedGuarantee> constitutedGuarantees = new HashSet<>();
    HashSet<NewGuarantee> newGuarantees = new HashSet<>();
    HashSet<Exception> exceptions = new HashSet<>();

    if (!quotationInfoList.isEmpty()) {

      quotation.setQuotationId(quotationInfoList.get(0).getQuotationId());
      quotation.setTioaux(quotationInfoList.get(0).getCreditInfoCpProductCode());

      Currency currency = new Currency();
      currency.setCode(
          Currency.CodeEnum.valueOf(
              quotationInfoList.get(0).getCreditInfoCpCurrencyCode()));
      currency.setDescription(
          Currency.DescriptionEnum.valueOf(
              quotationInfoList.get(0).getCreditInfoCpCurrencyDescription()));
      quotation.setCurrency(currency);

      quotation.setAmount(quotationInfoList.get(0).getCreditInfoCpLoanAmount());
      quotation.setTerm(quotationInfoList.get(0).getCreditInfoCpTerm());
      quotation.setTransRate(quotationInfoList.get(0).getTransferRate());
      quotation.setDate(String.valueOf(quotationInfoList.get(0).getRegisterDate()));
      quotation.setType(quotationInfoList.get(0).getCreditInfoCpOperationType());

      quotation.setSpecificDebt(quotationInfoList.get(0).getCustomerInfoSpecificDebt());
      quotation.setSpecificDebtDleace(quotationInfoList.get(0).getCustomerInfoSpecificDebtDleace());
      quotation.setLoanRenewal(quotationInfoList.get(0).getCreditInfoCpLoanRenewal());
      quotation.setRateType(quotationInfoList.get(0).getCreditInfoCpRateType());
      quotation.setDueDate(Util.formatStringToDate(quotationInfoList.get(0).getDueDate(),
                                                   Constantes.FECHA_YYYY_MM_DD));

      quotation.setSpecialRate(quotationInfoList.get(0).getSpecialRate());
      quotation.setOperationalCost(quotationInfoList.get(0).getOperationalCost());
      quotation.setExpectedLoss(quotationInfoList.get(0).getExpectedLoss());
      quotation.setCapitalReturn(quotationInfoList.get(0).getCapitalReturn());
      quotation.setBusinessSpread(quotationInfoList.get(0).getBusinessSpread());
      quotation.setMfa(quotationInfoList.get(0).getAlexandriaMfa());
      quotation.setMinimalRate(quotationInfoList.get(0).getMinimalRate());
      quotation.setInterestRate(quotationInfoList.get(0).getInterestRate());

      quotation.setRoe(quotationInfoList.get(0).getRoe());
      quotation.setRarorac(quotationInfoList.get(0).getRarorac());

      quotationInfoList.forEach(item -> {

        Exception exception = new Exception();
        exception.setRoleId(item.getRoleId());
        exception.setRoleDescription(item.getRolDescription());
        exception.setFromRate(item.getFromRate());
        exception.setTypeExcepction(
            Exception.TypeExcepctionEnum.fromValue(item.getTypeException()));
        exceptions.add(exception);
        quotation.setExceptions(new ArrayList<>(exceptions));

        ConstitutedGuarantee guaranteeAlexandria = new ConstitutedGuarantee();
        guaranteeAlexandria.setGuaranteeType(item.getContitutedGuaranteetype());
        guaranteeAlexandria.setGuaranteeSubType(item.getContitutedGuaranteesubtype());
        guaranteeAlexandria.setFeeTradeAmount(item.getFeeTradeAmount());
        guaranteeAlexandria.setAffectedAmount(item.getAmountAffected());
        guaranteeAlexandria.setExecutedAmount(item.getAmountExecuted());
        constitutedGuarantees.add(guaranteeAlexandria);

        NewGuarantee newGuarantee = new NewGuarantee();
        newGuarantee.setGuarantorIdc(item.getGuarantorInfoIdc());
        newGuarantee.setGuarantorRating(item.getClassificationRatingCode());
        newGuarantee.setGuaranteeType(item.getWrWarrantyType());
        newGuarantee.setGuaranteeSubType(item.getWrWarrantyCode());
        newGuarantee.setFeeTradeAmount(item.getWrCommercialValue());
        newGuarantee.setAffectedAmount(item.getWrRealizationValue());
        newGuarantee.setExecutedAmount(item.getWrAffectedValue());
        newGuarantees.add(newGuarantee);

      });
    }


    PricingWholesaleQuotationInfoResponse quotationInfoResponse
        = new PricingWholesaleQuotationInfoResponse();
    quotationInfoResponse.setQuotation(quotation);
    quotationInfoResponse.setNewGuarantees(new ArrayList<>(newGuarantees));
    quotationInfoResponse.setConstitutedGuarantees(new ArrayList<>(constitutedGuarantees));

    return quotationInfoResponse;
  }

}
