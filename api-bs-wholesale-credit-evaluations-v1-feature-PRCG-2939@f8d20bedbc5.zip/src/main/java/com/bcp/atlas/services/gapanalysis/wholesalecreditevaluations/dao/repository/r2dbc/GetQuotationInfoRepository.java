package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.repository.r2dbc;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.GetQuotationInfoEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * <b>Class</b>: LeadsRepository.java <br/>
 * <b>Copyright</b>: &copy; 2020 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u> Service Provider: Everis Perú SAC (EVE)</u>: <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>Neil Llique Mesía From (EVE)</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>2020-10-14 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Repository
public interface GetQuotationInfoRepository extends JpaRepository<GetQuotationInfoEntity, Integer> {
  @Query(value = "exec [prcg_mayorista].[sp_search_by_quotation_number]"
      + " @quotation_number = :quotationNumber", nativeQuery = true)
  List<GetQuotationInfoEntity> searchByQuotationNumber(
      @Param("quotationNumber") String quotationNumber);
}
