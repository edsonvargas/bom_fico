package com.bcp.atlas.services.gapanalysis.config;

import com.bcp.atlas.core.http.annotation.HttpComponentScan;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import io.vavr.Tuple3;
import java.util.HashMap;
import java.util.Map;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * <b>Class</b>: ErrorHandlerConfiguration.java <br/>
 * <b>Copyright</b>: &copy; 2020 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u> Service Provider: Everis Perú SAC (EVE)</u>: <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>2020-08-01 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */

@Configuration
@HttpComponentScan(
    basePackages = {"com.bcp.atlas.services.gapanalysis"})
public class ErrorHandlerConfiguration {

  /**
   * Method errorCategoriesMap
   *
   * @version 1.0
   */
  @Bean
  public  Map<Integer, Tuple3<String, String,String>>  errorCategoriesMap() {

    Map<Integer, Tuple3<String,String, String>> errorCodeFicoDm = new HashMap<>();

    errorCodeFicoDm.put(400, new Tuple3<>("INVALID_REQUEST",
                                          Constantes.ERROR_CODE_PR0002,
                                          Constantes.MESSAGE_ERROR_400));
    errorCodeFicoDm.put(401, new Tuple3<>("UNAUTHORIZED",Constantes.ERROR_CODE_PR0003,
                                          Constantes.MESSAGE_ERROR_401));
    errorCodeFicoDm.put(403, new Tuple3<>("FORBIDDEN",Constantes.ERROR_CODE_PR0004,
                                          Constantes.MESSAGE_ERROR_403));
    errorCodeFicoDm.put(404, new Tuple3<>("RESOURCE_NOT_FOUND",Constantes.ERROR_CODE_PR0005,
                                          Constantes.MESSAGE_ERROR_404));
    errorCodeFicoDm.put(409, new Tuple3<>("CONFLICT",Constantes.ERROR_CODE_PR0006,
                                          Constantes.MESSAGE_ERROR_409));
    errorCodeFicoDm.put(412, new Tuple3<>("PRECONDITION_FAILED",Constantes.ERROR_CODE_PR0007,
                                          Constantes.MESSAGE_ERROR_412));
    errorCodeFicoDm.put(503, new Tuple3<>("SERVICE_UNAVAILABLE",Constantes.ERROR_CODE_PR0008,
                                          Constantes.MESSAGE_ERROR_503));
    errorCodeFicoDm.put(408, new Tuple3<>("EXTERNAL_TIMEOUT",Constantes.ERROR_CODE_PR0009,
                                          Constantes.MESSAGE_ERROR_408));
    errorCodeFicoDm.put(500, new Tuple3<>("UNEXPECTED",Constantes.ERROR_CODE_PR0010,
                                          Constantes.MESSAGE_ERROR_500));

    return errorCodeFicoDm;
  }

}
