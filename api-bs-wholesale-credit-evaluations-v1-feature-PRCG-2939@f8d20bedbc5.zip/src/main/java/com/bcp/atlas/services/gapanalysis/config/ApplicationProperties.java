package com.bcp.atlas.services.gapanalysis.config;


import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

/**
 * <br/>
 * <b>Class</b>: AlwaysEncryptedProperties<br/>
 * <b>Copyright</b>: &copy; 2020 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 * <u>CosmosDbConfiguration</u>: BCP <br/>
 * <u>Developed by</u>: <br/>
 * <ul>
 * <li>Fernando Supo</li>
 * </ul>
 * <u>Changes</u>:<br/>
 * <ul>
 * <li>May 19, 2023 Creaci&oacute;n de Clase.</li>
 * </ul>
 * @version 1.0
 */
@Configuration
@Getter
@Setter
@Lazy
public class ApplicationProperties {

  @NotNull
  @Value("${query.timeout.seconds}")
  private Long queryTimeoutInSeconds;

}
