package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.Guarantee;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.MapperUtils;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ResponseBuilderTest {
  @Test
  void whenResponseBuilderDefaultTest() {

    Integer reqId = 1;

    CustomerGetResponse customerGetResponse =
        MapperUtils.convertToObject("AlexandriaResponse" + ".json", CustomerGetResponse.class);

    PricingWholesaleResponse pricingWholesaleResponse =
        MapperUtils.convertToObject("ResponseWholFinal" + ".json", PricingWholesaleResponse.class);
    Request request = MapperUtils.convertToObject("RequestApi" + ".json", Request.class);
    List<Guarantee> guarantees = new ArrayList<>();
    guarantees.add(MapperUtils.convertToObject("Guarantee" + ".json", Guarantee.class));

    Assertions.assertNotNull(
        ResponseBuilder.generateDbObjectExceptionRole(reqId, pricingWholesaleResponse));
    Assertions.assertNotNull(
        ResponseBuilder.generateDbObjectResponse(
            reqId, pricingWholesaleResponse, customerGetResponse));
    Assertions.assertNotNull(ResponseBuilder.generateDbObjectGuarantee(reqId, guarantees));
  }
}
