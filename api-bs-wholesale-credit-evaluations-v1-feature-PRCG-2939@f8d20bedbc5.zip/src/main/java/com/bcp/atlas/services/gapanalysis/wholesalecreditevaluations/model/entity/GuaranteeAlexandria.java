package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

/**
 * <b>Class</b>: GuaranteeAlexandria.java <br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Ago 1, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Data
@Entity
@Table(name = "guarantees_alexandria",schema = "prcg_mayorista")
public class GuaranteeAlexandria {


  @Column(name = "guarantee_id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Id
  private Integer guaranteeId;

  @Column(name = "guarantee_product_code")
  private String guaranteeProductCode;

  @Column(name = "guarantee_scope_code")
  private String guaranteeScopeCode;

  @Column(name = "minimum_amount_used")
  private BigDecimal minimumAmountUsed;

  @Column(name = "credit_info_cp_req_id")
  private Integer creditInfoCpReqId;

  @Column(name = "register_date")
  private LocalDateTime registerDate;

  @Column(name = "fee_trade_amount")
  private BigDecimal feeTradeAmount;

  @Column(name = "amount_affected")
  private BigDecimal amountAffected;

  @Column(name = "amount_executed")
  private BigDecimal amountExecuted;

}
