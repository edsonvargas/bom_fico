package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import lombok.Data;

/**
 * <b>Class</b>: Product.java <br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Ago 1, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Data
@Entity
@IdClass(GetQuotationInfoEntityPk.class)
public class GetQuotationInfoEntity {

  @Column(name = "quotation_id")
  @Id
  private Integer quotationId;

  @Column(name = "credit_info_cp_product_code")
  private String creditInfoCpProductCode;

  @Column(name = "credit_info_cp_currency_code")
  private String creditInfoCpCurrencyCode;

  @Column(name = "credit_info_cp_currency_description")
  private String creditInfoCpCurrencyDescription;

  @Column(name = "credit_info_cp_loan_amount")
  private BigDecimal creditInfoCpLoanAmount;

  @Column(name = "credit_info_cp_term")
  private Integer creditInfoCpTerm;

  @Column(name = "transfer_rate")
  private BigDecimal transferRate;

  @Column(name = "register_date")
  private LocalDateTime registerDate;

  @Column(name = "credit_info_cp_operation_type")
  private String creditInfoCpOperationType;

  @Column(name = "customer_info_specific_debt")
  private BigDecimal customerInfoSpecificDebt;

  @Column(name = "customer_info_specific_debt_dleace")
  private BigDecimal customerInfoSpecificDebtDleace;

  @Column(name = "credit_info_cp_loan_renewal")
  private BigDecimal creditInfoCpLoanRenewal;

  @Column(name = "credit_info_cp_rate_type")
  private String creditInfoCpRateType;

  @Column(name = "due_date")
  private String dueDate;

  @Column(name = "special_rate")
  private BigDecimal specialRate;

  @Column(name = "operational_cost")
  private BigDecimal operationalCost;

  @Column(name = "expected_loss")
  private BigDecimal expectedLoss;

  @Column(name = "capital_return")
  private BigDecimal capitalReturn;

  @Column(name = "business_spread")
  private BigDecimal businessSpread;

  @Column(name = "alexandria_mfa")
  private BigDecimal alexandriaMfa;

  @Column(name = "minimal_rate")
  private BigDecimal minimalRate;

  @Column(name = "interest_rate")
  private BigDecimal interestRate;

  @Column(name = "role_id")
  private Integer roleId;

  @Column(name = "rol_description")
  private String rolDescription;

  @Column(name = "type_exception")
  private String typeException;

  @Column(name = "from_rate")
  private BigDecimal fromRate;

  @Column(name = "roe")
  private BigDecimal roe;

  @Column(name = "rarorac")
  private BigDecimal rarorac;

  @Column(name = "contituted_guaranteetype")
  private String contitutedGuaranteetype;

  @Column(name = "contituted_guaranteesubtype")
  private String contitutedGuaranteesubtype;

  @Column(name = "contituted_fee_trade_amount")
  private BigDecimal feeTradeAmount;

  @Column(name = "contituted_amount_affected")
  private BigDecimal amountAffected;

  @Column(name = "contituted_amount_executed")
  private BigDecimal amountExecuted;


  @Column(name = "wr_warranty_type")
  private String wrWarrantyType;

  @Column(name = "wr_warranties_code")
  private String wrWarrantyCode;

  @Column(name = "wr_commercial_value")
  private BigDecimal wrCommercialValue;

  @Column(name = "wr_realization_value")
  private BigDecimal wrRealizationValue;

  @Column(name = "wr_affected_value")
  private BigDecimal wrAffectedValue;

  @Column(name = "guarantor_idc")
  private String guarantorInfoIdc;

  @Column(name = "guarantor_rating")
  private String classificationRatingCode;



}
