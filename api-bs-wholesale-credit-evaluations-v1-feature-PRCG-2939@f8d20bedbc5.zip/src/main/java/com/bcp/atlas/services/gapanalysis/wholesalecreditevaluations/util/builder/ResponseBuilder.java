package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;


import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.Guarantee;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CreditInfoCpResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExceptionRole;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.GuaranteeAlexandria;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;



/**
 * <br/>
 * Clase Interfaz del Servicio para la logica de negocio que consumira la clase REST
 * RateCalculationController<br/>
 * <b>Class</b>: FicoRequest<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Mar 25, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Component
@Slf4j
public class ResponseBuilder {

  /**
   * Method getIncentives()
   *
   * @version 1.0
   */
  public static List<ExceptionRole> generateDbObjectExceptionRole(
          Integer reqId, PricingWholesaleResponse finalResponse) {
    List<ExceptionRole> exceptionRolesList = new ArrayList<>();
    for (int i = 0; i < finalResponse.getExceptions().size(); i++) {
      ExceptionRole exceptionRole = new ExceptionRole();
      exceptionRole.setCreditInfoCpReqId(reqId);
      exceptionRole.setRoleId(finalResponse.getExceptions().get(i).getRoleId());
      exceptionRole.setRolDescription(finalResponse.getExceptions().get(i).getRoleDescription());
      exceptionRole.setTypeException(finalResponse.getExceptions().get(i).getTypeExcepction().getValue());
      exceptionRole.setFromRate(finalResponse.getExceptions().get(i).getFromRate());
      exceptionRole.setRegisterDate(LocalDateTime.now());
      exceptionRolesList.add(exceptionRole);
    }

    return exceptionRolesList;
  }

  /**
   * Method generateDbObjectGuarantee()
   *
   * @version 1.0
   */
  public static List<GuaranteeAlexandria> generateDbObjectGuarantee(
      Integer reqId, List<Guarantee> guarantees) {
    List<GuaranteeAlexandria> guaranteeDbList = new ArrayList<>();
    guarantees.forEach(item -> {
      GuaranteeAlexandria guaranteeAlexandria = new GuaranteeAlexandria();
      guaranteeAlexandria.setCreditInfoCpReqId(reqId);
      guaranteeAlexandria
          .setGuaranteeProductCode(item.getGuaranteeProduct().getGuaranteeProductCode());
      guaranteeAlexandria
            .setGuaranteeScopeCode(item.getGuaranteeScope().getGuaranteeScopeCode());
      guaranteeAlexandria
          .setMinimumAmountUsed(item.getMinimumAmountUsed());
      guaranteeAlexandria.setRegisterDate(LocalDateTime.now());
      guaranteeAlexandria.setFeeTradeAmount(item.getFeeTradeAmount());
      guaranteeAlexandria.setAmountAffected(item.getAmountAffected());
      guaranteeAlexandria.setAmountExecuted(item.getAmountExecuted());

      guaranteeDbList.add(guaranteeAlexandria);
    });
    return guaranteeDbList;

  }


  /**
   * Method generateDbObjectResponse()
   *
   * @version 1.0
   */
  public static CreditInfoCpResponse generateDbObjectResponse(
          Integer reqId,
          PricingWholesaleResponse finalResponse,
          CustomerGetResponse alexandriaResponse) {
    CreditInfoCpResponse creditInfoCpResponse = new CreditInfoCpResponse();
    creditInfoCpResponse.setCreditInfoCpReqId(reqId);
    creditInfoCpResponse.setTransferRate(finalResponse.getTransferRate());
    creditInfoCpResponse.setOperationalCost(finalResponse.getOperationalCost());
    creditInfoCpResponse.setCapitalReturn(finalResponse.getCapitalReturn());
    creditInfoCpResponse.setBusinessSpread(finalResponse.getBusinessSpread());
    creditInfoCpResponse.setExpectedLoss(finalResponse.getExpectedLoss());
    creditInfoCpResponse.setMinimalRate(finalResponse.getMinimalRate());

    if (Objects.nonNull(alexandriaResponse.getCustomerId())) {
      creditInfoCpResponse.setAlexandriaMfa(
          alexandriaResponse.getRatio().getActiveFinancialMarginRatio());
      creditInfoCpResponse.setClassificationRatingCode(
          alexandriaResponse.getRisk().getClassificationRating().getClassificationRatingCode());
    }

    creditInfoCpResponse.setRegisterDate(LocalDateTime.now());
    creditInfoCpResponse.setRoe(finalResponse.getRoe());
    creditInfoCpResponse.setRarorac(finalResponse.getRarorac());
    creditInfoCpResponse.setDueDate(finalResponse.getDueDate());
    return creditInfoCpResponse;
  }

}
