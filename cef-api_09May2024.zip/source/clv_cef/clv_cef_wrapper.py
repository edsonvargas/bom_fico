class ClvCefWrapper(object):
    is_batch_process = False

    def __format_result(self, clv_result):
        from pandas import DataFrame, concat
        
        columns_outputs = ['Min_Rate', 'Interest_Income', 'Cost_of_Funds', 'NPV',
                           'IRR', 'ROA', 'ROE', 'Net_Profit', 'ECAP',
                           'Loss_Rate', 'Avg_Balance', 'Avg_Balance_Yr1', 'Avg_Balance_Yr2', 'Avg_Balance_Yr3',
                           'Avg_Balance_Yr4', 'Avg_Balance_Yr5', 'Target_IRR', 'Capital_Flow_Yr1',
                           'Capital_Remuneration_Yr1', 'Interest_Income_Yr1',
                           'Non_Financial_Income_Yr1', 'Cost_of_Funds_Yr1', 'Losses_Yr1',
                           'Direct_Costs_Yr1', 'Indirect_Costs_Yr1', 'Income_Tax_Yr1',
                           'Capital_Flow_NPV_Yr1',
                           'Capital_Remuneration_NPV_Yr1', 'Interest_Income_NPV_Yr1',
                           'Non_Financial_Income_NPV_Yr1', 'Cost_of_Funds_NPV_Yr1', 'Losses_NPV_Yr1',
                           'Direct_Costs_NPV_Yr1', 'Indirect_Costs_NPV_Yr1', 'Income_Tax_NPV_Yr1',
                           'Capital_Flow_Yr2', 'Capital_Remuneration_Yr2',
                           'Interest_Income_Yr2',
                           'Non_Financial_Income_Yr2', 'Cost_of_Funds_Yr2', 'Losses_Yr2',
                           'Direct_Costs_Yr2', 'Indirect_Costs_Yr2', 'Income_Tax_Yr2',
                           'Capital_Flow_NPV_Yr2',
                           'Capital_Remuneration_NPV_Yr2', 'Interest_Income_NPV_Yr2',
                           'Non_Financial_Income_NPV_Yr2', 'Cost_of_Funds_NPV_Yr2', 'Losses_NPV_Yr2',
                           'Direct_Costs_NPV_Yr2', 'Indirect_Costs_NPV_Yr2', 'Income_Tax_NPV_Yr2',
                           'Capital_Flow_Yr3', 'Capital_Remuneration_Yr3',
                           'Interest_Income_Yr3',
                           'Non_Financial_Income_Yr3', 'Cost_of_Funds_Yr3', 'Losses_Yr3',
                           'Direct_Costs_Yr3', 'Indirect_Costs_Yr3', 'Income_Tax_Yr3',
                           'Capital_Flow_NPV_Yr3',
                           'Capital_Remuneration_NPV_Yr3', 'Interest_Income_NPV_Yr3',
                           'Non_Financial_Income_NPV_Yr3', 'Cost_of_Funds_NPV_Yr3', 'Losses_NPV_Yr3',
                           'Direct_Costs_NPV_Yr3', 'Indirect_Costs_NPV_Yr3', 'Income_Tax_NPV_Yr3',
                           'Capital_Flow_Yr4', 'Capital_Remuneration_Yr4',
                           'Interest_Income_Yr4',
                           'Non_Financial_Income_Yr4', 'Cost_of_Funds_Yr4', 'Losses_Yr4',
                           'Direct_Costs_Yr4', 'Indirect_Costs_Yr4', 'Income_Tax_Yr4',
                           'Capital_Flow_NPV_Yr4',
                           'Capital_Remuneration_NPV_Yr4', 'Interest_Income_NPV_Yr4',
                           'Non_Financial_Income_NPV_Yr4', 'Cost_of_Funds_NPV_Yr4', 'Losses_NPV_Yr4',
                           'Direct_Costs_NPV_Yr4', 'Indirect_Costs_NPV_Yr4', 'Income_Tax_NPV_Yr4',
                           'Capital_Flow_Yr5', 'Capital_Remuneration_Yr5',
                           'Interest_Income_Yr5',
                           'Non_Financial_Income_Yr5', 'Cost_of_Funds_Yr5', 'Losses_Yr5',
                           'Direct_Costs_Yr5', 'Indirect_Costs_Yr5', 'Income_Tax_Yr5',
                           'Capital_Flow_NPV_Yr5',
                           'Capital_Remuneration_NPV_Yr5', 'Interest_Income_NPV_Yr5',
                           'Non_Financial_Income_NPV_Yr5', 'Cost_of_Funds_NPV_Yr5', 'Losses_NPV_Yr5',
                           'Direct_Costs_NPV_Yr5', 'Indirect_Costs_NPV_Yr5', 'Income_Tax_NPV_Yr5',
                           'PD1', 'PD2', 'PD3', 'PD4', 'PD5', 'PD6',
                           'PD7', 'PD8', 'PD9', 'PD10', 'PD11', 'PD12',
                           'PD13', 'PD14', 'PD15', 'PD16', 'PD17', 'PD18',
                           'PD19', 'PD20', 'PD21', 'PD22', 'PD23', 'PD24',
                           'PD25', 'PD26', 'PD27', 'PD28', 'PD29', 'PD30',
                           'PD31', 'PD32', 'PD33', 'PD34', 'PD35', 'PD36',
                           'CAN1', 'CAN2', 'CAN3', 'CAN4', 'CAN5', 'CAN6',
                           'CAN7', 'CAN8', 'CAN9', 'CAN10', 'CAN11',
                           'CAN12', 'CAN13', 'CAN14', 'CAN15', 'CAN16',
                           'CAN17', 'CAN18', 'CAN19', 'CAN20', 'CAN21',
                           'CAN22', 'CAN23', 'CAN24', 'CAN25', 'CAN26',
                           'CAN27', 'CAN28', 'CAN29', 'CAN30', 'CAN31',
                           'CAN32', 'CAN33', 'CAN34', 'CAN35', 'CAN36',
                           'PRE1', 'PRE2', 'PRE3', 'PRE4', 'PRE5', 'PRE6',
                           'PRE7', 'PRE8', 'PRE9', 'PRE10', 'PRE11',
                           'PRE12', 'PRE13', 'PRE14', 'PRE15', 'PRE16',
                           'PRE17', 'PRE18', 'PRE19', 'PRE20', 'PRE21',
                           'PRE22', 'PRE23', 'PRE24', 'PRE25', 'PRE26',
                           'PRE27', 'PRE28', 'PRE29', 'PRE30', 'PRE31',
                           'PRE32', 'PRE33', 'PRE34', 'PRE35', 'PRE36',
                           'SALDOPROM1', 'SALDOPROM2', 'SALDOPROM3', 'SALDOPROM4',
                           'SALDOPROM5', 'SALDOPROM6', 'SALDOPROM7', 'SALDOPROM8',
                           'SALDOPROM9', 'SALDOPROM10', 'SALDOPROM11', 'SALDOPROM12',
                           'SALDOPROM13', 'SALDOPROM14', 'SALDOPROM15', 'SALDOPROM16',
                           'SALDOPROM17', 'SALDOPROM18', 'SALDOPROM19', 'SALDOPROM20',
                           'SALDOPROM21', 'SALDOPROM22', 'SALDOPROM23', 'SALDOPROM24',
                           'SALDOPROM25', 'SALDOPROM26', 'SALDOPROM27', 'SALDOPROM28',
                           'SALDOPROM29', 'SALDOPROM30', 'SALDOPROM31', 'SALDOPROM32',
                           'SALDOPROM33', 'SALDOPROM34', 'SALDOPROM35', 'SALDOPROM36',
                           'IF1', 'IF2', 'IF3', 'IF4', 'IF5', 'IF6',
                           'IF7', 'IF8', 'IF9', 'IF10', 'IF11', 'IF12',
                           'IF13', 'IF14', 'IF15', 'IF16', 'IF17', 'IF18',
                           'IF19', 'IF20', 'IF21', 'IF22', 'IF23', 'IF24',
                           'IF25', 'IF26', 'IF27', 'IF28', 'IF29', 'IF30',
                           'IF31', 'IF32', 'IF33', 'IF34', 'IF35', 'IF36',
                           'EF1', 'EF2', 'EF3', 'EF4', 'EF5', 'EF6',
                           'EF7', 'EF8', 'EF9', 'EF10', 'EF11', 'EF12',
                           'EF13', 'EF14', 'EF15', 'EF16', 'EF17', 'EF18',
                           'EF19', 'EF20', 'EF21', 'EF22', 'EF23', 'EF24',
                           'EF25', 'EF26', 'EF27', 'EF28', 'EF29', 'EF30',
                           'EF31', 'EF32', 'EF33', 'EF34', 'EF35', 'EF36',
                           'REQUEST_ID', 'PD_MinRate', 'PRE_MinRate', 'CAN_MinRate',
                           'PD_IRR', 'PRE_IRR', 'CAN_IRR']

        df_result = DataFrame(columns=columns_outputs)
        df_join = concat([df_result, clv_result], join="inner", ignore_index=True)
        df_result = concat([df_result,df_join])
        df_result = df_result.fillna('NaN')
        df_result['REQUEST_ID'] = df_result['REQUEST_ID'].replace(to_replace='[A-Za-z]',value='',regex=True)
        return df_result

    def __chooseImpl(self, df_input):
        
        from source.clv_cef.cef_engine import CLV_Engine as pricing
        data_input = df_input if not self.is_batch_process else None
        engine = pricing.CLVEngine(data=data_input)
        engine.transform(df_input)
        engine.predict()
        print(type(df_input['REQ_TYPE']))
        req_type = df_input['REQ_TYPE'][0]
        if req_type == 1:
            clv_result = engine.getMinRate()
        elif req_type == 2:
            clv_result = engine.getMinRateAggProfitability()
        elif req_type == 3:
            clv_result = engine.getAggProfitability()
        elif req_type == 4:
            clv_result = engine.getDetailProfitability()
        elif req_type == 5:
            clv_result = engine.getMinRateDetailProfitability()
        elif req_type == 6:
            clv_result = engine.getCLVCurves()
        elif req_type == 7:
            clv_result = engine.getAllOutputs()
        else:
            clv_result = engine.getAllOutputs()        
        

        return clv_result

    def __homologateInputs(self, df_input): 
        equivalent = {
            'REQUEST_ID': 'REQUEST_ID',
            'ANIO': 'AÑO',
            'PLAZO': 'PLAZO',
            'REQUESTED_AMOUNT': 'DESEMBOLSO',
            'CODMONEDA': 'CODMONEDA',
            'CANAL': 'CANAL',
            'SCORE_PRECOVID': 'SCORE',
            'SCORE_POSTCOVID': 'SCORE_POST_COVID',
            'INGRESO_MTOINGRESO': 'MTOINGRESO',
            'INGRESO_MTOMEJORINGRESOAJUSTADOSOL': 'MTOMEJORINGRESOAJUSTADOSOL',
            'FLG_NORMAL': 'FLG_NORMAL',
            'FLG_PDH': 'FLG_PDH',
            'SUBSEGMENTO': 'SUBSEGMENTO',
            'TEA': 'TEA',
            'MODELO': 'MODELO',
            'MTODEUDA_TOTAL': 'MTODEUDA_TOTAL',
            'NIVELEDUCACIONAL': 'NIVELEDUCACIONAL',
            'EMPLEO': 'EMPLEO',
            'TCAMBIO': 'TCAMBIO',
            'MESAPERTURA': 'MESAPERTURA',
            'TIPOCAMBIO': 'TIPOCAMBIO',
            'FMPASIVO_SUM_12': 'FMPASIVO_SUM_12',
            'PMPASIVO_MIN_24': 'PMPASIVO_MIN_24',
            'ANT_LABORAL_MESES': 'ANT_LABORAL_MESES',
            'TIPCAMPANA': 'TIPCAMPANA',
            'TT': 'TT',
            'SEGMENTO_ORTOGONAL': 'SEGMENTO',
            'REQ_TYPE': 'REQ_TYPE',
        }

        column_type = {
            'REQUEST_ID': str,
            'AÑO': int,
            'PLAZO': int,
            'DESEMBOLSO': float,
            'CODMONEDA': str,
            'CANAL': str,
            'SCORE': float,
            'SCORE_POST_COVID': float,
            'MTOINGRESO': float,
            'MTOMEJORINGRESOAJUSTADOSOL': float,
            'FLG_NORMAL': bool,
            'FLG_PDH': bool,
            'SUBSEGMENTO': str,
            'TEA': float,
            'MODELO': str,
            'MTODEUDA_TOTAL': float,
            'NIVELEDUCACIONAL': str,
            'EMPLEO': float,
            'TCAMBIO': float,
            'MESAPERTURA': str if 'TT1' in df_input.columns else int,
            'TIPOCAMBIO': float,
            'FMPASIVO_SUM_12': float,
            'PMPASIVO_MIN_24': float,
            'ANT_LABORAL_MESES': int,
            'TIPCAMPANA': str,
            'TT': float,
            'SEGMENTO': int,
            'REQ_TYPE': int
        }
        # df_input = df_input.copy()
        df = df_input.rename(columns=equivalent)        
        df = df.astype(column_type)
        df = df.copy()
        df['AÑO'] = 2014
        df['TCAMBIO'] = 0.022856
        df['EMPLEO'] = -0.02966676
        df['CODCLAVECIC'] = '.'
        df['FMPASIVO_SUM_12'] = df['FMPASIVO_SUM_12'].fillna(225856.5)
        df['PMPASIVO_MIN_24'] = df['PMPASIVO_MIN_24'].fillna(2799.27)
        df['ANT_LABORAL_MESES'] = df['ANT_LABORAL_MESES'].fillna(80)
        df['FLG_NORMAL'] = df['FLG_NORMAL'].fillna(0)
        df['SEGMENTO'] = df['SEGMENTO'].fillna(14)
        df['SCORE'] = df["SCORE_POST_COVID"]

        df.loc[df.FMPASIVO_SUM_12 == -1, 'FMPASIVO_SUM_12'] = 225856.5
        df.loc[df.PMPASIVO_MIN_24 == -1, 'PMPASIVO_MIN_24'] = 2799.27
        df.loc[df.ANT_LABORAL_MESES == -1, 'ANT_LABORAL_MESES'] = 80
        df.loc[df.SEGMENTO == -1, 'SEGMENTO'] = 14
        df.loc[df.NIVELEDUCACIONAL == 'TECNICO', 'NIVELEDUCACIONAL'] = 'TÉCNICO'
        df.loc[df.CODMONEDA == 'PEN', 'CODMONEDA'] = 'SOLES'
        df.loc[df.CODMONEDA == 'USD', 'CODMONEDA'] = 'DÓLARES'
        df.loc[df.MTODEUDA_TOTAL == -1, 'MTODEUDA_TOTAL'] = 0
        df.loc[df.FLG_PDH == 1, 'FLG_PDH'] = "SI"
        df.loc[df.FLG_PDH == 0, 'FLG_PDH'] = "NO"
        # df.loc[df.SCORE == -1, 'SCORE'] = df["SCORE_POST_COVID"]
        # df.loc[df.SCORE == 0, 'SCORE'] = df["SCORE_POST_COVID"]
        
        df.loc[df.PLAZO == 18, 'PLAZO'] = 12

        df.loc[df.SUBSEGMENTO.isin(['X1N', 'X1E']), 'SUBSEGMENTO'] = "BEX"
        df.loc[df.SUBSEGMENTO.isin(['M1N', 'M1E']), 'SUBSEGMENTO'] = "CONSUMO"
        df.loc[df.SUBSEGMENTO.isin(['LEN', 'LEE']), 'SUBSEGMENTO'] = "ENALTA"
        df.loc[~(df.SUBSEGMENTO.isin(['BEX', 'CONSUMO', 'ENALTA'])), 'SUBSEGMENTO'] = "NO CLIENTE"

        return df

    # Main prediction function
    def predict(self, X, feature_names):
        
        from pandas import DataFrame
        from logging import error
        from datetime import datetime
        
        """ 
        # X: prediction data
        # feature_names: column names
        
        """
        # get data
        # logging.basicConfig(filename='myapp.log')
        
        df_input = DataFrame(data=X, columns=feature_names)
        if not self.is_batch_process:
            df_input["MESAPERTURA"]=df_input["REQUEST_ID"]
        request_id = df_input['REQUEST_ID'].astype(str).str.cat(sep=',')

        error(f"[INFO: BCP-PRICING] - CEF CLV Start v26Mar2024 request_ids:[{request_id}]: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')}")
        
        df = self.__homologateInputs(df_input)
        df_clv_result = self.__chooseImpl(df)
        df_final = self.__format_result(df_clv_result)

        error(f"[INFO: BCP-PRICING] - CEF CLV End v26Mar2024 request_ids:[{request_id}]: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')}")   

        return df_final
