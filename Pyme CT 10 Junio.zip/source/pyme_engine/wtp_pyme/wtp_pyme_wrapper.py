from threading import Thread

from pyme_engine.wtp_pyme.wtp_engine import WTP_Engine as pricing


class WtpPymeWrapper(object):

    def __init__(self, X):
        X["MESAPERTURA"]=X["REQUEST_ID"]
        self.df_input = X
        self.__homologateInputs(X)
        # self.th = Thread(target=self.__homologateInputs, args=(self.df_input,))
        # self.th.start()

    def __chooseImpl(self, df_input):
        
        engine = pricing.WTPEngine()
        engine.transform(df_input)
        engine.get_takeup_rate()
        engine.get_efectividad()
        engine.get_porcentaje_oferta()
        result1, result2, result3, result4 = engine.get_final_rate()
        
        return result3

    def __homologateInputs(self, df_input):
        from numpy import nan
        equivalent = {
            'ANTIGUEDAD_MESES':'antiguedad_meses',
            'CAN_MTO_TMO_VEN_RET_PRM_U12':'can_mto_tmo_ven_ret_prm_u12',
            'CAN_TKT_TMO_VEN_DEP_PRM_U12':'can_tkt_tmo_ven_dep_prm_u12',
            'CAT_ZONA_APP_AGP_F':'cat_zona_app_agp_f',
            'FAD':'fad',
            'IND_SHOPPER':'ind_shopper',
            'IND_SHOPPER_BANK':'ind_shopper_bank',
            'ING_ULT12M':'ing_ult12m',
            'ING_ULT3M':'ing_ult3m',
            # 'MONTODESEMBOLSADOSOL':'montodesembolsadosol',
            'NUM_CANCELACIONES_12M':'num_cancelaciones_12m',
            'NUM_CANCELACIONES_24M':'num_cancelaciones_24m',
            'PDAPPLICANT_PRE':'pdapplicant_pre',
            # 'MontoPD':'pdapplicant_pre',
            'PROD_ANTMAX_CCT':'prod_antmax_cct',
            'PROD_ANTMAX_CVI_PRM_U12':'prod_antmax_cvi_prm_u12',
            'PROD_ANTMAX_PAS':'prod_antmax_pas',
            'PROD_ANTMIN_PYM':'prod_antmin_pym',
            'PROD_CTD_PYM':'prod_ctd_pym',
            'PROD_CTD_SLD_CCT_PRM_U6M':'prod_ctd_sld_cct_prm_u6m',
            'PROD_FLG_CCT_X3M_U3M':'prod_flg_cct_x3m_u3m',
            'PROD_MTO_SLD_CEN_PRM_U6M':'prod_mto_sld_cen_prm_u6m',
            'RCC_CTD_CNT_RLPR_PYM_REC':'rcc_ctd_cnt_rlpr_pym_rec',
            'RCC_CTD_DEU_BCP':'rcc_ctd_deu_bcp',
            'RCC_CTD_DEU_NBCP':'rcc_ctd_deu_nbcp',
            'RCC_CTD_DEU_PYM_BM_PRM_U12':'rcc_ctd_deu_pym_bm_prm_u12',
            'RCC_CTD_GAR':'rcc_ctd_gar',
            'RCC_MTO_CNT_RLTC_PYM_MIN_U12':'rcc_mto_cnt_rltc_pym_min_u12',
            'RCC_MTO_GAR':'rcc_mto_gar',
            'RCC_MTO_SLD_ENT_BA':'rcc_mto_sld_ent_ba',
            'RCC_MTO_SLD_NBCP':'rcc_mto_sld_nbcp',
            'RCC_MTO_SLD_PYM':'rcc_mto_sld_pym',
            'RCC_MTO_SLD_PYM_BCP_PRM_U3M':'rcc_mto_sld_pym_bcp_prm_u3m',
            'RCC_PCT_UTL_LIN_PYM_TCR_BCP_PRM_U3M':'rcc_pct_utl_lin_pym_tcr_bcp_prm_u3m',
            'RCC_SOW_PYM_BCP_PRM_U12':'rcc_sow_pym_bcp_prm_u12',
            'RCC_SOW_PYM_BCP_PRM_U9M':'rcc_sow_pym_bcp_prm_u9m',
            'SF3_SF24':'sf3_sf24',
            'VENTAS_SOL':'ventas_sol',
            'FAD_SOL':'fad_sol',
            'FADSOL':'fadsol',
            'ACT_ECO_FIN':'act_eco_fin',
            'NPV':'npv'
        }

        column_type={
            'antiguedad_meses':int,
            'can_mto_tmo_ven_ret_prm_u12':int,
            'can_tkt_tmo_ven_dep_prm_u12':int,
            'cat_zona_app_agp_f':str,
            'fad':float,
            'ind_shopper':float,
            'ind_shopper_bank':float,
            'ing_ult12m':float,
            'ing_ult3m':float,
            'montodesembolsadosol':float,
            'num_cancelaciones_12m':float,
            'num_cancelaciones_24m':float,
            'pdapplicant_covid':float,
            'pdapplicant_pre':float,
            'prod_antmax_cct':float,
            'prod_antmax_cvi_prm_u12':float,
            'prod_antmax_pas':float,
            'prod_antmin_pym':int,
            'prod_ctd_pym':float,
            'prod_ctd_sld_cct_prm_u6m':float,
            'prod_flg_cct_x3m_u3m':float,
            'prod_mto_sld_cen_prm_u6m':float,
            'rcc_ctd_cnt_rlpr_pym_rec':float,
            'rcc_ctd_deu_bcp':float,
            'rcc_ctd_deu_nbcp':float,
            'rcc_ctd_deu_pym_bm_prm_u12':float,
            'rcc_ctd_gar':float,
            'rcc_mto_cnt_rltc_pym_min_u12':float,
            'rcc_mto_gar':float,
            'rcc_mto_sld_ent_ba':float,
            'rcc_mto_sld_nbcp':float,
            'rcc_mto_sld_pym':float,
            'rcc_mto_sld_pym_bcp_prm_u3m':float,
            'rcc_pct_utl_lin_pym_tcr_bcp_prm_u3m':float,
            'rcc_sow_pym_bcp_prm_u12':float,
            'rcc_sow_pym_bcp_prm_u9m':float,
            'sf3_sf24':float,
            'ventas_sol':float,
            'fad_sol':float,
            'fadsol':float,
            'act_eco_fin':str, 
            'tea':float
        }

        df = df_input.rename(columns=equivalent).astype(column_type)
        df = df.copy()      

        df = df.replace(to_replace=['nan',-1,'-1',''],value=nan)
        df['pdapplicant_covid']=df['MontoPD']
        df['pdapplicant_pre']=df['MontoPD']

        self.df_input = df

    # Main prediction function
    def predict(self):
        # self.th.join()
        df_input = self.df_input
        
        wtp_result = self.__chooseImpl(df_input)

        return wtp_result
