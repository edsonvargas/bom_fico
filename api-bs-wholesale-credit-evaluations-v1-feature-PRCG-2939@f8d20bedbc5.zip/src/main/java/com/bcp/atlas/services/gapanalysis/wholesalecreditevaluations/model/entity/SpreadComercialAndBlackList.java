package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity;

import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import lombok.Data;

/**
 * <b>Class</b>: CreditInfoRepository<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis Peru SAC <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Ago 07, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Data
@Entity
@Table(name = "spreadcomercial_and_blacklist",schema = "prcg_mayorista")
@IdClass(SpreadComercialAndBlackListPk.class)
public class SpreadComercialAndBlackList {

  @Id
  @Column(name = "spread_comercial")
  private BigDecimal spreadComercial;

  @Id
  @Column(name = "blacklist_rate")
  private BigDecimal blacklistRate;
}