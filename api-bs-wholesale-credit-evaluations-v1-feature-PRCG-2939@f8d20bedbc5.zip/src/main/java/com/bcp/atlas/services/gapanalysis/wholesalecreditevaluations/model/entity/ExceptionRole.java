package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;



/**
 * <b>Class</b>: Product.java <br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Ago 1, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Data
@Entity
@Table(name = "exception_role",schema = "prcg_mayorista")
public class ExceptionRole {

  @Column(name = "exception_role_id")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Id
  private Integer exceptionRoleId;

  @Column(name = "role_id")
  private Integer roleId;

  @Column(name = "rol_description")
  private String rolDescription;

  @Column(name = "type_exception")
  private String typeException;

  @Column(name = "from_rate")
  private BigDecimal fromRate;

  @Column(name = "credit_info_cp_req_id")
  private Integer creditInfoCpReqId;

  @Column(name = "register_date")
  private LocalDateTime registerDate;

}
