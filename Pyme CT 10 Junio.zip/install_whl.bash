
python setup.py bdist_wheel --universal
cp dist/clv_pyme-1.0-py2.py3-none-any.whl install 
pip install dist/clv_pyme-1.0-py2.py3-none-any.whl --force
# mlxctl login