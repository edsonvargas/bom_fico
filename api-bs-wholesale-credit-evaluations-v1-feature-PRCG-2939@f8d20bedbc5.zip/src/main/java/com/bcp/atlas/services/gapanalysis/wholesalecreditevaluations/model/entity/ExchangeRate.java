package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import lombok.Data;

/**
 * <b>Class</b>: Product.java <br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Sep 8, 2023 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Data
@Entity
@Table(name = "exchange_rate",schema = "prcg_mayorista")
@IdClass(ExchangeRatePk.class)
public class ExchangeRate {

  @Column(name = "ammount_exchange_currency_origin_destination")
  private BigDecimal ammountExchangeCurrencyOriginDestination;

  @Column(name = "currency_code_origin")
  private String currencyCodeOrigin;

  @Column(name = "currency_code_destination")
  private String currencyCodeDestination;

  @Column(name = "type_clasification_inter_curr_code")
  private String typeClasificationInterCurrCode;

  @Column(name = "hor_exchange_type")
  private String horExchangeType;

  @Column(name = "nbr_currency_origin")
  private String nbrCurrencyOrigin;

  @Column(name = "nbr_currency_destination")
  private String nbrCurrencyDestination;

  @Column(name = "des_type_clasification_inter_curr_code")
  private String desTypeClasificationInterCurrCode;

  @Column(name = "ammount_exchange_currency_destination_origin")
  private BigDecimal ammountExchangeCurrencyDestinationOrigin;

  @Column(name = "date_update_register")
  private LocalDate dateUpdateRegister;

  @Column(name = "type_frecuency_register")
  private String typeFrecuencyRegister;

  @Column(name = "date_routine")
  private String dateRoutine;

  @Column(name = "date_exchange_type")
  private String dateExchangeType;

  @Column(name = "cod_app")
  @Id
  private String codApp;

  @Column(name = "date_day")
  @Id
  private LocalDate dateDay;

}
