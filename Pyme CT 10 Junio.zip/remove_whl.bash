rm install/clv_pyme-1.0-py2.py3-none-any.whl 
rm dist/clv_pyme-1.0-py2.py3-none-any.whl
rm -rf build/lib/pyme_engine