package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util;

import com.bcp.atlas.core.constants.ErrorCategory;
import com.bcp.atlas.core.exception.ApiException;
import com.bcp.atlas.core.exception.impl.FieldValidationException;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder.constants.Constantes;
import io.reactivex.Observable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;

/**
 * <b>Class</b>: Util<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis Peru SAC <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Feb 24, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */
@Component
public final class Util {


  /**
   * Method convertToObject
   *
   * @version 1.0
   */
  public static String getDefaultValueString(String s) {
    if (StringUtils.isEmpty(s)) {
      return "0";
    }
    return s;
  }

  /**
   * Method convertToObject
   *
   * @version 1.0
   */
  public static Integer getDefaultValueInt(Integer a) {
    return ObjectUtils.defaultIfNull(a,-1);
  }

  /**
   * Method convertToObject
   *
   * @version 1.0
   */
  public static BigDecimal getDefaultValueBig(BigDecimal s) {
    return ObjectUtils.defaultIfNull(s,BigDecimal.ZERO);
  }


  /**
   * Method getDefaultValueBigFicoDm
   *
   * @version 1.0
   */
  public static BigDecimal getDefaultValueBigFicoDm(BigDecimal s) {
    if (Objects.isNull(s) || BigDecimal.ONE.negate().equals(s)) {
      return BigDecimal.ZERO;
    }
    return s;
  }

  /**
   * Method buildFieldValidationException
   *
   * @version 1.0
   */
  public static List<FieldError> buildFieldValidationException(String objectName,String field,
      String defaultMessage) {
    List<FieldError> fieldErrors = new ArrayList<>();
    FieldError error = new FieldError(objectName, field, defaultMessage);
    fieldErrors.add(error);
    return fieldErrors;
  }

  /**
   * Method getDefaultValueStringMlx
   *
   * @version 1.0
   */
  public static String getDefaultValueStringMlx(String s) {
    if (StringUtils.isEmpty(s)) {
      return "";
    }
    return s;
  }

  /**
   * Method getDefaultValueStringMlx
   *
   * @version 1.0
   */
  public static String getDefaultValueStringMlx(Integer s) {
    if (s == null) {
      return "-1";
    }
    return String.valueOf(s);
  }

  /**
   * Method getDefaultValueStringMlx
   *
   * @version 1.0
   */
  public static String getDefaultValueStringMlx(Float s) {
    if (s == null) {
      return "-1";
    }
    return String.valueOf(s);
  }

  /**
   * Method getDefaultValueBigdecimalMlx
   *
   * @version 1.0
   */
  public static String getDefaultValueBigdecimalMlx(BigDecimal s) {
    if (s == null) {
      return "-1";
    }
    return String.valueOf(s);
  }

  /**
   * Method getDefaultValueBigdecimalMlx
   *
   * @version 1.0
   */
  public static String getDefaultValueBigdecimalMlx(String s) {
    if (StringUtils.isEmpty(s)) {
      return "-1";
    }
    return s;
  }

  /**
   * Method getGuarantorOrCustomerResponse
   *
   * @version 1.0
   */
  public static CustomerGetResponse getGuarantorOrCustomerResponse(
      CustomerGetResponse customerGetResponse,
      CustomerGetResponse guarantorGetResponse) {
    if (StringUtils.equals(guarantorGetResponse.getIdc(),"0")) {
      return customerGetResponse;
    } else {
      return guarantorGetResponse;
    }
  }

  /**
   * Method getOneDefaultValueToMlx
   *
   * @version 1.0
   */
  public static String getOneDefaultValueToMlx(Integer s) {
    if (s == null) {
      return "1";
    }
    return String.valueOf(s);
  }

  /**
   * Method getOneDefaultValueToMlx
   *
   * @version 1.0
   */
  public static String getOneDefaultValueToMlx(BigDecimal s) {
    if (s == null) {
      return "1";
    }
    return String.valueOf(s);
  }

  /**
   * Method getDefaultZeroFromStringToMlx
   *
   * @version 1.0
   */
  public static String getDefaultZeroFromStringToMlx(BigDecimal s) {
    if (s == null) {
      return "0";
    }
    return String.valueOf(s);
  }

  /**
   * Method validateQuotationIdExist
   *
   * @version 1.0
   */
  public static String validateQuotationIdExist() {
    throw new FieldValidationException(
        Constantes.MENSAJE_ERROR_ID_NO_EXISTE,
        buildFieldValidationException("quotationRequest",
                                      "quotationId",
                                      Constantes.MENSAJE_ERROR_ID_NO_EXISTE));

  }

  /**
   * Method getDefautltFlagBLackList
   *
   * @version 1.0
   */
  public static Boolean getDefautltFlagBLackList(Boolean s) {
    return Objects.nonNull(s) ? s : Boolean.FALSE;
  }

  /**
   * Method getDefaultBigDecimal
   *
   * @version 1.0
   */
  public static BigDecimal getDefaultBigDecimal(BigDecimal s) {
    if (s == null) {
      return BigDecimal.ONE.negate();
    }
    return s;
  }

  /**
   * Method formatStringToDate
   *
   * @version 1.0
   */
  public static LocalDate formatStringToDate(String fecha, String formato) {
    LocalDate localDate = null;
    if (Objects.nonNull(fecha)) {
      DateTimeFormatter formatoEntrada = DateTimeFormatter.ofPattern(formato);
      localDate = LocalDate.parse(fecha,formatoEntrada);
    }

    return localDate;
  }


  /**
   * Method validateTermMaxValue
   *
   * @version 1.0
   */
  public static Observable<Request> validateTermMaxValue(Request request) {
    if (request.getCreditInfo().getCreditInfoBase().getTerm().intValue() > 365) {

      throw ApiException.builder()
          .description("Los datos proporcionados no son válidos")
          .errorType(Constantes.ERROR_TYPE)
          .addDetail().withDescription(
              "creditInfo.creditInfoBase.term debe ser menor o igual a 365")
          .push()
          .category(ErrorCategory.INVALID_REQUEST)
          .systemCode(Constantes.ERROR_CODE_PR0001)
          .build();

    }
    return Observable.just(request);
  }

  /**
   * Method getDefaultTypeGuaranteLetter
   * It i for contingent
   * @version 1.0
   */
  public static String getDefaultTypeGuaranteeLetter(String s) {
    if (s == null) {
      return "";
    }
    return s;
  }

}
