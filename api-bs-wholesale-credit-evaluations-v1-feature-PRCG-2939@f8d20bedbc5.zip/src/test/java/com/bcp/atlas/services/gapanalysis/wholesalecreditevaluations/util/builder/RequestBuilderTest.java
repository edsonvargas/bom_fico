package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.builder;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util.MapperUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * <b>Class</b>: Util<br>
 * <b>Copyright</b>: &copy; 2022 Banco de Cr&eacute;dito del Per&uacute;.<br>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br>
 *     <u>Service Provider</u>: Everis Peru SAC <br>
 *     <u>Developed by</u>: <br>
 *     <ul>
 *     </ul>
 *     <u>Changes</u>:<br>
 *     <ul>
 *       <li>Nov 11, 2022 Creaci&oacute;n de Clase.
 *     </ul>
 *
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class RequestBuilderTest {

  @InjectMocks RequestBuilder requestBuilder;

  @Test
  void whenRequestBuilderDefaultTest() {
    Integer reqId = 1;

    Request request = MapperUtils.convertToObject("RequestApi" + ".json", Request.class);

    Assertions.assertNotNull(requestBuilder.generateDbObjectRequest(request));
  }
}
