# CLV Curves

# 0. Libraries
import pyme_engine.clv_pyme.clv_engine.utils as ut

# 1. Curva de Cancelaciones
class CurveCan():
    """ Clase que calcula la curva de cancelaciones """
    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]            

    def transform(self, X):
        X_transformed = ut.can_transform(X)
        return X_transformed

    def predict(self, X):
        X_predict = ut.can_predict(X, self.param_Tt)
        return X_predict


# 2. Curva de Probabilidad de Default (PD)
class CurvePD():
    """ Clase que calcula la curva de probabilidad de default (PD) """
    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        X_transformed = ut.pd_transform(X)
        return X_transformed

    def predict(self, X):
        X_predict, self.pd12 = ut.pd_predict(
            X, self.param_scalar, self.param_T, self.param_Tt, self.param_rangoTt)
        return X_predict


# 3. Curva de Prepagos
class CurvePre():
    """ Clase que calcula la curva de prepagos """
    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        X_transformed = ut.pre_transform(X)
        return X_transformed

    def predict(self, X):
        X_predict = ut.pre_predict(X, self.param_Tt)
        return X_predict


# 4. Curva de Loss Given Default (LGD)
class CurveLGD():
    """ Clase que calcula la curva de loss given default (LGD) """
    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        X_transformed = ut.lgd_transform(X, self.param_localidad_zona)
        return X_transformed

    def predict(self, X):
        X_predict, self.lgd21, self.lgd12 = ut.lgd_predict(
            X, self.param_coefs_curva_base, self.param_lgd_for_ecap_map, self.param_coefs_curva_final, self.param_lgd_wo)
        return X_predict


# 5. Curva de Roll-Rates 1 (RR1)
class CurveRR1():
    """ Clase que calcula la curva de roll-rates 1 (RR1) """

    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        X_transformed = ut.rr1_transform(X, self.param_T1, self.param_factor1)
        return X_transformed

    def predict(self, X):
        X_predict = ut.rr1_predict(X)
        return X_predict

# 6. Curva de Roll-Rates 2 (RR2)
class CurveRR2():
    """ Clase que calcula la curva de roll-rates 2 (RR2) """
    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        X_transformed = ut.rr2_transform(X, self.param_T2, self.param_factor2)
        return X_transformed

    def predict(self, X):
        X_predict = ut.rr2_predict(X)
        return X_predict


# 7. Capital Economico (ECAP)
class CurveCAP():
    """ Clase que calcula el capital economico (ECAP) """
    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        X_transformed = ut.cap_transform(X)
        return X_transformed

    def predict(self, X):
        X_predict, self.pd_ttc_rep, self.lgd_ttc_rep, self.cap_new = ut.cap_predict(X, self.param_PDTTC, self.param_scalar)
        return X_predict


# 8. Costos (en t=0 y lifetime)
class CurveCostos():
    """ Clase que calcula los costos en t=0 y lifetime """
    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        costos_t_0_fact, costos_lifetime_fact = ut.costos_transform(X, self.param_costos_t_0, self.param_costos_lifetime)
        return costos_t_0_fact, costos_lifetime_fact


# 9. Ingresos No Financieros (INOF)
class CurveInoF():
    """ Clase que calcula los ingresos no financieros (INOF) """
    def __init__(self, hyperparams):
        [setattr(self, key, hyperparams[key]) for key in hyperparams]

    def transform(self, X):
        inof_fact = ut.inof_transform(X, self.param_ixs)
        return inof_fact


# 10. Tasa de Transferencia y Tasas de Descuento
class CurvesTT_Desc():
    """ Clase que calcula las tasas de descuento y carga en memoria los params del calculo de la tasa de transferencia zero-cupon """
    def __init__(self, hyperparams, flag_monitoreo=False):
        for key in hyperparams:
            setattr(self, key, hyperparams[key])
        self.flag_monitoreo = flag_monitoreo

    def transform(self, X):
        df_tt_desc = ut.tt_desc_transform(
            X, self.param_remcap, self.param_prepagos, self.param_tt_factor, self.param_tasadescuento_tmin, self.flag_monitoreo)
        return df_tt_desc
    