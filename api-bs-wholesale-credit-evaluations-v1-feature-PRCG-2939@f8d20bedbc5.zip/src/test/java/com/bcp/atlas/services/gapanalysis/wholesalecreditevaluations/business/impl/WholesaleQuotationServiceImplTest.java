package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationInfoResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleQuotationNumberResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.QuotationRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.WholesaleQuotationDao;
import io.reactivex.Observable;
import io.reactivex.observers.TestObserver;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class WholesaleQuotationServiceImplTest {

  @Mock private WholesaleQuotationDao wholesaleQuotationDao;

  @InjectMocks private WholesaleQuotationServiceImpl wholsaleQuotationServiceImpl;

  @Test
  void whenProductIsCortoPlazo() {
    PricingWholesaleQuotationInfoResponse response =
        mock(PricingWholesaleQuotationInfoResponse.class);
    when(wholesaleQuotationDao.getQuotation(any(String.class)))
        .thenReturn(Observable.just((response)));
    TestObserver<PricingWholesaleQuotationInfoResponse> testObserver =
        wholsaleQuotationServiceImpl.getQuotation("CP2023042010").test();
    testObserver.awaitTerminalEvent();
    Assertions.assertNotNull(testObserver);
  }

  @Test
  void whenGenerateQuotationNumber() {
    QuotationRequest quotationRequest = mock(QuotationRequest.class);
    when(wholesaleQuotationDao.generateQuotationNumber(quotationRequest))
        .thenReturn(Observable.just("CP20230421100"));
    TestObserver<PricingWholesaleQuotationNumberResponse> testObserver =
        wholsaleQuotationServiceImpl.generateQuotationNumber(quotationRequest).test();
    testObserver.awaitTerminalEvent();
    testObserver.assertTerminated();
    testObserver.assertNoErrors();
    testObserver.assertValue(response -> "CP20230421100".equals(response.getQuotationNumber()));
  }
}
