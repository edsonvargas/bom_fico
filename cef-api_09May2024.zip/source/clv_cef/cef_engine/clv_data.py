from pathlib import Path
from pandas import DataFrame, read_csv, concat


class ClvData:
    __instance = None
    PATH = "data"
    DataFramesLoaded = dict()
    terms = None

    @staticmethod
    def get_instance():
        """ Static access method. """
        if ClvData.__instance is None:
            ClvData()
        return ClvData.__instance

    def __init__(self):
        self.__load_data()
        # """ Virtually private constructor. """
        if ClvData.__instance is None:
            ClvData.__instance = self

    def __load_data(self):
        files = ["varios_Group_PD","educated_initial_guess","roll_ThetaT","pd_scalars","varios_Enalta",
                "can_thetaT","pd_thetaT_init","pre_Logit","costos_montoT0","tt_prepagos","tt_zdf",
                "descuentos_tasadescuento_leads","pd_thetaTt_init","lgd_ThetaT","costos_t","costos_canalT0",
                "desc_tabla","pre_Primera","educated_initial_guess_zoom","can_thetaTt","pd_thetaT",
                "ingresos_portes_moneda","tt_descuentos_tasadescuento_leads","lgd_Limites_Inputs",
                "descuentos_tasadescuento_leads_subsegmento","ingresos_portes_segmento","varios_PDcalibrada",
                "pre_MCO","descuentos_tasadescuento_tmin","roll_Theta","ecap_PDTTC","ecap_scalars",
                "pd_thetaTt","lgd_Enalta","costos_otrosT0","ingresos_seguros","param_remcap",
                "indicator_target","varios_factor_pre_can"]

        parent_path= f"{Path(__file__).resolve().parent}/data/"

        def read_data(file):
            data = None
            final_path = f"{parent_path}{file}.csv"
            if Path(final_path).exists():
                data = read_csv(final_path)
            self.DataFramesLoaded[file] = data
        [read_data(file) for file in files]

    def set_data_prepagos(self, input_clv):
        df = input_clv.copy()
        df["MESAPERTURA"] = df["REQUEST_ID"]
        df = df.set_index("REQUEST_ID")
        df_final = DataFrame(columns=['SUBSEGMENTO', 'MESAPERTURA', 'PLAZO', 't', 'prepagoRDM'])

        df_prepago = df.loc[:, "PRE1":"PRE60"].replace(-1,0)
        df_columns_prepago = df_prepago.columns.str.replace("PRE", "").values

        df_prepago.insert(0,"PRE0",0)
        df_prepago[["SUBSEGMENTO", "PLAZO"]] = df[["SUBSEGMENTO", "PLAZO"]]

        for idx, row in df_prepago.iterrows():
            df1 = DataFrame({
                'SUBSEGMENTO': row["SUBSEGMENTO"],
                'MESAPERTURA': idx,
                'PLAZO': row["PLAZO"],
                't': df_columns_prepago,
                'prepagoRDM': row["PRE0":"PRE59"]
            })

            df_final = concat([df_final,df1])

        df_final = df_final.reset_index()
        df_final = df_final[['SUBSEGMENTO', 'MESAPERTURA', 'PLAZO', 't', 'prepagoRDM']]
        df_final = df_final.astype(dtype={'SUBSEGMENTO': str, 'MESAPERTURA': str, 'PLAZO': int, 't': int, 'prepagoRDM': float})
        self.DataFramesLoaded["tt_prepagos"] = df_final
        return self

    def set_data_ttzdf(self, input_clv):
        df = input_clv.copy()
        df["MESAPERTURA"] = df["REQUEST_ID"]
        df = df.set_index("REQUEST_ID")

        df_final = DataFrame(columns=['MESAPERTURA', 't', 'tt_fact'])
        df_tt = df.loc[:, "TT1":"TT61"]
        df_columns_tt = df_tt.columns.str.replace("TT", "").values
        
        df_tt.insert(0,"TT0",0)
        

        for idx, row in df_tt.iterrows():
            df1 = DataFrame({
                "MESAPERTURA": idx,
                "tt_fact": row["TT0":"TT60"],
                "t": df_columns_tt
            })

            df_final = concat([df_final,df1])

        df_final = df_final.reset_index()
        df_final = df_final[['MESAPERTURA', 't', 'tt_fact']]
        df_final = df_final.astype(dtype={'MESAPERTURA': str, 't': int, 'tt_fact': float})
        self.DataFramesLoaded["tt_zdf"] = df_final
        return self
