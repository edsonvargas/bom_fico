package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.util;

import static org.junit.Assert.assertThrows;

import com.bcp.atlas.core.exception.ApiException;
import com.bcp.atlas.core.exception.impl.FieldValidationException;
import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CommonTransferRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CommonTransferRatePk;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CreditInfoCpRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CreditInfoCpResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExceptionRole;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExchangeRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExchangeRatePk;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.GetQuotationInfoEntityPk;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.SpreadComercialAndBlackListPk;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.mlx.ClvMlxHeader;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.mlx.Data;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.mlx.MlxRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.mlx.Tensor;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.token.TokenRequest;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Test de la clase UtilTest <br>
 * <b>Class</b>: UtilTest<br>
 * <b>Copyright</b>: &copy; 2018 Banco de Cr&eacute;dito del Per&uacute;.<br>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br>
 *     <u>Service Provider</u>: Everis <br>
 *     <u>Developed by</u>: <br>
 *     <ul>
 *     </ul>
 *     <u>Changes</u>:<br>
 *     <ul>
 *       <li>Oct 12, 2020 Creaci&oacute;n de Clase.
 *     </ul>
 *
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class UtilTest {

  @InjectMocks Util util;

  @Test
  void whenValueStringIsNullTest() {
    String value = null;
    Assertions.assertEquals("0", util.getDefaultValueString(value));
  }

  @Test
  void whenValueStringIsNotNullTest() {
    String value = "prueba";
    Assertions.assertNotNull(util.getDefaultValueString(value));
  }

  @Test
  void whenValueIntegerIsNullTest() {
    Integer value = null;
    Assertions.assertEquals(-1, util.getDefaultValueInt(value));
  }

  @Test
  void whenValueIntegerIsNotNullTest() {
    Integer value = 3;
    Assertions.assertNotNull(util.getDefaultValueInt(value));
  }

  @Test
  void whenValueBigDecimalIsNullTest() {
    BigDecimal value = null;
    Assertions.assertEquals(BigDecimal.ZERO, util.getDefaultValueBig(value));
  }

  @Test
  void whenValueBigDecimalIsNotNullTest() {
    BigDecimal value = BigDecimal.ONE;
    Assertions.assertNotNull(util.getDefaultValueBig(value));
  }

  @Test
  void whenValueBigDecimalIsNotNullFicoDmTest() {
    BigDecimal value = BigDecimal.ONE.negate();
    Assertions.assertEquals(BigDecimal.ZERO, util.getDefaultValueBigFicoDm(value));
    Assertions.assertEquals(BigDecimal.ZERO, util.getDefaultValueBigFicoDm(null));
  }

  @Test
  void whenValueBigDecimalIsNotNullFicoDmElseTest() {
    BigDecimal value = BigDecimal.ONE;
    Assertions.assertEquals(BigDecimal.ONE, util.getDefaultValueBigFicoDm(BigDecimal.ONE));
  }

  @Test
  void whenValidateQuotationIdExistTest() {
    assertThrows(FieldValidationException.class, () -> util.validateQuotationIdExist());
  }

  @Test
  void whengetDefaultValueIdcMlxTest() {
    BigDecimal value = BigDecimal.ONE.negate();
    Assertions.assertEquals("1", util.getDefaultValueStringMlx("1"));
  }

  @Test
  void whengetDefaultValueIdcMlxEmptyTest() {
    BigDecimal value = BigDecimal.ONE.negate();
    Assertions.assertEquals("", util.getDefaultValueStringMlx(""));
  }

  @Test
  void whengetDefaultValueStringMlxtest() {
    BigDecimal value = BigDecimal.ONE;
    BigDecimal value2 = null;
    Integer value3 = null;
    Float value4 = null;
    Assertions.assertEquals("1", util.getDefaultValueStringMlx("1"));
    Assertions.assertEquals("", util.getDefaultValueStringMlx(""));
    Assertions.assertEquals("1", util.getDefaultValueBigdecimalMlx(value));
    Assertions.assertEquals("-1", util.getDefaultValueBigdecimalMlx(value2));
    Assertions.assertEquals("-1", util.getDefaultValueStringMlx(value3));
    Assertions.assertEquals("1", util.getDefaultValueStringMlx(1));
    Assertions.assertEquals("-1", util.getDefaultValueStringMlx(value4));
    Assertions.assertEquals("1.0", util.getDefaultValueStringMlx(Float.valueOf("1")));
  }

  @Test
  void whengetGuarantorOrCustomerResponseTest() {
    CustomerGetResponse customerGetResponse = new CustomerGetResponse();
    CustomerGetResponse guarantorGetResponse = new CustomerGetResponse();
    guarantorGetResponse.setIdc("0");
    CustomerGetResponse guarantorGetResponse2 = new CustomerGetResponse();
    guarantorGetResponse2.setIdc("1");
    Assertions.assertEquals(
        customerGetResponse,
        util.getGuarantorOrCustomerResponse(customerGetResponse, guarantorGetResponse));
    Assertions.assertEquals(
        guarantorGetResponse2,
        util.getGuarantorOrCustomerResponse(customerGetResponse, guarantorGetResponse2));
  }

  @Test
  void validateTermMaxValue() {
    Request request = MapperUtils.convertToObject("RequestApi.json", Request.class);
    request.getCreditInfo().getCreditInfoBase().setTerm(366);
    assertThrows(ApiException.class, () -> util.validateTermMaxValue(request));
  }

  @Test
  void valdiateEntity() {

    CommonTransferRate commonTransferRate = new CommonTransferRate();
    commonTransferRate.setCurrency("C");
    commonTransferRate.setQuote(1);
    CommonTransferRatePk commonTransferRatePk = new CommonTransferRatePk();
    commonTransferRatePk.setQuote(1);
    commonTransferRatePk.setRate(1f);
    CreditInfoCpRequest creditInfoCpRequest = new CreditInfoCpRequest();
    CreditInfoCpResponse creditInfoCpResponse = new CreditInfoCpResponse();
    ExceptionRole exceptionRole = new ExceptionRole();
    ExchangeRate exchangeRate = new ExchangeRate();
    ExchangeRatePk exchangeRatePk = new ExchangeRatePk();
    exchangeRatePk.setCodApp("C");
    exchangeRatePk.setDateDay(LocalDate.now());
    GetQuotationInfoEntityPk getQuotationInfoEntityPk = new GetQuotationInfoEntityPk();
    getQuotationInfoEntityPk.setQuotationId(1);
    SpreadComercialAndBlackListPk spreadComercialAndBlackListPk =
        new SpreadComercialAndBlackListPk();
    spreadComercialAndBlackListPk.setBlacklistRate(new BigDecimal("1"));
    spreadComercialAndBlackListPk.setSpreadComercial(new BigDecimal("1"));

    TokenRequest tokenRequest = new TokenRequest();
    tokenRequest.setClientId("C");
    tokenRequest.setSecret("C");

    ClvMlxHeader clvMlxHeader = new ClvMlxHeader();
    clvMlxHeader.setAuthorization("C");

    Data data = new Data();
    data.setNames(new ArrayList<>());

    MlxRequest mlxRequest = new MlxRequest();
    mlxRequest.setJsonData(new ArrayList<>(new ArrayList<>()));

    Tensor tensor = new Tensor();
    tensor.setShape(new ArrayList<>());
    tensor.setValues(new ArrayList<>());

    Assertions.assertNotNull(commonTransferRate);
    Assertions.assertNotNull(commonTransferRate.getCurrency());
    Assertions.assertNotNull(commonTransferRate.getQuote());
    Assertions.assertNotNull(commonTransferRatePk);
    Assertions.assertNotNull(commonTransferRatePk.getQuote());
    Assertions.assertNotNull(commonTransferRatePk.getRate());
    Assertions.assertNotNull(exchangeRatePk);
    Assertions.assertNotNull(exchangeRatePk.getCodApp());
    Assertions.assertNotNull(exchangeRatePk.getDateDay());
    Assertions.assertNotNull(getQuotationInfoEntityPk.getQuotationId());
    Assertions.assertNotNull(spreadComercialAndBlackListPk.getBlacklistRate());
    Assertions.assertNotNull(spreadComercialAndBlackListPk.getSpreadComercial());
    Assertions.assertNotNull(tokenRequest.getClientId());
    Assertions.assertNotNull(tokenRequest.getSecret());
    Assertions.assertNotNull(clvMlxHeader.getAuthorization());
    Assertions.assertNotNull(data.getNames());
    Assertions.assertNotNull(mlxRequest.getJsonData());
    Assertions.assertNotNull(tensor.getValues());
    Assertions.assertNotNull(tensor.getShape());


  }
}
