package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;



/**
 * <br/>
 * Clase Interfaz del Servicio para la logica de negocio que consumira la clase REST
 * RateCalculationController<br/>
 * <b>Class</b>: RateCalculationService<br/>
 * <b>Copyright</b>: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: Everis <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>G.CH.J</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Mar 25, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */


@Data
public class NoRevPayloadInput implements Serializable {

  private static final long serialVersionUID = 1L;

  @JsonProperty("datosSolicitud")
  private NoRevSolicitud datosSolicitud;

}
