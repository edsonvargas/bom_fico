package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.business.impl;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.OperationNumberRequest;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleOperationNumberResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao.WholesaleOperationDao;
import io.reactivex.Observable;
import io.reactivex.observers.TestObserver;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class WholesaleOperationServiceImplTest {

  @Mock private WholesaleOperationDao wholesaleOperationDao;

  @InjectMocks private WholesaleOperationServiceImpl wholesaleOperationServiceImpl;

  @Test
  void whenSaveOperationNumber() {
    PricingWholesaleOperationNumberResponse response =
        mock(PricingWholesaleOperationNumberResponse.class);
    OperationNumberRequest request = mock(OperationNumberRequest.class);
    when(wholesaleOperationDao.saveOperationNumber(request)).thenReturn(Observable.just(response));
    TestObserver<PricingWholesaleOperationNumberResponse> testObserver =
        wholesaleOperationServiceImpl.saveOperationNumber(request).test();
    testObserver.awaitTerminalEvent();
  }
}
