package com.bcp.atlas.services.gapanalysis.config;

import com.azure.identity.ManagedIdentityCredentialBuilder;
import com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionAzureKeyVaultProvider;
import com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionKeyStoreProvider;
import com.microsoft.sqlserver.jdbc.SQLServerConnection;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import javax.sql.DataSource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

/**
 * <br/>
 * <b>Class</b>: AlwaysEncryptedProperties<br/>
 * <b>Copyright</b>: &copy; 2020 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * <b>Company</b>: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 * <u>CosmosDbConfiguration</u>: BCP <br/>
 * <u>Developed by</u>: <br/>
 * <ul>
 * <li>Fernando Supo</li>
 * </ul>
 * <u>Changes</u>:<br/>
 * <ul>
 * <li>May 19, 2023 Creaci&oacute;n de Clase.</li>
 * </ul>
 * @version 1.0
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataSourceBeanPostProcessorConfiguration implements BeanPostProcessor {

  private static final Logger logger = LoggerFactory.getLogger(
      DataSourceBeanPostProcessorConfiguration.class);

  @Autowired
  private AlwaysEncryptedProperties alwaysEncryptedProperties;

  @Override
  public Object postProcessBeforeInitialization(@NotNull final Object bean,
      @NotNull final String beanName) throws BeansException {
    return bean;
  }

  @Override
  public Object postProcessAfterInitialization(@NotNull final Object bean,
      @NotNull final String beanName) throws BeansException {
    if (bean instanceof DataSource) {
      logger.info("Configuring Always Encrypted_test");
      try {
        if (alwaysEncryptedProperties.getColumnEncryptionSetting()) {
          SQLServerColumnEncryptionAzureKeyVaultProvider akvProvider;
          switch (alwaysEncryptedProperties.getType()) {
            case MANAGED_IDENTITY:
              akvProvider =
                  managedIdentity(alwaysEncryptedProperties.getClientId());
              break;
            case SERVICE_PRINCIPAL:
              akvProvider = servicePrincipal(alwaysEncryptedProperties.getClientId(),
                  alwaysEncryptedProperties.getClientSecret());
              break;
            default:
              return bean;
          }

          Map<String, SQLServerColumnEncryptionKeyStoreProvider> keyStoreMap = new HashMap<>();
          keyStoreMap.put(akvProvider.getName(), akvProvider);
          SQLServerConnection.registerColumnEncryptionKeyStoreProviders(keyStoreMap);
        }
      } catch (SQLException ex) {
        logger.error(ex.getMessage());
        throw new FatalBeanException(ex.getMessage());
      }
    }
    return bean;
  }

  private SQLServerColumnEncryptionAzureKeyVaultProvider servicePrincipal(String clientId,
      String clientSecret) throws SQLServerException {
    if (clientId == null
        || clientId.isEmpty()
        || clientSecret == null
        || clientSecret.isEmpty()) {
      throw new FatalBeanException("AlwaysEncrypted feature requires Service "
          + "Principal that has access to Vault - setup clientId and ClientSecret");
    }
    return
        new SQLServerColumnEncryptionAzureKeyVaultProvider(clientId, clientSecret);
  }

  private SQLServerColumnEncryptionAzureKeyVaultProvider managedIdentity(String clientId)
      throws SQLServerException {
    ManagedIdentityCredentialBuilder builder =
        new ManagedIdentityCredentialBuilder();
    Optional.ofNullable(clientId)
        .map(String::trim)
        .ifPresent(builder::clientId);
    return new SQLServerColumnEncryptionAzureKeyVaultProvider(builder.build());
  }
}