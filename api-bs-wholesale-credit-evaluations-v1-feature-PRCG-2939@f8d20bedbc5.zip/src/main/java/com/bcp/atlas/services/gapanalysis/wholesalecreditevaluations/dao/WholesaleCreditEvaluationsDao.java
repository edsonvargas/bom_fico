package com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.dao;

import com.bcp.atlas.services.gapanalysis.alexandria.model.thirdparty.CustomerGetResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.PricingWholesaleResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluation.model.api.Request;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.dto.TokenAppcodeDto;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CommonTransferRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.CreditInfoCpResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.ExchangeRate;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.entity.SpreadComercialAndBlackList;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.dm.DmResponse;
import com.bcp.atlas.services.gapanalysis.wholesalecreditevaluations.model.thirdparty.fico.mlx.MlxResponse;
import io.reactivex.Observable;
import java.util.List;
import retrofit2.Response;

/**
 * <br/>
 * Clase service que contiene los metodos necesarios para tramitar la data y logica de negocio que
 * consumira la clase REST LoanRateController<br/>
 * <b>Class</b>: LoanRateServiceImpl<br/>
 * Copyright: &copy; 2021 Banco de Cr&eacute;dito del Per&uacute;.<br/>
 * Company: Banco de Cr&eacute;dito del Per&uacute;.<br/>
 *
 * @author Banco de Cr&eacute;dito del Per&uacute; (BCP) <br/>
 *         <u>Service Provider</u>: BCP <br/>
 *         <u>Developed by</u>: <br/>
 *         <ul>
 *         <li>Christian Garcia</li>
 *         </ul>
 *         <u>Changes</u>:<br/>
 *         <ul>
 *         <li>Dec 13, 2021 Creaci&oacute;n de Clase.</li>
 *         </ul>
 * @version 1.0
 */


public interface WholesaleCreditEvaluationsDao {

  Observable<PricingWholesaleResponse> wholeInfo(
      Request request,
      TokenAppcodeDto tokenAppcodeDto,
      CustomerGetResponse customerGetResponse,
      CustomerGetResponse guarantorGetResponse,
      Observable<CommonTransferRate> commonTransferRatesObservable,
      SpreadComercialAndBlackList spreadComercialAndBlackList,
      ExchangeRate exchangeRate);

  Observable<PricingWholesaleResponse> mlxFirst(
      Request request,
      CustomerGetResponse customerGetResponse,
      CustomerGetResponse guarantorGetResponse,
      TokenAppcodeDto tokenAppCode,
      Observable<CommonTransferRate> commonTransferRatesObservable,
      SpreadComercialAndBlackList spreadComercialAndBlackList,
      ExchangeRate exchangeRate);

  Observable<PricingWholesaleResponse> dmResponse(
      MlxResponse mlx,
      Request request,
      CustomerGetResponse alexandriaResponse1,
      TokenAppcodeDto tokenAppCode,
      SpreadComercialAndBlackList spreadComercialAndBlackList);

  Observable<PricingWholesaleResponse> getResponseFinal(
      PricingWholesaleResponse response, CreditInfoCpResponse infoCpResponse);

  Observable<PricingWholesaleResponse> saveData(
      Request request, Response<DmResponse> dmResponse,CustomerGetResponse alexandriaResponse);
}
