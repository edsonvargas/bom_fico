
class ClvMayoristaWrapper(object):

    def __homologateInputs(self, df_input):  # -> pd.DataFrame:

        equivalent = {            
            'moneda':'codmoneda',
            'plazo': 'numvencimiento',
            'tipocambio':'tipo_cambio',
            'importe': 'mtoimporte',
            'tipooperacion':'tipo_operacion',
            'RT_D_D_SBS':'rt_deudirref_deudirtot_sbs',
            'MFA':'pctmargenfinancieroactivo',
            'CTDMAXAT_MED_18':'ctdmaxatrcond_med_18',
            'MAXANT':'maxantiguedad',
            'numletras':'num_letras'
        }

        df = df_input.rename(columns=equivalent)

        df.loc[df.codmoneda=='PEN','codmoneda']='0001'
        df.loc[df.codmoneda=='USD','codmoneda']='1001'
        #diferenciar solo para CFZ
        if len(df[df['codproducto'].str.startswith('CFZ')])>0:
            df['numvencimiento'] = df['numvencimiento'] + 15
            df['tipcalculadora'] = 'F'

        df.loc[df.TIPBANCA=='P','TIPBANCA']='N'
        
        D_CODUNICOCLI = df['CODUNICOCLI'][0]
        
        df.columns = df.columns.str.lower()
        
        #columns=['codmoneda','codproducto','tiplimitegar','mtocomercial','mtoafectacion','mtorealizacion','codunicocli','tipgarantia']
        columns=['codproducto','codmoneda','mtominutil','tiplimitegar','codunicocli','tipgarantia']
        
        data_g_c = df.filter(regex='gar_[a-z]+\d+').values[0].tolist()
        data_g_lc = df.filter(regex='garlc_[a-z]+\d+').values[0].tolist()
        data_g_n = df.filter(regex='garn_[a-z]+\d+').values[0].tolist()

        data_g_c_final = [ data_g_c[x:x+4]+[D_CODUNICOCLI]+["C"] for x in range(0, len(data_g_c), 4) if data_g_c[x+2] > 0  ]
        data_g_lc_final = [ data_g_lc[x:x+4]+[D_CODUNICOCLI]+["L"] for x in range(0, len(data_g_lc), 4) if data_g_lc[x+2] > 0]
        data_g_n_final = [ data_g_n[x:x+4]+[D_CODUNICOCLI]+["N"] for x in range(0, len(data_g_n), 4) if data_g_n[x+2] > 0]

        data_g_final = data_g_c_final + data_g_lc_final + data_g_n_final

        #tt_posicion = "TT"+str(df_input['plazo'].values[0])
        #tt = df_input.loc[:, tt_posicion]
        tt = df_input.loc[:, 'TT1']
        return df, data_g_final, columns, tt

    def __chooseImpl(self, df_input, df_g, tt):
        
        from source.clv_mayorista.engine import engine as pricing
        engine = pricing.CLVEngine()
        engine.transform(df_input, df_g)
        engine.predict()
        engine.compute_min_rate(tt)
        clv_result = engine.get_rate_components()         

        return clv_result

    def __format_result(self, clv_result):
        
        column_type = {
            'co': float,
            'pe': float,
            'tt': float,
            'rk': float
        }
        
        clv_result = clv_result.astype(column_type)
        
        return clv_result

    # Main prediction function
    def predict(self, X, feature_names):
        
        from logging import error
        import datetime

        
        from pandas import DataFrame
        """ 
        # X: prediction data
        # feature_names: column names
        """

        df_input = DataFrame(data=X, columns=feature_names)

        request_id = df_input['channelRequestId'].astype(str).str.cat(sep=',')

        error("[INFO: BCP-PRICING v2023.01.04] - mayorista clv Start request_ids:[{requestsid}]: {start_clv}".
        
                format(start_clv=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
        
                        requestsid=request_id))
        

        df, df_g, df_columns,tt = self.__homologateInputs(df_input)
        df_clv_result = self.__chooseImpl(df, DataFrame(data=df_g,columns=df_columns),tt=tt)
        df_final = self.__format_result(df_clv_result)

        error("[INFO: BCP-PRICING v2023.01.04] - mayorista clv End request_ids:[{requestsid}]: {start_clv}".
        
                format(start_clv=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
        
                        requestsid=request_id))

        return df_final
