# Libraries

import warnings

from numpy import (arange, array, clip, concatenate, count_nonzero, cumprod,
                   cumsum, diff, divide, empty_like, inf, isnan, max, maximum,
                   minimum, multiply, nansum, ones, ones_like, power, stack,
                   sum, zeros_like, select, argmax, indices, roll)
from pandas import DataFrame
# import modin.pandas as pd

warnings.filterwarnings("ignore")
# float_formatter = "{:.4f}".format
# set_printoptions(formatter={'float_kind':float_formatter})

# Functions

#Se usa?
def get_delta_entidades(self, product_code_final, X):
    """ 
    Returns: 
    >>> Pandas DataFrame with delta entidades
    """
    conditions = [('product_code_final' == 1)]
    choices = ["No aplica"]
    X['Deltaentidades'] = select(conditions, choices, default=X['DeltaEntidades'])

    return Deltaentidades

#Se usa?
def get_tipo_cliente(self, X):
    """ 
    Returns: 
    >>> Pandas DataFrame with type of client
    """

    conditions = [(X['FlgComportamientoPersona'] == 0)]
    choices = ["No Cliente"]
    X['Tipo de cliente'] = select(conditions, choices, default="Cliente")

    return tipo_cliente


def Bfactor2(rate, T, Tmax=145):
    rate = rate.reshape(1, -1)
    # Input validation
    _, m = rate.shape
    _, m1 = T.shape
    assert (m == m1), "rate and T should be of the same shape"
    T_m = max(T)
    if Tmax < T_m:
        Tmax = T_m
    # Building inputs
    # t = repeat(arange(1, Tmax+1).reshape(-1, 1), m, axis=1)
    t = arange(1, Tmax + 1).reshape(-1, 1)
    # r = repeat(rate, Tmax, axis=0)
    r = rate
    # T = repeat(T, Tmax, axis=0)
    # Vectorized computation
    arr = (power(1 + r, T) - power(1 + r, t - 1)) / \
        (power(1 + r, T) - 1)
    return maximum(arr, 0)


def Afactor1(rate, T, Tmax=145):
    t = arange(1, Tmax + 1).reshape(-1, 1)
    Den = power(1 + rate, T-t+1) - 1
    Af = divide(rate , Den, out=ones_like(Den), where=(Den!=0))
    Af[(Af==inf)|(isnan(Af))]=0
    return maximum(Af, 0)


def Bf1(t, r, T):
    return ((1 + r)**T - (1 + r)**(t - 1)) / ((1 + r)**T - 1)


def Bfactor1(r, T, Tmax=144):
    t = arange(1, Tmax + 1).reshape(-1, 1)  # shape (T, 1)
    Bf = maximum(array([Bf1(time, rate, Tm)
                              for time in t for rate in r for Tm in T]), 0)
    return Bf


def shift(arr, num, fill_value=0):
    """
    Shifts a numpy array of shape (T, m) num times filling fill_values to the missing slots

    Parameters
    ----------
    arr : array_like of shape = (T, m)
        a numpy array containing T observations for m samples
    num : scalar indicating the number of lags (if positive) or leads (if negative) to shift the numpy array verticaly

    fill_value: scalar indicating shift numpy array {1}

    Returns
    -------
    arr : array_like of shape = (T, m)
        a numpy array containing shifted T observations for m samples

    Examples
    -------
    random.seed(42)
    test_array = random.randn(3, 5)
    test_array
    shift(test_array, 2)

    Returns

    array( [[ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ],
            [ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ],
            [ 0.49671415, -0.1382643 ,  0.64768854,  1.52302986, -0.23415337]])


    shift(test_array, 1)

    Returns
    array([[ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ],
       [ 0.49671415, -0.1382643 ,  0.64768854,  1.52302986, -0.23415337],
       [-0.23413696,  1.57921282,  0.76743473, -0.46947439,  0.54256004]])

    shift(test_array,-1)

    Returns
    array([[-0.23413696,  1.57921282,  0.76743473, -0.46947439,  0.54256004],
       [-0.46341769, -0.46572975,  0.24196227, -1.91328024, -1.72491783],
       [ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ]])

    """
    result = empty_like(arr)
    if num > 0:
        result[:num] = fill_value
        result[num:] = arr[:-num]
    elif num < 0:
        result[num:] = fill_value
        result[:num] = arr[-num:]
    else:
        result[:] = arr
    return result


def cif_to_cond_prob(cif1, cif2, s1=1, s2=1):
    """
    Converts two CIFs (Cumulative Incidence Functions) to conditional probabilities of death.
    T is the number of periods, m is the number of samples.

    Parameters
    ----------
    cif1 : array_like of shape = (T, m)
        a numpy array containing event 1 CIF curve in each column.
    cif2 : array_like of shape = (T, m)
        a numpy array containing event 1 CIF curve in each column.
    s1: scalar indicating shift of cif1 curves {1}
    s2: scalar indicating shift of cif1 curves {1}

    Returns
    -------
    (conditional_prob_1, conditional_prob_2)
        2-tuple containing one numpy array in each element.
        conditional_prob_1 contains pd curves for the first CIF
        conditional_prob_2 contains pd curves for the first CIF

    Example
    -------
    cif_PD = cumsum(random.uniform(0, high=1, size=(10, 5)), axis=0)/10
    cif_CAN = cumsum(random.uniform(0, high=1, size=(10, 5)), axis=0)/10
    PD , CAN = cif_to_cond_prob(cif_PD, cif_CAN, s1=1, s2=3)
    """
    cif1_shifted = shift(cif1, s1)
    # cif2_shifted = shift(cif2, s2)
    # den = (1-cif1_shifted-cif2_shifted)   # Descomentar esta linea si el clv
    # se corrige l modelo estandar
    # Comentar esta linea si el clv se corrige al modelo estandar
    den = (1 - cif1_shifted - cif2)
    # cond_prob2 = (cif2-cif2_shifted)/den  # Descomentar esta linea si el clv
    # se corrige l modelo estandar
    # cond_prob2 = 0  # Comentar esta linea si el clv se corrige al modelo estandar
    cond_prob1 = clip((cif1 - cif1_shifted) / den, 0, 1)

    return (cond_prob1, 0)


def compute_S(PD, CAN, PRE, Bf):
    """
    Computes Survival curve and laggs it one period S(t-1)

    Parameters
    ----------
    PD : array_like of shape = (T, m)
        a numpy array containing probability of default (conditional to survival in t-1). T periods in each rows (1...T) and m samples in each column (1 ...m).
    CAN : array_like of shape = (T, m)
        a numpy array containing probability of full prepayment (conditional to survival in t-1). T periods in each rows (1...T) and m samples in each column (1 ...m).
    PRE : array_like of shape = (T, m)
        a numpy array containing probability of prepayment (conditional to survival in t-1). T periods in each rows (1...T) and m samples in each column (1 ...m).
    Bf: array_like of shape = (T, m)
        a numpy array containing Bf factors. T periods in each rows (1...T) and m samples in each column (1 ...m). Row 1 contains only 1"s

    Returns
    -------
    S_(t-1)
       numpy array in each element (T rows and m columns)

    Example
    -------


    """
    # Pseudo survival function
    Stilde = cumprod((1 - PD) * (1 - CAN), axis=0)
    Stilde_m1 = shift(Stilde, 1, 1)

    # Prepayment survival function
    PRE_m1 = maximum(shift(PRE, 1, 0), 0)
    Den = Stilde_m1 * Bf
    C = divide(PRE_m1 , Den, out=zeros_like(Den), where=(Den!=0))

    Cstar = cumsum(C, axis=0)
    PRE_bar = maximum(minimum(1 - Cstar, 1), 0)
    # Survival Function
    S = Stilde_m1 * PRE_bar
    return S


def pbroyden(
        func,
        x0=0.01,
        eps=0.00001,
        tol=0.00001,
        max_iter=30,
        verbose=True):
    """
    Pseudo Broyden Method: Algorithm to find roots for a multivariate function with multivariate outputs.

    Parameters
    ----------
    func : function (Rn to Rn) (If used to compute Economic Profit (at present value) usually inputs a vector of m samples of rates for initial values and outputs a m-vector of Economic profits)       

    x0 : array_like of shape (m,) that inputs initial guess for rates
    eps : step to vary arguments to optimize func
    tol : tolerance number for diference between 0 and the actual solution value output
    max_iter: maximun of iterations to use
    verbose: If set to true prints # of iterations

    Returns
    -------
    arr : array_like of shape = (m,) containing optimun solution (IRR if used to compute roots of Economic Profit)

    Examples
    -------

    1) Simulation of data
    random.seed(1)
    # Datos del producto
    m = 1_000 # Number of samples
    desembolsos = random.randint(10000, 11000, (1, m))  # shape (1, m)
    T = random.choice([12, 24, 36, 48, 60 ], m).reshape(1, -1) # shape (1, m)
    Tmax = max(T)
    descuentos = 0.19/12*ones((1, m)).reshape(1, -1)
    # Curvas del CLENTE para este producto
    cif_PD = cumsum(random.uniform(
        0, high=1, size=(Tmax, m)), axis=0)/Tmax/3  # shape (T, m)
    cif_CAN = cumsum(random.uniform(
        0, high=1, size=(Tmax, m)), axis=0)/Tmax/3 # shape (T, m)
    PRE = cumsum(random.uniform(0, high=1, size=(Tmax, m)),
                    axis=0)/Tmax/30 # shape (T, m)
    PD , CAN = cif_to_cond_prob(cif_PD, cif_CAN, s1=1, s2=1)

    2) defining function to optimize

    3) Solving for roots with Pseudo Broyden"s Algorithm
    r0 = random.uniform(0.2/12, .30/12, (1, m)).reshape(1, -1)   # shape (1, m)
    param = {"PD":PD, "CAN":CAN, "PRE":PRE}
    funct = lambda x: van(descuentos, desembolsos, x, T, param).reshape(m, )
    def test2():
        tmin = pbroyden(funct, r0.reshape(m, ))
        return tmin.reshape(m, )

    """
    iter_counter = 0
    error = 10
    xm = x0
    xp = xm + eps
    fem = func(xm)
    fep = func(xp)
    m = fem.shape[0]
    delta_error = 10
    solved = False
    solved_operations = 0
    counter_solved = 0
    mask_solved = array([False]*m).reshape(m,)
    mask_reshape_solved = array([False]*m).reshape(1, m)
    while ~( (error < tol) | (iter_counter > max_iter)| (delta_error < 0.0001) | ((counter_solved == 3) & (solved_operations > 0.5*m))):
        
        swap = abs(fem) > abs(fep)
        xmtemp = xm[0, swap]
        xm[0, swap] = xp[0, swap] 
        xp[0, swap] = xmtemp

        femtemp = fem[swap]
        fem[swap] = fep[swap] 
        fep[swap] = femtemp

        iter_counter += 1
        Den = (xp[~mask_reshape_solved] - xm[~mask_reshape_solved])
        fprime = divide((fep[~mask_solved] - fem[~mask_solved]), Den, out=ones_like(Den), where=(Den!=0))
        xp[~mask_reshape_solved] = xm[~mask_reshape_solved]
        fep[~mask_solved] = fem[~mask_solved]
        
        xm[~mask_reshape_solved] = xm[~mask_reshape_solved] - fem[~mask_solved] / fprime
        fem = func(xm) # xm[~mask_reshape_solved] + mask output function
        
        solved = (abs(fem) < tol)
        mask_solved[solved] = True
        mask_reshape_solved = mask_solved.reshape(1, m)

        error_prev = error
        error = nansum(abs(fem[~mask_solved]))
        delta_error = abs(error - error_prev)

        # q = [0, 0.01, 0.05, 0.25, 0.5, 0.95, 0.99, 1]
        # distrib = lambda x: nanquantile(x, q)
        # num_nan = count_nonzero(isnan(fem))
        solved_operations_prev = solved_operations
        solved_operations = count_nonzero(solved)
        if solved_operations == solved_operations_prev:
            counter_solved += 1 
        else:
            counter_solved = 0
         
        # print('________________________________________________ ')
        # print('iteration:', iter_counter) 
        # print('q:', q) 
        # print('# nans:', num_nan)
        # print('# solved_operations:', solved_operations)
        # print('Error:', error, 'Delta:', delta_error)
        # print('Van distrib:', distrib(fem))
        # print('x distrib:', distrib(xm))
        # print('fprime distrib:', distrib(fprime))

    # if (iter_counter > max_iter):
    #     print("Maximun of iterations reached")
    # elif verbose:
    #     print("Solution Found in {} iterations!".format(iter_counter))

    return xm


def get_tt_dscto_parameters_transform(X):
    """
    """

    desembolsos = X["MontoSolicitado"].values
    r = (power(1 + X["MontoTasaEspecial"].values, 1/12) - 1).reshape(1, -1)
    T = (X["CantidadPlazo"].values).reshape(1, -1)

    return desembolsos, r, T


def get_tt_dscto_parameters_predict(m, tt_dscto):
    """
    """

    dscto_anual = tt_dscto["Tasa_dscto"].values
    descuentos = ((1 + dscto_anual)**(1/12) - 1)*ones((1, m)).reshape(1, -1)

    dscto_anual_tea = tt_dscto["Tasa_dscto_tea"].values
    descuentos_tea = ((1 + dscto_anual_tea)**(1/12) - 1)*ones((1, m)).reshape(1, -1) 

    return descuentos, descuentos_tea


def get_pv_param(X_transformed, X_curves, T):

    # RemCap_yearly = X_transformed["TT_DSCTO"]["RemCap"].values[0]
    # RemCap_yearly = X_transformed["TT_DSCTO"]["RemCap"].values
    RemCap_yearly = array(X_transformed["TT_DSCTO"]["RemCap"].values.tolist())
    RemCap_monthly = power(1 + RemCap_yearly, 1/12) - 1

    tt_yearly = X_transformed["TT_DSCTO"]["TT"].values
    tt_monthly = power(1 + tt_yearly, 1/12) - 1
    tt = tt_monthly.reshape(1, -1)

    # ROA OBjetivo
    # roa_obj = X_curves['TT_DSCTO']['Tasa_dscto_tea']

    # Curves
    cif_PD = concatenate(X_curves["PD"].values.tolist()).T  # Matrix of cumulative PDs (shape T,m)
    cif_CAN = concatenate(X_curves["CAN"].values.tolist()).T  # Matrix of cumulative CANs (shape T,m)
    PRE = concatenate(X_curves["PRE"].values.tolist()).T  # Matrix of cumulative PREs (shape T,m)

    cif_CAN_shifted2 = shift(cif_CAN, 2)
    curva_aux = cif_PD + cif_CAN_shifted2
    b1 = curva_aux > 1
    mask_value_position = argmax(b1, axis=0)  # Si no se cumple, argmax da cero
    b_mask = mask_value_position<=0
    mask_value_position = b_mask*143 + (1 - b_mask)*mask_value_position
    rows = indices((curva_aux.shape[0], curva_aux.shape[1]))[0]
    mask_value = sum((rows==mask_value_position)*cif_PD, axis=0).reshape(1,-1)  # Cap en base al T en el que PD + CAN > 1
    cif_PD = (rows<mask_value_position)*cif_PD + (rows>=mask_value_position)*mask_value
    # plazo > t
    mask_valueT = sum((rows==T-1)*cif_PD, axis=0).reshape(1,-1)
    cif_PD = (rows<T)*cif_PD + (rows>=T)*mask_valueT

    # Limite a la curva de Cancelaciones
    cif_CAN_shifted = roll(cif_CAN, shift=1, axis=0)
    cif_CAN_shifted[0,:] = 0
    curva_aux_can = cif_PD + cif_CAN_shifted
    b1 = curva_aux_can > 1
    mask_value_position = argmax(b1, axis=0) - 1  # Si no se cumple, argamax da cero y esta fila da -1
    b_mask = mask_value_position <= 0
    mask_value_position = b_mask*143 + (1-b_mask)*mask_value_position  # Reemplazando los cero y -1 por 143
    mask_value = sum((rows==mask_value_position)*cif_CAN, axis=0).reshape(1, -1)  # Cap en base al T en el que PD + CAN > 1
    cif_CAN = (rows<mask_value_position)*cif_CAN + (rows>=mask_value_position)*mask_value

    PD , _ = cif_to_cond_prob(shift(cif_PD, -2), shift(cif_CAN, 1), 1 , 1)  # comentar si clv se corrige a modelo estandar
    CAN , _ = cif_to_cond_prob(shift(cif_CAN, 0), shift(cif_PD, -2), 1, 1)  # comentar si clv se corrige a modelo estandar
    # PD , CAN = cif_to_cond_prob(cif_CAN, cif_PD, 1, 1)  # descomentar si clv se corrige al modelo estandar. todo se calculara en un solo paso
    # PRE = cum_PRE - shift(cum_PRE, 1)
    cum_PRE = cumsum(PRE, axis=0)
    
    LGD = concatenate(X_curves["LGD"].values.tolist()).T
    ECf = concatenate(X_curves["CAP"].values.tolist()).T
    RR1 = concatenate(X_curves["RR1"].values.tolist()).T
    RR2 = concatenate(X_curves["RR2"].values.tolist()).T


    COSTOS_T0, COSTOS_VIDA = X_transformed["COST"]
    COSTOS_T0 = COSTOS_T0.T
    COSTOS_VIDA = array(COSTOS_VIDA).T

    INOF = array(X_transformed["INOF"]).T

    prepagoRDM = X_transformed["TT_DSCTO"]["prepagoRDM"]
    tt_fact = X_transformed["TT_DSCTO"]["tt_fact"]

    param = {"PD": PD, "cif_PD": cif_PD, "CAN": CAN, "cif_CAN": cif_CAN, "PRE": PRE, "cum_PRE": cum_PRE, "RR1": RR1, "RR2": RR2, "COSTOS_VIDA": COSTOS_VIDA, 
        "COSTOS_T0": COSTOS_T0, "INOF": INOF, "tt": tt, "LGD": LGD, "ECf": ECf, "RemCap": RemCap_monthly, "IR": 0.295, "prepagoRDM": prepagoRDM,
        "tt_fact": tt_fact}

    return param


def pv_structure(descuentos, desembolsos, r, T, param, flag_monitoreo=False):

    PD, cif_PD = param["PD"], param["cif_PD"]
    CAN, cif_CAN = param["CAN"], param["cif_CAN"]
    PRE = param["PRE"]
    LGD = param["LGD"]
    ECf = param["ECf"]
    RemCap = param["RemCap"]
    tt = param["tt"]  # TT
    IR = param["IR"]

    r = r.reshape(1, -1)
    descuentos = descuentos.reshape(1, -1)
 
    # Bbar: Contractual Balance
    Bf = Bfactor2(r, T, Tmax=144)
    Bbar = multiply(Bf, desembolsos)

    # Sm1: Survival Curves
    # PD transformada
    Sm1 = compute_S(PD, CAN, PRE, Bf)

    # B: Behavioral Balance
    B = maximum(Sm1*Bbar, 0)

    if flag_monitoreo == False:

        ###########################################
        #### Actualizacion de la TT Zero Cupon ####
        ###########################################
    
        PrepagoRDM = stack(param["prepagoRDM"])
        tt_fact = stack(param["tt_fact"])

        # Survival Curve TT Zero Cupon
        Sm1_tt = cumprod(1 - PrepagoRDM, axis=1).T

        # Behavioral Balance TT Zero Cupon
        B_tt = maximum(Sm1_tt*Bbar, 0)

        # Factor de Descuento (TT)
        exponente = arange(0, 4321, 30).reshape(1, -1)
        fact_dscto = power(divide(1, 1 + divide(tt_fact, 365)), exponente).T  # (61,m)

        saldo_t_por_factor = B_tt*fact_dscto[:144,:]
        saldo_t_1_por_factor = B_tt*fact_dscto[1:,:]
        saldo_t_1_por_factor_360 = saldo_t_1_por_factor*(30/365)
    
        tt = divide(sum(saldo_t_por_factor, axis=0) - sum(saldo_t_1_por_factor, axis=0), sum(saldo_t_1_por_factor_360, axis=0))
        tt = tt/12  # TT ZC Actualizada

        ###########################################

    # Cronograma Banca
    B_m_D = B*(1 - PD)  # B_m_D: Balance minus Default (Saldo Inicial)
    A = multiply(Afactor1(r, T, Tmax=144), B_m_D)  # A: Amortizations
    P = minimum(multiply(PRE, B[0,:]), B_m_D)  # P: Prepayments
    D = PD*B  # D: Default

    # Ingresos Financieros usa el Cronograma de Banca
    I = B_m_D*r  # Interest

    C = CAN*(B_m_D - A) # C: Cancelations

    D_ef = shift(D, 2)
    B_ef_aux = B[0,:] - cumsum(D_ef + A + C + P, axis=0)
    B_ef = maximum(concatenate([B[0,:].reshape(1, -1), B_ef_aux[0:-1,:]], axis=0), 0)
    
    COF = -B_ef*tt  # COF: Cost Of Funds (Interest Outcome)
    EL = -LGD*D_ef  # EL: Expected Loss
    EC = B_ef*ECf.reshape(1,-1)  # EC: Economic Capital
    # RemEC = EC*RemCap  # RemEC: Remuneration to Economic Capital
    # RemEC = EC*RemCap.reshape(1,-1)  # RemEC: Remuneration to Economic Capital
    RemEC = EC*RemCap.T  # RemEC: Remuneration to Economic Capital

    EC_flow = -diff(EC, axis=0, append=0)
    EC_t_0 = -EC[0,:].reshape(1, -1)

    # Cuentas Habiles
    CH_t_2_T = maximum((1 - cif_PD - cif_CAN), 0) 
    CH = roll(CH_t_2_T, shift=1, axis=0)
    CH[0,:] = 1
    
    # Cuentas Habiles rezagado
    CH_m_1 = roll(CH, shift=1, axis=0)
    CH_m_1[0,:] = 0  

    # Roll-Rate 1 rezagado
    rr1 = param["RR1"]  # Curva Roll Rate (1-30)
    rr2 = param["RR2"]  # Curva Roll Rate (31-60)
    rr1_m_1 = roll(rr1, shift=1, axis=0)
    rr1_m_1[0,:] = 0  

    # Costos en t = 0
    costos_t_0 = -param["COSTOS_T0"]

    # Costos lifetime
    costos = param["COSTOS_VIDA"]

    # Costos cobranzas 1-30
    costos_rr1 = CH*costos[:,0]*rr1

    # Costos cobranzas 31-60
    costos_rr2 = CH_m_1*costos[:,1]*rr2*rr1_m_1

    # Costos Mantenimiento SBS
    B_f_1 = roll(B, shift=-1, axis=0)
    B_f_1[143,:] = 0
    costos_mant_sbs = B_m_D*costos[:,2]

    # Costos administrativos, operativos e indirectos
    CH_f_1 = roll(CH, shift=-1, axis=0)
    CH_f_1[143,:] = CH_t_2_T[143,:]
    costos_CH = CH_f_1*costos[:,3]  

    # Costos administrativos, operativos e indirectos (SALDO) # NEW
    B_f_1 = roll(B, shift=-1, axis=0)
    B_f_1[143,:] = 0
    costos_B = B_m_D*costos[:,4]

    costos_lifetime = -(costos_rr1 + costos_rr2 + costos_mant_sbs + costos_CH + costos_B)*(B_m_D>0) # NEW
    # costos_lifetime = -(costos_rr1 + costos_rr2 + costos_mant_sbs + costos_CH)*(B_m_D>0)
    
    # Ingresos no financieros (INOF)
    inof_portes_fact = param["INOF"][0].reshape(1, -1)  # portes
    inof_desgravamen_fact = param["INOF"][1].reshape(1, -1)  # desgravamen
    # inof_cobranza_fact = param["INOF"][2].reshape(1, -1)  # cobranza

    portes = CH_f_1*inof_portes_fact  # CuentasHabiles*factor
    seguro_desgravamen = B_m_D*inof_desgravamen_fact  # SaldoInicial*factor (B_m_D?)
    # cobranza = B_f_1*inof_cobranza_fact  # SaldoFinal*factor

    # inof = (portes + seguro_desgravamen + cobranza)*(B_m_D>0)
    inof = (portes + seguro_desgravamen)*(B_m_D>0)

    # Taxes
    tax_t_0 = -(costos_t_0)*IR
    tax_lifetime = -(I + COF + EL + RemEC + inof + costos_lifetime)*IR 

    # Computing the Cash Flow
    # CF = maximum((I + COF + EL + RemEC + EC_flow + inof + costos_lifetime + tax_lifetime)*(B_m_D>0)*(B>0), 0)
    CF = (I + COF + EL + RemEC + EC_flow + inof + costos_lifetime + tax_lifetime)*(B_m_D>0)*(B>0)

    # Computing the Net Present Value (NPV)
    Tmax = CF.shape[0]
    descuento_matrix = array([power(1/(1 + descuento), t)
                                 for descuento in descuentos for t in arange(1, Tmax + 1).reshape(-1, 1)])

    # Discounted Cash Flows for simple sum
    CF_discounted = multiply(descuento_matrix, CF)
    CF_t_0 = tax_t_0 + EC_t_0 + costos_t_0  # Cash Flow in t=0
    pv = sum(CF_discounted, axis=0).reshape(
        1, -1) + CF_t_0  # Net Present Value
        
    return pv

def roa_estimator(roa_target, desembolsos, r, T, param, flag_monitoreo=False):

    PD, cif_PD = param["PD"], param["cif_PD"]
    CAN, cif_CAN = param["CAN"], param["cif_CAN"]
    PRE = param["PRE"]
    LGD = param["LGD"]
    ECf = param["ECf"]
    RemCap = param["RemCap"]
    tt = param["tt"]  # TT
    IR = param["IR"]

    r = r.reshape(1, -1)
 
    # Bbar: Contractual Balance
    Bf = Bfactor2(r, T, Tmax=144)
    Bbar = multiply(Bf, desembolsos)

    # Sm1: Survival Curves
    # PD transformada
    Sm1 = compute_S(PD, CAN, PRE, Bf)

    # B: Behavioral Balance
    B = maximum(Sm1*Bbar, 0)

    if flag_monitoreo == False:

        ###########################################
        #### Actualizacion de la TT Zero Cupon ####
        ###########################################
    
        PrepagoRDM = stack(param["prepagoRDM"])
        tt_fact = stack(param["tt_fact"])

        # Survival Curve TT Zero Cupon
        Sm1_tt = cumprod(1 - PrepagoRDM, axis=1).T

        # Behavioral Balance TT Zero Cupon
        B_tt = maximum(Sm1_tt*Bbar, 0)

        # Factor de Descuento (TT)
        exponente = arange(0, 4321, 30).reshape(1, -1)
        fact_dscto = power(divide(1, 1 + divide(tt_fact, 365)), exponente).T  # (145, m)

        saldo_t_por_factor = B_tt * fact_dscto[:144,:]
        saldo_t_1_por_factor = B_tt * fact_dscto[1:,:]
        saldo_t_1_por_factor_360 = saldo_t_1_por_factor * (30 / 365)
    
        tt = divide(sum(saldo_t_por_factor, axis=0) - sum(saldo_t_1_por_factor, axis=0), sum(saldo_t_1_por_factor_360, axis=0))
        tt = tt / 12  # TT ZC Actualizada

        ###########################################

    # Cronograma Banca
    B_m_D = B*(1 - PD)  # B_m_D: Balance minus Default (Saldo Inicial)
    A = multiply(Afactor1(r, T, Tmax=144), B_m_D)  # A: Amortizations
    P = minimum(multiply(PRE, B[0,:]), B_m_D)  # P: Prepayments
    D = PD*B  # D: Default

    # Ingresos Financieros usa el Cronograma de Banca
    I = B_m_D*r  # Interest

    C = CAN*(B_m_D - A) # C: Cancelations

    D_ef = shift(D, 2)
    B_ef_aux = B[0,:] - cumsum(D_ef + A + C + P, axis=0)
    B_ef = maximum(concatenate([B[0,:].reshape(1, -1), B_ef_aux[0:-1,:]], axis=0), 0)
    
    COF = -B_ef*tt  # COF: Cost Of Funds (Interest Outcome)
    EL = -LGD*D_ef  # EL: Expected Loss
    EC = B_ef*ECf.reshape(1,-1)  # EC: Economic Capital
    # RemEC = EC*RemCap  # RemEC: Remuneration to Economic Capital
    # RemEC = EC*RemCap.reshape(1,-1)  # RemEC: Remuneration to Economic Capital
    RemEC = EC*RemCap.T  # RemEC: Remuneration to Economic Capital
    EC_flow = -diff(EC, axis=0, append=0)
    EC_t_0 = -EC[0,:].reshape(1, -1)

    # Cuentas Habiles
    CH_t_2_T = maximum((1 - cif_PD - cif_CAN), 0) 
    CH = roll(CH_t_2_T, shift=1, axis=0)
    CH[0,:] = 1
    
    # Cuentas Habiles rezagado
    CH_m_1 = roll(CH, shift=1, axis=0)
    CH_m_1[0,:] = 0  

    # Roll-Rate 1 rezagado
    rr1 = param["RR1"]  # Curva Roll Rate (1-30)
    rr2 = param["RR2"]  # Curva Roll Rate (31-60)
    rr1_m_1 = roll(rr1, shift=1, axis=0)
    rr1_m_1[0,:] = 0  

    # Costos en t = 0
    costos_t_0 = -param["COSTOS_T0"]

    # Costos lifetime
    costos = param["COSTOS_VIDA"]

    # Costos cobranzas 1-30
    costos_rr1 = CH*costos[:,0]*rr1

    # Costos cobranzas 31-60
    costos_rr2 = CH_m_1*costos[:,1]*rr2*rr1_m_1

    # Costos Mantenimiento SBS
    B_f_1 = roll(B, shift=-1, axis=0)
    B_f_1[143,:] = 0
    costos_mant_sbs = B_m_D*costos[:,2]

    # Costos administrativos, operativos e indirectos
    CH_f_1 = roll(CH, shift=-1, axis=0)
    CH_f_1[143,:] = CH_t_2_T[143,:]
    costos_CH = CH_f_1*costos[:,3]

    # Costos administrativos, operativos e indirectos (SALDO) # NEW
    B_f_1 = roll(B, shift=-1, axis=0)
    B_f_1[143,:] = 0
    costos_B = B_m_D*costos[:,4]

    costos_lifetime = -(costos_rr1 + costos_rr2 + costos_mant_sbs + costos_CH + costos_B)*(B_m_D>0) # NEW  
    # costos_lifetime = -(costos_rr1 + costos_rr2 + costos_mant_sbs + costos_CH)*(B_m_D>0)
    
    # Ingresos no financieros (INOF)
    inof_portes_fact = param["INOF"][0].reshape(1, -1)  # portes
    inof_desgravamen_fact = param["INOF"][1].reshape(1, -1)  # desgravamen
    # inof_cobranza_fact = param["INOF"][2].reshape(1, -1)  # cobranza

    portes = CH_f_1*inof_portes_fact  # CuentasHabiles*factor
    seguro_desgravamen = B_m_D*inof_desgravamen_fact  # SaldoInicial*factor (B_m_D?)
    # cobranza = B_f_1*inof_cobranza_fact  # SaldoFinal*factor

    # inof = (portes + seguro_desgravamen + cobranza)*(B_m_D>0)
    inof = (portes + seguro_desgravamen)*(B_m_D>0)

    # Taxes
    tax_t_0 = -(costos_t_0)*IR
    tax_lifetime = -(I + COF + EL + RemEC + inof + costos_lifetime)*IR 

    # Computing the Cash Flow
    # CF = maximum((I + COF + EL + RemEC + EC_flow + inof + costos_lifetime + tax_lifetime)*(B_m_D>0)*(B>0), 0)
    CF = (I + COF + EL + RemEC + EC_flow + inof + costos_lifetime + tax_lifetime)*(B_m_D>0)*(B>0)

    CF_t_0 = tax_t_0 + EC_t_0 + costos_t_0

    cf_final = sum(CF, axis=0).reshape(1, -1) + CF_t_0 
    saldo = sum(B, axis=0).reshape(1, -1)   
    roa = (divide(cf_final, saldo)*12).reshape(-1,)
        
    return roa - roa_target.reshape(-1,)


def get_participacion_cosecha_en_calendario(array_base, diff_meses):
    array_base = array_base.copy()
    diff_meses = diff_meses.copy()
    array_base = array_base.T

    pos = where(arange(array_base.shape[1]) >= diff_meses[:, newaxis])

    y_index = pos[0]
    x_index = pos[1] - repeat(diff_meses, array_base.shape[1]-abs(where(diff_meses>=0, diff_meses, 0)))
    mask_index = (x_index< array_base.shape[1])
    new_array = zeros_like(array_base)
    new_array[y_index[mask_index], x_index[mask_index]] = array_base[pos[0][mask_index], pos[1][mask_index]]
    return new_array.T


def get_components(discounts, loan_amount, r, T, param, dict_comp, flag_monitoreo=False, diff_meses=None):

    PD, cif_PD = param["PD"], param["cif_PD"]
    CAN, cif_CAN = param["CAN"], param["cif_CAN"]
    PRE, cum_PRE = param["PRE"], param["cum_PRE"]
    LGD = param["LGD"]
    ECf = param["ECf"]
    RemCap = param["RemCap"]
    tt = param["tt"] # TT
    IR = param["IR"]

    r = r.reshape(1, -1)
    discounts = discounts.reshape(1, -1)
 
    # Bbar: Contractual Balance
    Bf = Bfactor2(r, T, Tmax=144)
    Bbar = multiply(Bf, loan_amount)

    # Sm1: Survival Curves
    # PD transformada
    Sm1 = compute_S(PD, CAN, PRE, Bf)

    # B: Behavioral Balance
    B = maximum(Sm1*Bbar, 0)
      
    if flag_monitoreo == False:

        ###########################################
        #### Actualizacion de la TT Zero Cupon ####
        ###########################################

        PrepagoRDM = stack(param["prepagoRDM"])
        tt_fact = stack(param["tt_fact"])

        # Survival Curve TT Zero Cupon
        Sm1_tt = cumprod(1 - PrepagoRDM, axis=1).T

        # Behavioral Balance TT Zero Cupon
        B_tt = maximum(Sm1_tt*Bbar, 0)

        # Factor de Descuento (TT)
        exponente = arange(0, 4321, 30).reshape(1, -1)
        fact_dscto = power(divide(1, 1 + divide(tt_fact, 365)), exponente).T  # (61,m)

        saldo_t_por_factor = B_tt*fact_dscto[:144,:]
        saldo_t_1_por_factor = B_tt*fact_dscto[1:,:]
        saldo_t_1_por_factor_360 = saldo_t_1_por_factor*(30/365)
    
        tt = divide(sum(saldo_t_por_factor, axis=0) - sum(saldo_t_1_por_factor, axis=0), sum(saldo_t_1_por_factor_360, axis=0))
        tt = tt/12  # TT ZC Actualizada

        ###########################################

    # Cronograma Banca
    B_m_D = B*(1-PD) # B_m_D: Balance before Default (Saldo Final)
    A = multiply(Afactor1(r, T, Tmax=144), B_m_D)  # A: Amortizations
    P = minimum(multiply(PRE, B[0,:]), B_m_D)  # P: Prepayments
    D = PD*B  # D: Default

    # Ingresos Financieros usa el Cronograma de Banca
    I = B_m_D*r  # Interest

    C = CAN*(B_m_D-A)  # C: Cancelations

    D_ef = shift(D, 2)
    B_ef_aux = B[0,:] - cumsum(D_ef + A + C + P, axis=0)
    B_ef = maximum(concatenate([B[0,:].reshape(1, -1), B_ef_aux[0:-1,:]], axis=0), 0)
    
    COF = -B_ef*tt  # COF: Cost Of Funds (Interest Outcome)
    EL = -LGD*D_ef  # EL: Expected Loss
    EC = B_ef*ECf.reshape(1,-1)  # EC: Economic Capital
    # RemEC = EC*RemCap  # RemEC: Remuneration to Economic Capital
    # RemEC = EC*RemCap.reshape(1,-1)  # RemEC: Remuneration to Economic Capital
    RemEC = EC*RemCap.T  # RemEC: Remuneration to Economic Capital
    EC_flow = -diff(EC, axis=0, append=0)
    EC_t_0 = -EC[0,:].reshape(1, -1)

    # Cuentas Habiles
    CH_t_2_T = maximum((1 - cif_PD - cif_CAN), 0) 
    CH = roll(CH_t_2_T, shift=1, axis=0)
    CH[0,:] = 1
    
    # Cuentas Habiles rezagado
    CH_m_1 = roll(CH, shift=1, axis=0)
    CH_m_1[0,:] = 0  

    # Roll-Rate 1 rezagado
    rr1 = param["RR1"]  # Curva Roll Rate (1-30)
    rr2 = param["RR2"]  # Curva Roll Rate (31-60)
    rr1_m_1 = roll(rr1, shift=1, axis=0)
    rr1_m_1[0,:] = 0  

    # Costos en t = 0
    costos_t_0 = -param["COSTOS_T0"]

    # Costos lifetime
    costos = param["COSTOS_VIDA"]
    
    # Costos cobranzas 1-30
    costos_rr1 = CH*costos[:,0]*rr1

    # Costos cobranzas 31-60
    costos_rr2 = CH_m_1*costos[:,1]*rr2*rr1_m_1

    # Costos Mantenimiento SBS
    B_f_1 = roll(B, shift=-1, axis=0)
    B_f_1[143,:] = 0
    costos_mant_sbs = B_f_1*costos[:,2]

    # Costos administrativos, operativos e indirectos
    CH_f_1 = roll(CH, shift=-1, axis=0)
    CH_f_1[143,:] = CH_t_2_T[143,:]
    costos_CH = CH_f_1*costos[:,3]  

    # Costos administrativos, operativos e indirectos (SALDO) # NEW
    B_f_1 = roll(B, shift=-1, axis=0)
    B_f_1[143,:] = 0
    costos_B = B_f_1*costos[:,4]   # B_m_D new, B_f_1 ex

    costos_lifetime = -(costos_rr1 + costos_rr2 + costos_mant_sbs + costos_CH + costos_B)*(B_m_D>0) # NEW
    # costos_lifetime = -(costos_rr1 + costos_rr2 + costos_mant_sbs + costos_CH)*(B_m_D>0)
    
    # Ingresos no financieros (INOF)
    inof_portes_fact = param["INOF"][0].reshape(1, -1)  # portes
    inof_desgravamen_fact = param["INOF"][1].reshape(1, -1)  # desgravamen
    # inof_cobranza_fact = param["INOF"][2].reshape(1, -1)  # cobranza

    portes = CH_f_1*inof_portes_fact  # CuentasHabiles*factor
    seguro_desgravamen = B_m_D*inof_desgravamen_fact  # SaldoInicial*factor (B_m_D?)
    # cobranza = B_f_1*inof_cobranza_fact  # SaldoFinal*factor

    # inof = (portes + seguro_desgravamen + cobranza)*(B_m_D>0)
    inof = (portes + seguro_desgravamen)*(B_m_D>0)

    # Taxes
    tax_t_0 = -(costos_t_0)*IR
    tax_lifetime = -(I + COF + EL + RemEC + inof + costos_lifetime)*IR 

    # Computing the Cash Flow
    # CF = maximum((I + COF + EL + RemEC + EC_flow + inof + costos_lifetime + tax_lifetime)*(B_m_D>0)*(B>0), 0)
    CF = (I + COF + EL + RemEC + EC_flow + inof + costos_lifetime + tax_lifetime)*(B_m_D>0)*(B>0)
    CF_t_0 = tax_t_0 + EC_t_0 + costos_t_0

    Tmax = CF.shape[0]
    discount_matrix = array([power(1/(1 + discount), t)
                            for discount in discounts for t in arange(1, Tmax + 1).reshape(-1, 1)])

    #################
    #### Reporte ####
    #################

    df = DataFrame(index=range(CF.shape[1]))

    if "NPV" in dict_comp:
        CF_discounted = multiply(discount_matrix, CF)
        pv = sum(CF_discounted, axis=0).reshape(1, -1) + CF_t_0  # Net Present Value
        df["NPV"] = pv.reshape(-1,)
    if "Net Profit" in dict_comp:
        suma_cf_aritmetico = sum(CF, axis=0).reshape(1, -1) + CF_t_0
        cf_aritmetico_prom_anual = divide(suma_cf_aritmetico, divide(T, 12))
        df["Net_Profit"] = cf_aritmetico_prom_anual.reshape(-1,)
    if "ROE" in dict_comp:
        suma_cf_aritmetico = sum(CF, axis=0).reshape(1, -1) + CF_t_0 
        suma_economic_capital_aritmetico = sum(EC, axis=0).reshape(1, -1) 
        roe = divide(suma_cf_aritmetico, suma_economic_capital_aritmetico)*12
        df["ROE"] = roe.reshape(-1,)
    if "ECAP" in dict_comp:
        df["ECAP"] = divide(sum(EC, axis=0), T).reshape(-1,)
    if "ROA" in dict_comp:
        cf_final = sum(CF, axis=0).reshape(1, -1) + CF_t_0 
        saldo = sum(B, axis=0).reshape(1, -1)   
        df["ROA"] = (divide(cf_final, saldo)*12).reshape(-1,)
    if "Avg Balance" in dict_comp:
        df["Avg_Balance"] = divide(sum(B, axis=0), T).reshape(-1,)
    if "Target IRR" in dict_comp:
        df["Target_IRR"] = (power(1 + discounts, 12) - 1).reshape(-1,)
    if "Loss" in dict_comp:
        df["Loss"] = sum(EL, axis=0).reshape(-1,)
    if "COF" in dict_comp:
        df["cof"] = sum(COF, axis=0).reshape(-1,)
    if "RemCap" in dict_comp:
        df["RemCap"] = sum(RemEC, axis=0).reshape(-1,)
    if "Interes" in dict_comp:
        df["Interes"] = sum(I, axis=0).reshape(-1,)
    if "inof" in dict_comp:
        df["inof"] = sum(inof, axis=0).reshape(-1,)
    if "Margen Neto" in dict_comp:
        margen_neto = sum(I + COF + EL + inof, axis=0)
        saldo = sum(B, axis=0)
        df["Spread_Neto"] = (divide(margen_neto, saldo)*12).reshape(-1,)
        df["Margen_Neto"] = margen_neto.reshape(-1,)
        df["RemEc"] = sum(RemEC, axis=0).reshape(-1,)
        df["RemCap"] = RemCap.reshape(-1,)
        # df[["RemCap" + str(x) for x in list(range(1, 13))]] = (repeat(RemCap[:, newaxis], 12, axis=1))
        # df[["RemCap" + str(x) for x in list(range(1, 13))]] = RemCap[:,:12]
    if "Margen Neto - 12M" in dict_comp:
        margen_neto_12m = (I + COF + EL + inof)[:12,:]
        df[["Margen_Neto_" + str(x) for x in list(range(1, 13))]] = margen_neto_12m.T
    if "Margen Neto - 24M" in dict_comp:
        # margen_neto_24m = (I + COF + inof)[:24,:]
        margen_neto_24m = (I + COF + inof)[:24,:]
        df[["Margen_Neto_" + str(x) for x in list(range(1, 25))]] = margen_neto_24m.T
    if "Interest Income" in dict_comp:
        df["Interest_Income"] = sum(I, axis=0).reshape(-1,)
    if "Cost of Funds" in dict_comp:
        df["Cost_of_Funds"] = sum(COF, axis=0).reshape(-1,)
    
    if "PD Curve" in dict_comp:
        PD_marg = cif_PD - shift(cif_PD, 1)
        # df[["PD" + str(x) for x in list(range(1, 145))]] = PD_marg.T
        # df[["PD" + str(x) for x in list(range(1, 145))]] = cif_PD.T
        df[["PD" + str(x) for x in list(range(1, 37))]] = PD_marg[:36,:].T
    if "LGD Curve" in dict_comp:
        # df[["LGD" + str(x) for x in list(range(1, 145))]] = LGD.T
        df[["LGD" + str(x) for x in list(range(1, 37))]] = LGD[:36,:].T
    if "PRE Curve" in dict_comp:
        PRE_marg = cum_PRE - shift(cum_PRE, 1)
        # df[["PRE" + str(x) for x in list(range(1, 145))]] = PRE_marg.T 
        df[["PRE" + str(x) for x in list(range(1, 37))]] = PRE_marg[:36,:].T 
    if "CAN Curve" in dict_comp:
        CAN_marg = cif_CAN - shift(cif_CAN, 1)
        # df[["CAN" + str(x) for x in list(range(1, 145))]] = CAN_marg.T
        df[["CAN" + str(x) for x in list(range(1, 37))]] = CAN_marg[:36,:].T
    if "Saldo Curve" in dict_comp:
        # df[["Saldo" + str(x) for x in list(range(1, 144))]] = B[1:].T
        df[["Saldo" + str(x) for x in list(range(1, 37))]] = B[:36,:].T
        # B_12 = get_participacion_cosecha_en_calendario(B, diff_meses)
        # df[["Saldo_Portafolio_" + str(x) for x in list(range(1, 13))]] = B_12[:12,:].T
    if "IF Curve" in dict_comp:
        # df[["IF" + str(x) for x in list(range(1, 145))]] = I.T
        df[["IF" + str(x) for x in list(range(1, 37))]] = I[:36,:].T
        # I_12 = get_participacion_cosecha_en_calendario(I, diff_meses)
        # df[["IF_Portafolio_" + str(x) for x in list(range(1, 13))]] = I_12[:12,:].T
    if "EF Curve" in dict_comp:
        # df[["EF" + str(x) for x in list(range(1, 145))]] = COF.T
        df[["EF" + str(x) for x in list(range(1, 37))]] = COF[:36,:].T
        # COF_12 = get_participacion_cosecha_en_calendario(COF, diff_meses)
        # df[["EF_Portafolio_" + str(x) for x in list(range(1, 13))]] = COF_12[:12,:].T
    if "EL Curve" in dict_comp:
        # df[["EL" + str(x) for x in list(range(1, 145))]] = EL.T
        df[["EL" + str(x) for x in list(range(1, 37))]] = EL[:36,:].T
        # EL_12 = get_participacion_cosecha_en_calendario(EL, diff_meses)
        # df[["EL_Portafolio_" + str(x) for x in list(range(1, 13))]] = EL_12[:12,:].T
    if "INOF Curve" in dict_comp:
        # df[["INOF" + str(x) for x in list(range(1, 145))]] = inof.T
        df[["INOF" + str(x) for x in list(range(1, 37))]] = inof[:36,:].T
        # inof_12 = get_participacion_cosecha_en_calendario(inof, diff_meses)
        # df[["INOF_Portafolio_" + str(x) for x in list(range(1, 13))]] = inof_12[:12,:].T
    if "RemEC Curve" in dict_comp:
        # df[["RemEC" + str(x) for x in list(range(1, 145))]] = inof.T
        df[["RemEC" + str(x) for x in list(range(1, 37))]] = RemEC[:36,:].T
        # RemEC_12 = get_participacion_cosecha_en_calendario(RemEC, diff_meses)
        # df[["RemEC_Portafolio_" + str(x) for x in list(range(1, 13))]] = RemEC_12[:12,:].T
    if "Costos Curve" in dict_comp:
        # df[["EL" + str(x) for x in list(range(1, 145))]] = inof.T
        df["COSTOS_0"] = costos_t_0.T
        df[["COSTOS_" + str(x) for x in list(range(1, 37))]] = costos_lifetime[:36,:].T

        # costos_lifetime_12 = get_participacion_cosecha_en_calendario(costos_lifetime, diff_meses)
        # df["Costos_Portafolio_0"] = (costos_t_0*(diff_meses <= 0).astype(int)).T
        # df[["Costos_Portafolio_" + str(x) for x in list(range(1, 13))]] = costos_lifetime_12[:12,:].T
    if "Taxes Curve" in dict_comp:
        # df[["EL" + str(x) for x in list(range(1, 145))]] = inof.T
        df["TAXES_0"] = tax_t_0.T
        df[["TAXES_" + str(x) for x in list(range(1, 37))]] = tax_lifetime[:36,:].T

        # taxes_lifetime_12 = get_participacion_cosecha_en_calendario(tax_lifetime, diff_meses)
        # df["Taxes_Portafolio_0"] = (tax_t_0*(diff_meses <= 0).astype(int)).T
        # df[["Taxes_Portafolio_" + str(x) for x in list(range(1, 13))]] = taxes_lifetime_12[:12,:].T     
    if "TT" in dict_comp:
        df["TT"] = (power(1 + tt, 12) - 1).reshape(-1,)
    if "COSTOS" in dict_comp:
        # df["Costos"] = (sum(costos_lifetime, axis=0).reshape(1,-1) + costos_t_0).reshape(-1,)
        # costs_discounted = multiply(discount_matrix, costos_lifetime)
        # df["VAN_Costos"] = (sum(costs_discounted, axis=0).reshape(1,-1) + costos_t_0).reshape(-1,)
        df["COSTOS_0"] = costos_t_0.T
        df[["COSTOS_" + str(x) for x in list(range(1, 145))]] = costos_lifetime.T
    if "INGRESOS" in dict_comp:
        # df["Ingresos"] = (sum(I+ RemEC + inof, axis=0).reshape(1,-1) + 0).reshape(-1,)
        # interests_discounted = multiply(discount_matrix, I + RemEC + inof)
        # df["VAN_Intereses"] = (sum(interests_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
        df[["INGRESOS_" + str(x) for x in list(range(1, 145))]] = (I+ RemEC + inof).T
    if "Componentes VAN Negativo" in dict_comp:  # VAN Total debe ser cero si se ingresa una tasa mínima
        cf_discounted = multiply(discount_matrix, CF)
        df["VAN_Total"] = (sum(cf_discounted, axis=0).reshape(1,-1) + costos_t_0 + tax_t_0 + EC_t_0).reshape(-1,)
        capital_discounted = multiply(discount_matrix, EC_flow)
        df["VAN_Capital"] = (sum(capital_discounted, axis=0).reshape(1,-1) + EC_t_0).reshape(-1,)
        tt_discounted = multiply(discount_matrix, COF)
        df["VAN_TT"] = (sum(tt_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
        loss_discounted = multiply(discount_matrix, EL)
        df["VAN_Perdida"] = (sum(loss_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
        costs_discounted = multiply(discount_matrix, costos_lifetime)
        df["VAN_Costos"] = (sum(costs_discounted, axis=0).reshape(1,-1) + costos_t_0).reshape(-1,)
        taxes_discounted = multiply(discount_matrix, tax_lifetime)
        df["VAN_IR"] = (sum(taxes_discounted, axis=0).reshape(1,-1) + tax_t_0).reshape(-1,)
    if "Componentes VAN Positivo" in dict_comp:
        interests_discounted = multiply(discount_matrix, I)
        df["VAN_Intereses"] = (sum(interests_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
        inof_discounted = multiply(discount_matrix, inof)
        df["VAN_INOF"] = (sum(inof_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
        rem_cap_discounted = multiply(discount_matrix, RemEC)
        df["VAN_RemCap"] = (sum(rem_cap_discounted, axis=0).reshape(1,-1) + 0).reshape(-1,)
    if "Costo venta" in dict_comp:
        df["Costo_t_0"] = costos_t_0.reshape(-1,)
    if "Costo lifetime" in dict_comp:
        df["Costo_lifetime"] = sum(costos_lifetime, axis=0).reshape(-1,)
    if "Costo lifetime promedio" in dict_comp:
        suma_costos_lifetime = sum(costos_lifetime, axis=0)
        df["Costo_lifetime_Promedio"] = divide(suma_costos_lifetime, divide(T, 12)).reshape(-1,)
    if "Ingreso no financiero promedio" in dict_comp:
        suma_ingreso_no_financiero = sum(inof, axis=0)
        df["Ingreso_No_Financiero_Promedio"] = divide(suma_ingreso_no_financiero, divide(T, 12)).reshape(-1,)
    if "Ingreso financiero promedio" in dict_comp:
        suma_ingreso_financiero = sum(I, axis=0)
        df["Ingreso_Financiero_Promedio"] = divide(suma_ingreso_financiero, divide(T, 12)).reshape(-1,)
    if "Egresos financieros promedio" in dict_comp:
        suma_egresos_financieros = sum(COF, axis=0)  # Cost of Funds
        df["Impuestos_Promedio"] = divide(suma_egresos_financieros, divide(T, 12)).reshape(-1,)
    if "Impuestos promedio" in dict_comp:
        suma_taxes = sum(tax_lifetime, axis=0)
        df["Impuestos_Promedio"] = divide(suma_taxes, divide(T, 12)).reshape(-1,)
    if "Utilidad Neta Discounted" in dict_comp:
        # Utilidad Neta replica lo que entra al GyP (no considera capital)
        I_discounted = multiply(discount_matrix, I)
        COF_discounted = multiply(discount_matrix, COF)
        EL_discounted = multiply(discount_matrix, EL)
        inof_discounted = multiply(discount_matrix, inof)
        costos_lifetime_discounted = multiply(discount_matrix, costos_lifetime)
        tax_lifetime_discounted = multiply(discount_matrix, tax_lifetime)
        ut_neta_discouneted = (sum(I_discounted + COF_discounted + EL_discounted + inof_discounted + costos_lifetime_discounted + tax_lifetime_discounted, axis=0).T + costos_t_0 + tax_t_0).reshape(-1,)
        df["ut_neta_discounted"] = ut_neta_discouneted
    if "GyP" in dict_comp:
        i_sum = sum(I * (B_m_D > 0), axis=0).reshape(1, -1)
        ef_sum = sum(COF * (B_m_D > 0), axis=0).reshape(1, -1)
        el_sum = sum(EL * (B_m_D > 0), axis=0).reshape(1, -1)
        remEC_sum = sum(RemEC * (B_m_D > 0), axis=0).reshape(1, -1)
        ixs_sum = sum(inof * (B_m_D > 0), axis=0).reshape(1, -1)
        gastos_sum = sum(costos_lifetime * (B_m_D > 0), axis=0).reshape(1, -1) + costos_t_0
        taxes_sum = sum(tax_lifetime * (B_m_D > 0), axis=0).reshape(1, -1) + tax_t_0
        saldo = sum(B, axis=0).reshape(1, -1) 
        df['SALDO'] = saldo.reshape(-1,)
        df['IF'] = i_sum.reshape(-1,)
        df['EF'] = ef_sum.reshape(-1,)
        df['EL'] = el_sum.reshape(-1,)
        df['GEB'] = remEC_sum.reshape(-1,)
        df['IxS'] = ixs_sum.reshape(-1,)
        df['GASTOS'] = gastos_sum.reshape(-1,)
        df['TAXES'] = taxes_sum.reshape(-1,)
    if "GyP Portafolio" in dict_comp:
        B_m_D_12 = get_participacion_cosecha_en_calendario(B_m_D, diff_meses)[:12,:]

        I_12 = get_participacion_cosecha_en_calendario(I, diff_meses)[:12,:]
        i_sum_new = sum(I_12 * (B_m_D_12 > 0), axis=0).reshape(1, -1)

        cof_12 = get_participacion_cosecha_en_calendario(COF, diff_meses)[:12,:]
        ef_sum_new = sum(cof_12 * (B_m_D_12 > 0), axis=0).reshape(1, -1)

        EL_12 = get_participacion_cosecha_en_calendario(EL, diff_meses)[:12,:]
        el_sum_new = sum(EL_12 * (B_m_D_12 > 0), axis=0).reshape(1, -1)

        RemEC_12 = get_participacion_cosecha_en_calendario(RemEC, diff_meses)[:12,:]
        remEC_sum_new = sum(RemEC_12 * (B_m_D_12 > 0), axis=0).reshape(1, -1)        

        inof_12 = get_participacion_cosecha_en_calendario(inof, diff_meses)[:12,:]
        ixs_sum_new = sum(inof_12 * (B_m_D_12 > 0), axis=0).reshape(1, -1)

        costos_lifetime_12 = get_participacion_cosecha_en_calendario(costos_lifetime, diff_meses)[:12,:]
        gastos_sum_new = sum(costos_lifetime_12 * (B_m_D_12 > 0), axis=0).reshape(1, -1) + costos_t_0*(diff_meses <= 0).astype(int)

        taxes_lifetime_12 = get_participacion_cosecha_en_calendario(tax_lifetime, diff_meses)[:12,:]
        taxes_sum_new = sum(taxes_lifetime_12 * (B_m_D_12 > 0), axis=0).reshape(1, -1) + tax_t_0*(diff_meses <= 0).astype(int)

        saldo_12 = get_participacion_cosecha_en_calendario(B, diff_meses)[:12,:]
        saldo_12_sum_new = sum(saldo_12, axis=0).reshape(1, -1) 
        
        df['SALDO_Portafolio'] = saldo_12_sum_new.reshape(-1,)
        df['IF_Portafolio'] = i_sum_new.reshape(-1,)
        df['EF_Portafolio'] = ef_sum_new.reshape(-1,)
        df['EL_Portafolio'] = el_sum_new.reshape(-1,)
        df['GEB_Portafolio'] = remEC_sum_new.reshape(-1,)
        df['IxS_Portafolio'] = ixs_sum_new.reshape(-1,)
        df['GASTOS_Portafolio'] = gastos_sum_new.reshape(-1,)
        df['TAXES_Portafolio'] = taxes_sum_new.reshape(-1,)
    if "Costitos" in dict_comp:
        costos_lifetime_saldo = -(costos_mant_sbs + costos_B)*(B_m_D>0) # NEW
        gastos_lifetime_sum_saldo = sum(costos_lifetime_saldo * (B_m_D > 0), axis=0).reshape(1, -1)
        costos_lifetime_unidades = -(costos_rr1 + costos_rr2 + costos_CH )*(B_m_D>0) # NEW
        gastos_lifetime_sum_unidades = sum(costos_lifetime_unidades * (B_m_D > 0), axis=0).reshape(1, -1) 
        df['COSTO_LIFETIME_SALDO'] = gastos_lifetime_sum_saldo.reshape(-1,)
        df['COSTO_LIFETIME_UNIDADES'] = gastos_lifetime_sum_unidades.reshape(-1,)
    return df
