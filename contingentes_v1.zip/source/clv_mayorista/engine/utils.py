from pandas import merge_asof, DataFrame
from numpy import clip, ceil, maximum, nan, minimum, select, vstack, repeat, tile, isnan, array
from math import erf, exp


################################################################################
########################### PROBABILIDAD DE DEFAULT ############################
################################################################################
    
def pd_transform(X):
    """
    Parameters
    ----------
    X: DataFrame
        The function expects minimally the following columns:
        "tipbanca", "tiprating", "numvencimiento", "pd_ttc_cp"
    Returns
    -------
    DataFrame
        The function returns following columns:
        "tipbanca", "tiprating", "maxdia", "pd_ttc"
    """
    X = X.copy()
    #Se renombran las columnas
    d = {
        "pd_ttc_cp": "pd_ttc"
    }
    X.rename(columns=d, inplace=True)
    #Se calcula el "maxdia"
    #X["numvencimiento"] = (X["numvencimiento"] + 15) if X["tipcalculadora"].values == 'F' else X["numvencimiento"]

    X["maxdia"] = (clip(ceil(X["numvencimiento"]/30)*30,
                           a_min=30,
                           a_max=360)).astype(int)
    #Se seleccionan las columnas para retornar
    columns = ["tipbanca", "tiprating", "maxdia", "pd_ttc", "codproducto","tipcalculadora"]

    return X[columns]

def pd_predict(X, param_pd_pit, param_producto):
    """
    PParameters
    ----------
    X: DataFrame
        The function expects minimally the following columns: 
        "tipbanca", "tiprating", "maxdia", "pd_ttc"
    param_pd: DataFrame
        The function expects minimally the following columns:
        "tipbanca", "tiprating", "maxdia", "pd_pit"
    Returns
    -------
    DataFrame
        The function returns following columns:
        "pd_pit", "pd_ttc"
    """
    X = X.copy()
    #Se asigna la PD PIT
    columns = ["tipbanca","tiprating","maxdia"]
    X = X.merge(param_pd_pit, how="left", on=columns)
    columns = ["codproducto"]
    X = X.merge(param_producto, how="left", on=columns)
    #Se seleccionan las columnas para retornar
    columns = ["pd_pit", "pd_ttc","pctccf","tipocobro","tipcalculadora"]

    return X[columns]

################################################################################
############################## LOSS GIVEN DEFAULT ##############################
################################################################################

def lgd_transform(X, X_g, param_ifrs, param_grupo):
    """
    Parameters
    ----------
    X: DataFrame
        The function expects minimally the following columns:
        TODO: Add column names
    X_g: DataFrame
        The function expects minimally the following columns:
        "codunicocli", "codmoneda", "codproducto",
        "mtocomercial", "mtoafectacion", "mtorealizacion"
    param_ifrs: DataFrame
        The function expects minimally the following columns:
            "codproducto", "tipoifrs"
    param_grupo: DataFrame
        The function expects minimally the following columns:
            "codproducto", "grupo"
    Returns
    -------
    DataFrame
        The function returns following columns:
        TODO: Add column names
    """
    X = X.copy()
    X_g = X_g.copy()
    #Se extrae el tipo de cambio al momento de la operación [NO MOVER]
    tipo_cambio = X.at[0, "tipo_cambio"]
    #Se renombran las columnas
    d = {
        "rt_deudirref_deudirtot_sbs": "ratio_ddr_ddt"
    }
    X.rename(columns=d, inplace=True)
    #Se asigna el tipo de cambio correcto para dolarizar
    mask = X["codmoneda"] == "1001"
    X.loc[mask, "tipo_cambio"] = 1
    #Se dolarizan las columnas "mtoimporte" y "mtorenovacion"
    X["mto_importe_dol"] = X["mtoimporte"].div(X["tipo_cambio"], axis=0)
    X["mto_renovacion_dol"] = X["mtorenovacion"].div(X["tipo_cambio"], axis=0)
    #Se pega el tipo de cambio al dataframe de garantía
    X_g["tipo_cambio"] = tipo_cambio
    #Se asigna el tipo de cambio correcto para dolarizar
    mask = X_g['codmoneda'] == "1001"
    X_g.loc[mask, "tipo_cambio"] = 1
    #Se dolarizan las columnas "mtocomercial", "mtoafectacion", "mtorealizacion"
    #columns = ["mtocomercial", "mtoafectacion", "mtorealizacion"]
    columns = ["mtominutil"]
    X_g[columns] = X_g[columns].div(X_g["tipo_cambio"], axis=0)
    #Se calcula el valor mínimo de cada garantía
    X_g['mto_cobertura_dol'] = X_g[columns].min(axis=1)
    #Se calculan las exposiciones para calcular la LGD TTC y la LGD PIT
        #LGD TTC
    X["mto_exposicion_ttc_dol"] = X["saldoccf_dol"] + X["mto_importe_dol"]
        #LGD PIT
    X["mto_exposicion_pit_inicial_dol"] = X["saldodol"]
    mask = X["tipo_operacion"] == "R"
    X.loc[mask, "mto_exposicion_pit_inicial_dol"] = maximum(
        X["saldodol"] - X["mto_renovacion_dol"], 0)
    X["mto_exposicion_pit_final_dol"] = (X["mto_exposicion_pit_inicial_dol"]
                                         + X["mto_importe_dol"])
    #Se seleccionan las columnas para la siguiente parte del proceso
    columns = [
        "codunicocli", "tipbanca", "mto_exposicion_ttc_dol",
        "mto_exposicion_pit_inicial_dol", "mto_exposicion_pit_final_dol",
        "ratio_ddr_ddt", "sow", "cantfinancieras",
        "ctdmaxatrcond_med_18", "maxantiguedad"
    ]
    X = X[columns]
    ############################ Transform LGD TTC #############################
    #Se asignan las garantías ya agrupadas por cada tipo IFRS
    temp_ttc = merge_garantias(X, X_g, param = param_ifrs,
                               key = "tipoifrs", ttc = True)
    X_tr = X.merge(temp_ttc, how = "left", on = "codunicocli")
    tipo_garantias = param_ifrs["tipoifrs"].unique()
    columns = ["mto_cobertura_dol_" + str(i) for i in tipo_garantias]
    X_tr["mto_cobertura_dol"] = X_tr[columns].sum(axis=1)
    ############################ Transform LGD PIT #############################
    #Se asignan las garantías ya agrupadas por cada grupo
    temp_pit = merge_garantias(X, X_g, param = param_grupo,
                               key = "grupo", ttc = False)
    X_tr = X_tr.merge(temp_pit, how = "left", on = "codunicocli")

    return X_tr

def lgd_predict(X, param_lgd_ttc, param_modelo_lgd_pit,
                param_modelo_cobertura, param_modelo_cascada):
    """
    Parameters
    ----------
    X: DataFrame
        The function expects minimally the following columns:
        TODO: Add column names
    param_lgd_ttc: DataFrame
        The function expects minimally the following columns:
        "tipoifrs", "minlgdttc", "maxlgdttc",
        "mincoberturattc", "maxcoberturattc"
    param_modelo_lgd_pit: DataFrame
        The function expects minimally the following columns:
        TODO: Add column names
    param_modelo_cobertura: DataFrame
        The function expects minimally the following columns:
        TODO: Add column names
    param_modelo_cascada: DataFrame
        The function expects minimally the following columns:
        "tipbanca", "lgd_GAL", "lgd_G1", "lgd_G2", "lgd_G3", "lgd_G4",
        "ratio_cob_max_GAL", "ratio_cob_max_G1", "ratio_cob_max_G2",
        "ratio_cob_max_G3", "ratio_cob_max_G4"
    Returns
    -------
    DataFrame
        The function returns following columns:
        "lgd_pit", "lgd_ttc"
    """
    ############################# Predict LGD TTC ##############################
    tipo_garantias = param_lgd_ttc["tipoifrs"]
    for i in tipo_garantias:
        #Se asignan los parámetros para cada tipo IFRS
        mask = param_lgd_ttc["tipoifrs"] == i
        columns = [
            "mincoberturattc", "maxcoberturattc",
            "minlgdttc", "maxlgdttc"
        ]
        c_min, c_max, lgd_min, lgd_max = ((param_lgd_ttc.loc[mask, columns])
                                          .squeeze())
        #Se hace asignaciones previas a la aplicación de reglas
        ratio_cobertura = X["ratio_cobertura_" + str(i)]
        column = "lgd_garantia_" + str(i)
        X[column] = nan
        #Se aplican las reglas
        if i == 4:
            #Regla Nº4
            X[column] = lgd_max
        else:
            #Regla Nº1
            mask = ratio_cobertura <= c_min
            X.loc[mask, column] = lgd_max
            #Regla Nº2
            mask = (ratio_cobertura > c_min) & (ratio_cobertura < c_max)
            X.loc[mask, column] = (lgd_max - (lgd_max - lgd_min)
                                   *ratio_cobertura[mask]/c_max)
            #Regla Nº3
            mask = ratio_cobertura >= c_max
            X.loc[mask, column] = lgd_min
    #Se multiplica el monto de cobertura por la LGD, para cada IFRS
    columns_1 = ["lgd_garantia_" + str(i) for i in tipo_garantias]
    columns_2 = ["mto_cobertura_dol_" + str(i) for i in tipo_garantias]
    numerator = (X[columns_1].values*X[columns_2].values).sum(axis=1)
    #Se divide el resultado entre el monto de cobertura total
    denominator = X["mto_cobertura_dol"]
    mask = X["mto_cobertura_dol"] > 0
    X["lgd_colateralizada"] = 0.45
    denominator.replace(to_replace = 0, value = 0.00000001, inplace=True)
    #denominator = 0.00000001 if denominator == 0 else denominator
    X.loc[mask, "lgd_colateralizada"] = (numerator/denominator)[mask]
    #Se calcula la LGD TTC
    X["lgd_ttc"] = (0.45 - (0.45
                            - X["lgd_colateralizada"])
                            *X["mto_cobertura_dol"]
                            /maximum(X["mto_exposicion_ttc_dol"],
                                        X["mto_cobertura_dol"]))
    
    ############################# Predict LGD PIT ##############################
    #Se calcula la LGD con las condiciones iniciales y finales
    lgdpit_inicial = predict_lgdpit(
        X, param_modelo_cobertura, param_modelo_lgd_pit,
        param_modelo_cascada, inicial=True)
    lgdpit_final = predict_lgdpit(
        X, param_modelo_cobertura, param_modelo_lgd_pit,
        param_modelo_cascada, inicial=False)
    #Se calcula el marginal entre a LGD PIT inicial y final
    exposicion_inicial = X["mto_exposicion_pit_inicial_dol"]
    exposicion_final = X["mto_exposicion_pit_final_dol"]
    lgdMarginal = exposicion_final - exposicion_inicial
    lgdMarginal.replace(to_replace=0, value=0.00000001, inplace=True)
    #lgdMarginal = 0.00000001 if lgdMarginal == 0 else lgdMarginal
    lgdpit = ((lgdpit_final*exposicion_final
              - lgdpit_inicial*exposicion_inicial)
              /(exposicion_final - exposicion_inicial))
    #Se calcula la LGD PIT
    lgdpit = minimum(lgdpit, (lgdpit + lgdpit_final)/2)
    lgdpit = maximum(lgdpit, 0.07) #TODO: Parametrizar
    X["lgd_pit"] = lgdpit

    #Se seleccionan las columnas para retornar
    columns = ["lgd_pit", "lgd_ttc"]

    return X[columns]

################################################################################
################################### CAPITAL ####################################
################################################################################

def capital_transform(X):
    """
    Parameters
    ----------
    X: DataFrame
        The function expects minimally the following columns:
        "tipo_cambio", "codmoneda", "mtoimporte", "saldoccf_dol",
        "bu", "subcategory", "tipbanca", "pctmargenfinancieroactivo",
        "pd_ttc_cp"
    Returns
    -------
    DataFrame
        The function returns following columns:
        "bu", "subcategory", "ead", "tipbanca",
        "pctmargenfinancieroactivo", "pd_ttc_cp"
    """
    X = X.copy()
    #Se extrae el tipo de cambio al momento de la operación [NO MOVER]
    tipo_cambio = X.at[0, "tipo_cambio"]
    #Se asigna el tipo de cambio correcto para solarizar
    mask = X["codmoneda"] == "0001"
    X.loc[mask, "tipo_cambio"] = 1
    #Se solariza el "mtoimporte"
    X["mto_importe_sol"] = X["mtoimporte"].multiply(X["tipo_cambio"], axis=0)
    #Se calcula la "ead" en soles [Exposure at Default]
    X["ead"] = X["saldoccf_dol"]*tipo_cambio + X["mto_importe_sol"]
    #Se seleccionan las columnas para retornar
    columns = [
        "bu", "subcategory", "ead", "tipbanca",
        "pctmargenfinancieroactivo", "pd_ttc_cp","tipcalculadora"
    ] 

    return X[columns]

def capital_predict(X, param_ecap, param_roe, param_mfa):
    """
    Parameters
    ----------
    X: DataFrame
        The function expects minimally the following columns:
        TODO: Add column names
    param_ecap: DataFrame
        The function expects minimally the following columns:
        TODO: Add column names
    param_roe: DataFrame
        The function expects minimally the following columns:
        TODO: Add column names
    param_mfa: DataFrame
        The function expects minimally the following columns:
        TODO: Add column names
    Returns
    -------
    DataFrame
        The function returns following columns:
        TODO: Add column names
    """
    X = X.copy()
    X.reset_index(inplace=True)
    #Se preprocessa param_ecap
    param_ecap = param_ecap.copy() 
    COLUMNS = [
        "pd", "lgd", "pd2", "lgd2", "ead1", "ead2",
        "ead1xpd", "ead2xpd", "ead1xlgd", "ead2xlgd", "pdxlgd"
    ]
    columns = ["b_" + column for column in COLUMNS]
    param_ecap.loc[:, columns].fillna(0, inplace=True)
    #param_ecap["tramo_max"].fillna(inf, inplace=True)
    
    ##################### Predict Economic Capital (ECAP) ######################
    #Se asiganan los parámetros del ECAP
    X.sort_values("ead", inplace=True)
    param_ecap.sort_values("tramo_min", inplace=True)
    columns = ["bu", "subcategory"]    
    X["ead"]=X["ead"].astype('float')
    X["bu"]=X["bu"].astype('int64')
    X["subcategory"]=X["subcategory"].astype('int64')
    X = merge_asof(X, param_ecap, left_on = "ead",
                      right_on = "tramo_min", by = columns)
    X.sort_values("index", inplace=True)
    X.reset_index(drop=True, inplace=True)
    #Se crea la variables necesarias para el cálculo
        #Variables base
    X["x_pd"] = minimum(X["pd_ttc_cp"], X["pd_max"]) 
    X["x_lgd"] = X["lgd_ttc"].copy()
        #Variables elevadas al cuadrado
    X["x_pd2"] = X["x_pd"]**2
    X["x_lgd2"] = X["x_lgd"]**2
        #Variablas dummy
    mask = (X["ead"] >= 10e6) & (X["ead"] < 56e6)   #TODO: parametrizar
    X["x_ead1"] = 0
    X.loc[mask, "x_ead1"] = 1
    mask = (X["ead"] >= 56e6)                       #TODO: parametrizar
    X["x_ead2"] = 0
    X.loc[mask, "x_ead2"] = 1
        #Interacciones entre variables
    X["x_ead1xpd"] = X["x_ead1"]*X["x_pd"]
    X["x_ead2xpd"] = X["x_ead2"]*X["x_pd"]
    X["x_ead1xlgd"] = X["x_ead1"]*X["x_lgd"]
    X["x_ead2xlgd"] = X["x_ead2"]*X["x_lgd"]
    X["x_pdxlgd"] = X["x_pd"]*X["x_lgd"]
    #Se multiplican las variables por los coeficientes [Beta*X+Intercepto]
    columns = [
        "pd", "lgd", "pd2", "lgd2", "ead1", "ead2",
        "ead1xpd", "ead2xpd", "ead1xlgd", "ead2xlgd", "pdxlgd"
        ]
    columns_1 = ["b_" + column for column in columns]
    columns_2 = ["x_" + column for column in columns]
    X["x_b"] = ((X[columns_1].values*X[columns_2].values).sum(axis=1)
                + X["intercept"])
    #Se calcula el ECAP
    condlist = [X["link"] == "probit", X["link"] == "logit"]
    X["x_b"] = X["x_b"].astype('float')
    # choicelist = [norm.cdf(X["x_b"]), logistic.cdf(X["x_b"])]
    choicelist = [norm_cdf(X["x_b"]), log_cdf(X["x_b"])]
    X["ecap"] = select(condlist, choicelist)*X["escalar_capital"]

    ##################### Predict Return on Equity (ROE) #######################
    #Se asignan los parámetros de ROE
    columns = ["tipbanca"]
    if(X["tipcalculadora"].values == 'F'):
        columns = ["tipbanca","tipcalculadora"]
    X = X.merge(param_roe, how="left", on=columns)
    #Se calcula el ROE
    X["factor_roe"] = X["rend_esperado"].copy()
    X["roe"] = X["factor_roe"]*X["coef_capital"]
    
    ################## Predict Margen Financiero Activo (MFA) ##################
    #Se asignan los parámetros de MFA
    X = X.merge(param_mfa, how="left", on="tipbanca")
    #Se calcula el MFA
    X["mfa"] = X["pctmargenfinancieroactivo"].copy()
    mask = X["pctmargenfinancieroactivo"] <= 0
    X.loc[mask, "mfa"] = X.loc[mask, "pct_margen_fin_act"]

    #Se seleccionan las columnas para retornar
    columns = ["ecap", "roe", "mfa"]

    return X[columns]

################################################################################
#################################### COSTOS ####################################
################################################################################

def costos_transform(X):
    """
    Parameters
    ----------
    X: DataFrame
        The function expects minimally the following columns:
        "tipbanca", "codproducto"
    Returns
    -------
    DataFrame
        The function returns following columns:
        "tipbanca", "codproducto"
    """    
    X = X.copy()
    X.replace({"num_letras": -1}, 1, inplace=True) # TODO: testear
    #Se seleccionan las columnas para retornar
    columns = ["tipbanca", "codproducto", "num_letras","tipofianza"]

    return X[columns]

def costos_predict(X, param_costos, param_costos_agrupacion,bn_param_costos):
    """
    Parameters
    ----------
    X: DataFrame
        The function expects minimally the following columns:
        "tipbanca", "codproducto"
    param_costos: DataFrame
        The function expects minimally the following columns:
        TODO: completar
    param_costos_agrupacion: DataFrame
        The function expects minimally the following columns:
        TODO: completar
    Returns
    -------
    DataFrame
        The function returns following columns:
        "fijo_mant", "fijo_vta", "variable_mant",
        "variable_vta", "piso", "techo"
    """    
    X = X.copy()
    #Se asignan los parámetros de costos
    columns = ["tipbanca","codproducto"]
    X = X.merge(param_costos_agrupacion, how = "left", on = columns)
    columns = ["tipbanca", "agrupacion","tipofianza"]
    X = X.merge(param_costos, how = "left", on = columns)

    #banca negocio
    columns = ["tipbanca", "agrupacion"] # no se repite?
    X = X.merge(bn_param_costos, how = "left", on = columns)
    
    #Se seleccionan las columnas para retornar
    columns = [
        "fijo_mant", "fijo_vta", "variable_mant", "variable_vta", "piso", 
        "techo", "num_letras","pctcostoventa","pctcostomant","impmin"
    ]

    return X[columns]

################################################################################
############################### HELPER FUNCTIONS ###############################
################################################################################

def merge_garantias(X, X_g, param, key, ttc=True):
    """
    Función que combina la información del cliente con la de las garantías
    """
    X = X.copy()
    X_g = X_g.copy()
    #Se asignan los parámetros
    X_g = X_g.merge(param, how="left", on="codproducto")
    #Se suman las garantías por cliente y tipo de garantía
    by = ["codunicocli", key]
    columns = ["mto_cobertura_dol"]
    X_g = (X_g.groupby(by=by)[columns].sum()).reset_index()
    #Se calculan los ratios de cobertura según corresponda
        #TTC
    if ttc==True:
        columns = ["codunicocli", "mto_exposicion_ttc_dol"]
        X_g = X_g.merge(X[columns], how = "left", on = "codunicocli")
        X_g["ratio_cobertura"] = (X_g["mto_cobertura_dol"]
                                  /X_g["mto_exposicion_ttc_dol"])
        columns = [
            "codunicocli", key, "mto_cobertura_dol", "ratio_cobertura"
        ]
        #PIT
    else:
        columns = [
            "codunicocli", "mto_exposicion_pit_inicial_dol",
            "mto_exposicion_pit_final_dol"
        ]
        X_g = X_g.merge(X[columns], how = "left", on = "codunicocli")
        X_g["ratio_cobertura_inicial"] = (X_g["mto_cobertura_dol"]
                                          /X_g["mto_exposicion_pit_inicial_dol"])
        X_g["ratio_cobertura_final"] = (X_g["mto_cobertura_dol"]
                                        /X_g["mto_exposicion_pit_final_dol"])
        columns = [
            "codunicocli", key, "ratio_cobertura_inicial",
            "ratio_cobertura_final"
            ]
    #Se seleccionan las columnas para retornar
    X_g = X_g[columns]
    #Se construye la maqueta para realizar el unstack
    tipo_garantias = param[key].unique()
    num_tipo_garantias = len(tipo_garantias)
    clientes = X["codunicocli"].unique() #TODO: ¿Puedo poner X_g en vez de X?
    num_clientes = len(clientes)
    data = vstack([repeat(clientes, num_tipo_garantias),
                      tile(tipo_garantias, num_clientes)]).T
    columns = ["codunicocli", key]
    X_tr = DataFrame(data = data, columns = columns)
    #Se coloca los montos y ratios de cobertura en la maqueta
    X_tr = X_tr.merge(X_g, how = "left")
    X_tr.fillna(0, inplace = True)
    #Se realiza en unstack
    X_tr.set_index(["codunicocli", key], inplace=True)
    X_tr = X_tr.unstack(key)
    X_tr.columns = X_tr.columns.map('{0[0]}_{0[1]}'.format)
    X_tr.reset_index(inplace = True)

    return X_tr

def predict_lgdpit(X, param_modelo_cobertura, param_modelo_lgd_pit,
                   param_modelo_cascada, inicial = True):
    """
    Función que calcula la lgd pit
    """
    nombre = 'inicial_' if inicial == True else 'final_'
    X = X.copy()
    #Se asignan los parámetros
    X = X.merge(param_modelo_cobertura, how="left", on="tipbanca")
    X = X.merge(param_modelo_lgd_pit, how="left", on="tipbanca")
    X = X.merge(param_modelo_cascada, how="left", on="tipbanca")

    ########################## Modelo de cobertura #############################
    grupos = ["BIB", "HIP", "MOB", "VAL"]
    #Se colocan las cotas superiores e inferiores a los ratios
    for grupo in grupos:
        column = "ratio_cobertura_" + nombre + grupo
        a_min = X["ratio_cob_min_" + grupo]
        a_max = X["ratio_cob_max_" + grupo]
        X[column] = clip(X[column], a_min=a_min, a_max=a_max)
        # X[column] = clip(X[column], a_min=a_min, a_max=a_max, axis=0)
    #Se multiplican las variables por los coeficientes [Beta*X+Intercepto]
    columns_1 = ["ratio_cobertura_" + nombre + grupo for grupo in grupos]
    columns_2 = ["b_" + grupo for grupo in grupos]
    X["cob_agrupada"] = ((X[columns_1].values*X[columns_2].values).sum(axis=1)
                         + X["intercept_cob"])
    
    ####################### Modelo de lgd recuperable ##########################
    columns = [
        "cob_agrupada", "ratio_ddr_ddt", "sow", "cantfinancieras",
        "ctdmaxatrcond_med_18", "maxantiguedad"
    ]
    #Se colocan las cotas superiores e inferiores a los ratios
    for column in columns:
        a_min = X["min_" + column]
        a_max = X["max_" + column]
        X[column] = clip(X[column], a_min=a_min, a_max=a_max)
        # X[column] = clip(X[column], a_min=a_min, a_max=a_max, axis=0)
    #Se multiplican las variables por los coeficientes [Beta*X+Intercepto]
    columns_1 = columns.copy()
    columns_2 = ["b_" + column for column in columns]
    lgd_recuperable = (((X[columns_1].values*X[columns_2].values).sum(axis=1)
                       + X["intercept_lgd"])*X["factor_lgd_pit"])

    ######################### Modelo de la cascada #############################
    #Parte Nº1: se calcula el monto no coberturado 
    grupos = ["HIP", "MOB", "VAL"]
    columns = ["ratio_cobertura_" + nombre + grupo for grupo in grupos]
    mto_no_coberturado_dol = X["mto_exposicion_pit_" + nombre + "dol"].copy()
    #Monto_no_coberturado se calcula como:
    #monto_no_coberturado - (%_de_recupero * %_de_cobertura * monto_exposicion)
    mto_no_coberturado_dol = (mto_no_coberturado_dol
                              - (1 - lgd_recuperable)
                              *X[columns].sum(axis=1)
                              *X["mto_exposicion_pit_" + nombre + "dol"])
    
    #Parte N12: se aplica el modedelo de cascada
    grupos = ["GAL", "G1", "G2", "G3", "G4"]    
    for grupo in grupos:
        column = "ratio_cobertura_" + nombre + grupo
        a_max = X["ratio_cob_max_" + grupo]
        X[column] = minimum(X[column], a_max)
        mto_no_coberturado_new_dol = (mto_no_coberturado_dol
                                      - (1 - X["lgd_" + grupo])
                                      *(X["ratio_cobertura_" + nombre  + grupo]
                                      *X["mto_exposicion_pit_"+nombre+"dol"]))
        a_min = 0.07  #TODO: Parametrizar
        if grupo == "GAL":
            lgd_pit = maximum(
                lgd_recuperable*(1 - X["ratio_cobertura_" + nombre + grupo])
                + X["lgd_" + grupo]*X["ratio_cobertura_" + nombre + grupo],
                a_min)
        else:
            lgd_pit = clip(
                mto_no_coberturado_new_dol/(mto_no_coberturado_dol+0.000000000001)*lgd_pit,
                a_min = a_min,
                a_max = lgd_pit)
        mto_no_coberturado_dol = mto_no_coberturado_new_dol.copy()
    #Se considera el caso de división entre 0
    #
    lgd_pit = lgd_pit.astype('float')
    mask = isnan(lgd_pit)
    lgd_pit[mask] = lgd_recuperable[mask]
    
    return lgd_pit

def norm_cdf(x):
    # print(sqrt(2.0))
    def cdf1(value):
        return (1.0 + erf(value / 1.4142135623730951)) / 2.0 # (1.0 + erf(value / sqrt(2.0))) / 2.0

    if len(x)==1:
        #'Cumulative distribution function for the standard normal distribution'
        return cdf1(x)
    else:
        return array([[cdf1(item)] for item in x])

def log_cdf(x):
    # print(sqrt(2.0))
    def cdf2(value):
        return (exp(value) / (1.0 + exp(value))) # (1.0 + erf(value / sqrt(2.0))) / 2.0

    if len(x)==1:
        #'Cumulative distribution function for the standard normal distribution'
        return cdf2(x)
    else:
        return array([[cdf2(item)] for item in x])

        